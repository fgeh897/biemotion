package
{
   import FgEH.PoseManager.WidgetRuntimeX.FgEHPoseDialogMain;
   import flash.display.Sprite;
   
   public class FgEHPoseWidget extends Sprite
   {
      
      public var widget:FgEHPoseDialogMain;
      
      public function FgEHPoseWidget()
      {
         super();
         this.widget = new FgEHPoseDialogMain();
         addChild(this.widget);
      }
   }
}

