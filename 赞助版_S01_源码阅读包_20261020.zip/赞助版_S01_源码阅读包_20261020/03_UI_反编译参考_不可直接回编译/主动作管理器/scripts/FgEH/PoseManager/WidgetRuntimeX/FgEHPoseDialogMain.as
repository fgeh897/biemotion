package FgEH.PoseManager.WidgetRuntimeX
{
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.display.Shape;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.FocusEvent;
   import flash.events.KeyboardEvent;
   import flash.events.MouseEvent;
   import flash.geom.Matrix;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFieldType;
   import flash.text.TextFormat;
   import flash.ui.Keyboard;
   import flash.utils.clearTimeout;
   import flash.utils.getDefinitionByName;
   import flash.utils.getTimer;
   import flash.utils.setTimeout;
   import gamedata.Dialog.UiDialogMessage;
   import olympus.controls.IconComponent;
   import olympus.core.UISettings;
   import olympus.core.widget.WidgetBase;
   import olympus.events.PushButtonEvent;
   import olympus.gamepad.EnterParams;
   import olympus.gamepad.NavManager;
   import olympus.input.IInputFocusable;
   import olympus.input.adapters.DynamicOmnidirectionalAdapter;
   import olympus.io.CommunicationManager;
   import olympus.utils.ImageUtils;
   import olympus.utils.SystemUtils;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol21")]
   public class FgEHPoseDialogMain extends WidgetBase implements IInputFocusable
   {
      
      private static const ITEMS_PER_PAGE:int = 12;
      
      private static const RESPONSE_ITEM_BASE:int = 100000;
      
      private static const RESPONSE_FAVORITE_BASE:int = 400000;
      
      private static const RESPONSE_BACK:int = 700000;
      
      private static const RESPONSE_MODE:int = 800000;
      
      private static const RESPONSE_PAGE_BASE:int = 900000;
      
      private static const RESPONSE_NAV_BASE:int = 810000;
      
      private static const RESPONSE_GROUP_MANAGE:int = 620000;
      
      private static const RESPONSE_GROUP_CREATE:int = 620001;
      
      private static const RESPONSE_GROUP_SMART_TWO:int = 620020;
      
      private static const RESPONSE_GROUP_SMART_THREE:int = 620021;
      
      private static const RESPONSE_GROUP_TAB_BASE:int = 620100;
      
      private static const RESPONSE_GROUP_EDIT_BASE:int = 621000;
      
      private static const RESPONSE_GROUP_DELETE_BASE:int = 622000;
      
      private static const RESPONSE_GROUP_RENAME_BASE:int = 625000;
      
      private static const RESPONSE_GROUP_SMART_PATTERN:int = 620030;
      
      private static const RESPONSE_GROUP_EDIT_DONE:int = 620031;
      
      private static const RESPONSE_GROUP_MEMBER_TOGGLE_BASE:int = 623000;
      
      private static const RESPONSE_GROUP_OUTER_TOGGLE_BASE:int = 626000;
      
      private static const RESPONSE_OUTER_GROUP_CREATE:int = 640001;
      
      private static const RESPONSE_OUTER_GROUP_DONE:int = 640002;
      
      private static const RESPONSE_OUTER_GROUP_SELECT_ALL:int = 640003;
      
      private static const RESPONSE_OUTER_GROUP_CLEAR:int = 640004;
      
      private static const RESPONSE_OUTER_GROUP_EDIT_BASE:int = 641000;
      
      private static const RESPONSE_OUTER_GROUP_DELETE_BASE:int = 642000;
      
      private static const RESPONSE_OUTER_GROUP_RENAME_BASE:int = 643000;
      
      private static const RESPONSE_ROOT_SORT_TOGGLE:int = 650000;
      
      private static const RESPONSE_FAV_PACK_VIEW_TOGGLE:int = 650001;
      
      private static const RESPONSE_FAV_POSE_VIEW_TOGGLE:int = 650002;
      
      private static const RESPONSE_LINKED_VIEW_TOGGLE:int = 650003;
      
      private static const RESPONSE_CREATOR_VIEW_TOGGLE:int = 650004;
      
      private static const RESPONSE_ROOT_SEARCH_APPLY:int = 650005;
      
      private static const RESPONSE_EDIT_INFO_REFRESH:int = 660999;
      
      private static const FAVORITE_ITEM_SEPARATOR:String = "<<<FGEH_FAV_ITEM>>>";
      
      private static const EXT_MAGIC:String = "FGEH_POSE_UI_EXT_V1";
      
      private static const MEMBER_EDIT_MAGIC:String = "FGEH_MEMBER_EDIT_V1";
      
      private static const OUTER_GROUP_MAGIC:String = "FGEH_OUTER_GROUPS_V1";
      
      private static const ROOT_TOOLS_MAGIC:String = "FGEH_ROOT_TOOLS_V1";
      
      private static const BATCH_FAVORITE_GROUPS_MAGIC:String = "FGEH_BATCH_FAVORITE_GROUPS_V1";
      
      private static const EDIT_INFO_MAGIC:String = "FGEH_EDIT_INFO_V1";
      
      private static const LINKED_DETAIL_MAGIC:String = "FGEH_LINKED_DETAIL_V1";
      
      private static const LINKED_PRODUCTS_MAGIC:String = "FGEH_LINKED_PRODUCTS_V1";
      
      private static const LINKED_PRODUCTS_V2_MAGIC:String = "FGEH_LINKED_PRODUCTS_V2";
      
      private static const LINKED_OBJECT_PRODUCTS_MAGIC:String = "FGEH_LINKED_OBJECT_PRODUCTS_V1";
      
      private static const LINKED_EDIT_MAGIC:String = "FGEH_LINKED_EDIT_V1";
      
      private static const GLOBAL_WIDGETS_MAGIC:String = "FGEH_GLOBAL_WIDGETS_V1";
      
      private static const LOCALIZATION_MAGIC:String = "FGEH_LOCALIZATION_V2";
      
      private static const PLUMBOB_THEME_GREEN:Object = {
         "onLight":13172614,
         "onMid":7527521,
         "onBase":4439889,
         "onDark":2330431,
         "onOutline":2326329,
         "offLight":14542815,
         "offMid":11122603,
         "offBase":8359553,
         "offDark":6713960,
         "offOutline":6713960,
         "slash":7306354
      };
      
      private static const PLUMBOB_THEME_PINK_BROWN:Object = {
         "onLight":16766691,
         "onMid":15837370,
         "onBase":13207183,
         "onDark":9986920,
         "onOutline":9132897,
         "offLight":15722726,
         "offMid":13352633,
         "offBase":10324612,
         "offDark":7957094,
         "offOutline":7957094,
         "slash":8153702
      };
      
      private static const RESPONSE_SWITCH_TARGET:int = 730000;
      
      private static const RESPONSE_PLAY_ALL_VISIBLE:int = 731000;
      
      private static const RESPONSE_LINKED_RESTORE_OUTFIT:int = 732000;
      
      private static const RESPONSE_LINKED_CLEAR_OBJECTS:int = 732001;
      
      private static const RESPONSE_PROXY_GROUP_MANAGE:int = RESPONSE_ITEM_BASE + 2;
      
      private static const NATIVE_CELL_CLASS:String = "widgets.Pickers.controls.ObjectPickerIconTextCellView";
      
      private static const DEBUG_NATIVE_HIT:Boolean = false;
      
      private static const LINKED_GRID_SHIFT:Number = -272;
      
      private static const LINKED_ITEMS_PER_PAGE:int = 8;
      
      private static const LINKED_SCROLL_SHIFT:Number = -490;
      
      private static var sCASGUIImageClass:Class = null;
      
      public var mcContent:MovieClip;
      
      public var mData:UiDialogMessage;
      
      protected var mMainInputAdapter:DynamicOmnidirectionalAdapter;
      
      private var mNativeLayer:MovieClip;
      
      private var mNativeCells:Array;
      
      private var mNativeHitRects:Array;
      
      private var mLastFavoriteIndex:int = -1;
      
      private var mLastFavoriteTime:int = -10000;
      
      private var mLastMiddleEditIndex:int = -1;
      
      private var mLastMiddleEditTime:int = -10000;
      
      private var mFixedToolsLayer:MovieClip;
      
      private var mSwitchTargetButton:Sprite;
      
      private var mPlayAllButton:Sprite;
      
      private var mBatchSelectButton:Sprite;
      
      private var mFavoriteToGroupButton:Sprite;
      
      private var mClearPoseQueueButton:Sprite;
      
      private var mGroupManageButton:Sprite;
      
      private var mFixedToolsHint:TextField;
      
      private var mSidebarNavLayer:MovieClip;
      
      private var mSidebarNavHits:Array;
      
      private var mGroupTabsLayer:MovieClip;
      
      private var mGroupTabButtons:Array;
      
      private var mGroupManagerLayer:MovieClip;
      
      private var mGroupManagerRows:Array;
      
      private var mGroupManagerPage:int = 0;
      
      private var mOuterGroupChipPage:int = 0;
      
      private var mSelectionLayer:MovieClip;
      
      private var mSelectionOverlays:Array;
      
      private var mFavoriteLayer:MovieClip;
      
      private var mFavoriteMarkers:Array;
      
      private var mFavoriteOverrides:Object = {};
      
      private var mMemberSelectionOverrides:Object = {};
      
      private var mMemberEditToolsLayer:MovieClip;
      
      private var mOuterGroupToolsLayer:MovieClip;
      
      private var mOuterGroupManagerLayer:MovieClip;
      
      private var mOuterGroupManagerRows:Array;
      
      private var mOuterGroupManagerPage:int = 0;
      
      private var mRootToolsLayer:MovieClip;
      
      private var mRootSearchLayer:MovieClip;
      
      private var mRootSearchField:TextField;
      
      private var mRootSearchPlaceholder:TextField;
      
      private var mGlobalPlumbobLayer:MovieClip;
      
      private var mGlobalPlumbobVisual:Sprite;
      
      private var mGlobalPlumbobHit:Sprite;
      
      private var mGlobalPlumbobEnabled:Boolean = true;
      
      private var mGlobalPlumbobHover:Boolean = false;
      
      private var mUiLocalization:Object = null;
      
      private var mLocalizationProbeSent:Boolean = false;
      
      private var mRootSearchClearButton:Sprite;
      
      private var mRootSearchLocalQuery:String = "";
      
      private var mRootSearchResults:Array = [];
      
      private var mRootSearchHaystacks:Array = [];
      
      private var mRootSearchLocalPage:int = 0;
      
      private var mRootSearchSyncTimer:uint = 0;
      
      private var mRootSearchLastSynced:String = "";
      
      private var mBatchFavoriteGroupLayer:MovieClip;
      
      private var mBatchFavoriteGroupScope:String = "";
      
      private var mBatchFavoriteGroupPage:int = 0;
      
      private var mBatchFavoriteGroupAnchorX:Number = 0;
      
      private var mBatchFavoriteGroupAnchorY:Number = 0;
      
      private var mBatchFavoriteGroupInputMode:Boolean = false;
      
      private var mBatchFavoriteGroupInput:TextField;
      
      private var mPackOrganizerActive:Boolean = false;
      
      private var mPackOrganizerSingleIndex:int = -1;
      
      private var mPackOrganizerSingleValue:String = "";
      
      private var mRightPressIndex:int = -1;
      
      private var mRightPressStartedAt:int = 0;
      
      private var mRightPressStartX:Number = 0;
      
      private var mRightPressStartY:Number = 0;
      
      private var mSuppressRightFavoriteUntil:int = 0;
      
      private var mEditInfoLayer:MovieClip;
      
      private var mEditInfoNameField:TextField;
      
      private var mEditInfoNoteField:TextField;
      
      private var mEditInfoKey:String = "";
      
      private var mEditInfoIndex:int = -1;
      
      private var mEditInfoLinkedMode:Boolean = false;
      
      private var mLinkedEditNameOverrides:Object = {};
      
      private var mLinkedEditNoteOverrides:Object = {};
      
      private var mLastLinkedEditKey:String = "";
      
      private var mLastLinkedEditTime:int = -10000;
      
      private var mLinkedManageButton:Sprite;
      
      private var mLinkedDrawerLayer:MovieClip;
      
      private var mLinkedDrawerRows:Array;
      
      private var mLinkedManageMode:Boolean = false;
      
      private var mLinkedActiveIndex:int = 0;
      
      private var mLinkedResourcePage:int = 0;
      
      private var mLinkedLocalPage:int = -1;
      
      private var mLinkedIgnoreNativeUntil:int = 0;
      
      private var mLinkedMultiSelectMode:Boolean = false;
      
      private var mLinkedSelectedPoses:Object = {};
      
      private var mBatchSelectMode:Boolean = false;
      
      private var mBatchSelectedPoses:Object = {};
      
      private var mBatchLocalPage:int = -1;
      
      private var mOuterManageLocalPage:int = -1;
      
      private var mUiBuildPinged:Boolean = false;
      
      private var mLinkedMarqueeLayer:MovieClip;
      
      private var mLinkedMarqueeDown:Boolean = false;
      
      private var mLinkedMarqueeDragging:Boolean = false;
      
      private var mLinkedMarqueeStartX:Number = 0;
      
      private var mLinkedMarqueeStartY:Number = 0;
      
      private var mMarqueeAutoBatchCandidate:Boolean = false;
      
      private var mScrollDragActive:Boolean = false;
      
      private var mScrollDragTarget:DisplayObject;
      
      private var mScrollGrabOverlay:Sprite;
      
      private var mHeaderPortraitLayer:MovieClip;
      
      private var mHeaderPortraitImageLayer:MovieClip;
      
      private var mHeaderPortraitMask:Sprite;
      
      private var mHeaderPortraitCornerCover:Sprite;
      
      private var mHeaderPortraitFrame:Sprite;
      
      private var mHeaderPortraitIconInfo:Object = null;
      
      private var mLinkedBaseX:Object = {};
      
      private var mLinkedBaseY:Object = {};
      
      private var mLinkedResourceOverrides:Object = {};
      
      private var mLinkedAutoOverrides:Object = {};
      
      private var mLinkedSummaryOverrides:Object = {};
      
      private var mLinkedInspectorExpanded:Boolean = true;
      
      private var mLinkedTypeFilter:String = "cas";
      
      private var mLinkedOriginFilter:String = "all";
      
      private var mCASDirectProbeOpen:Boolean = false;
      
      private var mLinkedProductPreviewChoice:Object = {};
      
      private var mLinkedCASSelectionOverrides:Object = {};
      
      private var mLinkedCASRowSnapshotOverrides:Object = {};
      
      private var mLinkedObjectRowSnapshotOverrides:Object = {};
      
      private var mLinkedCASRowEpoch:Object = {};
      
      private var mLinkedV2SelectedLookupCache:Object = {};
      
      private var mLinkedCASPreviewPanel:MovieClip;
      
      private var mLinkedCASPreviewPanels:Object = {};
      
      private var mLinkedCASPreviewCard:MovieClip;
      
      private var mLinkedCASPreviewProductIndex:int = -1;
      
      private var mLinkedCASProductCards:Array = [];
      
      private var mLinkedObjectProductCards:Array = [];
      
      private var mLinkedRemoveLayer:MovieClip;
      
      private var mLinkedRemoveProductIndex:int = -1;
      
      private var mLinkedRemoveLocalIds:Array = [];
      
      private var mLinkedRemoveHasExternal:Boolean = false;
      
      private var mLinkedRightPressProductIndex:int = -1;
      
      private var mLinkedRightPressStartedAt:int = 0;
      
      private var mLinkedRightPressStartX:Number = 0;
      
      private var mLinkedRightPressStartY:Number = 0;
      
      private var mLinkedPoseStatusLabel:TextField;
      
      private var mLinkedCASHoverTimer:uint = 0;
      
      private var mLinkedCASHoverPending:Object = null;
      
      private var mLinkedCASSwatchHoverTimer:uint = 0;
      
      private var mLinkedCASSwatchHoverPending:Object = null;
      
      private var mLinkedCASSwatchRestoreTimer:uint = 0;
      
      private var mLinkedCASPreviewPollTimer:uint = 0;
      
      private var mLinkedCASPreviewRequestSerial:uint = 0;
      
      private var mLinkedCASPreviewPending:Object = null;
      
      private var mLinkedCASPreviewGenderCache:Object = {};
      
      private var mPackLlamaBitmapData:BitmapData = null;
      
      private var mPackLlamaBounds:Rectangle = null;
      
      private var mPackLlamaOverlays:Array = [];
      
      private var mStageWheelBound:Boolean = false;
      
      private var mStageMiddleBound:Boolean = false;
      
      public function FgEHPoseDialogMain()
      {
         addFrameScript(21,this.frame22);
         super();
      }
      
      override public function Initialize() : void
      {
         super.Initialize();
         if(SystemUtils.UsingConsoleInputMode)
         {
            this.InitGamepad();
         }
         if(this.mcContent != null && this.mcContent.btnOk != null)
         {
            this.mcContent.btnOk.addEventListener(PushButtonEvent.CLICK,this.OnChromeClick,false,0,true);
         }
         this.DisableLegacyPackButtons();
         this.ListenClick("fgehCloseButton",this.OnChromeClick);
         this.ListenClick("fgehLibraryButton",this.OnChromeClick);
         this.ListenClick("fgehScrollTrackHit",this.OnChromeClick);
         var thumbHit:DisplayObject = this.Child("fgehScrollThumbHit");
         if(thumbHit != null)
         {
            thumbHit.addEventListener(MouseEvent.MOUSE_DOWN,this.OnThumbDown,false,0,true);
            thumbHit.addEventListener(MouseEvent.MOUSE_UP,this.OnThumbUp,false,0,true);
         }
         var thumbVisual:DisplayObject = this.Child("fgehScrollThumb");
         if(thumbVisual != null)
         {
            thumbVisual.addEventListener(MouseEvent.MOUSE_DOWN,this.OnThumbDown,false,0,true);
            thumbVisual.addEventListener(MouseEvent.MOUSE_UP,this.OnThumbUp,false,0,true);
         }
         this.BuildScrollGrabOverlay();
         this.InstallStageWheelListener();
         this.BuildNativeCells();
         this.CapturePackLlamaPlaceholder();
         this.BuildSidebarNav();
         this.BuildGroupTabs();
         this.BuildGroupManager();
         this.BuildSelectionLayer();
         this.BuildFavoriteLayer();
         this.BuildMemberEditTools();
         this.BuildOuterGroupTools();
         this.BuildOuterGroupManager();
         this.BuildRootTools();
         this.BuildRootSearch();
         this.BuildHeaderPortrait();
         this.BuildGlobalPlumbobWidget();
         this.BuildBatchFavoriteGroupLayer();
         this.BuildEditInfoModal();
         this.BuildLinkedDrawer();
         this.BuildLinkedRemoveLayer();
         this.BuildFixedTools();
      }
      
      override public function Show(param1:Object = null) : void
      {
         var restoreLinkedLayout:Boolean;
         var _loc4_:int = getTimer();
         super.Show(param1);
         this.InstallStageWheelListener();
         this.mData = param1 as UiDialogMessage;
         this.mUiLocalization = null;
         this.mLocalizationProbeSent = false;
         this.mHeaderPortraitIconInfo = null;
         this.mGlobalPlumbobEnabled = this.GetGlobalPlumbobEnabled();
         this.mGlobalPlumbobHover = false;
         if(this.mRootSearchSyncTimer != 0)
         {
            try
            {
               clearTimeout(this.mRootSearchSyncTimer);
            }
            catch(eSearchTimer:Error)
            {
            }
         }
         this.mRootSearchSyncTimer = 0;
         this.mRootSearchLocalQuery = this.GetStringText(6,"");
         this.mRootSearchLocalPage = this.GetIntText(1,0);
         this.mRootSearchResults = [];
         this.mRootSearchHaystacks = [];
         this.RebuildRootSearchIndex();
         this.RebuildRootSearchResults();
         restoreLinkedLayout = this.mLinkedManageMode;
         this.mLinkedManageMode = false;
         this.mLinkedActiveIndex = 0;
         this.mLinkedResourcePage = 0;
         this.mLinkedLocalPage = -1;
         this.mLinkedIgnoreNativeUntil = 0;
         this.mLinkedMultiSelectMode = false;
         this.mLinkedSelectedPoses = {};
         this.mBatchSelectMode = false;
         this.mBatchSelectedPoses = {};
         this.mBatchLocalPage = -1;
         this.mOuterManageLocalPage = -1;
         this.mPackOrganizerActive = false;
         this.mPackOrganizerSingleIndex = -1;
         this.mPackOrganizerSingleValue = "";
         this.mRightPressIndex = -1;
         this.mRightPressStartedAt = 0;
         this.mSuppressRightFavoriteUntil = 0;
         this.AbortMarqueeInteraction();
         this.mFavoriteOverrides = {};
         this.mMemberSelectionOverrides = {};
         this.mBatchFavoriteGroupScope = "";
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupInputMode = false;
         this.mBatchFavoriteGroupInput = null;
         if(this.mBatchFavoriteGroupLayer != null)
         {
            this.mBatchFavoriteGroupLayer.visible = false;
         }
         this.mMarqueeAutoBatchCandidate = false;
         this.mLinkedMarqueeDown = false;
         this.mLinkedMarqueeDragging = false;
         this.mScrollDragActive = false;
         this.mScrollDragTarget = null;
         this.mLinkedResourceOverrides = {};
         this.mLinkedAutoOverrides = {};
         this.mLinkedSummaryOverrides = {};
         this.mLinkedInspectorExpanded = true;
         this.mLinkedTypeFilter = "cas";
         this.mLinkedOriginFilter = "all";
         this.mCASDirectProbeOpen = false;
         this.mLinkedProductPreviewChoice = {};
         this.mLinkedCASSelectionOverrides = {};
         this.mLinkedCASRowSnapshotOverrides = {};
         this.mLinkedObjectRowSnapshotOverrides = {};
         this.mLinkedCASRowEpoch = {};
         this.mLinkedV2SelectedLookupCache = {};
         this.mLinkedEditNameOverrides = {};
         this.mLinkedEditNoteOverrides = {};
         this.mEditInfoLinkedMode = false;
         this.CancelPendingCASProductHover();
         this.CancelPendingCASSwatchHover();
         this.CancelCASPreviewImageRequest();
         this.mLinkedCASPreviewGenderCache = {};
         this.mLinkedCASPreviewPanel = null;
         this.mLinkedCASPreviewPanels = {};
         this.mLinkedCASPreviewCard = null;
         this.mLinkedObjectProductCards = [];
         this.mLinkedCASPreviewProductIndex = -1;
         if(this.mLinkedDrawerLayer != null)
         {
            this.mLinkedDrawerLayer.visible = false;
         }
         this.mLinkedRightPressProductIndex = -1;
         this.mLinkedRightPressStartedAt = 0;
         this.mLinkedRemoveProductIndex = -1;
         this.mLinkedRemoveLocalIds = [];
         this.mLinkedRemoveHasExternal = false;
         if(this.mLinkedRemoveLayer != null)
         {
            this.mLinkedRemoveLayer.visible = false;
         }
         if(this.mData != null)
         {
            this.Draw(this.mData);
            this.HidePoseManagerTitle();
            this.HideLegacyViewTitle();
            if(restoreLinkedLayout)
            {
               this.ApplyLinkedManageLayout();
            }
            this.RefreshNativeCells();
            this.RefreshSelectionOverlays();
            this.RefreshFixedTools();
            if(!this.mUiBuildPinged)
            {
               this.mUiBuildPinged = true;
               CommunicationManager.PostServerCommand("fgeh.ui_build_ping",encodeURIComponent("V8.9.69.6"),encodeURIComponent(this.GetV7ViewKind()),encodeURIComponent(String(this.GetV7ActiveGroupIndex())));
            }
            this.SyncCardInteractionState();
         }
         if(SystemUtils.UsingController)
         {
            NavManager.Instance.FocusWidgetForward(WidgetName);
         }
         this.FgehCasExportCollectionV3();
         if(this.GetV7ActiveNav() == 6)
         {
            if(this.GetLinkedPackId() == "__FGEH_CAS_LIBRARY__")
            {
               this.SetVisible("fgehLibraryButton",true);
               this.SetVisible("fgehLibraryLabel",true);
               if(this.Child("fgehLibraryButton") != null)
               {
                  this.Child("fgehLibraryButton").mouseEnabled = true;
                  this.Child("fgehLibraryButton").mouseChildren = false;
                  this.mcContent.setChildIndex(this.Child("fgehLibraryButton"),this.mcContent.numChildren - 1);
               }
               if(this.Child("fgehLibraryLabel") != null)
               {
                  this.Child("fgehLibraryLabel").mouseEnabled = false;
                  this.mcContent.setChildIndex(this.Child("fgehLibraryLabel"),this.mcContent.numChildren - 1);
               }
            }
         }
         var §+$activation§:String = this.GetStringText(9,"");
         if(§+$activation§.indexOf("__FGEH_LINKED_REENTER_INDEX__:") == 0)
         {
            this.EnterLinkedManage(int(§+$activation§.substr(30)));
         }
         if(this.GetV7ViewKind().indexOf("root") == 0)
         {
            this.HideLegacyRootSidebar();
         }
         if(this.GetLinkedPackId() == "__FGEH_CAS_LIBRARY__")
         {
            this.SetVisible("fgehLibraryButton",false);
            this.SetVisible("fgehLibraryLabel",false);
         }
         CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_SHOW_TOTAL" + ":" + (getTimer() - _loc4_),param1.dialog_id);
      }
      
      override public function Hide(param1:Object = null) : void
      {
         if(this.mLinkedManageMode)
         {
            this.ExitLinkedManage();
         }
         this.RemoveStageWheelListener();
         super.Hide();
         if(SystemUtils.UsingController)
         {
            NavManager.Instance.FocusBack();
         }
         try
         {
            getDefinitionByName("fgeh.ui.targets::TargetRail").Hide(this);
            return;
         }
         catch(_loc_e_:*)
         {
         }
      }
      
      private function Child(param1:String) : DisplayObject
      {
         if(this.mcContent == null)
         {
            return null;
         }
         return this.mcContent.getChildByName(param1);
      }
      
      private function ListenClick(param1:String, param2:Function) : void
      {
         var target:DisplayObject = this.Child(param1);
         if(target != null)
         {
            target.addEventListener(MouseEvent.CLICK,param2,false,0,true);
         }
      }
      
      private function SetHtml(param1:String, param2:String) : void
      {
         var target:DisplayObject = this.Child(param1);
         if(target == null)
         {
            return;
         }
         try
         {
            Object(target).htmlText = param2;
         }
         catch(e:Error)
         {
            try
            {
               Object(target).text = param2;
            }
            catch(e2:Error)
            {
            }
         }
      }
      
      private function SetVisible(param1:String, param2:Boolean) : void
      {
         var target:DisplayObject = this.Child(param1);
         if(target != null)
         {
            target.visible = param2;
         }
      }
      
      private function GetIntText(param1:int, param2:int = 0) : int
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function GetStringText(param1:int, param2:String = "") : String
      {
         try
         {
            if(this.mData != null)
            {
               if(this.mData.additional_texts != null)
               {
                  if(param1 >= 0)
                  {
                     if(param1 < this.mData.additional_texts.length)
                     {
                        if(this.mLinkedBaseX != null)
                        {
                           var _loc3_:* = this.mLinkedBaseX["fgehTextCacheR74"];
                           while(true)
                           {
                              if(_loc3_ != null)
                              {
                                 if(_loc3_["data"] === this.mData)
                                 {
                                    break;
                                 }
                              }
                              _loc3_ = {
                                 "data":this.mData,
                                 "texts":{}
                              };
                              this.mLinkedBaseX["fgehTextCacheR74"] = _loc3_;
                              break;
                           }
                           var _loc4_:* = this.mData.additional_texts[param1];
                           var _loc5_:* = _loc3_["texts"][param1];
                           if(_loc5_ != null)
                           {
                              if(_loc5_["texts"] === _loc4_)
                              {
                                 return _loc5_["value"];
                              }
                           }
                           var _loc6_:String = String(_loc4_);
                           _loc3_["texts"][param1] = {
                              "texts":_loc4_,
                              "value":_loc6_
                           };
                           return _loc6_;
                        }
                        return String(this.mData.additional_texts[param1]);
                     }
                  }
               }
            }
            return param2;
         }
         catch(_loc_e_:*)
         {
         }
      }
      
      private function GetRowField(param1:int, param2:int, param3:String = "") : String
      {
         var index:int = 13 + param1 * 6 + param2;
         return this.GetStringText(index,param3);
      }
      
      private function IsLegacyNormalPackDetail() : Boolean
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function ActiveItemsPerPage() : int
      {
         if(!this.mLinkedManageMode)
         {
            if(this.GetV7ActiveNav() == 9)
            {
               return 9;
            }
         }
         return this.mLinkedManageMode ? LINKED_ITEMS_PER_PAGE : ITEMS_PER_PAGE;
      }
      
      private function ActiveTotalItems() : int
      {
         return this.mLinkedManageMode ? this.GetLinkedRowCount() : this.RootSearchEffectiveTotal();
      }
      
      private function ActiveDataIndexAtVisible(param1:int) : int
      {
         return this.mLinkedManageMode ? param1 : this.RootSearchDataIndexAt(param1);
      }
      
      private function ActiveVisibleIndexForSlot(param1:int) : int
      {
         return this.GetCurrentPage() * this.ActiveItemsPerPage() + param1;
      }
      
      private function GetCurrentPage() : int
      {
         if(this.mLinkedManageMode && this.mLinkedLocalPage >= 0)
         {
            return this.mLinkedLocalPage;
         }
         if(this.mBatchSelectMode && this.mBatchLocalPage >= 0)
         {
            return this.mBatchLocalPage;
         }
         if(this.IsOuterGroupRemoveManageMode() && this.mOuterManageLocalPage >= 0)
         {
            return this.mOuterManageLocalPage;
         }
         if(this.IsRootLiveSearchActive())
         {
            return this.mRootSearchLocalPage;
         }
         if(this.HasV7Extension())
         {
            if(this.GetV7ViewKind().indexOf("root") == 0)
            {
               if(this.GetV7ActiveNav() <= 5)
               {
                  return this.mRootSearchLocalPage;
               }
            }
         }
         return this.GetIntText(1,0);
      }
      
      private function GetPageCount() : int
      {
         if(this.mLinkedManageMode)
         {
            return Math.max(1,int(Math.ceil(this.GetLinkedRowCount() / LINKED_ITEMS_PER_PAGE)));
         }
         if(this.IsRootLiveSearchActive())
         {
            var searchCount:int = this.RootSearchEffectiveTotal();
            return Math.max(1,int(Math.ceil(searchCount / this.ActiveItemsPerPage())));
         }
         var result:int = this.GetIntText(2,1);
         if(result < 1)
         {
            result = 1;
         }
         return result;
      }
      
      private function GetTotalItems() : int
      {
         var result:int = this.GetIntText(7,0);
         if(result <= 0 && this.mData != null && this.mData.icon_infos != null)
         {
            result = int(this.mData.icon_infos.length);
         }
         return result;
      }
      
      private function DisableLegacyPackButtons() : void
      {
         var button:DisplayObject;
         var i:int = 1;
         while(i <= ITEMS_PER_PAGE)
         {
            button = this.Child("fgehPackButton" + i);
            if(button != null)
            {
               try
               {
                  Object(button).mouseEnabled = false;
               }
               catch(e:Error)
               {
               }
               try
               {
                  Object(button).mouseChildren = false;
               }
               catch(e2:Error)
               {
               }
               button.visible = false;
            }
            i++;
         }
      }
      
      private function HidePoseManagerTitle() : void
      {
         if(this.mcContent == null)
         {
            return;
         }
         this.HideTextRecursive(this.mcContent,"POSE MANAGER");
      }
      
      private function HideLegacyViewTitle() : void
      {
         var title:DisplayObject = this.Child("fgehViewTitle");
         if(title != null)
         {
            title.visible = false;
            title.mouseEnabled = false;
         }
      }
      
      private function HideTextRecursive(param1:DisplayObject, param2:String) : void
      {
         var value:String;
         var clip:MovieClip;
         var i:int;
         if(param1 == null)
         {
            return;
         }
         if(param1 is TextField)
         {
            try
            {
               value = TextField(param1).text.toUpperCase();
               if(value.indexOf(param2) >= 0)
               {
                  param1.visible = false;
                  param1.mouseEnabled = false;
                  return;
               }
            }
            catch(e:Error)
            {
            }
         }
         if(param1 is MovieClip)
         {
            clip = param1 as MovieClip;
            i = 0;
            while(i < clip.numChildren)
            {
               this.HideTextRecursive(clip.getChildAt(i),param2);
               i++;
            }
         }
      }
      
      private function GetTotalItems() : int
      {
         return this.GetIntText(7,0);
      }
      
      private function GetExtensionBase() : int
      {
         return 12 + this.GetTotalItems() * 6;
      }
      
      private function HasV7Extension() : Boolean
      {
         var base:int = this.GetExtensionBase();
         return this.mData != null && this.mData.additional_texts != null && base >= 0 && base < this.mData.additional_texts.length && String(this.mData.additional_texts[base]) == EXT_MAGIC;
      }
      
      private function GetV7ViewKind() : String
      {
         if(!this.HasV7Extension())
         {
            return "";
         }
         return this.GetStringText(this.GetExtensionBase() + 1,"");
      }
      
      private function GetV7ActiveNav() : int
      {
         if(!this.HasV7Extension())
         {
            return 0;
         }
         return this.GetIntText(this.GetExtensionBase() + 2,0);
      }
      
      private function GetV7GroupCount() : int
      {
         if(!this.HasV7Extension())
         {
            return 0;
         }
         return this.GetIntText(this.GetExtensionBase() + 3,0);
      }
      
      private function GetV7ActiveGroupIndex() : int
      {
         if(!this.HasV7Extension())
         {
            return -1;
         }
         return this.GetIntText(this.GetExtensionBase() + 4,-1);
      }
      
      private function GetV7GroupName(param1:int) : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function FindPayloadMagic(param1:String) : int
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function HasRootToolsExtension() : Boolean
      {
         return this.FindPayloadMagic(ROOT_TOOLS_MAGIC) >= 0;
      }
      
      private function GetRootViewLabel() : String
      {
         var base:int = this.FindPayloadMagic(ROOT_TOOLS_MAGIC);
         return base >= 0 ? this.GetStringText(base + 1,"") : "";
      }
      
      private function GetRootSortLabel() : String
      {
         var base:int = this.FindPayloadMagic(ROOT_TOOLS_MAGIC);
         return base >= 0 ? this.GetStringText(base + 2,"A → Z") : "A → Z";
      }
      
      private function IsRootViewToggleEnabled() : Boolean
      {
         var base:int = this.FindPayloadMagic(ROOT_TOOLS_MAGIC);
         return base >= 0 && this.GetIntText(base + 3,0) == 1;
      }
      
      private function IsRootSortToggleEnabled() : Boolean
      {
         var base:int = this.FindPayloadMagic(ROOT_TOOLS_MAGIC);
         return base >= 0 && this.GetIntText(base + 4,0) == 1;
      }
      
      private function GetGlobalPlumbobEnabled() : Boolean
      {
         var base:int = this.FindPayloadMagic(GLOBAL_WIDGETS_MAGIC);
         return base < 0 || this.GetIntText(base + 1,1) == 1;
      }
      
      private function GetGlobalWidgetThemeId() : String
      {
         var base:int = this.FindPayloadMagic(GLOBAL_WIDGETS_MAGIC);
         return base < 0 ? "classic_green" : this.GetStringText(base + 2,"classic_green");
      }
      
      private function GetGlobalPlumbobTheme() : Object
      {
         return this.GetGlobalWidgetThemeId() == "pink_brown" ? PLUMBOB_THEME_PINK_BROWN : PLUMBOB_THEME_GREEN;
      }
      
      private function IsUsableLocalizedText(value:String) : Boolean
      {
         if(value == null || value.length == 0)
         {
            return false;
         }
         var lowered:String = value.toLowerCase();
         if(lowered == "null" || lowered == "undefined")
         {
            return false;
         }
         if(lowered.indexOf("missing string") >= 0)
         {
            return false;
         }
         if(value.indexOf("***") >= 0)
         {
            return false;
         }
         if(lowered.length >= 2 && lowered.substr(0,2) == "0x")
         {
            return false;
         }
         return true;
      }
      
      private function BuildUiLocalizationCache() : void
      {
         this.mUiLocalization = {};
         var base:int = this.FindPayloadMagic(LOCALIZATION_MAGIC);
         if(base < 0)
         {
            if(!this.mLocalizationProbeSent)
            {
               this.mLocalizationProbeSent = true;
            }
            if(this.mData != null)
            {
               var _temp_2:* = CommunicationManager;
               var _temp_1:* = "fgeh.hash_probe.capture";
               encodeURIComponent("HASH_PROBE_V1|marker=" + base + "|nav_all=" + this.mUiLocalization["nav_all_packs"] + "|nav_fav=" + this.mUiLocalization["nav_favorite_packs"] + "|close=" + this.mUiLocalization["common_close"]);
               _temp_1;
               _temp_2;
            }
            return;
         }
         var count:int = this.GetIntText(base + 1,0);
         if(count == 642)
         {
            this.mUiLocalization["__fgeh_schema_base"] = base;
            return;
         }
         var i:int = 0;
         while(i < count)
         {
            var key:String = this.GetStringText(base + 2 + i * 2,"");
            var value:Number = base + 3 + i * 2;
            if(key != null && key.length > 0)
            {
               this.mUiLocalization[key] = value;
            }
            i++;
         }
         if(!this.mLocalizationProbeSent)
         {
            this.mLocalizationProbeSent = true;
         }
         if(this.mData != null)
         {
            var _temp_5:* = CommunicationManager;
            var _temp_4:* = "fgeh.hash_probe.capture";
            encodeURIComponent("HASH_PROBE_V1|marker=" + base + "|nav_all=" + this.mUiLocalization["nav_all_packs"] + "|nav_fav=" + this.mUiLocalization["nav_favorite_packs"] + "|close=" + this.mUiLocalization["common_close"]);
            _temp_4;
            _temp_5;
         }
      }
      
      private function L(param1:String, param2:String = "") : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function GetBatchFavoriteGroupsBase() : int
      {
         return this.FindPayloadMagic(BATCH_FAVORITE_GROUPS_MAGIC);
      }
      
      private function GetFavoriteGroupNames(param1:String) : Array
      {
         var result:Array = [];
         var base:int = this.GetBatchFavoriteGroupsBase();
         if(base < 0)
         {
            return result;
         }
         var packCount:int = this.GetIntText(base + 1,0);
         var i:int = 0;
         if(param1 == "pack")
         {
            while(i < packCount)
            {
               result.push(this.GetStringText(base + 2 + i,""));
               i++;
            }
            return result;
         }
         var poseCountIndex:int = base + 2 + packCount;
         var poseCount:int = this.GetIntText(poseCountIndex,0);
         if(param1 == "pose")
         {
            i = 0;
            while(i < poseCount)
            {
               result.push(this.GetStringText(poseCountIndex + 1 + i,""));
               i++;
            }
         }
         return result;
      }
      
      private function GetOuterActionGroupNames() : Array
      {
         var result:Array = [];
         var base:int = this.GetBatchFavoriteGroupsBase();
         if(base < 0)
         {
            return result;
         }
         var packCount:int = this.GetIntText(base + 1,0);
         var poseCountIndex:int = base + 2 + packCount;
         var poseCount:int = this.GetIntText(poseCountIndex,0);
         var outerCountIndex:int = poseCountIndex + 1 + poseCount;
         if(this.mData == null || this.mData.additional_texts == null || outerCountIndex < 0 || outerCountIndex >= this.mData.additional_texts.length)
         {
            return result;
         }
         var outerCount:int = this.GetIntText(outerCountIndex,0);
         var i:int = 0;
         while(i < outerCount)
         {
            result.push(this.GetStringText(outerCountIndex + 1 + i,""));
            i++;
         }
         return result;
      }
      
      private function GetEditInfoBase() : int
      {
         return this.FindPayloadMagic(EDIT_INFO_MAGIC);
      }
      
      private function GetEditInfoKey(param1:int) : String
      {
         var base:int = this.GetEditInfoBase();
         if(base < 0)
         {
            return "";
         }
         var count:int = this.GetIntText(base + 1,0);
         if(param1 < 0 || param1 >= count)
         {
            return "";
         }
         return this.GetStringText(base + 2 + param1 * 3,"");
      }
      
      private function GetEditInfoName(param1:int) : String
      {
         var base:int = this.GetEditInfoBase();
         return base >= 0 ? this.GetStringText(base + 3 + param1 * 3,"") : "";
      }
      
      private function GetEditInfoNote(param1:int) : String
      {
         var base:int = this.GetEditInfoBase();
         return base >= 0 ? this.GetStringText(base + 4 + param1 * 3,"") : "";
      }
      
      private function GetLinkedEditBase() : int
      {
         return this.FindPayloadMagic(LINKED_EDIT_MAGIC);
      }
      
      private function GetLinkedEditField(param1:String, param2:int, param3:String = "") : String
      {
         var base:int = this.GetLinkedEditBase();
         if(base < 0 || param1 == null || param1.length == 0)
         {
            return param3;
         }
         var count:int = this.GetIntText(base + 1,0);
         var i:int = 0;
         while(i < count)
         {
            var itemBase:int = base + 2 + i * 4;
            if(this.GetStringText(itemBase,"") == param1)
            {
               return this.GetStringText(itemBase + 1 + param2,param3);
            }
            i++;
         }
         return param3;
      }
      
      private function LinkedCASEditKey(param1:int) : String
      {
         return "linked_cas_product::" + this.GetLinkedProductField(this.mLinkedActiveIndex,param1,0,"");
      }
      
      private function LinkedObjectEditKey(param1:int) : String
      {
         return "linked_object_product::" + this.GetLinkedObjectProductField(this.mLinkedActiveIndex,param1,0,"");
      }
      
      private function LinkedEditCustomName(param1:String) : String
      {
         try
         {
            if(this.mLinkedEditNameOverrides.hasOwnProperty(param1))
            {
               return String(this.mLinkedEditNameOverrides[param1]);
            }
         }
         catch(e:Error)
         {
         }
         return this.GetLinkedEditField(param1,0,"");
      }
      
      private function LinkedEditNote(param1:String) : String
      {
         try
         {
            if(this.mLinkedEditNoteOverrides.hasOwnProperty(param1))
            {
               return String(this.mLinkedEditNoteOverrides[param1]);
            }
         }
         catch(e:Error)
         {
         }
         return this.GetLinkedEditField(param1,1,"");
      }
      
      private function LinkedEditOriginalLabel(param1:String) : String
      {
         return this.GetLinkedEditField(param1,2,"");
      }
      
      private function GetLinkedCASProductDisplayLabel(param1:int) : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function GetLinkedObjectProductDisplayLabel(param1:int) : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function GetLinkedDetailBase() : int
      {
         return this.FindPayloadMagic(LINKED_DETAIL_MAGIC);
      }
      
      private function HasLinkedDetailExtension() : Boolean
      {
         return this.GetLinkedDetailBase() >= 0;
      }
      
      private function GetLinkedPackId() : String
      {
         var base:int = this.GetLinkedDetailBase();
         if(base < 0)
         {
            return "";
         }
         return this.GetStringText(base + 1,"");
      }
      
      private function GetLinkedRowCount() : int
      {
         var base:int = this.GetLinkedDetailBase();
         if(base < 0)
         {
            return 0;
         }
         return this.GetIntText(base + 2,0);
      }
      
      private function LinkedRowBase(param1:int) : int
      {
         var base:int = this.GetLinkedDetailBase();
         if(base < 0 || param1 < 0 || this.mData == null)
         {
            return -1;
         }
         var cursor:int = base + 3;
         var i:int = 0;
         while(i < param1)
         {
            if(this.mData.additional_texts == null || cursor + 3 >= this.mData.additional_texts.length)
            {
               return -1;
            }
            var resourceCount:int = this.GetIntText(cursor + 3,0);
            cursor += 4 + resourceCount * 7;
            i++;
         }
         return cursor;
      }
      
      private function GetLinkedPoseName(param1:int) : String
      {
         var base:int = this.LinkedRowBase(param1);
         return base >= 0 ? this.GetStringText(base,"") : "";
      }
      
      private function GetLinkedResourceCount(param1:int) : int
      {
         var base:int = this.LinkedRowBase(param1);
         return base >= 0 ? this.GetIntText(base + 3,0) : 0;
      }
      
      private function GetLinkedResourceField(param1:int, param2:int, param3:int, param4:String = "") : String
      {
         var base:int = this.LinkedRowBase(param1);
         if(base < 0 || param2 < 0)
         {
            return param4;
         }
         var count:int = this.GetIntText(base + 3,0);
         if(param2 >= count)
         {
            return param4;
         }
         return this.GetStringText(base + 4 + param2 * 7 + param3,param4);
      }
      
      private function GetLinkedProductsBase() : int
      {
         return this.FindPayloadMagic(LINKED_PRODUCTS_MAGIC);
      }
      
      private function GetLinkedProductsV2Base() : int
      {
         return this.FindPayloadMagic(LINKED_PRODUCTS_V2_MAGIC);
      }
      
      private function HasLinkedProductsV2Extension() : Boolean
      {
         return this.GetLinkedProductsV2Base() >= 0;
      }
      
      private function HasLinkedProductsExtension() : Boolean
      {
         return this.HasLinkedProductsV2Extension() || this.GetLinkedProductsBase() >= 0;
      }
      
      private function LinkedV2CatalogBase(param1:int) : int
      {
         var base:int = this.GetLinkedProductsV2Base();
         if(base < 0 || param1 < 0 || this.mData == null)
         {
            return -1;
         }
         var catalogCount:int = this.GetIntText(base + 2,0);
         if(param1 >= catalogCount)
         {
            return -1;
         }
         var cursor:int = base + 3;
         var ci:int = 0;
         while(ci < param1)
         {
            var productCount:int = this.GetIntText(cursor,0);
            cursor += 1;
            var pi:int = 0;
            while(pi < productCount)
            {
               var variantCount:int = this.GetIntText(cursor + 3,0);
               cursor += 4 + variantCount * 5;
               pi++;
            }
            ci++;
         }
         return cursor;
      }
      
      private function LinkedV2PoseStatesBase() : int
      {
         if(this.mLinkedDrawerLayer != null)
         {
            var _loc8_:* = this.mLinkedDrawerLayer["fgehPoseStatesOffsetR77"];
            if(_loc8_ != null)
            {
               if(_loc8_["data"] === this.mData)
               {
                  return _loc8_["value"];
               }
            }
         }
         var base:int = this.GetLinkedProductsV2Base();
         if(base < 0)
         {
            _loc8_ = -1;
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehPoseStatesOffsetR77"] = {
                  "data":this.mData,
                  "value":_loc8_
               };
            }
            return _loc8_;
         }
         var cursor:int = base + 3;
         var catalogCount:int = this.GetIntText(base + 2,0);
         var ci:int = 0;
         while(ci < catalogCount)
         {
            var productCount:int = this.GetIntText(cursor,0);
            cursor += 1;
            var pi:int = 0;
            while(pi < productCount)
            {
               var variantCount:int = this.GetIntText(cursor + 3,0);
               cursor += 4 + variantCount * 5;
               pi++;
            }
            ci++;
         }
         _loc8_ = cursor;
         if(this.mLinkedDrawerLayer != null)
         {
            this.mLinkedDrawerLayer["fgehPoseStatesOffsetR77"] = {
               "data":this.mData,
               "value":_loc8_
            };
         }
         return _loc8_;
      }
      
      private function LinkedV2PoseStateBase(param1:int) : int
      {
         var statesBase:int = this.LinkedV2PoseStatesBase();
         if(statesBase < 0 || param1 < 0)
         {
            return -1;
         }
         var poseCount:int = this.GetIntText(statesBase,0);
         if(param1 >= poseCount)
         {
            return -1;
         }
         return statesBase + 1 + param1 * 4;
      }
      
      private function GetLinkedV2PoseCatalogIndex(param1:int) : int
      {
         var base:int = this.LinkedV2PoseStateBase(param1);
         return base >= 0 ? this.GetIntText(base + 1,0) : 0;
      }
      
      private function GetLinkedV2SelectedCSV(param1:int) : String
      {
         var base:int = this.LinkedV2PoseStateBase(param1);
         return base >= 0 ? this.GetStringText(base + 3,"") : "";
      }
      
      private function GetLinkedV2SelectedLookup(param1:int) : Object
      {
         var lookup:Object;
         var csv:String;
         var values:Array;
         var i:int;
         var value:String;
         var poseKey:String = this.GetLinkedPoseName(param1);
         try
         {
            if(this.mLinkedV2SelectedLookupCache.hasOwnProperty(poseKey))
            {
               return this.mLinkedV2SelectedLookupCache[poseKey] as Object;
            }
         }
         catch(eCache:Error)
         {
         }
         lookup = {};
         csv = this.GetLinkedV2SelectedCSV(param1);
         if(csv != null && csv.length > 0)
         {
            values = csv.split(",");
            i = 0;
            while(i < values.length)
            {
               value = String(values[i]);
               if(value.length > 0)
               {
                  lookup[value] = true;
               }
               i++;
            }
         }
         try
         {
            this.mLinkedV2SelectedLookupCache[poseKey] = lookup;
         }
         catch(eStore:Error)
         {
         }
         return lookup;
      }
      
      private function CSVContainsId(param1:String, param2:String) : Boolean
      {
         if(param1 == null || param1.length == 0 || param2 == null || param2.length == 0)
         {
            return false;
         }
         var values:Array = param1.split(",");
         var i:int = 0;
         while(i < values.length)
         {
            if(String(values[i]) == param2)
            {
               return true;
            }
            i++;
         }
         return false;
      }
      
      private function LinkedProductsRowBase(param1:int) : int
      {
         var base:int = this.GetLinkedProductsBase();
         if(base < 0 || param1 < 0 || this.mData == null)
         {
            return -1;
         }
         var cursor:int = base + 3;
         var rowIndex:int = 0;
         while(rowIndex < param1)
         {
            if(this.mData.additional_texts == null || cursor + 1 >= this.mData.additional_texts.length)
            {
               return -1;
            }
            var productCount:int = this.GetIntText(cursor + 1,0);
            cursor += 2;
            var pi:int = 0;
            while(pi < productCount)
            {
               var variantCount:int = this.GetIntText(cursor + 3,0);
               cursor += 4 + variantCount * 4;
               pi++;
            }
            rowIndex++;
         }
         return cursor;
      }
      
      private function GetLinkedProductCount(param1:int) : int
      {
         if(this.HasLinkedProductsV2Extension())
         {
            var catalogBase:int = this.LinkedV2CatalogBase(this.GetLinkedV2PoseCatalogIndex(param1));
            return catalogBase >= 0 ? this.GetIntText(catalogBase,0) : 0;
         }
         var base:int = this.LinkedProductsRowBase(param1);
         return base >= 0 ? this.GetIntText(base + 1,0) : 0;
      }
      
      private function LinkedProductBase(param1:int, param2:int) : int
      {
         if(this.mLinkedDrawerLayer != null)
         {
            var _loc13_:* = this.mLinkedDrawerLayer["fgehProductOffsetR77"];
            if(_loc13_ != null)
            {
               if(_loc13_["data"] === this.mData)
               {
                  if(_loc13_["row"] == param1)
                  {
                     if(_loc13_["product"] == param2)
                     {
                        return _loc13_["value"];
                     }
                  }
               }
            }
         }
         if(this.HasLinkedProductsV2Extension())
         {
            var catalogBase:int = this.LinkedV2CatalogBase(this.GetLinkedV2PoseCatalogIndex(param1));
            if(catalogBase < 0 || param2 < 0)
            {
               _loc13_ = -1;
               if(this.mLinkedDrawerLayer != null)
               {
                  this.mLinkedDrawerLayer["fgehProductOffsetR77"] = {
                     "data":this.mData,
                     "value":_loc13_,
                     "row":param1,
                     "product":param2
                  };
               }
               return _loc13_;
            }
            var countV2:int = this.GetIntText(catalogBase,0);
            if(param2 >= countV2)
            {
               _loc13_ = -1;
               if(this.mLinkedDrawerLayer != null)
               {
                  this.mLinkedDrawerLayer["fgehProductOffsetR77"] = {
                     "data":this.mData,
                     "value":_loc13_,
                     "row":param1,
                     "product":param2
                  };
               }
               return _loc13_;
            }
            var cursorV2:int = catalogBase + 1;
            var p2:int = 0;
            while(p2 < param2)
            {
               var vc2:int = this.GetIntText(cursorV2 + 3,0);
               cursorV2 += 4 + vc2 * 5;
               p2++;
            }
            _loc13_ = cursorV2;
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehProductOffsetR77"] = {
                  "data":this.mData,
                  "value":_loc13_,
                  "row":param1,
                  "product":param2
               };
            }
            return _loc13_;
         }
         var rowBase:int = this.LinkedProductsRowBase(param1);
         if(rowBase < 0 || param2 < 0)
         {
            _loc13_ = -1;
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehProductOffsetR77"] = {
                  "data":this.mData,
                  "value":_loc13_,
                  "row":param1,
                  "product":param2
               };
            }
            return _loc13_;
         }
         var count:int = this.GetIntText(rowBase + 1,0);
         if(param2 >= count)
         {
            _loc13_ = -1;
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehProductOffsetR77"] = {
                  "data":this.mData,
                  "value":_loc13_,
                  "row":param1,
                  "product":param2
               };
            }
            return _loc13_;
         }
         var cursor:int = rowBase + 2;
         var pi:int = 0;
         while(pi < param2)
         {
            var variantCount:int = this.GetIntText(cursor + 3,0);
            cursor += 4 + variantCount * 4;
            pi++;
         }
         _loc13_ = cursor;
         if(this.mLinkedDrawerLayer != null)
         {
            this.mLinkedDrawerLayer["fgehProductOffsetR77"] = {
               "data":this.mData,
               "value":_loc13_,
               "row":param1,
               "product":param2
            };
         }
         return _loc13_;
      }
      
      private function GetLinkedProductField(param1:int, param2:int, param3:int, param4:String = "") : String
      {
         if(this.GetLinkedPoseName(param1) == "root_outfits")
         {
            if(this.mcContent.fgehR29Owner == this.mData)
            {
               if(this.mcContent.hasOwnProperty("fgehR29Swatches" + param2))
               {
                  var _loc10_:Array = this.mcContent["fgehR29Swatches" + param2];
                  if(_loc10_ != null)
                  {
                     if(_loc10_.fgehR29Owner == this.mData)
                     {
                        if(param3 == 3)
                        {
                           return _loc10_.length;
                        }
                     }
                  }
               }
            }
         }
         var base:int = this.LinkedProductBase(param1,param2);
         return base >= 0 ? this.GetStringText(base + param3,param4) : param4;
      }
      
      private function GetLinkedProductVariantField(param1:int, param2:int, param3:int, param4:int, param5:String = "") : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function FindLinkedProductForResource(param1:int, param2:int) : int
      {
         if(this.HasLinkedProductsV2Extension())
         {
            return -1;
         }
         var productCount:int = this.GetLinkedProductCount(param1);
         var pi:int = 0;
         while(pi < productCount)
         {
            var variantCount:int = int(this.GetLinkedProductField(param1,pi,3,"0"));
            var vi:int = 0;
            while(vi < variantCount)
            {
               if(int(this.GetLinkedProductVariantField(param1,pi,vi,0,"-1")) == param2)
               {
                  return pi;
               }
               vi++;
            }
            pi++;
         }
         return -1;
      }
      
      private function GetLinkedObjectProductsBase() : int
      {
         return this.FindPayloadMagic(LINKED_OBJECT_PRODUCTS_MAGIC);
      }
      
      private function HasLinkedObjectProductsExtension() : Boolean
      {
         return this.GetLinkedObjectProductsBase() >= 0;
      }
      
      private function LinkedObjectProductsRowBase(param1:int) : int
      {
         var base:int = this.GetLinkedObjectProductsBase();
         if(base < 0 || param1 < 0 || this.mData == null)
         {
            return -1;
         }
         var cursor:int = base + 3;
         var rowIndex:int = 0;
         while(rowIndex < param1)
         {
            var productCount:int = this.GetIntText(cursor + 1,0);
            cursor += 2;
            var pi:int = 0;
            while(pi < productCount)
            {
               var variantCount:int = this.GetIntText(cursor + 3,0);
               cursor += 4 + variantCount * 5;
               pi++;
            }
            rowIndex++;
         }
         return cursor;
      }
      
      private function GetLinkedObjectProductCount(param1:int) : int
      {
         var base:int = this.LinkedObjectProductsRowBase(param1);
         return base >= 0 ? this.GetIntText(base + 1,0) : 0;
      }
      
      private function LinkedObjectProductBase(param1:int, param2:int) : int
      {
         var rowBase:int = this.LinkedObjectProductsRowBase(param1);
         if(rowBase < 0 || param2 < 0)
         {
            return -1;
         }
         var count:int = this.GetIntText(rowBase + 1,0);
         if(param2 >= count)
         {
            return -1;
         }
         var cursor:int = rowBase + 2;
         var pi:int = 0;
         while(pi < param2)
         {
            var variantCount:int = this.GetIntText(cursor + 3,0);
            cursor += 4 + variantCount * 5;
            pi++;
         }
         return cursor;
      }
      
      private function GetLinkedObjectProductField(param1:int, param2:int, param3:int, param4:String = "") : String
      {
         var base:int = this.LinkedObjectProductBase(param1,param2);
         return base >= 0 ? this.GetStringText(base + param3,param4) : param4;
      }
      
      private function GetLinkedObjectProductVariantField(param1:int, param2:int, param3:int, param4:int, param5:String = "") : String
      {
         var base:int = this.LinkedObjectProductBase(param1,param2);
         if(base < 0 || param3 < 0)
         {
            return param5;
         }
         var count:int = this.GetIntText(base + 3,0);
         if(param3 >= count)
         {
            return param5;
         }
         return this.GetStringText(base + 4 + param3 * 5 + param4,param5);
      }
      
      private function FindLinkedObjectProductForResource(param1:int, param2:int) : int
      {
         if(!this.HasLinkedObjectProductsExtension())
         {
            return -1;
         }
         var productCount:int = this.GetLinkedObjectProductCount(param1);
         var pi:int = 0;
         while(pi < productCount)
         {
            var variantCount:int = int(this.GetLinkedObjectProductField(param1,pi,3,"0"));
            var vi:int = 0;
            while(vi < variantCount)
            {
               if(int(this.GetLinkedObjectProductVariantField(param1,pi,vi,0,"-1")) == param2)
               {
                  return pi;
               }
               vi++;
            }
            pi++;
         }
         return -1;
      }
      
      private function GetFilteredLinkedObjectProductIndices() : Array
      {
         var result:Array = [];
         if(this.mLinkedTypeFilter != "object" || !this.HasLinkedObjectProductsExtension())
         {
            return result;
         }
         var productCount:int = this.GetLinkedObjectProductCount(this.mLinkedActiveIndex);
         var pi:int = 0;
         while(pi < productCount)
         {
            var variantCount:int = int(this.GetLinkedObjectProductField(this.mLinkedActiveIndex,pi,3,"0"));
            var vi:int = 0;
            var visible:Boolean = false;
            while(vi < variantCount)
            {
               var origin:String = this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,pi,vi,4,"external");
               if(this.mLinkedOriginFilter == "all" || this.mLinkedOriginFilter == origin)
               {
                  visible = true;
                  break;
               }
               vi++;
            }
            if(visible)
            {
               result.push(pi);
            }
            pi++;
         }
         return result;
      }
      
      private function IsObjectProductCardMode() : Boolean
      {
         return this.mLinkedInspectorExpanded && this.mLinkedTypeFilter == "object" && this.HasLinkedObjectProductsExtension() && this.GetLinkedObjectProductCount(this.mLinkedActiveIndex) > 0;
      }
      
      private function GetLinkedObjectProductEnabledVariant(param1:int) : int
      {
         var count:int = int(this.GetLinkedObjectProductField(this.mLinkedActiveIndex,param1,3,"0"));
         var vi:int = 0;
         while(vi < count)
         {
            var resourceIndex:int = int(this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,param1,vi,0,"-1"));
            if(resourceIndex >= 0 && this.IsLinkedResourceEnabled(this.mLinkedActiveIndex,resourceIndex))
            {
               return vi;
            }
            vi++;
         }
         return -1;
      }
      
      private function IsLinkedResourceVisibleForCurrentOrigin(param1:int) : Boolean
      {
         if(param1 < 0)
         {
            return false;
         }
         if(this.mLinkedOriginFilter == "all")
         {
            return true;
         }
         return this.LinkedResourceOrigin(this.mLinkedActiveIndex,param1) == this.mLinkedOriginFilter;
      }
      
      private function GetFilteredLinkedProductIndices() : Array
      {
         if(this.mLinkedDrawerLayer != null)
         {
            var _loc9_:* = this.mLinkedDrawerLayer["fgehFilterCacheR74"];
            if(_loc9_ != null)
            {
               if(_loc9_["data"] === this.mData)
               {
                  if(_loc9_["row"] === this.mLinkedActiveIndex)
                  {
                     if(_loc9_["type"] === this.mLinkedTypeFilter)
                     {
                        if(_loc9_["origin"] === this.mLinkedOriginFilter)
                        {
                           return _loc9_["ids"];
                        }
                     }
                  }
               }
            }
         }
         var result:Array = [];
         if(this.mLinkedTypeFilter != "cas" || !this.HasLinkedProductsExtension())
         {
            var _loc10_:Array = result;
            §§push(_loc10_);
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehFilterCacheR74"] = {
                  "data":this.mData,
                  "row":this.mLinkedActiveIndex,
                  "type":this.mLinkedTypeFilter,
                  "origin":this.mLinkedOriginFilter,
                  "ids":_loc10_
               };
            }
            return §§pop();
         }
         var productCount:int = this.GetLinkedProductCount(this.mLinkedActiveIndex);
         var pi:int = 0;
         while(pi < productCount)
         {
            var variantCount:int = int(this.GetLinkedProductField(this.mLinkedActiveIndex,pi,3,"0"));
            var vi:int = 0;
            var visible:Boolean = false;
            while(vi < variantCount)
            {
               if(this.HasLinkedProductsV2Extension())
               {
                  var origin:String = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,pi,vi,5,"external");
                  if(this.mLinkedOriginFilter == "all" || origin == this.mLinkedOriginFilter)
                  {
                     visible = true;
                     break;
                  }
               }
               else
               {
                  var resourceIndex:int = int(this.GetLinkedProductVariantField(this.mLinkedActiveIndex,pi,vi,0,"-1"));
                  if(this.IsLinkedResourceVisibleForCurrentOrigin(resourceIndex))
                  {
                     visible = true;
                     break;
                  }
               }
               vi++;
            }
            if(visible)
            {
               result.push(pi);
            }
            pi++;
         }
         _loc10_ = result;
         §§push(_loc10_);
         if(this.mLinkedDrawerLayer != null)
         {
            this.mLinkedDrawerLayer["fgehFilterCacheR74"] = {
               "data":this.mData,
               "row":this.mLinkedActiveIndex,
               "type":this.mLinkedTypeFilter,
               "origin":this.mLinkedOriginFilter,
               "ids":_loc10_
            };
         }
         return §§pop();
      }
      
      private function IsCASProductCardMode() : Boolean
      {
         return this.mLinkedInspectorExpanded && this.mLinkedTypeFilter == "cas" && this.HasLinkedProductsExtension() && this.GetLinkedProductCount(this.mLinkedActiveIndex) > 0;
      }
      
      private function LinkedProductChoiceKey(param1:int) : String
      {
         return this.GetLinkedPoseName(this.mLinkedActiveIndex) + "|" + this.GetLinkedProductField(this.mLinkedActiveIndex,param1,0,String(param1));
      }
      
      private function GetLinkedProductChosenVariant(param1:int) : int
      {
         var key:String;
         var stored:int;
         var count:int = int(this.GetLinkedProductField(this.mLinkedActiveIndex,param1,3,"0"));
         if(count <= 0)
         {
            return 0;
         }
         key = this.LinkedProductChoiceKey(param1);
         try
         {
            if(this.mLinkedProductPreviewChoice.hasOwnProperty(key))
            {
               stored = int(this.mLinkedProductPreviewChoice[key]);
               if(stored >= 0 && stored < count)
               {
                  return stored;
               }
            }
         }
         catch(eStored:Error)
         {
         }
         return 0;
      }
      
      private function SetLinkedProductChosenVariant(param1:int, param2:int) : void
      {
         try
         {
            this.mLinkedProductPreviewChoice[this.LinkedProductChoiceKey(param1)] = param2;
         }
         catch(e:Error)
         {
         }
      }
      
      private function LinkedResourceKey(param1:int, param2:int) : String
      {
         return this.GetLinkedPoseName(param1) + "|" + this.GetLinkedResourceField(param1,param2,0,"") + "|" + this.GetLinkedResourceField(param1,param2,1,"0");
      }
      
      private function LinkedCASRowKey(param1:int) : String
      {
         return this.GetLinkedPoseName(param1);
      }
      
      private function GetLinkedCASRowEpoch(param1:int) : int
      {
         var rowKey:String = this.LinkedCASRowKey(param1);
         try
         {
            if(this.mLinkedCASRowEpoch.hasOwnProperty(rowKey))
            {
               return int(this.mLinkedCASRowEpoch[rowKey]);
            }
         }
         catch(e:Error)
         {
         }
         return 0;
      }
      
      private function BumpLinkedCASRowEpoch(param1:int) : int
      {
         var rowKey:String = this.LinkedCASRowKey(param1);
         var nextEpoch:int = this.GetLinkedCASRowEpoch(param1) + 1;
         try
         {
            this.mLinkedCASRowEpoch[rowKey] = nextEpoch;
         }
         catch(e:Error)
         {
         }
         return nextEpoch;
      }
      
      private function LinkedCASItemKey(param1:int, param2:String) : String
      {
         return this.GetLinkedPoseName(param1) + "|cas|" + this.GetLinkedCASRowEpoch(param1) + "|" + param2;
      }
      
      private function GetLinkedCASRowSnapshot(param1:int) : Object
      {
         var rowKey:String = this.LinkedCASRowKey(param1);
         try
         {
            if(this.mLinkedCASRowSnapshotOverrides.hasOwnProperty(rowKey))
            {
               return this.mLinkedCASRowSnapshotOverrides[rowKey] as Object;
            }
         }
         catch(e:Error)
         {
         }
         return null;
      }
      
      private function SetLinkedCASRowSnapshotOverride(param1:int, param2:Object) : void
      {
         var key:String;
         var rowKey:String = this.LinkedCASRowKey(param1);
         var snapshot:Object = {};
         if(param2 != null)
         {
            try
            {
               for(key in param2)
               {
                  if(param2[key] === true)
                  {
                     snapshot[key] = true;
                  }
               }
            }
            catch(eCopy:Error)
            {
            }
         }
         this.BumpLinkedCASRowEpoch(param1);
         try
         {
            this.mLinkedCASRowSnapshotOverrides[rowKey] = snapshot;
         }
         catch(eStore:Error)
         {
         }
      }
      
      private function IsLinkedCASItemEnabled(param1:int, param2:String) : Boolean
      {
         var key:String;
         var snapshot:Object;
         var lookup:Object;
         var count:int;
         var i:int;
         if(param2 == null || param2.length == 0 || param2 == "0")
         {
            return false;
         }
         key = this.LinkedCASItemKey(param1,param2);
         try
         {
            if(this.mLinkedCASSelectionOverrides.hasOwnProperty(key))
            {
               return Boolean(this.mLinkedCASSelectionOverrides[key]);
            }
         }
         catch(eOverride:Error)
         {
         }
         snapshot = this.GetLinkedCASRowSnapshot(param1);
         if(snapshot != null)
         {
            try
            {
               return snapshot.hasOwnProperty(param2) && snapshot[param2] === true;
            }
            catch(eSnapshot:Error)
            {
               return false;
            }
         }
         else
         {
            if(!this.HasLinkedProductsV2Extension())
            {
               count = this.GetLinkedResourceCount(param1);
               i = 0;
               while(i < count)
               {
                  if(this.GetLinkedResourceField(param1,i,0,"") == "cas" && this.GetLinkedResourceField(param1,i,1,"0") == param2)
                  {
                     return this.IsLinkedResourceEnabled(param1,i);
                  }
                  i++;
               }
               return false;
            }
            lookup = this.GetLinkedV2SelectedLookup(param1);
            try
            {
               return lookup != null && lookup.hasOwnProperty(param2) && lookup[param2] === true;
            }
            catch(eLookup:Error)
            {
               return false;
            }
         }
      }
      
      private function SetLinkedCASItemOverride(param1:int, param2:String, param3:Boolean) : void
      {
         if(param2 == null || param2.length == 0 || param2 == "0")
         {
            return;
         }
         try
         {
            this.mLinkedCASSelectionOverrides[this.LinkedCASItemKey(param1,param2)] = param3;
         }
         catch(e:Error)
         {
         }
      }
      
      private function GetLinkedObjectRowSnapshot(param1:int) : Object
      {
         var rowKey:String = this.LinkedCASRowKey(param1);
         try
         {
            if(this.mLinkedObjectRowSnapshotOverrides.hasOwnProperty(rowKey))
            {
               return this.mLinkedObjectRowSnapshotOverrides[rowKey] as Object;
            }
         }
         catch(e:Error)
         {
         }
         return null;
      }
      
      private function SetLinkedObjectRowSnapshotOverride(param1:int, param2:Object) : void
      {
         var key:String;
         var rowKey:String = this.LinkedCASRowKey(param1);
         var snapshot:Object = {};
         if(param2 != null)
         {
            try
            {
               for(key in param2)
               {
                  if(param2[key] === true)
                  {
                     snapshot[key] = true;
                  }
               }
            }
            catch(eCopy:Error)
            {
            }
         }
         try
         {
            this.mLinkedObjectRowSnapshotOverrides[rowKey] = snapshot;
         }
         catch(eStore:Error)
         {
         }
      }
      
      private function LinkedAutoKey(param1:int, param2:String) : String
      {
         return this.GetLinkedPoseName(param1) + "|" + param2;
      }
      
      private function IsLinkedResourceEnabled(param1:int, param2:int) : Boolean
      {
         var objectSnapshot:Object;
         var objectId:String;
         var key:String = this.LinkedResourceKey(param1,param2);
         try
         {
            if(this.mLinkedResourceOverrides.hasOwnProperty(key))
            {
               return Boolean(this.mLinkedResourceOverrides[key]);
            }
         }
         catch(e:Error)
         {
         }
         if(this.GetLinkedResourceField(param1,param2,0,"") == "object")
         {
            objectSnapshot = this.GetLinkedObjectRowSnapshot(param1);
            if(objectSnapshot != null)
            {
               objectId = this.GetLinkedResourceField(param1,param2,1,"0");
               try
               {
                  return objectSnapshot.hasOwnProperty(objectId) && objectSnapshot[objectId] === true;
               }
               catch(eSnapshot:Error)
               {
                  return false;
               }
            }
         }
         return this.GetLinkedResourceField(param1,param2,4,"0") == "1";
      }
      
      private function IsLinkedAutoEnabled(param1:int, param2:String) : Boolean
      {
         var base:int;
         var key:String = this.LinkedAutoKey(param1,param2);
         try
         {
            if(this.mLinkedAutoOverrides.hasOwnProperty(key))
            {
               return Boolean(this.mLinkedAutoOverrides[key]);
            }
         }
         catch(e:Error)
         {
         }
         base = this.LinkedRowBase(param1);
         if(base < 0)
         {
            return true;
         }
         return this.GetStringText(base + (param2 == "object" ? 2 : 1),"1") == "1";
      }
      
      private function IsSharedRootGroupBrowse() : Boolean
      {
         var kind:String = this.GetV7ViewKind();
         return kind == "root_grouped_packs" || kind == "root_fav_pack_groups" || kind == "root_fav_pose_groups";
      }
      
      private function IsSharedRootGroupEdit() : Boolean
      {
         var kind:String = this.GetV7ViewKind();
         return kind == "root_grouped_packs_edit" || kind == "root_fav_pack_groups_edit" || kind == "root_fav_pose_groups_edit";
      }
      
      private function IsOuterGroupRemoveManageMode() : Boolean
      {
         return this.HasV7Extension() && this.GetV7ViewKind() == "root_grouped_packs_edit";
      }
      
      private function SharedRootGroupTitle() : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function SharedRootGroupSubTitle() : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function GetAfterGroupBase() : int
      {
         return this.GetExtensionBase() + 5 + this.GetV7GroupCount();
      }
      
      private function HasMemberEditExtension() : Boolean
      {
         if(!this.HasV7Extension())
         {
            return false;
         }
         var base:int = this.GetAfterGroupBase();
         return this.GetStringText(base,"") == MEMBER_EDIT_MAGIC;
      }
      
      private function GetMemberEditGroupIndex() : int
      {
         if(!this.HasMemberEditExtension())
         {
            return -1;
         }
         return this.GetIntText(this.GetAfterGroupBase() + 1,-1);
      }
      
      private function GetMemberSelectedFlags() : String
      {
         if(!this.HasMemberEditExtension())
         {
            return "";
         }
         return this.GetStringText(this.GetAfterGroupBase() + 2,"");
      }
      
      private function IsMemberSelected(param1:int) : Boolean
      {
         var key:String;
         var flags:String;
         try
         {
            key = String(param1);
            if(this.mMemberSelectionOverrides.hasOwnProperty(key))
            {
               return Boolean(this.mMemberSelectionOverrides[key]);
            }
         }
         catch(eOverride:Error)
         {
         }
         flags = this.GetMemberSelectedFlags();
         return param1 >= 0 && param1 < flags.length && flags.charAt(param1) == "1";
      }
      
      private function SetLocalMemberSelected(param1:int, param2:Boolean) : void
      {
         try
         {
            this.mMemberSelectionOverrides[String(param1)] = param2;
         }
         catch(e:Error)
         {
         }
      }
      
      private function IsAnyMemberEditMode() : Boolean
      {
         return this.HasMemberEditExtension() && (this.GetV7ViewKind() == "pack_detail_group_edit" || this.IsSharedRootGroupEdit());
      }
      
      private function MemberEditMode() : String
      {
         var kind:String = this.GetV7ViewKind();
         if(kind == "pack_detail_group_edit")
         {
            return "inner";
         }
         if(kind == "root_grouped_packs_edit")
         {
            return "outer";
         }
         if(kind == "root_fav_pack_groups_edit")
         {
            return "fav_pack";
         }
         if(kind == "root_fav_pose_groups_edit")
         {
            return "fav_pose";
         }
         return "";
      }
      
      private function MemberEditGroupName() : String
      {
         if(this.GetV7ViewKind() == "pack_detail_group_edit")
         {
            var innerIndex:int = this.GetMemberEditGroupIndex();
            return innerIndex >= 0 ? this.GetV7GroupName(innerIndex) : "";
         }
         var outerIndex:int = this.GetV7ActiveGroupIndex();
         return outerIndex >= 0 ? this.GetV7GroupName(outerIndex) : "";
      }
      
      private function MemberEditItemValue(param1:int) : String
      {
         var key:String = this.GetEditInfoKey(param1);
         if(key.indexOf("pose_") == 0)
         {
            return key.substr(5);
         }
         if(key.indexOf("pack_") == 0)
         {
            return key.substr(5);
         }
         return "";
      }
      
      private function PostMemberToggleValues(param1:Array) : void
      {
         if(param1 == null || param1.length <= 0)
         {
            return;
         }
         var mode:String = this.MemberEditMode();
         var groupName:String = this.MemberEditGroupName();
         if(!mode || !groupName)
         {
            return;
         }
         CommunicationManager.PostServerCommand("fgeh.group_toggle_many",encodeURIComponent(mode),encodeURIComponent(groupName),"",encodeURIComponent(param1.join("\n")));
      }
      
      private function ToggleMemberIndexLocal(param1:int, param2:Boolean = true) : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function GetOuterGroupBase() : int
      {
         var base:int = this.GetAfterGroupBase();
         if(this.HasMemberEditExtension())
         {
            base += 3;
         }
         return base;
      }
      
      private function HasOuterGroupExtension() : Boolean
      {
         if(!this.HasV7Extension())
         {
            return false;
         }
         return this.GetStringText(this.GetOuterGroupBase(),"") == OUTER_GROUP_MAGIC;
      }
      
      private function GetOuterGroupCount() : int
      {
         if(!this.HasOuterGroupExtension())
         {
            return 0;
         }
         return this.GetIntText(this.GetOuterGroupBase() + 1,0);
      }
      
      private function GetOuterGroupName(param1:int) : String
      {
         if(!this.HasOuterGroupExtension() || param1 < 0)
         {
            return "";
         }
         return this.GetStringText(this.GetOuterGroupBase() + 2 + param1 * 2,"");
      }
      
      private function IsOuterGroupSelected(param1:int) : Boolean
      {
         if(!this.HasOuterGroupExtension() || param1 < 0)
         {
            return false;
         }
         return this.GetStringText(this.GetOuterGroupBase() + 3 + param1 * 2,"0") == "1";
      }
      
      private function HideLegacyRootSidebar() : void
      {
         if(this.mcContent == null)
         {
            return;
         }
         var libraryButton:DisplayObject = this.Child("fgehLibraryButton");
         if(libraryButton != null)
         {
            libraryButton.visible = false;
            libraryButton.mouseEnabled = false;
         }
         var modeButton:DisplayObject = this.Child("fgehModeButton");
         if(modeButton != null)
         {
            modeButton.visible = false;
            modeButton.mouseEnabled = false;
         }
         var libraryLabel:DisplayObject = this.Child("fgehLibraryLabel");
         if(libraryLabel != null)
         {
            libraryLabel.visible = false;
            libraryLabel.mouseEnabled = false;
         }
         var modeLabel:DisplayObject = this.Child("fgehModeLabel");
         if(modeLabel != null)
         {
            modeLabel.visible = false;
            modeLabel.mouseEnabled = false;
         }
      }
      
      private function HideLegacySidebarTextRecursive(param1:DisplayObject) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RestoreKnownCardText() : void
      {
         var i:int = 1;
         while(i <= this.ActiveItemsPerPage())
         {
            this.RestoreTextTree(this.Child("fgehPackName" + i));
            this.RestoreTextTree(this.Child("fgehPackCreator" + i));
            this.RestoreTextTree(this.Child("fgehPackCount" + i));
            i++;
         }
      }
      
      private function RestoreTextTree(param1:DisplayObject) : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.visible = true;
         if(param1 is TextField)
         {
            var field:TextField = param1 as TextField;
            field.visible = true;
            if(field.width < 105)
            {
               field.width = 125;
            }
            return;
         }
         if(param1 is MovieClip)
         {
            var clip:MovieClip = param1 as MovieClip;
            var childIndex:int = 0;
            while(childIndex < clip.numChildren)
            {
               this.RestoreTextTree(clip.getChildAt(childIndex));
               childIndex++;
            }
         }
      }
      
      private function StyleExistingTextTree(param1:DisplayObject, param2:Number, param3:uint, param4:Boolean) : void
      {
         var field:TextField;
         var format:TextFormat;
         var clip:MovieClip;
         var i:int;
         if(param1 == null)
         {
            return;
         }
         if(param1 is TextField)
         {
            field = param1 as TextField;
            format = null;
            try
            {
               format = field.getTextFormat();
            }
            catch(e:Error)
            {
               format = null;
            }
            if(format == null)
            {
               format = new TextFormat();
            }
            format.size = param2;
            format.color = param3;
            format.bold = param4;
            field.defaultTextFormat = format;
            try
            {
               field.setTextFormat(format);
            }
            catch(e2:Error)
            {
            }
            if(field.width < 128)
            {
               field.width = 138;
            }
            return;
         }
         if(param1 is MovieClip)
         {
            clip = param1 as MovieClip;
            i = 0;
            while(i < clip.numChildren)
            {
               this.StyleExistingTextTree(clip.getChildAt(i),param2,param3,param4);
               i++;
            }
         }
      }
      
      private function BuildGlobalPlumbobWidget() : void
      {
         if(this.mcContent == null || this.mGlobalPlumbobLayer != null)
         {
            return;
         }
         this.mGlobalPlumbobLayer = new MovieClip();
         this.mGlobalPlumbobLayer.name = "fgehGlobalPlumbobWidget";
         this.mGlobalPlumbobLayer.x = -468;
         this.mGlobalPlumbobLayer.y = -307;
         this.mGlobalPlumbobLayer.mouseEnabled = false;
         this.mGlobalPlumbobLayer.mouseChildren = true;
         this.mGlobalPlumbobVisual = new Sprite();
         this.mGlobalPlumbobVisual.mouseEnabled = false;
         this.mGlobalPlumbobLayer.addChild(this.mGlobalPlumbobVisual);
         this.mGlobalPlumbobHit = new Sprite();
         this.mGlobalPlumbobHit.buttonMode = true;
         this.mGlobalPlumbobHit.useHandCursor = true;
         this.mGlobalPlumbobHit.graphics.beginFill(65280,0.01);
         this.mGlobalPlumbobHit.graphics.moveTo(22,-3);
         this.mGlobalPlumbobHit.graphics.lineTo(39,43);
         this.mGlobalPlumbobHit.graphics.lineTo(22,89);
         this.mGlobalPlumbobHit.graphics.lineTo(5,43);
         this.mGlobalPlumbobHit.graphics.lineTo(22,-3);
         this.mGlobalPlumbobHit.graphics.endFill();
         this.mGlobalPlumbobHit.addEventListener(MouseEvent.CLICK,this.OnGlobalPlumbobClick,false,0,true);
         this.mGlobalPlumbobHit.addEventListener(MouseEvent.ROLL_OVER,this.OnGlobalPlumbobOver,false,0,true);
         this.mGlobalPlumbobHit.addEventListener(MouseEvent.ROLL_OUT,this.OnGlobalPlumbobOut,false,0,true);
         this.mGlobalPlumbobLayer.addChild(this.mGlobalPlumbobHit);
         this.mcContent.addChild(this.mGlobalPlumbobLayer);
         this.RefreshGlobalPlumbobWidget();
      }
      
      private function DrawGlobalPlumbobFacet(g:Object, points:Array, color:uint, alpha:Number = 1) : void
      {
         if(g == null || points == null || points.length < 6)
         {
            return;
         }
         g.beginFill(color,alpha);
         g.moveTo(Number(points[0]),Number(points[1]));
         var i:int = 2;
         while(i + 1 < points.length)
         {
            g.lineTo(Number(points[i]),Number(points[i + 1]));
            i += 2;
         }
         g.lineTo(Number(points[0]),Number(points[1]));
         g.endFill();
      }
      
      private function RefreshGlobalPlumbobWidget() : void
      {
         var theme:Object;
         var enabled:Boolean;
         var hover:Boolean;
         var light:uint;
         var mid:uint;
         var baseColor:uint;
         var dark:uint;
         var outline:uint;
         var v:Sprite;
         var cx:Number;
         var topY:Number;
         var midY:Number;
         var bottomY:Number;
         var leftX:Number;
         var rightX:Number;
         var seamL:Number;
         var seamR:Number;
         this.BuildGlobalPlumbobWidget();
         if(this.mGlobalPlumbobLayer == null || this.mGlobalPlumbobVisual == null)
         {
            return;
         }
         theme = this.GetGlobalPlumbobTheme();
         enabled = this.mGlobalPlumbobEnabled;
         hover = this.mGlobalPlumbobHover;
         light = uint(enabled ? theme.onLight : theme.offLight);
         mid = uint(enabled ? theme.onMid : theme.offMid);
         baseColor = uint(enabled ? theme.onBase : theme.offBase);
         dark = uint(enabled ? theme.onDark : theme.offDark);
         outline = uint(enabled ? theme.onOutline : theme.offOutline);
         v = this.mGlobalPlumbobVisual;
         v.graphics.clear();
         v.alpha = enabled ? 1 : 0.72;
         v.scaleX = v.scaleY = hover ? 1.07 : 1;
         v.x = hover ? -1.5 : 0;
         v.y = hover ? -2.5 : 0;
         cx = 22;
         topY = 0;
         midY = 43;
         bottomY = 86;
         leftX = 5;
         rightX = 39;
         seamL = 18;
         seamR = 26;
         this.DrawGlobalPlumbobFacet(v.graphics,[cx,topY,leftX,midY,seamL,midY],light,1);
         this.DrawGlobalPlumbobFacet(v.graphics,[cx,topY,seamL,midY,seamR,midY],mid,0.9);
         this.DrawGlobalPlumbobFacet(v.graphics,[cx,topY,seamR,midY,rightX,midY],mid,1);
         this.DrawGlobalPlumbobFacet(v.graphics,[leftX,midY,cx,bottomY,seamL,midY],baseColor,1);
         this.DrawGlobalPlumbobFacet(v.graphics,[seamL,midY,cx,bottomY,seamR,midY],baseColor,0.88);
         this.DrawGlobalPlumbobFacet(v.graphics,[seamR,midY,cx,bottomY,rightX,midY],dark,1);
         v.graphics.lineStyle(1.2,outline,enabled ? 0.86 : 0.6);
         v.graphics.moveTo(cx,topY);
         v.graphics.lineTo(leftX,midY);
         v.graphics.lineTo(cx,bottomY);
         v.graphics.lineTo(rightX,midY);
         v.graphics.lineTo(cx,topY);
         v.graphics.lineStyle(0.65,outline,enabled ? 0.2 : 0.14);
         v.graphics.moveTo(leftX,midY);
         v.graphics.lineTo(rightX,midY);
         v.graphics.moveTo(cx,topY);
         v.graphics.lineTo(seamL,midY);
         v.graphics.lineTo(cx,bottomY);
         v.graphics.moveTo(cx,topY);
         v.graphics.lineTo(seamR,midY);
         v.graphics.lineTo(cx,bottomY);
         if(!enabled)
         {
            v.graphics.lineStyle(3.5,uint(theme.slash),0.9);
            v.graphics.moveTo(9,23);
            v.graphics.lineTo(35,63);
         }
         this.mGlobalPlumbobLayer.visible = this.HasV7Extension();
         try
         {
            this.mcContent.setChildIndex(this.mGlobalPlumbobLayer,this.mcContent.numChildren - 1);
         }
         catch(e:Error)
         {
         }
      }
      
      private function OnGlobalPlumbobClick(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mGlobalPlumbobEnabled = !this.mGlobalPlumbobEnabled;
         this.RefreshGlobalPlumbobWidget();
         CommunicationManager.PostServerCommand("fgeh.headline_widget_toggle");
      }
      
      private function OnGlobalPlumbobOver(param1:MouseEvent) : void
      {
         this.mGlobalPlumbobHover = true;
         this.RefreshGlobalPlumbobWidget();
      }
      
      private function OnGlobalPlumbobOut(param1:MouseEvent) : void
      {
         this.mGlobalPlumbobHover = false;
         this.RefreshGlobalPlumbobWidget();
      }
      
      private function BuildHeaderPortrait() : void
      {
         if(this.mcContent == null || this.mHeaderPortraitLayer != null)
         {
            return;
         }
         this.mHeaderPortraitLayer = new MovieClip();
         this.mHeaderPortraitLayer.name = "fgehHeaderPortraitSuppression";
         this.mHeaderPortraitLayer.mouseEnabled = false;
         this.mHeaderPortraitLayer.mouseChildren = false;
         this.mHeaderPortraitLayer.x = -500;
         this.mHeaderPortraitLayer.y = -315;
         this.mHeaderPortraitLayer.graphics.beginFill(15794175,1);
         this.mHeaderPortraitLayer.graphics.drawRect(-6,-5,150,72);
         this.mHeaderPortraitLayer.graphics.endFill();
         this.mHeaderPortraitImageLayer = null;
         this.mHeaderPortraitFrame = null;
         this.mHeaderPortraitIconInfo = null;
         this.mcContent.addChild(this.mHeaderPortraitLayer);
      }
      
      private function FindNativePortraitImageTarget(param1:Object) : Object
      {
         var names:Array;
         var name:String;
         var candidate:Object;
         var i:int;
         var nested:Object;
         var clip:MovieClip;
         var child:DisplayObject;
         var found:Object;
         if(param1 == null)
         {
            return null;
         }
         names = ["mcImage","image","mcThumbnail","mcIcon"];
         candidate = null;
         i = 0;
         while(i < names.length)
         {
            name = String(names[i]);
            try
            {
               candidate = param1[name];
            }
            catch(eProp:Error)
            {
               candidate = null;
            }
            if(candidate != null && candidate !== param1)
            {
               try
               {
                  if(candidate is IconComponent || candidate["LoadImage"] is Function || candidate["GetLoadedImage"] is Function)
                  {
                     return candidate;
                  }
               }
               catch(eCandidate:Error)
               {
               }
               nested = this.FindNativePortraitImageTarget(candidate);
               if(nested != null)
               {
                  return nested;
               }
            }
            i++;
         }
         clip = param1 as MovieClip;
         if(clip != null)
         {
            i = 0;
            while(i < clip.numChildren)
            {
               child = clip.getChildAt(i);
               if(child != null)
               {
                  found = this.FindNativePortraitImageTarget(child);
                  if(found != null)
                  {
                     return found;
                  }
               }
               i++;
            }
         }
         return null;
      }
      
      private function CenterNativePortraitClip(param1:DisplayObject, param2:Number, param3:Number, param4:Number) : void
      {
         var bounds:Rectangle;
         var side:Number;
         var scale:Number;
         if(param1 == null)
         {
            return;
         }
         bounds = null;
         try
         {
            bounds = param1.getBounds(param1);
         }
         catch(eBounds:Error)
         {
            bounds = null;
         }
         if(bounds == null || bounds.width <= 0 || bounds.height <= 0)
         {
            param1.x = param2 - param4 / 2;
            param1.y = param3 - param4 / 2;
            return;
         }
         side = Math.max(bounds.width,bounds.height);
         scale = side > 0 ? param4 / side : 1;
         if(!isFinite(scale) || scale <= 0)
         {
            scale = 1;
         }
         param1.scaleX *= scale;
         param1.scaleY *= scale;
         param1.x = param2 - (bounds.x + bounds.width / 2) * param1.scaleX;
         param1.y = param3 - (bounds.y + bounds.height / 2) * param1.scaleY;
      }
      
      private function PositionNativePortraitByImage(param1:DisplayObject, param2:DisplayObject, param3:Number, param4:Number, param5:Number) : void
      {
         var b:Rectangle;
         var side:Number;
         var sc:Number;
         if(param1 == null || param2 == null)
         {
            return;
         }
         b = null;
         try
         {
            b = param2.getBounds(param1);
         }
         catch(eBounds:Error)
         {
            b = null;
         }
         if(b == null || b.width <= 0 || b.height <= 0)
         {
            this.CenterNativePortraitClip(param1,param3,param4,param5);
            return;
         }
         side = Math.max(b.width,b.height);
         sc = side > 0 ? param5 / side : 1;
         if(!isFinite(sc) || sc <= 0)
         {
            sc = 1;
         }
         param1.scaleX = sc;
         param1.scaleY = sc;
         param1.x = param3 - (b.x + b.width / 2) * sc;
         param1.y = param4 - (b.y + b.height / 2) * sc;
      }
      
      private function TryLoadNativeFamilyTreePortrait(param1:Object) : Boolean
      {
         var PortraitClass:Class;
         var portrait:MovieClip;
         var imageTarget:Object;
         var imageDisplay:DisplayObject;
         if(param1 == null || this.mHeaderPortraitImageLayer == null)
         {
            return false;
         }
         PortraitClass = null;
         portrait = null;
         imageTarget = null;
         imageDisplay = null;
         try
         {
            PortraitClass = getDefinitionByName("library.FamilyTree.SimIconButton") as Class;
         }
         catch(eClass:Error)
         {
            PortraitClass = null;
         }
         if(PortraitClass == null)
         {
            return false;
         }
         try
         {
            portrait = new PortraitClass() as MovieClip;
         }
         catch(eNew:Error)
         {
            portrait = null;
         }
         if(portrait == null)
         {
            return false;
         }
         this.mHeaderPortraitImageLayer.addChild(portrait);
         portrait.mouseEnabled = false;
         portrait.mouseChildren = false;
         try
         {
            portrait.gotoAndStop("up");
         }
         catch(eUp:Error)
         {
            try
            {
               portrait.gotoAndStop(1);
            }
            catch(eFrame:Error)
            {
            }
         }
         imageTarget = this.FindNativePortraitImageTarget(portrait);
         if(imageTarget == null)
         {
            if(portrait.parent == this.mHeaderPortraitImageLayer)
            {
               this.mHeaderPortraitImageLayer.removeChild(portrait);
            }
            return false;
         }
         try
         {
            ImageUtils.LoadFromIconInfo(imageTarget,param1,ImageUtils.THUMBNAIL_SIZE_LARGE);
         }
         catch(eLoad:Error)
         {
            if(portrait.parent == this.mHeaderPortraitImageLayer)
            {
               this.mHeaderPortraitImageLayer.removeChild(portrait);
            }
            return false;
         }
         imageDisplay = imageTarget as DisplayObject;
         if(imageDisplay != null)
         {
            this.PositionNativePortraitByImage(portrait,imageDisplay,42,40,72);
         }
         else
         {
            this.CenterNativePortraitClip(portrait,42,40,82);
         }
         if(this.mHeaderPortraitFrame != null)
         {
            this.mHeaderPortraitFrame.visible = false;
         }
         return true;
      }
      
      private function TryLoadNativeSimSelectorPortrait(param1:Object) : Boolean
      {
         var ButtonClass:Class;
         var ThumbClass:Class;
         var nativeButton:MovieClip;
         var holder:MovieClip;
         var thumb:Object;
         var thumbDisplay:DisplayObject;
         var imageTarget:Object;
         var loadFromInfo:Function;
         if(param1 == null || this.mHeaderPortraitImageLayer == null)
         {
            return false;
         }
         ButtonClass = null;
         ThumbClass = null;
         nativeButton = null;
         holder = null;
         thumb = null;
         thumbDisplay = null;
         imageTarget = null;
         try
         {
            ButtonClass = getDefinitionByName("widgets.Gameplay.SimSelector.controls.SimSelectorButtonNormal") as Class;
         }
         catch(eButtonClass:Error)
         {
            ButtonClass = null;
         }
         if(ButtonClass == null)
         {
            return false;
         }
         try
         {
            nativeButton = new ButtonClass() as MovieClip;
         }
         catch(eNewButton:Error)
         {
            nativeButton = null;
         }
         if(nativeButton == null)
         {
            return false;
         }
         this.mHeaderPortraitImageLayer.addChild(nativeButton);
         nativeButton.mouseEnabled = false;
         nativeButton.mouseChildren = false;
         try
         {
            nativeButton.gotoAndStop("up");
         }
         catch(eUp:Error)
         {
            try
            {
               nativeButton.gotoAndStop(1);
            }
            catch(eFrame:Error)
            {
            }
         }
         try
         {
            holder = Object(nativeButton)["mcThumbnailHolder"] as MovieClip;
         }
         catch(eHolder:Error)
         {
            holder = null;
         }
         if(holder == null)
         {
            if(nativeButton.parent == this.mHeaderPortraitImageLayer)
            {
               this.mHeaderPortraitImageLayer.removeChild(nativeButton);
            }
            return false;
         }
         try
         {
            thumb = Object(nativeButton)["mcThumbnail"];
         }
         catch(eThumb:Error)
         {
            thumb = null;
         }
         if(thumb == null)
         {
            try
            {
               ThumbClass = getDefinitionByName("SimThumbnail") as Class;
            }
            catch(eThumbClass:Error)
            {
               ThumbClass = null;
            }
            if(ThumbClass != null)
            {
               try
               {
                  thumb = new ThumbClass();
                  thumbDisplay = thumb as DisplayObject;
                  if(thumbDisplay != null)
                  {
                     holder.addChild(thumbDisplay);
                  }
               }
               catch(eNewThumb:Error)
               {
                  thumb = null;
               }
            }
         }
         imageTarget = this.FindNativePortraitImageTarget(thumb);
         if(imageTarget == null)
         {
            imageTarget = this.FindNativePortraitImageTarget(holder);
         }
         if(imageTarget == null)
         {
            if(nativeButton.parent == this.mHeaderPortraitImageLayer)
            {
               this.mHeaderPortraitImageLayer.removeChild(nativeButton);
            }
            return false;
         }
         try
         {
            loadFromInfo = ImageUtils.LoadFromIconInfo;
            loadFromInfo(imageTarget,param1,ImageUtils.THUMBNAIL_SIZE_LARGE);
         }
         catch(eLoad:Error)
         {
            if(nativeButton.parent == this.mHeaderPortraitImageLayer)
            {
               this.mHeaderPortraitImageLayer.removeChild(nativeButton);
            }
            return false;
         }
         try
         {
            if(holder.parent != null)
            {
               holder.parent.removeChild(holder);
            }
         }
         catch(eDetach:Error)
         {
         }
         if(nativeButton.parent == this.mHeaderPortraitImageLayer)
         {
            this.mHeaderPortraitImageLayer.removeChild(nativeButton);
         }
         this.mHeaderPortraitImageLayer.addChild(holder);
         holder.visible = true;
         holder.mouseEnabled = false;
         holder.mouseChildren = false;
         this.CenterNativePortraitClip(holder,42,40,82);
         return true;
      }
      
      private function RefreshHeaderPortrait() : void
      {
         var _loc5_:int = getTimer();
         var _loc3_:int = getTimer();
         if(this.mcContent == null)
         {
            CommunicationManager.PostServerCommand("fgeh.perf_phase","HEADER_PORTRAIT" + ":" + (getTimer() - _loc5_),this.mData.dialog_id);
            return;
         }
         this.BuildHeaderPortrait();
         if(this.mHeaderPortraitLayer == null)
         {
            CommunicationManager.PostServerCommand("fgeh.perf_phase","HEADER_PORTRAIT" + ":" + (getTimer() - _loc5_),this.mData.dialog_id);
            return;
         }
         try
         {
            this.mcContent.setChildIndex(this.mHeaderPortraitLayer,this.mcContent.numChildren - 1);
         }
         catch(eTop:Error)
         {
         }
         CommunicationManager.PostServerCommand("fgeh.perf_phase","HEADER_PORTRAIT" + ":" + (getTimer() - _loc5_),this.mData.dialog_id);
      }
      
      private function ApplyCardReadability(param1:int) : void
      {
         this.StyleExistingTextTree(this.Child("fgehPackName" + param1),14,2707288,true);
         this.StyleExistingTextTree(this.Child("fgehPackCreator" + param1),12.5,5602694,false);
         this.StyleExistingTextTree(this.Child("fgehPackCount" + param1),12.5,1617860,true);
      }
      
      private function ApplyHeaderReadability() : void
      {
         this.StyleExistingTextTree(this.Child("fgehPackStats"),13,3235689,true);
         this.StyleExistingTextTree(this.Child("fgehLibraryLabel"),13,3235689,true);
      }
      
      private function PositionPackStats() : void
      {
         var stats:DisplayObject;
         var track:DisplayObject;
         var trackBounds:Rectangle;
         var desiredLocal:Point;
         var desiredGlobal:Point;
         var desiredParent:Point;
         if(this.mcContent == null)
         {
            return;
         }
         stats = this.Child("fgehPackStats");
         track = this.Child("fgehScrollTrack");
         if(stats == null || stats.parent == null || track == null)
         {
            return;
         }
         try
         {
            trackBounds = track.getBounds(this.mcContent);
            desiredLocal = new Point(trackBounds.x - 104,trackBounds.y - 30);
            desiredGlobal = this.mcContent.localToGlobal(desiredLocal);
            desiredParent = stats.parent.globalToLocal(desiredGlobal);
            stats.x = desiredParent.x;
            stats.y = desiredParent.y;
         }
         catch(e:Error)
         {
         }
      }
      
      private function HideLegacyDetailSidebarExtras(param1:DisplayObject) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function BuildSidebarNav() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function CreateSidebarNavItem(param1:String, param2:String, param3:Number, param4:Number) : Sprite
      {
         var item:Sprite = new Sprite();
         item.name = param1;
         item.buttonMode = true;
         item.mouseEnabled = true;
         item.mouseChildren = false;
         this.PaintSidebarNavItem(item,false,false,param3,param4);
         var label:TextField = new TextField();
         label.name = param1 + "_label";
         label.mouseEnabled = false;
         label.selectable = false;
         label.width = param3 - 28;
         label.height = param4 - 4;
         label.x = 12;
         label.y = 7;
         this.ApplyExistingUIFont(label,"fgehModeLabel",13,4550520,true);
         label.text = param2;
         this.ApplyExistingUIFont(label,"fgehModeLabel",13,4550520,true);
         item.addChild(label);
         return item;
      }
      
      private function PaintSidebarNavItem(param1:Sprite, param2:Boolean, param3:Boolean, param4:Number = 184, param5:Number = 40) : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.graphics.clear();
         if(param2)
         {
            param1.graphics.beginFill(14547192,0.98);
            param1.graphics.drawRoundRect(0,0,param4,param5,13,13);
            param1.graphics.endFill();
         }
         else if(param3)
         {
            param1.graphics.beginFill(15661562,0.75);
            param1.graphics.drawRoundRect(0,0,param4,param5,13,13);
            param1.graphics.endFill();
         }
         else
         {
            param1.graphics.beginFill(16777215,0.001);
            param1.graphics.drawRect(0,0,param4,param5);
            param1.graphics.endFill();
         }
      }
      
      private function OnSidebarNavOver(param1:MouseEvent) : void
      {
         var item:Sprite = param1.currentTarget as Sprite;
         if(item == null)
         {
            return;
         }
         var index:int = int(item.name.replace("fgehSidebarNavHit",""));
         var active:int = this.GetV7ActiveNav();
         if(index < 10 && index == active)
         {
            return;
         }
         this.PaintSidebarNavItem(item,false,true,184,40);
      }
      
      private function OnSidebarNavOut(param1:MouseEvent) : void
      {
         var item:Sprite = param1.currentTarget as Sprite;
         if(item == null)
         {
            return;
         }
         var index:int = int(item.name.replace("fgehSidebarNavHit",""));
         var active:int = this.GetV7ActiveNav();
         this.PaintSidebarNavItem(item,index < 10 && index == active,false,184,40);
      }
      
      private function RefreshSidebarNav() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnSidebarNavClick(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var name:String = String(param1.currentTarget.name);
         var raw:String = name.replace("fgehSidebarNavHit","");
         var index:int = int(raw);
         if(index < 0)
         {
            index = 0;
         }
         if(index >= 0 && index <= 9)
         {
            this.PostResponse(RESPONSE_NAV_BASE + index);
            return;
         }
      }
      
      private function OuterManageSelectedIndices() : Array
      {
         var result:Array = [];
         if(!this.IsOuterGroupRemoveManageMode())
         {
            return result;
         }
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.IsMemberSelected(i))
            {
               result.push(i);
            }
            i++;
         }
         return result;
      }
      
      private function OuterManageSelectedValues() : Array
      {
         var result:Array = [];
         var indices:Array = this.OuterManageSelectedIndices();
         var i:int = 0;
         while(i < indices.length)
         {
            var value:String = this.MemberEditItemValue(int(indices[i]));
            if(value)
            {
               result.push(value);
            }
            i++;
         }
         return result;
      }
      
      private function OuterManageSelectedCount() : int
      {
         return this.OuterManageSelectedIndices().length;
      }
      
      private function ClearOuterManageSelection() : void
      {
         if(!this.IsOuterGroupRemoveManageMode())
         {
            return;
         }
         this.mMemberSelectionOverrides = {};
         this.RefreshSelectionOverlays();
         this.RefreshOuterGroupTools();
      }
      
      private function SelectOuterManageCurrentPage() : void
      {
         if(!this.IsOuterGroupRemoveManageMode())
         {
            return;
         }
         var page:int = this.GetCurrentPage();
         var total:int = this.GetTotalItems();
         var start:int = page * this.ActiveItemsPerPage();
         var end:int = Math.min(total,start + this.ActiveItemsPerPage());
         var i:int = start;
         while(i < end)
         {
            this.SetLocalMemberSelected(i,true);
            i++;
         }
         this.RefreshSelectionOverlays();
         this.RefreshOuterGroupTools();
      }
      
      private function SelectOuterManageAllResults() : void
      {
         if(!this.IsOuterGroupRemoveManageMode())
         {
            return;
         }
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            this.SetLocalMemberSelected(i,true);
            i++;
         }
         this.RefreshSelectionOverlays();
         this.RefreshOuterGroupTools();
      }
      
      private function OnOuterManageSelectPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.SelectOuterManageCurrentPage();
      }
      
      private function OnOuterManageSelectAll(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.SelectOuterManageAllResults();
      }
      
      private function OnOuterManageRemoveSelected(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.IsOuterGroupRemoveManageMode())
         {
            return;
         }
         var values:Array = this.OuterManageSelectedValues();
         if(values.length <= 0)
         {
            return;
         }
         var groupName:String = this.MemberEditGroupName();
         if(!groupName)
         {
            return;
         }
         CommunicationManager.PostServerCommand("fgeh.membership_remove_many",encodeURIComponent("outer"),encodeURIComponent(groupName),"",encodeURIComponent(values.join(FAVORITE_ITEM_SEPARATOR)));
         var activeIndex:int = this.GetV7ActiveGroupIndex();
         this.mMemberSelectionOverrides = {};
         this.mOuterManageLocalPage = -1;
         if(activeIndex >= 0)
         {
            this.PostResponse(RESPONSE_OUTER_GROUP_EDIT_BASE + activeIndex);
         }
         else
         {
            this.PostResponse(RESPONSE_OUTER_GROUP_DONE);
         }
      }
      
      private function BuildOuterGroupTools() : void
      {
         if(this.mcContent == null || this.mOuterGroupToolsLayer != null)
         {
            return;
         }
         this.mOuterGroupToolsLayer = new MovieClip();
         this.mOuterGroupToolsLayer.name = "fgehOuterGroupToolsLayer";
         this.mOuterGroupToolsLayer.mouseEnabled = false;
         this.mOuterGroupToolsLayer.mouseChildren = true;
         this.mcContent.addChild(this.mOuterGroupToolsLayer);
         this.mOuterGroupToolsLayer.visible = false;
      }
      
      private function RefreshOuterGroupTools() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnOuterManageCurrentGroup(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var index:int = this.GetV7ActiveGroupIndex();
         if(index < 0)
         {
            return;
         }
         this.CloseBatchFavoriteGroupMenu();
         if(this.mBatchSelectMode)
         {
            this.SetBatchSelectMode(false);
         }
         this.PostResponse(RESPONSE_OUTER_GROUP_EDIT_BASE + index);
      }
      
      private function OnOuterGroupCreate(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_OUTER_GROUP_CREATE);
      }
      
      private function OnOuterGroupDone(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_OUTER_GROUP_DONE);
      }
      
      private function OnOuterGroupSelectAll(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || !this.IsSharedRootGroupEdit())
         {
            return;
         }
         this.PostResponse(RESPONSE_OUTER_GROUP_SELECT_ALL);
      }
      
      private function OnOuterGroupClear(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || !this.IsSharedRootGroupEdit())
         {
            return;
         }
         this.PostResponse(RESPONSE_OUTER_GROUP_CLEAR);
      }
      
      private function BuildOuterGroupManager() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshOuterGroupManager() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnOuterManagerPrevPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mOuterGroupManagerPage > 0)
         {
            --this.mOuterGroupManagerPage;
            this.RefreshOuterGroupManager();
         }
      }
      
      private function OnOuterManagerNextPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var count:int = this.GetV7GroupCount();
         var pageCount:int = Math.max(1,int(Math.ceil(count / 5)));
         if(this.mOuterGroupManagerPage + 1 < pageCount)
         {
            ++this.mOuterGroupManagerPage;
            this.RefreshOuterGroupManager();
         }
      }
      
      private function OnOuterGroupManagerToggle(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var managerViewKind:String = this.GetV7ViewKind();
         if(this.mOuterGroupManagerLayer == null || !this.HasV7Extension() || !this.IsSharedRootGroupBrowse())
         {
            return;
         }
         var opening:Boolean = !this.mOuterGroupManagerLayer.visible;
         if(opening)
         {
            this.CloseBatchFavoriteGroupMenu();
            if(this.mBatchSelectMode)
            {
               this.SetBatchSelectMode(false);
            }
         }
         this.mOuterGroupManagerLayer.visible = opening;
         if(opening)
         {
            this.mOuterGroupManagerPage = 0;
            this.SetCardInteractionBlocked(true);
         }
         else
         {
            this.SetCardInteractionBlocked(false);
         }
         this.RefreshOuterGroupManager();
      }
      
      private function OnOuterGroupManagerEdit(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var index:int = int(String(param1.currentTarget.name).replace("fgehOuterManagerEdit",""));
         this.CloseBatchFavoriteGroupMenu();
         if(this.mBatchSelectMode)
         {
            this.SetBatchSelectMode(false);
         }
         this.PostResponse(RESPONSE_OUTER_GROUP_EDIT_BASE + index);
      }
      
      private function OnOuterGroupManagerRename(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var index:int = int(String(param1.currentTarget.name).replace("fgehOuterManagerRename",""));
         this.PostResponse(RESPONSE_OUTER_GROUP_RENAME_BASE + index);
      }
      
      private function OnOuterGroupManagerDelete(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var index:int = int(String(param1.currentTarget.name).replace("fgehOuterManagerDelete",""));
         this.PostResponse(RESPONSE_OUTER_GROUP_DELETE_BASE + index);
      }
      
      private function BuildSelectionLayer() : void
      {
         if(this.mcContent == null || this.mSelectionLayer != null)
         {
            return;
         }
         this.mSelectionLayer = new MovieClip();
         this.mSelectionLayer.name = "fgehSelectionLayer";
         this.mSelectionLayer.mouseEnabled = false;
         this.mSelectionLayer.mouseChildren = false;
         this.mSelectionOverlays = [];
         var i:int = 0;
         while(i < this.ActiveItemsPerPage())
         {
            var bounds:Rectangle = this.ExactGridHitBounds(i);
            var overlay:MovieClip = new MovieClip();
            overlay.name = "fgehSelectedOverlay" + (i + 1);
            overlay.x = bounds.x;
            overlay.y = bounds.y;
            overlay.mouseEnabled = false;
            overlay.mouseChildren = false;
            overlay.graphics.beginFill(14478563,0.22);
            overlay.graphics.lineStyle(2.5,6859145,0.96);
            overlay.graphics.drawRoundRect(2,2,bounds.width - 4,bounds.height - 4,9,9);
            overlay.graphics.endFill();
            var marker:Sprite = new Sprite();
            marker.name = "fgehSelectedMarker" + (i + 1);
            marker.mouseEnabled = false;
            marker.mouseChildren = false;
            marker.graphics.beginFill(6266491,1);
            marker.graphics.drawCircle(11,11,5.5);
            marker.graphics.endFill();
            overlay.addChild(marker);
            overlay.visible = false;
            this.mSelectionLayer.addChild(overlay);
            this.mSelectionOverlays.push(overlay);
            i++;
         }
         this.mcContent.addChild(this.mSelectionLayer);
      }
      
      private function BuildFavoriteLayer() : void
      {
         var i:int;
         var marker:Sprite;
         var p:int;
         var angle:Number;
         var radius:Number;
         var px:Number;
         var py:Number;
         var icon:DisplayObject;
         var iconBounds:Rectangle;
         var fallbackBounds:Rectangle;
         var cellBounds:Rectangle;
         if(this.mcContent == null || this.mFavoriteLayer != null)
         {
            return;
         }
         this.mFavoriteLayer = new MovieClip();
         this.mFavoriteLayer.name = "fgehFavoriteLayer";
         this.mFavoriteLayer.mouseEnabled = false;
         this.mFavoriteLayer.mouseChildren = false;
         this.mFavoriteMarkers = [];
         i = 0;
         for(; i < this.ActiveItemsPerPage(); marker.visible = false,this.mFavoriteLayer.addChild(marker),this.mFavoriteMarkers.push(marker),i++)
         {
            marker = new Sprite();
            marker.name = "fgehFavoriteMarker" + (i + 1);
            marker.mouseEnabled = false;
            marker.mouseChildren = false;
            marker.graphics.beginFill(16777215,0.95);
            marker.graphics.drawCircle(0,0,9);
            marker.graphics.endFill();
            marker.graphics.beginFill(15976014,1);
            marker.graphics.lineStyle(1,13211178,1);
            p = 0;
            while(p < 10)
            {
               angle = -Math.PI / 2 + p * Math.PI / 5;
               radius = p % 2 == 0 ? 6.8 : 3.1;
               px = Math.cos(angle) * radius;
               py = Math.sin(angle) * radius;
               if(p == 0)
               {
                  marker.graphics.moveTo(px,py);
               }
               else
               {
                  marker.graphics.lineTo(px,py);
               }
               p++;
            }
            marker.graphics.lineTo(0,-6.8);
            marker.graphics.endFill();
            icon = this.Child("fgehPackIcon" + (i + 1));
            if(icon != null)
            {
               try
               {
                  iconBounds = icon.getBounds(this.mcContent);
                  marker.x = iconBounds.right - 4;
                  marker.y = iconBounds.bottom - 4;
               }
               catch(eBounds:Error)
               {
                  fallbackBounds = this.ExactGridHitBounds(i);
                  marker.x = fallbackBounds.x + 77;
                  marker.y = fallbackBounds.y + 69;
               }
               continue;
            }
            cellBounds = this.ExactGridHitBounds(i);
            marker.x = cellBounds.x + 77;
            marker.y = cellBounds.y + 69;
         }
         this.mcContent.addChild(this.mFavoriteLayer);
      }
      
      private function FavoriteScopeForIndex(param1:int) : String
      {
         var key:String = this.GetEditInfoKey(param1);
         if(key.indexOf("pose_") == 0)
         {
            return "pose";
         }
         if(key.indexOf("pack_") == 0)
         {
            return "pack";
         }
         if(key.indexOf("creator_") == 0)
         {
            return "creator";
         }
         return "";
      }
      
      private function FavoriteValueForIndex(param1:int) : String
      {
         var key:String = this.GetEditInfoKey(param1);
         var scope:String = this.FavoriteScopeForIndex(param1);
         if(scope == "pose")
         {
            return key.substr(5);
         }
         if(scope == "pack")
         {
            return key.substr(5);
         }
         if(scope == "creator")
         {
            return key.substr(8);
         }
         return "";
      }
      
      private function CanFavoriteIndex(param1:int) : Boolean
      {
         return this.FavoriteScopeForIndex(param1) && this.FavoriteValueForIndex(param1);
      }
      
      private function HasFavoritableRows() : Boolean
      {
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.CanFavoriteIndex(i))
            {
               return true;
            }
            i++;
         }
         return false;
      }
      
      private function IsRowFavorite(param1:int) : Boolean
      {
         var key:String;
         var base:int;
         try
         {
            key = String(param1);
            if(this.mFavoriteOverrides.hasOwnProperty(key))
            {
               return Boolean(this.mFavoriteOverrides[key]);
            }
         }
         catch(eOverride:Error)
         {
         }
         if(this.mData == null || this.mData.additional_texts == null)
         {
            return false;
         }
         base = 13 + param1 * 6;
         if(base + 3 >= this.mData.additional_texts.length)
         {
            return false;
         }
         return String(this.mData.additional_texts[base + 3]) == "1";
      }
      
      private function SetLocalRowFavorite(param1:int, param2:Boolean) : void
      {
         try
         {
            this.mFavoriteOverrides[String(param1)] = param2;
         }
         catch(e:Error)
         {
         }
      }
      
      private function RefreshFavoriteMarkers() : void
      {
         var page:int;
         var total:int;
         var pageSize:int;
         var i:int;
         var marker:DisplayObject;
         var visibleIndex:int;
         var dataIndex:int;
         var visible:Boolean;
         if(this.mFavoriteLayer == null || this.mFavoriteMarkers == null)
         {
            return;
         }
         page = this.GetCurrentPage();
         total = this.ActiveTotalItems();
         pageSize = this.ActiveItemsPerPage();
         i = 0;
         while(i < this.mFavoriteMarkers.length)
         {
            marker = this.mFavoriteMarkers[i] as DisplayObject;
            visibleIndex = page * pageSize + i;
            dataIndex = i < pageSize ? this.ActiveDataIndexAtVisible(visibleIndex) : -1;
            if(marker != null)
            {
               visible = visibleIndex >= 0 && visibleIndex < total && dataIndex >= 0 && this.CanFavoriteIndex(dataIndex) && this.IsRowFavorite(dataIndex);
               marker.visible = visible;
            }
            i++;
         }
         try
         {
            this.mcContent.setChildIndex(this.mFavoriteLayer,this.mcContent.numChildren - 1);
         }
         catch(eTop:Error)
         {
         }
      }
      
      private function PaintSelectionOverlayState(param1:MovieClip, param2:Rectangle, param3:String) : void
      {
         var fill:uint;
         var border:uint;
         var dot:uint;
         var alpha:Number;
         var line:Number;
         var marker:Sprite;
         if(param1 == null || param2 == null)
         {
            return;
         }
         fill = 14478563;
         border = 6859145;
         dot = 6266491;
         alpha = 0.22;
         line = 2.5;
         if(param3 == "source")
         {
            fill = 14544882;
            border = 5152682;
            dot = 3771801;
            alpha = 0.3;
            line = 3;
         }
         else if(param3 == "target")
         {
            fill = 14478563;
            border = 6859145;
            dot = 6266491;
            alpha = 0.24;
            line = 2.5;
         }
         param1.graphics.clear();
         param1.graphics.beginFill(fill,alpha);
         param1.graphics.lineStyle(line,border,0.98);
         param1.graphics.drawRoundRect(2,2,param2.width - 4,param2.height - 4,9,9);
         param1.graphics.endFill();
         try
         {
            marker = param1.getChildByName("fgehSelectedMarker" + (String(this.mSelectionOverlays.indexOf(param1) + 1))) as Sprite;
            if(marker == null && param1.numChildren > 0)
            {
               marker = param1.getChildAt(0) as Sprite;
            }
            if(marker != null)
            {
               marker.graphics.clear();
               marker.graphics.beginFill(dot,1);
               if(param3 == "source")
               {
                  marker.graphics.drawCircle(11,11,6.2);
                  marker.graphics.endFill();
                  marker.graphics.lineStyle(1.4,16777215,1);
                  marker.graphics.drawCircle(11,11,3.2);
               }
               else
               {
                  marker.graphics.drawCircle(11,11,5.5);
                  marker.graphics.endFill();
               }
            }
         }
         catch(eMarker:Error)
         {
         }
      }
      
      private function RefreshSelectionOverlays() : void
      {
         var editing:Boolean;
         var linkedEditing:Boolean;
         var batchEditing:Boolean;
         var page:int;
         var total:int;
         var pageSize:int;
         var i:int;
         var overlay:DisplayObject;
         var visibleIndex:int;
         var dataIndex:int;
         var bounds:Rectangle;
         var linkedOverlay:MovieClip;
         var isSource:Boolean;
         var isTarget:Boolean;
         var nativeIndex:int;
         if(this.mSelectionLayer == null || this.mSelectionOverlays == null)
         {
            return;
         }
         editing = this.HasMemberEditExtension() && (this.GetV7ViewKind() == "pack_detail_group_edit" || this.IsSharedRootGroupEdit());
         linkedEditing = this.mLinkedManageMode && this.HasLinkedDetailExtension();
         batchEditing = this.mBatchSelectMode;
         this.mSelectionLayer.visible = editing || linkedEditing || batchEditing;
         page = this.GetCurrentPage();
         total = this.ActiveTotalItems();
         pageSize = this.ActiveItemsPerPage();
         i = 0;
         while(i < this.mSelectionOverlays.length)
         {
            overlay = this.mSelectionOverlays[i] as DisplayObject;
            visibleIndex = page * pageSize + i;
            dataIndex = i < pageSize ? this.ActiveDataIndexAtVisible(visibleIndex) : -1;
            if(overlay != null)
            {
               bounds = this.ExactGridHitBounds(i);
               overlay.x = bounds.x;
               overlay.y = bounds.y;
               if(linkedEditing)
               {
                  linkedOverlay = overlay as MovieClip;
                  if(this.mLinkedMultiSelectMode)
                  {
                     isSource = dataIndex >= 0 && visibleIndex < total && dataIndex == this.mLinkedActiveIndex;
                     isTarget = dataIndex >= 0 && visibleIndex < total && !isSource && this.IsLinkedPoseSelected(dataIndex);
                     overlay.visible = isSource || isTarget;
                     overlay.alpha = 1;
                     if(linkedOverlay != null && overlay.visible)
                     {
                        this.PaintSelectionOverlayState(linkedOverlay,bounds,isSource ? "source" : "target");
                     }
                  }
                  else
                  {
                     overlay.visible = dataIndex >= 0 && visibleIndex < total && dataIndex == this.mLinkedActiveIndex;
                     overlay.alpha = 1;
                     if(linkedOverlay != null && overlay.visible)
                     {
                        this.PaintSelectionOverlayState(linkedOverlay,bounds,"target");
                     }
                  }
               }
               else if(batchEditing)
               {
                  overlay.alpha = 1;
                  overlay.visible = dataIndex >= 0 && visibleIndex < total && this.IsBatchPoseSelected(dataIndex);
               }
               else
               {
                  overlay.alpha = 1;
                  overlay.visible = editing && dataIndex >= 0 && visibleIndex < total && this.IsMemberSelected(dataIndex);
               }
            }
            i++;
         }
         if(editing || linkedEditing || batchEditing)
         {
            try
            {
               nativeIndex = this.mcContent.getChildIndex(this.mNativeLayer);
               this.mcContent.setChildIndex(this.mSelectionLayer,Math.max(0,nativeIndex - 1));
            }
            catch(e:Error)
            {
            }
         }
         this.KeepLinkedDrawerOnTop();
      }
      
      private function BuildMemberEditTools() : void
      {
         if(this.mcContent == null || this.mMemberEditToolsLayer != null)
         {
            return;
         }
         this.mMemberEditToolsLayer = new MovieClip();
         this.mMemberEditToolsLayer.name = "fgehMemberEditToolsLayer";
         this.mMemberEditToolsLayer.mouseEnabled = false;
         this.mMemberEditToolsLayer.mouseChildren = true;
         this.mcContent.addChild(this.mMemberEditToolsLayer);
         this.mMemberEditToolsLayer.visible = false;
      }
      
      private function RefreshMemberEditTools() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnSmartPatternClick(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_GROUP_SMART_PATTERN);
      }
      
      private function OnMemberEditDone(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_GROUP_EDIT_DONE);
      }
      
      private function BuildGroupTabs() : void
      {
         if(this.mcContent == null || this.mGroupTabsLayer != null)
         {
            return;
         }
         this.mGroupTabsLayer = new MovieClip();
         this.mGroupTabsLayer.name = "fgehGroupTabsLayer";
         this.mGroupTabsLayer.mouseEnabled = false;
         this.mGroupTabsLayer.mouseChildren = true;
         this.mGroupTabButtons = [];
         this.mcContent.addChild(this.mGroupTabsLayer);
         this.mGroupTabsLayer.visible = false;
      }
      
      private function CreateEmphasisTab(param1:String, param2:String, param3:Number) : Sprite
      {
         var button:Sprite = new Sprite();
         button.name = param1;
         button.buttonMode = true;
         button.mouseEnabled = true;
         button.mouseChildren = false;
         this.PaintEmphasisTab(button,false,param3);
         var label:TextField = new TextField();
         label.name = param1 + "_label";
         label.mouseEnabled = false;
         label.selectable = false;
         label.width = param3 - 16;
         label.height = 28;
         label.x = 8;
         label.y = 2;
         this.ApplyExistingUIFont(label,"fgehModeLabel",14,2059899);
         label.text = param2;
         this.ApplyExistingUIFont(label,"fgehModeLabel",14,2059899);
         button.addChild(label);
         button.addEventListener(MouseEvent.MOUSE_OVER,this.OnEmphasisTabOver,false,0,true);
         button.addEventListener(MouseEvent.MOUSE_OUT,this.OnEmphasisTabOut,false,0,true);
         return button;
      }
      
      private function PaintEmphasisTab(param1:Sprite, param2:Boolean, param3:Number = 96) : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.graphics.clear();
         if(param2)
         {
            param1.graphics.beginFill(13365234,1);
            param1.graphics.lineStyle(1.5,5028552,1);
         }
         else
         {
            param1.graphics.beginFill(14546936,1);
            param1.graphics.lineStyle(1.5,6932177,1);
         }
         param1.graphics.drawRoundRect(0,0,param3,32,6,6);
         param1.graphics.endFill();
      }
      
      private function OnEmphasisTabOver(param1:MouseEvent) : void
      {
         var button:Sprite = param1.currentTarget as Sprite;
         if(button != null)
         {
            this.PaintEmphasisTab(button,true,button.width);
         }
      }
      
      private function OnEmphasisTabOut(param1:MouseEvent) : void
      {
         var button:Sprite = param1.currentTarget as Sprite;
         if(button != null)
         {
            this.PaintEmphasisTab(button,false,button.width);
         }
      }
      
      private function CreateSmallTab(param1:String, param2:String, param3:Number) : Sprite
      {
         var button:Sprite = new Sprite();
         button.name = param1;
         button.buttonMode = true;
         button.mouseEnabled = true;
         button.mouseChildren = false;
         this.PaintSmallTab(button,false,param3);
         var label:TextField = new TextField();
         label.mouseEnabled = false;
         label.selectable = false;
         label.width = param3 - 12;
         label.height = 26;
         label.x = 6;
         label.y = 3;
         this.ApplyExistingUIFont(label,"fgehModeLabel",13,3497833);
         label.text = param2;
         this.ApplyExistingUIFont(label,"fgehModeLabel",13,3497833);
         button.addChild(label);
         button.addEventListener(MouseEvent.MOUSE_OVER,this.OnSmallTabOver,false,0,true);
         button.addEventListener(MouseEvent.MOUSE_OUT,this.OnSmallTabOut,false,0,true);
         return button;
      }
      
      private function CreateDropdownArrowTab(param1:String, param2:Number = 30) : Sprite
      {
         return this.CreateSmallTab(param1,"▼",param2);
      }
      
      private function PaintSmallTab(param1:Sprite, param2:Boolean, param3:Number = 92) : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.graphics.clear();
         if(param2)
         {
            param1.graphics.beginFill(14743288,1);
            param1.graphics.lineStyle(1,6800079,1);
         }
         else
         {
            param1.graphics.beginFill(16317693,0.98);
            param1.graphics.lineStyle(1,13492965,1);
         }
         param1.graphics.drawRoundRect(0,0,param3,30,4,4);
         param1.graphics.endFill();
      }
      
      private function OnSmallTabOver(param1:MouseEvent) : void
      {
         var button:Sprite = param1.currentTarget as Sprite;
         if(button != null)
         {
            this.PaintSmallTab(button,true,button.getChildAt(0).width + 12);
         }
      }
      
      private function OnSmallTabOut(param1:MouseEvent) : void
      {
         var button:Sprite = param1.currentTarget as Sprite;
         if(button != null)
         {
            this.PaintSmallTab(button,false,button.getChildAt(0).width + 12);
         }
      }
      
      private function ClearDisplayChildren(param1:MovieClip) : void
      {
         if(param1 != null)
         {
            if(param1.name == "fgehAccessoryLibraryLayer")
            {
               if(param1["fgehR74CASPageCache"] != null)
               {
                  var _loc3_:* = param1["fgehR74CASPageCache"][0];
                  if(_loc3_ != null)
                  {
                     if(_loc3_["data"] === this.mData)
                     {
                        var _loc2_:Number = param1.numChildren - 1;
                        while(_loc2_ >= 0)
                        {
                           _loc3_ = param1.getChildAt(_loc2_);
                           if(_loc3_["fgehProductIndex"] != null)
                           {
                              _loc3_.visible = false;
                           }
                           else
                           {
                              param1.removeChildAt(_loc2_);
                           }
                           _loc2_ -= 1;
                        }
                        return;
                     }
                  }
                  param1["fgehR74CASPageCache"] = null;
               }
            }
         }
         if(param1 == null)
         {
            return;
         }
         while(param1.numChildren > 0)
         {
            param1.removeChildAt(param1.numChildren - 1);
         }
      }
      
      private function RefreshGroupTabs() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnGroupTabClick(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var name:String = String(param1.currentTarget.name);
         var index:int = int(name.replace("fgehGroupTab",""));
         this.PostResponse(RESPONSE_GROUP_TAB_BASE + index);
      }
      
      private function OnGroupCreateClick(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_GROUP_CREATE);
      }
      
      private function IsAnyManagerModalOpen() : Boolean
      {
         return this.mGroupManagerLayer != null && this.mGroupManagerLayer.visible || this.mOuterGroupManagerLayer != null && this.mOuterGroupManagerLayer.visible || this.mEditInfoLayer != null && this.mEditInfoLayer.visible || this.mBatchFavoriteGroupLayer != null && this.mBatchFavoriteGroupLayer.visible || this.mLinkedRemoveLayer != null && this.mLinkedRemoveLayer.visible;
      }
      
      private function SyncCardInteractionState() : void
      {
         if(this.mNativeLayer == null)
         {
            return;
         }
         var blocked:Boolean = this.IsAnyManagerModalOpen();
         this.mNativeLayer.visible = true;
         this.mNativeLayer.mouseEnabled = false;
         this.mNativeLayer.mouseChildren = !blocked;
         if(!blocked)
         {
            this.RefreshNativeCells();
         }
      }
      
      private function SetCardInteractionBlocked(param1:Boolean) : void
      {
         if(this.mNativeLayer == null)
         {
            return;
         }
         this.mNativeLayer.visible = true;
         this.mNativeLayer.mouseEnabled = false;
         this.mNativeLayer.mouseChildren = !param1;
         if(!param1)
         {
            this.RefreshNativeCells();
         }
      }
      
      private function BuildGroupManager() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshGroupManager() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnGroupManagerPrevPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mGroupManagerPage > 0)
         {
            --this.mGroupManagerPage;
            this.RefreshGroupManager();
         }
      }
      
      private function OnGroupManagerNextPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var count:int = this.GetV7GroupCount();
         var pageCount:int = Math.max(1,int(Math.ceil(count / 5)));
         if(this.mGroupManagerPage + 1 < pageCount)
         {
            ++this.mGroupManagerPage;
            this.RefreshGroupManager();
         }
      }
      
      private function OnOuterChipPrevPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mOuterGroupChipPage > 0)
         {
            --this.mOuterGroupChipPage;
            this.RefreshGroupManager();
         }
      }
      
      private function OnOuterChipNextPage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var count:int = this.GetOuterGroupCount();
         var pageCount:int = Math.max(1,int(Math.ceil(count / 4)));
         if(this.mOuterGroupChipPage + 1 < pageCount)
         {
            ++this.mOuterGroupChipPage;
            this.RefreshGroupManager();
         }
      }
      
      private function OnGroupOuterToggleClick(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var index:int = int(String(param1.currentTarget.name).replace("fgehOuterChip",""));
         this.PostResponse(RESPONSE_GROUP_OUTER_TOGGLE_BASE + index);
      }
      
      private function OnGroupManageToggle(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mGroupManagerLayer == null || !this.HasV7Extension() || this.GetV7ViewKind() != "pack_detail_groups")
         {
            return;
         }
         var opening:Boolean = !this.mGroupManagerLayer.visible;
         this.mGroupManagerLayer.visible = opening;
         if(opening)
         {
            this.mGroupManagerPage = 0;
            this.mOuterGroupChipPage = 0;
            this.SetCardInteractionBlocked(true);
         }
         else
         {
            this.SetCardInteractionBlocked(false);
         }
         this.RefreshGroupManager();
      }
      
      private function OnSmartTwoClick(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_GROUP_SMART_TWO);
      }
      
      private function OnSmartThreeClick(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_GROUP_SMART_THREE);
      }
      
      private function OnGroupEditClick(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var name:String = String(param1.currentTarget.name);
         var index:int = int(name.replace("fgehGroupEdit",""));
         this.PostResponse(RESPONSE_GROUP_EDIT_BASE + index);
      }
      
      private function OnGroupRenameClick(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var name:String = String(param1.currentTarget.name);
         var index:int = int(name.replace("fgehGroupRename",""));
         this.PostResponse(RESPONSE_GROUP_RENAME_BASE + index);
      }
      
      private function OnGroupDeleteClick(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var name:String = String(param1.currentTarget.name);
         var index:int = int(name.replace("fgehGroupDelete",""));
         this.PostResponse(RESPONSE_GROUP_DELETE_BASE + index);
      }
      
      private function BuildBatchFavoriteGroupLayer() : void
      {
         if(this.mcContent == null || this.mBatchFavoriteGroupLayer != null)
         {
            return;
         }
         this.mBatchFavoriteGroupLayer = new MovieClip();
         this.mBatchFavoriteGroupLayer.name = "fgehBatchFavoriteGroupLayer";
         this.mBatchFavoriteGroupLayer.mouseEnabled = true;
         this.mBatchFavoriteGroupLayer.mouseChildren = true;
         this.mcContent.addChild(this.mBatchFavoriteGroupLayer);
         this.mBatchFavoriteGroupLayer.visible = false;
      }
      
      private function CloseBatchFavoriteGroupMenu() : void
      {
         if(this.mBatchFavoriteGroupLayer != null)
         {
            this.mBatchFavoriteGroupLayer.visible = false;
            this.ClearDisplayChildren(this.mBatchFavoriteGroupLayer);
            this.mBatchFavoriteGroupLayer.graphics.clear();
         }
         this.mBatchFavoriteGroupScope = "";
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupInputMode = false;
         this.mBatchFavoriteGroupInput = null;
         this.mPackOrganizerActive = false;
         this.mPackOrganizerSingleIndex = -1;
         this.mPackOrganizerSingleValue = "";
         this.AbortMarqueeInteraction();
         this.SyncCardInteractionState();
         try
         {
            if(this.stage != null)
            {
               this.stage.focus = null;
            }
         }
         catch(e:Error)
         {
         }
      }
      
      private function OrganizerValues() : Array
      {
         if(this.mPackOrganizerSingleIndex >= 0 && this.mPackOrganizerSingleValue)
         {
            return [this.mPackOrganizerSingleValue];
         }
         return this.BatchSelectedItemValues();
      }
      
      private function CurrentPackGroupThumbnailContext() : Object
      {
         if(!this.HasV7Extension() || this.mPackOrganizerSingleIndex < 0 || this.mPackOrganizerSingleValue == null || this.mPackOrganizerSingleValue.length == 0)
         {
            return null;
         }
         var activeGroup:int = this.GetV7ActiveGroupIndex();
         if(activeGroup < 0)
         {
            return null;
         }
         var groupName:String = this.GetV7GroupName(activeGroup);
         if(groupName == null || groupName.length == 0)
         {
            return null;
         }
         var kind:String = this.GetV7ViewKind();
         if(kind == "root_grouped_packs")
         {
            return {
               "mode":"outer",
               "group_name":groupName
            };
         }
         if(kind == "root_fav_pack_group_play")
         {
            return {
               "mode":"fav_pack",
               "group_name":groupName
            };
         }
         return null;
      }
      
      private function CanSetCurrentGroupThumbnail() : Boolean
      {
         return this.CurrentPackGroupThumbnailContext() != null;
      }
      
      private function OrganizerGroupNames() : Array
      {
         if(this.mBatchFavoriteGroupScope == "outer")
         {
            return this.GetOuterActionGroupNames();
         }
         return this.GetFavoriteGroupNames(this.mBatchFavoriteGroupScope);
      }
      
      private function TraceOrganizer(param1:String, param2:String = "") : void
      {
      }
      
      private function OpenBatchFavoriteGroupMenu(param1:String, param2:Number, param3:Number) : void
      {
         if(this.IsOuterGroupRemoveManageMode() || this.mOuterGroupManagerLayer != null && this.mOuterGroupManagerLayer.visible)
         {
            return;
         }
         this.AbortMarqueeInteraction();
         if(param1 != "pack" && param1 != "pose")
         {
            return;
         }
         if(this.BatchSelectedItemValues().length <= 0)
         {
            return;
         }
         this.mPackOrganizerActive = false;
         this.mPackOrganizerSingleIndex = -1;
         this.mPackOrganizerSingleValue = "";
         this.mBatchFavoriteGroupScope = param1;
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupAnchorX = param2;
         this.mBatchFavoriteGroupAnchorY = param3;
         this.mBatchFavoriteGroupInputMode = false;
         this.RefreshBatchFavoriteGroupMenu();
         this.SetCardInteractionBlocked(true);
      }
      
      private function OpenPackOrganizeChooser(param1:Number, param2:Number, param3:int = -1) : void
      {
         if(this.IsOuterGroupRemoveManageMode() || this.mOuterGroupManagerLayer != null && this.mOuterGroupManagerLayer.visible)
         {
            return;
         }
         this.AbortMarqueeInteraction();
         this.mPackOrganizerSingleIndex = param3;
         this.mPackOrganizerSingleValue = "";
         if(param3 >= 0)
         {
            if(param3 >= this.GetTotalItems() || this.FavoriteScopeForIndex(param3) != "pack")
            {
               return;
            }
            this.mPackOrganizerSingleValue = this.FavoriteValueForIndex(param3);
            if(!this.mPackOrganizerSingleValue)
            {
               return;
            }
         }
         else if(this.BatchSelectionScope() != "pack" || this.BatchSelectedItemValues().length <= 0)
         {
            return;
         }
         this.mPackOrganizerActive = true;
         this.mBatchFavoriteGroupScope = "organize";
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupInputMode = false;
         this.mBatchFavoriteGroupAnchorX = Math.max(-200,Math.min(225,param1));
         this.mBatchFavoriteGroupAnchorY = Math.max(-205,Math.min(130,param2));
         this.TraceOrganizer(param3 >= 0 ? "single-pack-organizer-open" : "batch-pack-organizer-open",param3 >= 0 ? this.mPackOrganizerSingleValue : String(this.BatchSelectedItemValues().length));
         this.RefreshBatchFavoriteGroupMenu();
         this.SetCardInteractionBlocked(true);
      }
      
      private function RefreshBatchFavoriteGroupMenu() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function PostOrganizerToGroup(param1:String) : void
      {
         var scope:String = this.mBatchFavoriteGroupScope;
         var values:Array = this.OrganizerValues();
         if(!param1 || values.length <= 0)
         {
            return;
         }
         if(scope == "outer")
         {
            CommunicationManager.PostServerCommand("fgeh.membership_add_many",encodeURIComponent("outer"),encodeURIComponent(param1),"",encodeURIComponent(values.join(FAVORITE_ITEM_SEPARATOR)));
            this.TraceOrganizer("add-action-group",param1 + ":" + values.length);
         }
         else
         {
            if(!(scope == "pack" || scope == "pose"))
            {
               return;
            }
            var total:int = this.GetTotalItems();
            var i:int = 0;
            while(i < total)
            {
               if((this.mPackOrganizerSingleIndex == i || this.mPackOrganizerSingleIndex < 0 && this.IsBatchPoseSelected(i)) && this.FavoriteScopeForIndex(i) == scope)
               {
                  this.SetLocalRowFavorite(i,true);
               }
               i++;
            }
            this.RefreshFavoriteMarkers();
            CommunicationManager.PostServerCommand("fgeh.favorite_add_group",encodeURIComponent(scope),encodeURIComponent(param1),encodeURIComponent(values.join(FAVORITE_ITEM_SEPARATOR)));
            this.TraceOrganizer(scope == "pack" ? "add-favorite-folder" : "add-favorite-pose-group",param1 + ":" + values.length);
         }
         this.CloseBatchFavoriteGroupMenu();
         this.RefreshFixedTools();
         this.RefreshRootTools();
         this.RefreshRootSearch();
      }
      
      private function OnPackOrganizerFavoriteFolders(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mBatchFavoriteGroupScope = "pack";
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupInputMode = false;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnPackOrganizerOuterGroups(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mBatchFavoriteGroupScope = "outer";
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupInputMode = false;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnPackOrganizerBack(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mBatchFavoriteGroupScope = "organize";
         this.mBatchFavoriteGroupPage = 0;
         this.mBatchFavoriteGroupInputMode = false;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnPackOrganizerToggleFavorite(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
            if(param1.currentTarget != null)
            {
               if(String(param1.currentTarget.name) === "fgehOrganizerAddLinked")
               {
                  CommunicationManager.PostServerCommand("fgeh.link_pack_all",encodeURIComponent(this.mPackOrganizerSingleValue));
                  this.CloseBatchFavoriteGroupMenu();
                  return;
               }
            }
         }
         var index:int = this.mPackOrganizerSingleIndex;
         if(index < 0)
         {
            return;
         }
         this.CloseBatchFavoriteGroupMenu();
         this.PostFavoriteOnce(index);
      }
      
      private function OnPackOrganizerEditInfo(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var index:int = this.mPackOrganizerSingleIndex;
         if(index < 0)
         {
            return;
         }
         this.CloseBatchFavoriteGroupMenu();
         this.OpenEditInfoOnce(index);
      }
      
      private function OnPackOrganizerSetGroupThumbnail(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mPackOrganizerSingleIndex < 0 || this.mPackOrganizerSingleValue == null || this.mPackOrganizerSingleValue.length == 0)
         {
            return;
         }
         var context:Object = this.CurrentPackGroupThumbnailContext();
         if(context == null)
         {
            return;
         }
         CommunicationManager.PostServerCommand("fgeh.group_set_thumbnail",encodeURIComponent(String(context.mode)),encodeURIComponent(String(context.group_name)),encodeURIComponent(this.mPackOrganizerSingleValue));
         this.TraceOrganizer("set-group-thumbnail",String(context.mode) + "|" + String(context.group_name) + "|" + this.mPackOrganizerSingleValue);
         this.CloseBatchFavoriteGroupMenu();
      }
      
      private function OnBatchFavoriteGroupClose(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.CloseBatchFavoriteGroupMenu();
      }
      
      private function OnBatchFavoriteGroupItem(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var buttonName:String = String(param1.currentTarget.name);
         if(buttonName.indexOf("fgehBatchFavoriteGroupItem") != 0)
         {
            return;
         }
         var index:int = int(buttonName.substr("fgehBatchFavoriteGroupItem".length));
         var groups:Array = this.OrganizerGroupNames();
         if(index < 0 || index >= groups.length)
         {
            return;
         }
      }
      
      private function OnBatchFavoriteGroupPrev(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         --this.mBatchFavoriteGroupPage;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnBatchFavoriteGroupNext(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         ++this.mBatchFavoriteGroupPage;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnBatchFavoriteGroupNew(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mBatchFavoriteGroupInputMode = true;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnBatchFavoriteGroupNewCancel(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mBatchFavoriteGroupInputMode = false;
         this.RefreshBatchFavoriteGroupMenu();
      }
      
      private function OnBatchFavoriteGroupNewSave(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mBatchFavoriteGroupInput == null)
         {
            return;
         }
         var groupName:String = this.mBatchFavoriteGroupInput.text;
         groupName = groupName.replace(/^\s+|\s+$/g,"");
         if(!groupName)
         {
            return;
         }
         this.PostOrganizerToGroup(groupName);
      }
      
      private function GetRootSearchQuery() : String
      {
         return this.mRootSearchLocalQuery == null ? "" : this.mRootSearchLocalQuery;
      }
      
      private function IsRootSearchContext() : Boolean
      {
         if(!this.HasV7Extension())
         {
            return false;
         }
         var kind:String = this.GetV7ViewKind();
         if(kind == null || kind.length == 0 || kind == "root_settings")
         {
            return false;
         }
         if(kind.indexOf("_edit") >= 0)
         {
            return false;
         }
         return kind.indexOf("root") == 0 || kind.indexOf("pack_detail") == 0;
      }
      
      private function IsRootSearchVisible() : Boolean
      {
         return this.IsRootSearchContext() && !this.mLinkedManageMode;
      }
      
      private function IsRootLiveSearchActive() : Boolean
      {
         return this.IsRootSearchContext() && this.mRootSearchLocalQuery != null && this.mRootSearchLocalQuery.replace(/^\s+|\s+$/g,"").length > 0;
      }
      
      private function NormalizeRootSearchText(param1:String) : String
      {
         var value:String = param1 == null ? "" : param1.toLowerCase();
         value = value.replace(/[\s\-_–—:：\.]+/g," ");
         value = value.replace(/[\/\\]+/g," ");
         return value.replace(/^\s+|\s+$/g,"");
      }
      
      private function RebuildRootSearchIndex() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RootSearchRowMatches(param1:int, param2:String) : Boolean
      {
         var query:String = param2;
         if(query.length == 0)
         {
            return true;
         }
         var row:Object = null;
         if(this.mRootSearchHaystacks != null && param1 >= 0 && param1 < this.mRootSearchHaystacks.length)
         {
            row = this.mRootSearchHaystacks[param1];
         }
         if(row == null)
         {
            return false;
         }
         while(true)
         {
            if(this.mLinkedBaseX != null)
            {
               if(this.mLinkedBaseX["fgehSearchTokensF2"] != null)
               {
                  var tokens:Array = this.mLinkedBaseX["fgehSearchTokensF2"];
                  break;
               }
            }
            tokens = query.split(/\s+/);
            break;
         }
         var i:int = 0;
         while(i < tokens.length)
         {
            var token:String = String(tokens[i]);
            if(token.length > 0)
            {
               var compactToken:String = token.replace(/\s+/g,"");
               if("".indexOf(token) < 0 && "".indexOf(compactToken) < 0)
               {
                  return false;
               }
            }
            i++;
         }
         return true;
      }
      
      private function RebuildRootSearchResults() : void
      {
         this.mRootSearchResults = [];
         if(!this.IsRootSearchContext())
         {
            return;
         }
         if(this.mRootSearchHaystacks == null || this.mRootSearchHaystacks.length != this.GetTotalItems())
         {
            this.RebuildRootSearchIndex();
         }
         var query:String = this.GetRootSearchQuery();
         query = this.NormalizeRootSearchText(query);
         if(query == null || query.replace(/^\s+|\s+$/g,"").length == 0)
         {
            return;
         }
         if(this.mLinkedBaseX != null)
         {
            var _loc4_:* = this.mLinkedBaseX["fgehSearchCacheF2"];
            if(_loc4_ != null)
            {
               if(_loc4_["index"] === this.mRootSearchHaystacks)
               {
                  if(_loc4_["query"] == query)
                  {
                     if(_loc4_["results"] != null)
                     {
                        this.mRootSearchResults = _loc4_["results"];
                        return;
                     }
                  }
               }
            }
            this.mLinkedBaseX["fgehSearchTokensF2"] = query.split(/\s+/);
         }
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.RootSearchRowMatches(i,query))
            {
               this.mRootSearchResults.push(i);
            }
            i++;
         }
         if(this.mLinkedBaseX != null)
         {
            _loc4_ = this.mLinkedBaseX["fgehSearchCacheF2"];
            if(_loc4_ != null)
            {
               if(_loc4_["index"] === this.mRootSearchHaystacks)
               {
                  _loc4_["query"] = query;
                  _loc4_["results"] = this.mRootSearchResults;
               }
            }
         }
      }
      
      private function RootSearchEffectiveTotal() : int
      {
         return this.IsRootLiveSearchActive() ? (this.mRootSearchResults == null ? 0 : this.mRootSearchResults.length) : this.GetTotalItems();
      }
      
      private function RootSearchDataIndexAt(param1:int) : int
      {
         if(!this.IsRootLiveSearchActive())
         {
            return param1;
         }
         if(this.mRootSearchResults == null || param1 < 0 || param1 >= this.mRootSearchResults.length)
         {
            return -1;
         }
         return int(this.mRootSearchResults[param1]);
      }
      
      private function VisibleDataIndexForSlot(param1:int) : int
      {
         var visibleIndex:int = this.ActiveVisibleIndexForSlot(param1);
         return this.ActiveDataIndexAtVisible(visibleIndex);
      }
      
      private function HideLegacySearchTree(param1:DisplayObject) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function HideLegacySearchControl() : void
      {
         this.HideLegacySearchTree(this.mcContent);
      }
      
      private function RootSearchPlaceholderText() : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function PaintRootSearchBox(param1:Boolean) : void
      {
         if(this.mRootSearchLayer == null)
         {
            return;
         }
         this.mRootSearchLayer.graphics.clear();
         this.mRootSearchLayer.graphics.beginFill(16777215,0.99);
         this.mRootSearchLayer.graphics.lineStyle(param1 ? 2 : 1.25,param1 ? 4374476 : 10211285,1);
         this.mRootSearchLayer.graphics.drawRoundRect(0,0,184,32,7,7);
         this.mRootSearchLayer.graphics.endFill();
      }
      
      private function BuildRootSearch() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshRootSearch() : void
      {
         var visible:Boolean;
         this.HideLegacySearchControl();
         if(this.mRootSearchLayer == null || this.mRootSearchField == null)
         {
            return;
         }
         visible = this.IsRootSearchVisible();
         this.mRootSearchLayer.visible = visible;
         this.mRootSearchLayer.mouseEnabled = visible;
         this.mRootSearchLayer.mouseChildren = visible;
         if(!visible)
         {
            return;
         }
         if(this.mRootSearchPlaceholder != null)
         {
            this.mRootSearchPlaceholder.text = this.RootSearchPlaceholderText();
         }
         if(this.stage == null || this.stage.focus != this.mRootSearchField)
         {
            this.mRootSearchField.text = this.GetRootSearchQuery();
         }
         this.OnRootSearchChange(null);
         try
         {
            this.mcContent.setChildIndex(this.mRootSearchLayer,this.mcContent.numChildren - 1);
         }
         catch(e:Error)
         {
         }
      }
      
      private function ScheduleRootSearchStateSync() : void
      {
         if(this.GetV7ViewKind().indexOf("root") != 0)
         {
            return;
         }
         if(this.mRootSearchSyncTimer != 0)
         {
            try
            {
               clearTimeout(this.mRootSearchSyncTimer);
            }
            catch(e:Error)
            {
            }
         }
         this.mRootSearchSyncTimer = setTimeout(this.SyncRootSearchState,220);
      }
      
      private function SyncRootSearchState() : void
      {
         if(this.GetV7ViewKind().indexOf("root") != 0)
         {
            return;
         }
         this.mRootSearchSyncTimer = 0;
         var query:String = this.GetRootSearchQuery();
         var _loc2_:String = query + "|" + String(this.GetCurrentPage());
         if(_loc2_ == this.mRootSearchLastSynced)
         {
            return;
         }
         this.mRootSearchLastSynced = _loc2_;
         CommunicationManager.PostServerCommand("fgeh.root_search_query",encodeURIComponent(query) + "|" + String(this.GetCurrentPage()));
      }
      
      private function ApplyRootSearchLive(param1:String) : void
      {
         this.mRootSearchLocalQuery = param1 == null ? "" : param1;
         this.mRootSearchLocalPage = 0;
         this.mBatchLocalPage = -1;
         this.RebuildRootSearchResults();
         if(this.mData != null)
         {
            this.Draw(this.mData);
            this.RefreshNativeCells();
            this.RefreshSelectionOverlays();
            this.RefreshFavoriteMarkers();
            this.SyncCardInteractionState();
         }
         this.ScheduleRootSearchStateSync();
      }
      
      private function OnRootSearchChange(param1:Event) : void
      {
         if(this.mRootSearchField == null)
         {
            return;
         }
         var hasText:Boolean = this.mRootSearchField.text.length > 0;
         if(this.mRootSearchPlaceholder != null)
         {
            this.mRootSearchPlaceholder.visible = !hasText;
         }
         if(this.mRootSearchClearButton != null)
         {
            this.mRootSearchClearButton.visible = hasText;
            this.mRootSearchClearButton.mouseEnabled = hasText;
         }
         if(param1 != null)
         {
            this.ApplyRootSearchLive(this.mRootSearchField.text);
         }
      }
      
      private function OnRootSearchFocusIn(param1:FocusEvent) : void
      {
         this.PaintRootSearchBox(true);
      }
      
      private function OnRootSearchFocusOut(param1:FocusEvent) : void
      {
         this.PaintRootSearchBox(false);
      }
      
      private function OnRootSearchClear(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mRootSearchField != null)
         {
            this.mRootSearchField.text = "";
         }
         this.OnRootSearchChange(null);
         this.ApplyRootSearchLive("");
         if(this.stage != null && this.mRootSearchField != null)
         {
            try
            {
               this.stage.focus = this.mRootSearchField;
            }
            catch(e:Error)
            {
            }
         }
      }
      
      private function BuildRootTools() : void
      {
         if(this.mcContent == null || this.mRootToolsLayer != null)
         {
            return;
         }
         this.mRootToolsLayer = new MovieClip();
         this.mRootToolsLayer.name = "fgehRootToolsLayer";
         this.mRootToolsLayer.mouseEnabled = false;
         this.mRootToolsLayer.mouseChildren = true;
         this.mcContent.addChild(this.mRootToolsLayer);
         this.mRootToolsLayer.visible = false;
      }
      
      private function IsCurrentOuterGroupPackSelectionContext() : Boolean
      {
         return this.GetV7ViewKind() == "root_grouped_packs" && this.GetV7ActiveGroupIndex() >= 0 && this.BatchSelectionScope() == "pack";
      }
      
      private function OnRootBatchRemoveCurrentOuterGroup(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.IsCurrentOuterGroupPackSelectionContext())
         {
            return;
         }
         var values:Array = this.BatchSelectedItemValues();
         var groupIndex:int = this.GetV7ActiveGroupIndex();
         var groupName:String = this.GetV7GroupName(groupIndex);
         if(values.length <= 0 || !groupName)
         {
            return;
         }
         CommunicationManager.PostServerCommand("fgeh.membership_remove_many",encodeURIComponent("outer"),encodeURIComponent(groupName),"",encodeURIComponent(values.join(FAVORITE_ITEM_SEPARATOR)));
         this.mBatchSelectMode = false;
         this.mBatchLocalPage = -1;
         this.ClearBatchPoseSelection();
         this.ClearLinkedMarqueeVisual();
         this.PostResponse(RESPONSE_PAGE_BASE);
      }
      
      private function RefreshRootTools() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnRootBatchSelect(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.GetV7ViewKind().indexOf("root") != 0 || !this.HasFavoritableRows())
         {
            return;
         }
         this.SetBatchSelectMode(!this.mBatchSelectMode);
      }
      
      private function OnRootBatchFavoriteGroup(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         if(this.BatchSelectionScope() != "pack")
         {
            return;
         }
         var target:DisplayObject = param1.currentTarget as DisplayObject;
         var bounds:Rectangle = target.getBounds(this.mcContent);
         this.OpenPackOrganizeChooser(bounds.x - 208,bounds.bottom + 5,-1);
      }
      
      private function OnRootBatchFavorite(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostBatchFavoriteSelected();
         this.RefreshRootTools();
      }
      
      private function OnFavoriteAuthorsView(param1:MouseEvent) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnAllAuthorsView(param1:MouseEvent) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnRootSortToggle(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || this.GetV7ViewKind().indexOf("root") != 0)
         {
            return;
         }
         this.PostResponse(RESPONSE_ROOT_SORT_TOGGLE);
      }
      
      private function OnRootViewToggle(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || this.GetV7ViewKind().indexOf("root") != 0)
         {
            return;
         }
         var nav:int = this.GetV7ActiveNav();
         if(nav == 1)
         {
            this.PostResponse(RESPONSE_FAV_PACK_VIEW_TOGGLE);
            return;
         }
         if(nav == 2)
         {
            this.PostResponse(RESPONSE_CREATOR_VIEW_TOGGLE);
            return;
         }
         if(nav == 4)
         {
            this.PostResponse(RESPONSE_FAV_POSE_VIEW_TOGGLE);
            return;
         }
         if(nav == 5)
         {
            this.PostResponse(RESPONSE_LINKED_VIEW_TOGGLE);
            return;
         }
      }
      
      private function BuildEditInfoModal() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshEditInfoLocalization() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OpenEditInfo(param1:int) : void
      {
         var key:String;
         if(this.mEditInfoLayer == null)
         {
            return;
         }
         this.RefreshEditInfoLocalization();
         key = this.GetEditInfoKey(param1);
         if(key == null || key.length == 0)
         {
            return;
         }
         this.mEditInfoLinkedMode = false;
         this.mEditInfoKey = key;
         this.mEditInfoIndex = param1;
         this.mEditInfoNameField.text = this.GetEditInfoName(param1);
         this.mEditInfoNoteField.text = this.GetEditInfoNote(param1);
         this.mEditInfoLayer.visible = true;
         this.SetCardInteractionBlocked(true);
         try
         {
            this.mcContent.setChildIndex(this.mEditInfoLayer,this.mcContent.numChildren - 1);
            this.stage.focus = this.mEditInfoNameField;
         }
         catch(e:Error)
         {
         }
      }
      
      private function OpenLinkedEditInfo(param1:String, param2:String, param3:String) : void
      {
         var now:int;
         if(this.mEditInfoLayer == null || param1 == null || param1.length == 0)
         {
            return;
         }
         now = getTimer();
         if(this.mLastLinkedEditKey == param1 && now - this.mLastLinkedEditTime < 250)
         {
            return;
         }
         this.mLastLinkedEditKey = param1;
         this.mLastLinkedEditTime = now;
         this.mEditInfoLinkedMode = true;
         this.mEditInfoKey = param1;
         this.mEditInfoIndex = -1;
         this.mEditInfoNameField.text = param2 == null ? "" : param2;
         this.mEditInfoNoteField.text = param3 == null ? "" : param3;
         this.mEditInfoLayer.visible = true;
         this.SetCardInteractionBlocked(true);
         try
         {
            this.mcContent.setChildIndex(this.mEditInfoLayer,this.mcContent.numChildren - 1);
            this.stage.focus = this.mEditInfoNameField;
         }
         catch(e:Error)
         {
         }
      }
      
      private function OnEditInfoCancel(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mEditInfoLayer != null)
         {
            this.mEditInfoLayer.visible = false;
         }
         this.mEditInfoKey = "";
         this.mEditInfoIndex = -1;
         this.mEditInfoLinkedMode = false;
         this.SetCardInteractionBlocked(false);
      }
      
      private function OnEditInfoSave(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mEditInfoKey == null || this.mEditInfoKey.length == 0)
         {
            this.OnEditInfoCancel(param1);
            return;
         }
         var savedKey:String = this.mEditInfoKey;
         var savedName:String = this.mEditInfoNameField.text;
         var savedNote:String = this.mEditInfoNoteField.text;
         var linkedMode:Boolean = this.mEditInfoLinkedMode;
         CommunicationManager.PostServerCommand("fgeh.pose_edit_info",encodeURIComponent(savedKey),encodeURIComponent(savedName),encodeURIComponent(savedNote));
         this.mEditInfoLayer.visible = false;
         this.mEditInfoKey = "";
         this.mEditInfoIndex = -1;
         this.mEditInfoLinkedMode = false;
         if(linkedMode)
         {
            this.mLinkedEditNameOverrides[savedKey] = savedName;
            this.mLinkedEditNoteOverrides[savedKey] = savedNote;
            this.SetCardInteractionBlocked(false);
            this.RefreshLinkedEditedProductVisuals(savedKey);
            return;
         }
         this.PostResponse(RESPONSE_EDIT_INFO_REFRESH);
      }
      
      private function BuildLinkedDrawer() : void
      {
         if(this.mcContent == null || this.mLinkedDrawerLayer != null)
         {
            return;
         }
         if(this.mLinkedMarqueeLayer == null)
         {
            this.mLinkedMarqueeLayer = new MovieClip();
            this.mLinkedMarqueeLayer.name = "fgehLinkedMarqueeLayer";
            this.mLinkedMarqueeLayer.mouseEnabled = false;
            this.mLinkedMarqueeLayer.mouseChildren = false;
            this.mcContent.addChild(this.mLinkedMarqueeLayer);
         }
         this.mLinkedDrawerLayer = new MovieClip();
         this.mLinkedDrawerLayer.name = "fgehLinkedDrawerLayer";
         this.mLinkedDrawerLayer.mouseEnabled = true;
         this.mLinkedDrawerLayer.mouseChildren = true;
         this.mLinkedDrawerRows = [];
         this.mcContent.addChild(this.mLinkedDrawerLayer);
         this.mLinkedDrawerLayer.visible = false;
         this.mLinkedDrawerLayer.addEventListener(MouseEvent.MOUSE_DOWN,this.SwallowLinkedDrawerMouse,false,20000,true);
         this.mLinkedDrawerLayer.addEventListener(MouseEvent.MOUSE_UP,this.SwallowLinkedDrawerMouse,false,20000,true);
         this.mLinkedDrawerLayer.addEventListener(MouseEvent.CLICK,this.SwallowLinkedDrawerMouse,false,20000,true);
      }
      
      private function SwallowLinkedDrawerMouse(param1:MouseEvent) : void
      {
         if(param1 != null && this.mLinkedManageMode)
         {
            param1.stopPropagation();
         }
      }
      
      private function BuildLinkedRemoveLayer() : void
      {
         if(this.mcContent == null || this.mLinkedRemoveLayer != null)
         {
            return;
         }
         this.mLinkedRemoveLayer = new MovieClip();
         this.mLinkedRemoveLayer.name = "fgehLinkedRemoveLayer";
         this.mLinkedRemoveLayer.mouseEnabled = true;
         this.mLinkedRemoveLayer.mouseChildren = true;
         this.mcContent.addChild(this.mLinkedRemoveLayer);
         this.mLinkedRemoveLayer.visible = false;
      }
      
      private function LinkedObjectProductSourceState(param1:int) : Object
      {
         if(this.mLinkedTypeFilter == "cas")
         {
            var localIds:Array = [];
            var seenLocal:Object = {};
            var hasLocal:Boolean = false;
            var hasExternal:Boolean = false;
            var variantCount:int = int(this.GetLinkedProductField(this.mLinkedActiveIndex,param1,3,"0"));
            var vi:int = 0;
            while(vi < variantCount)
            {
               var origin:String = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,param1,vi,5,"external");
               var itemId:String = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,param1,vi,1,"0");
               if(origin == "local")
               {
                  hasLocal = true;
                  if(itemId != "0" && itemId.length > 0 && !seenLocal[itemId])
                  {
                     seenLocal[itemId] = true;
                     localIds.push(itemId);
                  }
               }
               else
               {
                  hasExternal = true;
               }
               vi++;
            }
            return {
               "localIds":localIds,
               "hasLocal":hasLocal,
               "hasExternal":hasExternal
            };
         }
         localIds = [];
         seenLocal = {};
         hasLocal = false;
         hasExternal = false;
         variantCount = int(this.GetLinkedObjectProductField(this.mLinkedActiveIndex,param1,3,"0"));
         vi = 0;
         while(vi < variantCount)
         {
            origin = this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,param1,vi,4,"external");
            itemId = this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,param1,vi,1,"0");
            if(origin == "local")
            {
               hasLocal = true;
               if(itemId != "0" && itemId.length > 0 && !seenLocal[itemId])
               {
                  seenLocal[itemId] = true;
                  localIds.push(itemId);
               }
            }
            else
            {
               hasExternal = true;
            }
            vi++;
         }
         return {
            "localIds":localIds,
            "hasLocal":hasLocal,
            "hasExternal":hasExternal
         };
      }
      
      private function CloseLinkedRemoveMenu(param1:MouseEvent = null) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mLinkedRemoveLayer != null)
         {
            this.mLinkedRemoveLayer.visible = false;
            this.ClearDisplayChildren(this.mLinkedRemoveLayer);
            this.mLinkedRemoveLayer.graphics.clear();
         }
         this.mLinkedRemoveProductIndex = -1;
         this.mLinkedRemoveLocalIds = [];
         this.mLinkedRemoveHasExternal = false;
         this.SetCardInteractionBlocked(false);
      }
      
      private function OpenLinkedObjectRemoveMenu(param1:int) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnLinkedRemoveConfirm(param1:MouseEvent) : void
      {
         if(this.mLinkedTypeFilter == "cas")
         {
            if(param1 != null)
            {
               param1.stopImmediatePropagation();
            }
            CommunicationManager.PostServerCommand("fgeh.linked_remove_local_cas",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),encodeURIComponent(this.mLinkedRemoveLocalIds.join(",")));
            this.CloseLinkedRemoveMenu();
            setTimeout(this.RefreshAfterLinkedLocalRemove,80);
            return;
         }
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mLinkedRemoveProductIndex < 0 || this.mLinkedRemoveLocalIds == null || this.mLinkedRemoveLocalIds.length == 0)
         {
            this.CloseLinkedRemoveMenu();
            return;
         }
         CommunicationManager.PostServerCommand("fgeh.linked_remove_local_object",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),encodeURIComponent(this.mLinkedRemoveLocalIds.join(",")));
         this.CloseLinkedRemoveMenu();
         setTimeout(this.RefreshAfterLinkedLocalRemove,80);
      }
      
      private function RefreshAfterLinkedLocalRemove() : void
      {
         this.PostResponse(RESPONSE_EDIT_INFO_REFRESH);
      }
      
      private function KeepLinkedDrawerOnTop() : void
      {
         if(this.mcContent == null || this.mLinkedDrawerLayer == null || !this.mLinkedManageMode || !this.mLinkedDrawerLayer.visible)
         {
            return;
         }
         try
         {
            this.mcContent.setChildIndex(this.mLinkedDrawerLayer,this.mcContent.numChildren - 1);
         }
         catch(e:Error)
         {
         }
      }
      
      private function IsPointerInsideLinkedDrawer() : Boolean
      {
         var drawerBounds:Rectangle;
         if(!this.mLinkedManageMode || this.mLinkedDrawerLayer == null || !this.mLinkedDrawerLayer.visible || this.stage == null)
         {
            return false;
         }
         try
         {
            drawerBounds = this.mLinkedDrawerLayer.getBounds(this.stage);
            return drawerBounds.contains(this.stage.mouseX,this.stage.mouseY);
         }
         catch(e:Error)
         {
            return false;
         }
      }
      
      private function ClearLinkedDrawer() : void
      {
         if(this.mLinkedDrawerLayer == null)
         {
            return;
         }
         this.CancelPendingCASProductHover();
         this.CancelPendingCASSwatchHover();
         this.CancelCASPreviewImageRequest();
         while(this.mLinkedDrawerLayer.numChildren > 0)
         {
            this.mLinkedDrawerLayer.removeChildAt(this.mLinkedDrawerLayer.numChildren - 1);
         }
         this.mLinkedDrawerLayer.graphics.clear();
         this.mLinkedDrawerRows = [];
         this.mLinkedCASProductCards = [];
         this.mLinkedObjectProductCards = [];
         this.mLinkedRightPressProductIndex = -1;
         this.mLinkedRightPressStartedAt = 0;
         this.mLinkedRemoveProductIndex = -1;
         this.mLinkedRemoveLocalIds = [];
         this.mLinkedRemoveHasExternal = false;
         if(this.mLinkedRemoveLayer != null)
         {
            this.mLinkedRemoveLayer.visible = false;
         }
         this.mLinkedPoseStatusLabel = null;
         this.mLinkedCASPreviewPanel = null;
         this.mLinkedCASPreviewCard = null;
         this.mLinkedCASPreviewProductIndex = -1;
         if(this.mcContent.getChildByName("fgehAccessoryLibraryLayer"))
         {
            this.ClearDisplayChildren(this.mcContent.getChildByName("fgehAccessoryLibraryLayer"));
            this.mcContent.getChildByName("fgehAccessoryLibraryLayer").graphics.clear();
            this.mcContent.getChildByName("fgehAccessoryLibraryLayer").visible = false;
         }
      }
      
      private function LinkedShiftObject(param1:String, param2:Number, param3:Number = 0) : void
      {
         var target:DisplayObject = this.Child(param1);
         if(target == null)
         {
            return;
         }
         try
         {
            if(!this.mLinkedBaseX.hasOwnProperty(param1))
            {
               this.mLinkedBaseX[param1] = target.x;
            }
            if(!this.mLinkedBaseY.hasOwnProperty(param1))
            {
               this.mLinkedBaseY[param1] = target.y;
            }
            target.x = Number(this.mLinkedBaseX[param1]) + param2;
            target.y = Number(this.mLinkedBaseY[param1]) + param3;
         }
         catch(e:Error)
         {
         }
      }
      
      private function ApplyLinkedManageLayout() : void
      {
         if(this.mcContent == null)
         {
            if(this.IsLegacyNormalPackDetail())
            {
               this.SetVisible("fgehLibraryButton",false);
               this.SetVisible("fgehLibraryLabel",false);
            }
            try
            {
               if(this.mLinkedManageMode)
               {
                  getDefinitionByName("fgeh.ui.targets::TargetRail").Hide(this);
               }
            }
            catch(_loc_e_:*)
            {
            }
         }
         else
         {
            this.SetVisible("fgehLegacySidebarBackground",!this.mLinkedManageMode);
            var slot:int = 1;
            while(slot <= this.ActiveItemsPerPage())
            {
               var dx:Number = 0;
               var dy:Number = 0;
               if(this.mLinkedManageMode && slot <= LINKED_ITEMS_PER_PAGE)
               {
                  var zero:int = slot - 1;
                  var oldCol:int = zero % 3;
                  var oldRow:int = int(zero / 3);
                  var newCol:int = zero % 2;
                  var newRow:int = int(zero / 2);
                  dx = LINKED_GRID_SHIFT + (newCol - oldCol) * 230;
                  dy = (newRow - oldRow) * 120;
               }
               this.LinkedShiftObject("fgehPackCard" + slot,dx,dy);
               this.LinkedShiftObject("fgehPackIcon" + slot,dx,dy);
               this.LinkedShiftObject("fgehPackName" + slot,dx,dy);
               this.LinkedShiftObject("fgehPackCreator" + slot,dx,dy);
               this.LinkedShiftObject("fgehPackCount" + slot,dx,dy);
               slot++;
            }
            var scrollOffset:Number = this.mLinkedManageMode ? LINKED_SCROLL_SHIFT : 0;
            this.LinkedShiftObject("fgehScrollTrack",scrollOffset,0);
            this.LinkedShiftObject("fgehScrollThumb",scrollOffset,0);
            this.LinkedShiftObject("fgehScrollTrackHit",scrollOffset,0);
            this.LinkedShiftObject("fgehScrollThumbHit",scrollOffset,0);
            this.LinkedShiftObject("fgehPackStats",this.mLinkedManageMode ? LINKED_GRID_SHIFT : 0,0);
            if(this.mLinkedManageMode)
            {
               this.SetVisible("fgehLibraryButton",false);
               this.SetVisible("fgehLibraryLabel",false);
               if(this.mFixedToolsLayer != null)
               {
                  this.mFixedToolsLayer.visible = false;
               }
               if(this.mGroupTabsLayer != null)
               {
                  this.mGroupTabsLayer.visible = false;
               }
            }
            else
            {
               if(this.IsLegacyNormalPackDetail())
               {
                  this.SetVisible("fgehLibraryButton",true);
                  this.SetVisible("fgehLibraryLabel",true);
               }
               this.RefreshGroupTabs();
               this.RefreshFixedTools();
            }
            this.UpdateScrollThumb(this.GetCurrentPage(),this.GetPageCount());
            this.RefreshNativeCells();
            this.RefreshFavoriteMarkers();
            if(this.IsLegacyNormalPackDetail())
            {
               this.SetVisible("fgehLibraryButton",false);
               this.SetVisible("fgehLibraryLabel",false);
            }
            try
            {
               if(this.mLinkedManageMode)
               {
                  getDefinitionByName("fgeh.ui.targets::TargetRail").Hide(this);
               }
            }
            catch(_loc_e_:*)
            {
            }
         }
         §§pop();
      }
      
      private function EnterLinkedManage(param1:int = -1) : void
      {
         if(!this.HasLinkedDetailExtension())
         {
            return;
         }
         var count:int = this.GetLinkedRowCount();
         if(count <= 0)
         {
            return;
         }
         if(param1 < 0 || param1 >= count)
         {
            param1 = this.GetCurrentPage() * this.ActiveItemsPerPage();
            if(param1 < 0 || param1 >= count)
            {
               param1 = 0;
            }
         }
         this.mLinkedManageMode = true;
         this.mLinkedLocalPage = param1 / LINKED_ITEMS_PER_PAGE;
         this.mLinkedActiveIndex = param1;
         this.mLinkedResourcePage = 0;
         this.mLinkedMultiSelectMode = false;
         this.ClearLinkedPoseSelection();
         if(this.mData != null)
         {
            this.Draw(this.mData);
         }
         this.ApplyLinkedManageLayout();
         this.RefreshRootSearch();
         this.RefreshSelectionOverlays();
         this.RefreshLinkedDrawer();
      }
      
      private function ExitLinkedManage() : void
      {
         if(!this.mLinkedManageMode)
         {
            return;
         }
         this.mLinkedIgnoreNativeUntil = getTimer() + 300;
         this.mLinkedManageMode = false;
         if(this.mLinkedDrawerLayer != null)
         {
            this.mLinkedDrawerLayer.visible = false;
         }
         if(this.mData != null)
         {
            this.Draw(this.mData);
         }
         this.ApplyLinkedManageLayout();
         this.RefreshRootSearch();
         this.RefreshSelectionOverlays();
         this.mLinkedLocalPage = -1;
         this.mLinkedMultiSelectMode = false;
         this.mLinkedMarqueeDown = false;
         this.mLinkedMarqueeDragging = false;
         this.ClearLinkedMarqueeVisual();
         this.ClearLinkedPoseSelection();
      }
      
      private function ClearBatchPoseSelection() : void
      {
         this.mBatchSelectedPoses = {};
      }
      
      private function IsBatchPoseSelected(param1:int) : Boolean
      {
         try
         {
            return Boolean(this.mBatchSelectedPoses[String(param1)]);
         }
         catch(e:Error)
         {
            return false;
         }
      }
      
      private function SetBatchPoseSelected(param1:int, param2:Boolean) : void
      {
         var key:String;
         if(param1 < 0 || param1 >= this.GetTotalItems())
         {
            return;
         }
         key = String(param1);
         try
         {
            if(param2)
            {
               this.mBatchSelectedPoses[key] = true;
            }
            else
            {
               delete this.mBatchSelectedPoses[key];
            }
         }
         catch(e:Error)
         {
         }
      }
      
      private function BatchSelectedPoseCount() : int
      {
         var key:String;
         var count:int = 0;
         try
         {
            for(key in this.mBatchSelectedPoses)
            {
               if(Boolean(this.mBatchSelectedPoses[key]))
               {
                  count++;
               }
            }
         }
         catch(e:Error)
         {
         }
         return count;
      }
      
      private function BatchSelectionScope() : String
      {
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.IsBatchPoseSelected(i))
            {
               var scope:String = this.FavoriteScopeForIndex(i);
               if(scope)
               {
                  return scope;
               }
            }
            i++;
         }
         return "";
      }
      
      private function BatchSelectedItemValues() : Array
      {
         var result:Array = [];
         var scope:String = this.BatchSelectionScope();
         if(!scope)
         {
            return result;
         }
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.IsBatchPoseSelected(i) && this.FavoriteScopeForIndex(i) == scope)
            {
               var value:String = this.FavoriteValueForIndex(i);
               if(value)
               {
                  result.push(value);
               }
            }
            i++;
         }
         return result;
      }
      
      private function AreAllBatchSelectedFavorite() : Boolean
      {
         var scope:String = this.BatchSelectionScope();
         if(!scope)
         {
            return false;
         }
         var found:Boolean = false;
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.IsBatchPoseSelected(i) && this.FavoriteScopeForIndex(i) == scope)
            {
               found = true;
               if(!this.IsRowFavorite(i))
               {
                  return false;
               }
            }
            i++;
         }
         return found;
      }
      
      private function PostBatchFavoriteSelected() : void
      {
         var values:Array = this.BatchSelectedItemValues();
         var scope:String = this.BatchSelectionScope();
         if(values.length <= 0 || !scope)
         {
            return;
         }
         var enabled:Boolean = !this.AreAllBatchSelectedFavorite();
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.IsBatchPoseSelected(i) && this.FavoriteScopeForIndex(i) == scope)
            {
               this.SetLocalRowFavorite(i,enabled);
            }
            i++;
         }
         this.RefreshFavoriteMarkers();
         CommunicationManager.PostServerCommand("fgeh.batch_favorite",encodeURIComponent(scope),encodeURIComponent(values.join(FAVORITE_ITEM_SEPARATOR)),enabled ? 1 : 0);
         this.RefreshFixedTools();
         this.RefreshRootTools();
         this.RefreshRootSearch();
      }
      
      private function BatchSelectedPoseNames() : Array
      {
         var result:Array = [];
         var total:int = this.GetTotalItems();
         var i:int = 0;
         while(i < total)
         {
            if(this.IsBatchPoseSelected(i))
            {
               var key:String = this.GetEditInfoKey(i);
               if(key.indexOf("pose_") == 0)
               {
                  key = key.substr(5);
               }
               if(key)
               {
                  result.push(key);
               }
            }
            i++;
         }
         return result;
      }
      
      private function SetBatchSelectMode(param1:Boolean) : void
      {
         if(param1 == this.mBatchSelectMode)
         {
            return;
         }
         if(param1)
         {
            var currentPage:int = this.GetCurrentPage();
            this.mBatchSelectMode = true;
            this.mBatchLocalPage = currentPage;
            this.ClearBatchPoseSelection();
            if(this.mLinkedManageMode)
            {
               this.ExitLinkedManage();
            }
         }
         else
         {
            this.CloseBatchFavoriteGroupMenu();
            this.mBatchSelectMode = false;
            this.mBatchLocalPage = -1;
            this.ClearBatchPoseSelection();
            this.mLinkedMarqueeDown = false;
            this.mLinkedMarqueeDragging = false;
            this.ClearLinkedMarqueeVisual();
         }
         this.RefreshSelectionOverlays();
         this.RefreshFixedTools();
         this.RefreshRootTools();
         this.RefreshRootSearch();
         this.SyncCardInteractionState();
      }
      
      private function ClearLinkedPoseSelection() : void
      {
         this.mLinkedSelectedPoses = {};
      }
      
      private function IsLinkedPoseSelected(param1:int) : Boolean
      {
         try
         {
            return Boolean(this.mLinkedSelectedPoses[String(param1)]);
         }
         catch(e:Error)
         {
            return false;
         }
      }
      
      private function SetLinkedPoseSelected(param1:int, param2:Boolean) : void
      {
         var key:String;
         if(param1 < 0 || param1 >= this.GetLinkedRowCount())
         {
            return;
         }
         key = String(param1);
         try
         {
            if(param2)
            {
               this.mLinkedSelectedPoses[key] = true;
            }
            else
            {
               delete this.mLinkedSelectedPoses[key];
            }
         }
         catch(e:Error)
         {
         }
      }
      
      private function LinkedSelectedPoseCount() : int
      {
         var key:String;
         var count:int = 0;
         try
         {
            for(key in this.mLinkedSelectedPoses)
            {
               if(Boolean(this.mLinkedSelectedPoses[key]))
               {
                  count++;
               }
            }
         }
         catch(e:Error)
         {
         }
         return count;
      }
      
      private function LinkedSelectedTargetCount() : int
      {
         var count:int = this.LinkedSelectedPoseCount();
         if(this.IsLinkedPoseSelected(this.mLinkedActiveIndex))
         {
            count--;
         }
         return Math.max(0,count);
      }
      
      private function LinkedSelectedPoseNames() : Array
      {
         var result:Array = [];
         var rowCount:int = this.GetLinkedRowCount();
         var i:int = 0;
         while(i < rowCount)
         {
            if(this.IsLinkedPoseSelected(i) && i != this.mLinkedActiveIndex)
            {
               var poseName:String = this.GetLinkedPoseName(i);
               if(poseName)
               {
                  result.push(poseName);
               }
            }
            i++;
         }
         return result;
      }
      
      private function ToggleLinkedMultiSelect() : void
      {
         var wasExpanded:Boolean = this.mLinkedInspectorExpanded;
         this.mLinkedMultiSelectMode = !this.mLinkedMultiSelectMode;
         this.ClearLinkedPoseSelection();
         if(this.mLinkedMultiSelectMode)
         {
            this.mLinkedInspectorExpanded = true;
            this.SetLinkedPoseSelected(this.mLinkedActiveIndex,true);
         }
         else
         {
            this.mLinkedMarqueeDown = false;
            this.mLinkedMarqueeDragging = false;
            this.ClearLinkedMarqueeVisual();
         }
         if(this.mLinkedMultiSelectMode && !wasExpanded)
         {
            this.RefreshLinkedDrawer();
         }
         else
         {
            this.UpdateLinkedMultiSelectChrome();
         }
         this.RefreshSelectionOverlays();
         this.SyncCardInteractionState();
         this.KeepLinkedDrawerOnTop();
      }
      
      private function GetLinkedSummaryOverride(param1:int, param2:String) : String
      {
         var key:String;
         try
         {
            key = String(param1);
            if(this.mLinkedSummaryOverrides.hasOwnProperty(key))
            {
               return String(this.mLinkedSummaryOverrides[key]);
            }
         }
         catch(e:Error)
         {
         }
         return param2;
      }
      
      private function GetLinkedRowSummary(param1:int) : String
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshLinkedRowSummary(param1:int) : void
      {
         var summary:String;
         var page:int;
         var first:int;
         var slot:int;
         if(param1 < 0 || param1 >= this.GetLinkedRowCount())
         {
            return;
         }
         summary = this.GetLinkedRowSummary(param1);
         try
         {
            this.mLinkedSummaryOverrides[String(param1)] = summary;
         }
         catch(eStore:Error)
         {
         }
         page = this.GetCurrentPage();
         first = page * this.ActiveItemsPerPage();
         slot = param1 - first;
         if(slot >= 0 && slot < this.ActiveItemsPerPage())
         {
            this.SetHtml("fgehPackCreator" + (slot + 1),summary);
            this.ApplyCardReadability(slot + 1);
         }
      }
      
      private function SetLinkedRowSummaryFast(param1:int, param2:String) : void
      {
         var page:int;
         var first:int;
         var slot:int;
         if(param1 < 0 || param1 >= this.GetLinkedRowCount())
         {
            return;
         }
         try
         {
            this.mLinkedSummaryOverrides[String(param1)] = param2;
         }
         catch(eStore:Error)
         {
         }
         page = this.GetCurrentPage();
         first = page * this.ActiveItemsPerPage();
         slot = param1 - first;
         if(slot >= 0 && slot < this.ActiveItemsPerPage())
         {
            this.SetHtml("fgehPackCreator" + (slot + 1),param2);
            this.ApplyCardReadability(slot + 1);
         }
      }
      
      private function LinkedGridCanvasBounds() : Rectangle
      {
         var first:Rectangle = this.ExactGridHitBounds(0);
         var last:Rectangle = this.ExactGridHitBounds(this.ActiveItemsPerPage() - 1);
         return new Rectangle(first.x,first.y,last.right - first.x,last.bottom - first.y);
      }
      
      private function ClearLinkedMarqueeVisual() : void
      {
         if(this.mLinkedMarqueeLayer != null)
         {
            this.mLinkedMarqueeLayer.graphics.clear();
         }
      }
      
      private function AbortMarqueeInteraction() : void
      {
         this.mLinkedMarqueeDown = false;
         this.mLinkedMarqueeDragging = false;
         this.mMarqueeAutoBatchCandidate = false;
         this.ClearLinkedMarqueeVisual();
         if(this.mNativeLayer != null)
         {
            this.mNativeLayer.visible = true;
         }
         this.SyncCardInteractionState();
      }
      
      private function CanDirectBatchSelectHere() : Boolean
      {
         if(this.mLinkedManageMode || this.IsAnyMemberEditMode())
         {
            return false;
         }
         return this.HasFavoritableRows();
      }
      
      private function SelectionBlankCanvasBounds() : Rectangle
      {
         var grid:Rectangle = this.LinkedGridCanvasBounds();
         return new Rectangle(grid.x - 8,grid.y - 8,grid.width + 16,grid.height + 34);
      }
      
      private function OnSelectionBlankClick(param1:MouseEvent) : void
      {
         if(param1 == null || !this.mBatchSelectMode || this.mLinkedManageMode || this.IsAnyMemberEditMode() || this.IsAnyManagerModalOpen() || this.mcContent == null)
         {
            return;
         }
         if(getTimer() < this.mLinkedIgnoreNativeUntil)
         {
            return;
         }
         var canvas:Rectangle = this.SelectionBlankCanvasBounds();
         if(!canvas.contains(this.mcContent.mouseX,this.mcContent.mouseY))
         {
            return;
         }
         if(this.NativeIndexUnderStageMouse() >= 0)
         {
            return;
         }
         param1.stopImmediatePropagation();
         this.SetBatchSelectMode(false);
      }
      
      private function GetMarqueeDataIndices(param1:Rectangle) : Array
      {
         var result:Array = [];
         if(param1 == null || param1.width < 2 || param1.height < 2)
         {
            return result;
         }
         var page:int = this.GetCurrentPage();
         var total:int = this.ActiveTotalItems();
         var pageSize:int = this.ActiveItemsPerPage();
         var slot:int = 0;
         while(slot < pageSize)
         {
            var visibleIndex:int = page * pageSize + slot;
            var dataIndex:int = this.ActiveDataIndexAtVisible(visibleIndex);
            if(visibleIndex >= 0 && visibleIndex < total && dataIndex >= 0 && param1.intersects(this.ExactGridHitBounds(slot)))
            {
               result.push(dataIndex);
            }
            slot++;
         }
         return result;
      }
      
      private function ApplyMemberMarqueeSelection(param1:Rectangle) : void
      {
         if(param1 == null || !this.IsAnyMemberEditMode())
         {
            return;
         }
         var indices:Array = this.GetMarqueeDataIndices(param1);
         if(indices.length <= 0)
         {
            return;
         }
         var shouldSelect:Boolean = false;
         var i:int = 0;
         while(i < indices.length)
         {
            if(!this.IsMemberSelected(int(indices[i])))
            {
               shouldSelect = true;
               break;
            }
            i++;
         }
         var changed:Array = [];
         i = 0;
         while(i < indices.length)
         {
            var dataIndex:int = int(indices[i]);
            var current:Boolean = this.IsMemberSelected(dataIndex);
            if(current != shouldSelect)
            {
               var value:String = this.ToggleMemberIndexLocal(dataIndex,false);
               if(value)
               {
                  changed.push(value);
               }
            }
            i++;
         }
         if(changed.length > 0 && !this.IsOuterGroupRemoveManageMode())
         {
            this.PostMemberToggleValues(changed);
         }
         this.RefreshSelectionOverlays();
         if(this.IsOuterGroupRemoveManageMode())
         {
            this.RefreshOuterGroupTools();
         }
      }
      
      private function DrawLinkedMarquee(param1:Number, param2:Number, param3:Number, param4:Number) : Rectangle
      {
         var left:Number = Math.min(param1,param3);
         var top:Number = Math.min(param2,param4);
         var right:Number = Math.max(param1,param3);
         var bottom:Number = Math.max(param2,param4);
         var canvas:Rectangle = this.LinkedGridCanvasBounds();
         left = Math.max(left,canvas.left);
         top = Math.max(top,canvas.top);
         right = Math.min(right,canvas.right);
         bottom = Math.min(bottom,canvas.bottom);
         var rect:Rectangle = new Rectangle(left,top,Math.max(0,right - left),Math.max(0,bottom - top));
         if(this.mLinkedMarqueeLayer != null)
         {
            this.mLinkedMarqueeLayer.graphics.clear();
            this.mLinkedMarqueeLayer.graphics.beginFill(7317899,0.1);
            this.mLinkedMarqueeLayer.graphics.lineStyle(1.5,6266491,0.95);
            this.mLinkedMarqueeLayer.graphics.drawRect(rect.x,rect.y,rect.width,rect.height);
            this.mLinkedMarqueeLayer.graphics.endFill();
            try
            {
               this.mcContent.setChildIndex(this.mLinkedMarqueeLayer,this.mcContent.numChildren - 1);
               if(this.mLinkedDrawerLayer != null && this.mLinkedDrawerLayer.visible)
               {
                  this.mcContent.setChildIndex(this.mLinkedDrawerLayer,this.mcContent.numChildren - 1);
               }
            }
            catch(e:Error)
            {
            }
         }
         return rect;
      }
      
      private function ApplyLinkedMarqueeSelection(param1:Rectangle) : void
      {
         var indices:Array;
         var linkedMode:Boolean;
         var shouldSelect:Boolean;
         var foundEditable:Boolean;
         var i:int;
         var probeIndex:int;
         var dataIndex:int;
         if(param1 == null || param1.width < 2 || param1.height < 2)
         {
            return;
         }
         if(this.IsAnyMemberEditMode())
         {
            this.ApplyMemberMarqueeSelection(param1);
            return;
         }
         indices = this.GetMarqueeDataIndices(param1);
         if(indices.length <= 0)
         {
            return;
         }
         linkedMode = this.mLinkedManageMode && this.mLinkedMultiSelectMode;
         if(linkedMode)
         {
            this.SetLinkedPoseSelected(this.mLinkedActiveIndex,true);
         }
         shouldSelect = false;
         foundEditable = false;
         i = 0;
         while(i < indices.length)
         {
            probeIndex = int(indices[i]);
            if(linkedMode && probeIndex == this.mLinkedActiveIndex)
            {
               i++;
            }
            else
            {
               foundEditable = true;
               if(linkedMode)
               {
                  if(!this.IsLinkedPoseSelected(probeIndex))
                  {
                     shouldSelect = true;
                     break;
                  }
               }
               else if(this.mBatchSelectMode)
               {
                  if(!this.IsBatchPoseSelected(probeIndex))
                  {
                     shouldSelect = true;
                     break;
                  }
               }
               i++;
            }
         }
         if(!foundEditable)
         {
            return;
         }
         i = 0;
         while(i < indices.length)
         {
            dataIndex = int(indices[i]);
            if(linkedMode)
            {
               if(dataIndex != this.mLinkedActiveIndex)
               {
                  this.SetLinkedPoseSelected(dataIndex,shouldSelect);
               }
            }
            else if(this.mBatchSelectMode)
            {
               this.SetBatchPoseSelected(dataIndex,shouldSelect);
            }
            i++;
         }
         try
         {
            this.RefreshSelectionOverlays();
         }
         catch(eOverlay:Error)
         {
         }
         if(this.mLinkedManageMode)
         {
            try
            {
               if(this.mLinkedMultiSelectMode)
               {
                  this.RefreshLinkedMultiSelectStatus();
               }
               else
               {
                  this.RefreshLinkedDrawer();
               }
            }
            catch(eDrawer:Error)
            {
            }
         }
         if(this.mBatchSelectMode)
         {
            try
            {
               this.RefreshFixedTools();
            }
            catch(eFixed:Error)
            {
            }
            try
            {
               this.RefreshRootTools();
            }
            catch(eRootTools:Error)
            {
            }
         }
      }
      
      private function OnLinkedMarqueeMouseDown(param1:MouseEvent) : void
      {
         if(param1 == null || this.mcContent == null)
         {
            return;
         }
         if(this.mScrollDragActive || this.IsPointerInsideScrollChrome())
         {
            return;
         }
         var linkedSelect:Boolean = this.mLinkedManageMode && this.mLinkedMultiSelectMode && this.HasLinkedDetailExtension();
         var memberEdit:Boolean = this.IsAnyMemberEditMode();
         var batchActive:Boolean = this.mBatchSelectMode;
         var directBatch:Boolean = this.CanDirectBatchSelectHere();
         if(!linkedSelect && !memberEdit && !batchActive && !directBatch)
         {
            return;
         }
         if(this.mLinkedManageMode && this.IsPointerInsideLinkedDrawer())
         {
            return;
         }
         var x:Number = this.mcContent.mouseX;
         var y:Number = this.mcContent.mouseY;
         var canvas:Rectangle = this.LinkedGridCanvasBounds();
         if(!canvas.contains(x,y))
         {
            return;
         }
         this.mMarqueeAutoBatchCandidate = directBatch && !batchActive;
         this.mLinkedMarqueeDown = true;
         this.mLinkedMarqueeDragging = false;
         this.mLinkedMarqueeStartX = x;
         this.mLinkedMarqueeStartY = y;
         this.ClearLinkedMarqueeVisual();
      }
      
      private function OnLinkedMarqueeMouseMove(param1:MouseEvent) : void
      {
         if(param1 == null || !this.mLinkedMarqueeDown || this.mcContent == null)
         {
            return;
         }
         if(this.mScrollDragActive)
         {
            this.AbortMarqueeInteraction();
            return;
         }
         if(!param1.buttonDown)
         {
            this.AbortMarqueeInteraction();
            return;
         }
         var x:Number = this.mcContent.mouseX;
         var y:Number = this.mcContent.mouseY;
         var dx:Number = x - this.mLinkedMarqueeStartX;
         var dy:Number = y - this.mLinkedMarqueeStartY;
         if(!this.mLinkedMarqueeDragging)
         {
            if(Math.abs(dx) < 7 && Math.abs(dy) < 7)
            {
               return;
            }
            if(this.mMarqueeAutoBatchCandidate && !this.mBatchSelectMode)
            {
               this.SetBatchSelectMode(true);
            }
            this.mLinkedMarqueeDragging = true;
            if(this.mNativeLayer != null)
            {
               this.mNativeLayer.mouseChildren = false;
            }
         }
         this.DrawLinkedMarquee(this.mLinkedMarqueeStartX,this.mLinkedMarqueeStartY,x,y);
         param1.stopImmediatePropagation();
      }
      
      private function OnLinkedMarqueeMouseUp(param1:MouseEvent) : void
      {
         var wasDragging:Boolean;
         var rect:Rectangle;
         if(!this.mLinkedMarqueeDown)
         {
            return;
         }
         wasDragging = this.mLinkedMarqueeDragging;
         this.mLinkedMarqueeDown = false;
         this.mLinkedMarqueeDragging = false;
         this.mMarqueeAutoBatchCandidate = false;
         if(wasDragging && this.mcContent != null)
         {
            rect = this.DrawLinkedMarquee(this.mLinkedMarqueeStartX,this.mLinkedMarqueeStartY,this.mcContent.mouseX,this.mcContent.mouseY);
            this.ClearLinkedMarqueeVisual();
            this.mLinkedIgnoreNativeUntil = getTimer() + 320;
            this.SyncCardInteractionState();
            if(param1 != null)
            {
               param1.stopImmediatePropagation();
            }
            try
            {
               this.ApplyLinkedMarqueeSelection(rect);
            }
            catch(eApply:Error)
            {
            }
            this.ClearLinkedMarqueeVisual();
            this.SyncCardInteractionState();
         }
         else
         {
            this.ClearLinkedMarqueeVisual();
            this.SyncCardInteractionState();
         }
      }
      
      private function LinkedResourceOrigin(param1:int, param2:int) : String
      {
         var value:String = this.GetLinkedResourceField(param1,param2,6,"external").toLowerCase();
         return value == "local" ? "local" : "external";
      }
      
      private function LinkedResourceTypeCount(param1:int, param2:String) : int
      {
         var total:int = this.GetLinkedResourceCount(param1);
         var result:int = 0;
         var i:int = 0;
         while(i < total)
         {
            if(this.GetLinkedResourceField(param1,i,0,"") == param2)
            {
               result++;
            }
            i++;
         }
         return result;
      }
      
      private function GetFilteredLinkedResourceIndices() : Array
      {
         var result:Array = [];
         var total:int = this.GetLinkedResourceCount(this.mLinkedActiveIndex);
         var i:int = 0;
         while(i < total)
         {
            var type:String = this.GetLinkedResourceField(this.mLinkedActiveIndex,i,0,"");
            if(type == this.mLinkedTypeFilter)
            {
               var origin:String = this.LinkedResourceOrigin(this.mLinkedActiveIndex,i);
               if(this.mLinkedOriginFilter == "all" || this.mLinkedOriginFilter == origin)
               {
                  result.push(i);
               }
            }
            i++;
         }
         return result;
      }
      
      private function LinkedResourcePageSize() : int
      {
         if(this.GetV7ActiveNav() == 6)
         {
            if(this.GetLinkedPackId() == "__FGEH_CAS_LIBRARY__")
            {
               return 16;
            }
         }
         if(this.IsCASProductCardMode() || this.IsObjectProductCardMode())
         {
            return 4;
         }
         return this.mLinkedInspectorExpanded ? 6 : 4;
      }
      
      private function LinkedResourcePageCount() : int
      {
         if(this.IsCASProductCardMode())
         {
            var count:int = int(this.GetFilteredLinkedProductIndices().length);
         }
         else if(this.IsObjectProductCardMode())
         {
            count = int(this.GetFilteredLinkedObjectProductIndices().length);
         }
         else
         {
            count = int(this.GetFilteredLinkedResourceIndices().length);
         }
         return Math.max(1,int(Math.ceil(count / this.LinkedResourcePageSize())));
      }
      
      private function LoadLinkedIconIntoBox(param1:MovieClip, param2:Object, param3:Number) : Boolean
      {
         var NativeClass:Class;
         var cell:MovieClip;
         var rawIcon:Object;
         var iconDisplay:DisplayObject;
         var iconComponent:IconComponent;
         var thumbSize:String;
         var baseW:Number;
         var baseH:Number;
         var scale:Number;
         if(param1 == null || param2 == null || param3 <= 0)
         {
            return false;
         }
         NativeClass = null;
         cell = null;
         rawIcon = null;
         iconDisplay = null;
         iconComponent = null;
         thumbSize = null;
         baseW = 0;
         baseH = 0;
         scale = 1;
         try
         {
            NativeClass = getDefinitionByName(NATIVE_CELL_CLASS) as Class;
            if(NativeClass == null)
            {
               return false;
            }
            cell = new NativeClass() as MovieClip;
            if(cell == null)
            {
               return false;
            }
            param1.addChild(cell);
            try
            {
               cell.gotoAndStop(1);
            }
            catch(eFrame:Error)
            {
            }
            try
            {
               rawIcon = Object(cell)["mcIcon"];
            }
            catch(eGetIcon:Error)
            {
               rawIcon = null;
            }
            if(rawIcon == null)
            {
               if(cell.parent == param1)
               {
                  param1.removeChild(cell);
               }
               return false;
            }
            iconDisplay = rawIcon as DisplayObject;
            if(rawIcon is IconComponent)
            {
               iconComponent = rawIcon as IconComponent;
            }
            else
            {
               try
               {
                  iconComponent = rawIcon["image"] as IconComponent;
               }
               catch(eImage:Error)
               {
                  iconComponent = null;
               }
            }
            if(iconDisplay == null || iconComponent == null)
            {
               if(cell.parent == param1)
               {
                  param1.removeChild(cell);
               }
               return false;
            }
            if(iconDisplay.parent != null)
            {
               iconDisplay.parent.removeChild(iconDisplay);
            }
            if(cell.parent == param1)
            {
               param1.removeChild(cell);
            }
            param1.addChild(iconDisplay);
            iconDisplay.visible = true;
            iconDisplay.x = 0;
            iconDisplay.y = 0;
            baseW = iconDisplay.width;
            baseH = iconDisplay.height;
            if(baseW > 0 && baseH > 0)
            {
               scale = Math.min(param3 / baseW,param3 / baseH);
               if(isFinite(scale) && scale > 0)
               {
                  iconDisplay.scaleX *= scale;
                  iconDisplay.scaleY *= scale;
               }
               iconDisplay.x = (param3 - iconDisplay.width) / 2;
               iconDisplay.y = (param3 - iconDisplay.height) / 2;
            }
            thumbSize = ImageUtils.CalculateCatalogThumbnailSize(iconComponent);
            if(thumbSize == ImageUtils.THUMBNAIL_SIZE_SMALL)
            {
               thumbSize = ImageUtils.THUMBNAIL_SIZE_MEDIUM;
            }
            ImageUtils.LoadFromIconInfo(iconComponent,param2,thumbSize);
            return true;
         }
         catch(e:Error)
         {
            try
            {
               if(iconDisplay != null && iconDisplay.parent == param1)
               {
                  param1.removeChild(iconDisplay);
               }
               if(cell != null && cell.parent == param1)
               {
                  param1.removeChild(cell);
               }
            }
            catch(eCleanup:Error)
            {
            }
            return false;
         }
      }
      
      private function LoadCASDirectThumbnailIntoBox(param1:MovieClip, param2:String, param3:String, param4:Number) : Boolean
      {
         var imageObject:Object;
         var imageDisplay:DisplayObject;
         var requestUrl:String;
         var CachedImageClass:Class;
         if(param1 == null || param2 == null || param2.length == 0 || param4 <= 0)
         {
            return false;
         }
         imageObject = null;
         imageDisplay = null;
         requestUrl = "img://thumbs/cas/c_" + param2 + "_l_" + param3;
         try
         {
            try
            {
               imageObject = Object(param1).fgehReusableCASImage;
               imageDisplay = imageObject as DisplayObject;
               if(imageDisplay != null && imageDisplay.parent != param1)
               {
                  imageObject = null;
                  imageDisplay = null;
               }
            }
            catch(eExisting:Error)
            {
               imageObject = null;
               imageDisplay = null;
            }
            if(imageObject == null)
            {
               if(sCASGUIImageClass == null)
               {
                  sCASGUIImageClass = getDefinitionByName("library.Components.GUIImage") as Class;
               }
               if(sCASGUIImageClass == null)
               {
                  return false;
               }
               CachedImageClass = sCASGUIImageClass;
               imageObject = new CachedImageClass();
               imageDisplay = imageObject as DisplayObject;
               if(imageDisplay == null)
               {
                  return false;
               }
               param1.addChild(imageDisplay);
               Object(param1).fgehReusableCASImage = imageObject;
            }
            imageDisplay.x = 0;
            imageDisplay.y = 0;
            imageDisplay.visible = true;
            try
            {
               if("SetSize" in imageObject)
               {
                  imageObject["SetSize"](param4,param4);
               }
               else
               {
                  imageDisplay.width = param4;
                  imageDisplay.height = param4;
               }
            }
            catch(eSize:Error)
            {
               try
               {
                  imageDisplay.width = param4;
                  imageDisplay.height = param4;
               }
               catch(eSize2:Error)
               {
               }
            }
            if(!("LoadImage" in imageObject))
            {
               return false;
            }
            imageObject["LoadImage"](requestUrl);
            return true;
         }
         catch(e:Error)
         {
            return false;
         }
      }
      
      private function CASProbeObjectString(param1:Object, param2:String, param3:String = "") : String
      {
         if(param1 == null || param2 == null || param2.length == 0)
         {
            return param3;
         }
         try
         {
            if(param2 in param1 && param1[param2] != null)
            {
               return String(param1[param2]);
            }
         }
         catch(e:Error)
         {
         }
         return param3;
      }
      
      private function CASProbeSwatchGroupKey(param1:String) : String
      {
         var value:String;
         if(param1 == null)
         {
            return "";
         }
         value = param1;
         try
         {
            value = value.replace(/\s*[-–—:]?\s*(swatch|colour|color|variant|style)\s*#?\s*\d+\s*$/i,"");
            value = value.replace(/\s+$/g,"");
            value = value.toLowerCase();
         }
         catch(e:Error)
         {
         }
         return value;
      }
      
      private function ClearCASProductPreviewBox(param1:MovieClip) : void
      {
         var reusable:DisplayObject;
         var i:int;
         var child:DisplayObject;
         if(param1 == null)
         {
            return;
         }
         reusable = null;
         try
         {
            reusable = Object(param1).fgehReusableCASImage as DisplayObject;
         }
         catch(eReusable:Error)
         {
         }
         i = param1.numChildren - 1;
         while(i >= 0)
         {
            child = param1.getChildAt(i);
            if(child !== reusable)
            {
               param1.removeChildAt(i);
            }
            i--;
         }
      }
      
      private function CASProductPaletteColor(param1:int) : uint
      {
         var palette:Array = [15590611,14272418,13015922,10253144,7295558,4143674,2040615,16046553,15378097,14183296,12010082,15910821,15242599,14249797,15852189,14206814,11127175,7317372,5148533,11000276,7324612,5940167,7049679,8091846,11045830,14132945,14921664,14014426,11055031,7502726,16777215,1118481];
         if(param1 < 0)
         {
            param1 = 0;
         }
         return uint(palette[param1 % palette.length]);
      }
      
      private function CASProductSwatchColor(param1:int, param2:String) : uint
      {
         var parsed:Number;
         var text:String = param2 == null ? "" : param2;
         try
         {
            text = text.replace(/^\s*#/g,"");
            if(text.length >= 6)
            {
               parsed = Number(parseInt(text.substr(0,6),16));
               if(!isNaN(parsed))
               {
                  return uint(parsed);
               }
            }
         }
         catch(e:Error)
         {
         }
         return this.CASProductPaletteColor(param1);
      }
      
      private function PaintCASProductSwatch(param1:Sprite, param2:int, param3:Boolean, param4:Boolean, param5:String = "") : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.graphics.clear();
         param1.graphics.beginFill(this.CASProductSwatchColor(param2,param5),1);
         param1.graphics.lineStyle(param3 ? 3 : (param4 ? 2 : 1),param3 ? 5217403 : (param4 ? 5487053 : 12045777),1);
         param1.graphics.drawRoundRect(0,0,20,20,5,5);
         param1.graphics.endFill();
         if(param3)
         {
            param1.graphics.lineStyle(1,16777215,1);
            param1.graphics.beginFill(5217403,1);
            param1.graphics.drawCircle(16,4,2.7);
            param1.graphics.endFill();
         }
      }
      
      private function GetLinkedProductEnabledVariant(param1:int) : int
      {
         var count:int = int(this.GetLinkedProductField(this.mLinkedActiveIndex,param1,3,"0"));
         var vi:int = 0;
         while(vi < count)
         {
            var itemId:String = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,param1,vi,1,"0");
            if(this.IsLinkedCASItemEnabled(this.mLinkedActiveIndex,itemId))
            {
               return vi;
            }
            vi++;
         }
         return -1;
      }
      
      private function LoadCASProductDefaultIntoCard(param1:MovieClip, param2:int) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function SetCASPreviewStatus(param1:MovieClip, param2:String) : void
      {
         var status:TextField;
         if(param1 == null)
         {
            return;
         }
         status = null;
         try
         {
            status = Object(param1).fgehCASPreviewStatus as TextField;
         }
         catch(eExisting:Error)
         {
         }
         if(param2 == null || param2.length == 0)
         {
            if(status != null && status.parent == param1)
            {
               param1.removeChild(status);
            }
            try
            {
               Object(param1).fgehCASPreviewStatus = null;
            }
            catch(eClear:Error)
            {
            }
            return;
         }
         if(status == null)
         {
            status = new TextField();
            status.mouseEnabled = false;
            status.selectable = false;
            status.width = 116;
            status.height = 18;
            status.y = 98;
            this.ApplyExistingUIFont(status,"fgehModeLabel",7.2,7903134,true);
            param1.addChild(status);
            try
            {
               Object(param1).fgehCASPreviewStatus = status;
            }
            catch(eStore:Error)
            {
            }
         }
         status.text = param2;
      }
      
      private function CancelCASPreviewImageRequest() : void
      {
         var pending:Object;
         var display:DisplayObject;
         if(this.mLinkedCASPreviewPollTimer != 0)
         {
            try
            {
               clearTimeout(this.mLinkedCASPreviewPollTimer);
            }
            catch(eTimer:Error)
            {
            }
         }
         this.mLinkedCASPreviewPollTimer = 0;
         ++this.mLinkedCASPreviewRequestSerial;
         pending = this.mLinkedCASPreviewPending;
         this.mLinkedCASPreviewPending = null;
         if(pending == null)
         {
            return;
         }
         try
         {
            display = pending.imageDisplay as DisplayObject;
            if(display != null)
            {
               display.removeEventListener(Event.COMPLETE,this.OnCASPreviewPendingComplete);
               if(display.parent != null)
               {
                  display.parent.removeChild(display);
               }
            }
         }
         catch(eCleanup:Error)
         {
         }
      }
      
      private function RemoveCASPreviewPendingDisplay(param1:Object) : void
      {
         var display:DisplayObject;
         if(param1 == null)
         {
            return;
         }
         try
         {
            display = param1.imageDisplay as DisplayObject;
            if(display != null)
            {
               display.removeEventListener(Event.COMPLETE,this.OnCASPreviewPendingComplete);
               if(display.parent != null)
               {
                  display.parent.removeChild(display);
               }
            }
         }
         catch(e:Error)
         {
         }
         try
         {
            param1.imageObject = null;
            param1.imageDisplay = null;
         }
         catch(eFields:Error)
         {
         }
      }
      
      private function StartCASPreviewImageAttempt(param1:Object, param2:String) : void
      {
         var host:MovieClip;
         var ImageClass:Class;
         var imageObject:Object;
         var imageDisplay:DisplayObject;
         if(param1 == null || uint(param1.token) != this.mLinkedCASPreviewRequestSerial || param1.host == null)
         {
            return;
         }
         this.RemoveCASPreviewPendingDisplay(param1);
         host = param1.host as MovieClip;
         if(host == null)
         {
            return;
         }
         try
         {
            if(sCASGUIImageClass == null)
            {
               sCASGUIImageClass = getDefinitionByName("library.Components.GUIImage") as Class;
            }
            if(sCASGUIImageClass == null)
            {
               this.FailCASPreviewImageRequest(param1);
               return;
            }
            ImageClass = sCASGUIImageClass;
            imageObject = new ImageClass();
            imageDisplay = imageObject as DisplayObject;
            if(imageDisplay == null)
            {
               this.FailCASPreviewImageRequest(param1);
               return;
            }
            imageDisplay.x = 0;
            imageDisplay.y = 0;
            imageDisplay.visible = false;
            try
            {
               if("SetSize" in imageObject)
               {
                  imageObject["SetSize"](Number(param1.size),Number(param1.size));
               }
               else
               {
                  imageDisplay.width = Number(param1.size);
                  imageDisplay.height = Number(param1.size);
               }
            }
            catch(eSize:Error)
            {
               imageDisplay.width = Number(param1.size);
               imageDisplay.height = Number(param1.size);
            }
            host.addChildAt(imageDisplay,0);
            imageDisplay.addEventListener(Event.COMPLETE,this.OnCASPreviewPendingComplete,false,0,true);
            param1.imageObject = imageObject;
            param1.imageDisplay = imageDisplay;
            param1.gender = param2;
            param1.attemptStartedAt = getTimer();
            if(!("LoadImage" in imageObject))
            {
               this.FailCASPreviewImageRequest(param1);
               return;
            }
            imageObject["LoadImage"]("img://thumbs/cas/c_" + String(param1.itemId) + "_l_" + param2);
            if(this.mLinkedCASPreviewPollTimer != 0)
            {
               try
               {
                  clearTimeout(this.mLinkedCASPreviewPollTimer);
               }
               catch(eOldTimer:Error)
               {
               }
            }
            this.mLinkedCASPreviewPollTimer = setTimeout(this.PollCASPreviewImageRequest,60);
         }
         catch(e:Error)
         {
            this.FailCASPreviewImageRequest(param1);
         }
      }
      
      private function RequestCASPreviewImage(param1:MovieClip, param2:String, param3:Number) : void
      {
         var oldDisplay:DisplayObject;
         var token:uint;
         var preferred:String;
         var request:Object;
         if(param1 == null || param2 == null || param2.length == 0 || param2 == "0")
         {
            return;
         }
         try
         {
            if(String(Object(param1).fgehCurrentCASItemId) == param2)
            {
               this.SetCASPreviewStatus(param1,"");
               return;
            }
         }
         catch(eCurrent:Error)
         {
         }
         try
         {
            if(this.mLinkedCASPreviewPending != null && this.mLinkedCASPreviewPending.host === param1 && String(this.mLinkedCASPreviewPending.itemId) == param2)
            {
               return;
            }
         }
         catch(ePending:Error)
         {
         }
         this.CancelCASPreviewImageRequest();
         try
         {
            oldDisplay = Object(param1).fgehReusableCASImage as DisplayObject;
            if(oldDisplay != null)
            {
               oldDisplay.visible = false;
            }
            Object(param1).fgehCurrentCASItemId = "";
         }
         catch(eBlank:Error)
         {
         }
         this.SetCASPreviewStatus(param1,"");
         token = this.mLinkedCASPreviewRequestSerial;
         preferred = "f";
         try
         {
            if(this.mLinkedCASPreviewGenderCache.hasOwnProperty(param2))
            {
               preferred = String(this.mLinkedCASPreviewGenderCache[param2]);
            }
         }
         catch(eCache:Error)
         {
         }
         if(preferred != "m")
         {
            preferred = "f";
         }
         request = {
            "token":token,
            "host":param1,
            "itemId":param2,
            "size":param3,
            "firstGender":preferred,
            "attempt":0,
            "gender":preferred,
            "attemptStartedAt":getTimer(),
            "imageObject":null,
            "imageDisplay":null
         };
         this.mLinkedCASPreviewPending = request;
         this.StartCASPreviewImageAttempt(request,preferred);
      }
      
      private function IsCASPreviewImageLoaded(param1:Object) : Boolean
      {
         var imageObject:Object;
         if(param1 == null || param1.imageObject == null)
         {
            return false;
         }
         try
         {
            imageObject = param1.imageObject;
            if("GetLoadedImage" in imageObject)
            {
               return imageObject["GetLoadedImage"]() != null;
            }
         }
         catch(e:Error)
         {
         }
         return false;
      }
      
      private function PollCASPreviewImageRequest() : void
      {
         this.mLinkedCASPreviewPollTimer = 0;
         var request:Object = this.mLinkedCASPreviewPending;
         if(request == null || uint(request.token) != this.mLinkedCASPreviewRequestSerial)
         {
            return;
         }
         if(this.IsCASPreviewImageLoaded(request))
         {
            this.CommitCASPreviewImageRequest(request);
            return;
         }
         var elapsed:int = getTimer() - int(request.attemptStartedAt);
         var attempt:int = int(request.attempt);
         if(attempt == 0 && elapsed >= 380)
         {
            request.attempt = 1;
            var secondGender:String = String(request.firstGender) == "f" ? "m" : "f";
            this.StartCASPreviewImageAttempt(request,secondGender);
            return;
         }
         if(attempt == 1 && elapsed >= 420)
         {
            request.attempt = 2;
            this.StartCASPreviewImageAttempt(request,String(request.firstGender));
            return;
         }
         if(attempt >= 2 && elapsed >= 650)
         {
            this.FailCASPreviewImageRequest(request);
            return;
         }
         this.mLinkedCASPreviewPollTimer = setTimeout(this.PollCASPreviewImageRequest,60);
      }
      
      private function OnCASPreviewPendingComplete(param1:Event) : void
      {
         var request:Object = this.mLinkedCASPreviewPending;
         if(request == null || uint(request.token) != this.mLinkedCASPreviewRequestSerial || param1 == null || param1.currentTarget !== request.imageDisplay)
         {
            return;
         }
         this.CommitCASPreviewImageRequest(request);
      }
      
      private function CommitCASPreviewImageRequest(param1:Object) : void
      {
         var host:MovieClip;
         var display:DisplayObject;
         var oldDisplay:DisplayObject;
         if(param1 == null || uint(param1.token) != this.mLinkedCASPreviewRequestSerial || param1.host == null || param1.imageDisplay == null)
         {
            return;
         }
         host = param1.host as MovieClip;
         display = param1.imageDisplay as DisplayObject;
         if(host == null || display == null || display.parent != host)
         {
            return;
         }
         if(this.mLinkedCASPreviewPollTimer != 0)
         {
            try
            {
               clearTimeout(this.mLinkedCASPreviewPollTimer);
            }
            catch(eTimer:Error)
            {
            }
         }
         this.mLinkedCASPreviewPollTimer = 0;
         try
         {
            display.removeEventListener(Event.COMPLETE,this.OnCASPreviewPendingComplete);
         }
         catch(eEvent:Error)
         {
         }
         oldDisplay = null;
         try
         {
            oldDisplay = Object(host).fgehReusableCASImage as DisplayObject;
         }
         catch(eOld:Error)
         {
         }
         if(oldDisplay != null && oldDisplay !== display)
         {
            try
            {
               if(oldDisplay.parent == host)
               {
                  host.removeChild(oldDisplay);
               }
            }
            catch(eRemoveOld:Error)
            {
            }
         }
         display.visible = true;
         try
         {
            Object(host).fgehReusableCASImage = param1.imageObject;
            Object(host).fgehCurrentCASItemId = String(param1.itemId);
         }
         catch(eStore:Error)
         {
         }
         try
         {
            this.mLinkedCASPreviewGenderCache[String(param1.itemId)] = String(param1.gender);
         }
         catch(eGenderCache:Error)
         {
         }
         this.SetCASPreviewStatus(host,"");
         this.mLinkedCASPreviewPending = null;
      }
      
      private function FailCASPreviewImageRequest(param1:Object) : void
      {
         var host:MovieClip;
         if(param1 == null)
         {
            return;
         }
         if(this.mLinkedCASPreviewPollTimer != 0)
         {
            try
            {
               clearTimeout(this.mLinkedCASPreviewPollTimer);
            }
            catch(eTimer:Error)
            {
            }
         }
         this.mLinkedCASPreviewPollTimer = 0;
         this.RemoveCASPreviewPendingDisplay(param1);
         if(this.mLinkedCASPreviewPending === param1 && uint(param1.token) == this.mLinkedCASPreviewRequestSerial)
         {
            host = param1.host as MovieClip;
            if(host != null)
            {
               this.SetCASPreviewStatus(host,"");
               try
               {
                  Object(host).fgehCurrentCASItemId = "";
               }
               catch(eBlankFail:Error)
               {
               }
            }
            this.mLinkedCASPreviewPending = null;
         }
      }
      
      private function UpdateCASProductHoverPreview(param1:MovieClip, param2:int, param3:int) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function PaintCASProductCardShellFast(param1:MovieClip, param2:Boolean) : void
      {
         var cardW:Number;
         var cardH:Number;
         var enabledVariant:int;
         var anyEnabled:Boolean;
         if(param1 == null)
         {
            return;
         }
         cardW = 0;
         cardH = 0;
         enabledVariant = -1;
         try
         {
            cardW = Number(Object(param1).fgehCardW);
            cardH = Number(Object(param1).fgehCardH);
            enabledVariant = int(Object(param1).fgehEnabledVariantIndex);
         }
         catch(e:Error)
         {
         }
         if(cardW <= 0 || cardH <= 0)
         {
            return;
         }
         anyEnabled = enabledVariant >= 0;
         param1.graphics.clear();
         param1.graphics.beginFill(anyEnabled ? 15858421 : (param2 ? 15990013 : 16777215),1);
         param1.graphics.lineStyle(anyEnabled ? 2.2 : (param2 ? 2 : 1.25),anyEnabled ? 5809789 : (param2 ? 4571599 : 12901856),1);
         param1.graphics.drawRoundRect(0,0,cardW,cardH,9,9);
         param1.graphics.endFill();
      }
      
      private function RefreshCASProductCardVisualState(param1:MovieClip, param2:int, param3:Boolean = true) : void
      {
         var cardW:Number;
         var cardH:Number;
         var enabledVariant:int;
         var anyEnabled:Boolean;
         var cardHover:Boolean;
         var dot:Shape;
         var hoverVariant:int;
         var swatches:Array;
         var i:int;
         var swatch:Sprite;
         var swatchVariantIndex:int;
         var swatchColor:String;
         if(param1 == null || param2 < 0)
         {
            return;
         }
         cardW = 0;
         cardH = 0;
         try
         {
            cardW = Number(Object(param1).fgehCardW);
            cardH = Number(Object(param1).fgehCardH);
         }
         catch(eSize:Error)
         {
         }
         if(cardW <= 0 || cardH <= 0)
         {
            return;
         }
         enabledVariant = this.GetLinkedProductEnabledVariant(param2);
         try
         {
            Object(param1).fgehEnabledVariantIndex = enabledVariant;
         }
         catch(eCacheEnabled:Error)
         {
         }
         anyEnabled = enabledVariant >= 0;
         cardHover = false;
         try
         {
            cardHover = Boolean(Object(param1).fgehCASCardHover);
         }
         catch(eHoverCard:Error)
         {
         }
         param1.graphics.clear();
         param1.graphics.beginFill(anyEnabled ? 15858421 : (cardHover ? 15990013 : 16777215),1);
         param1.graphics.lineStyle(anyEnabled ? 2.2 : (cardHover ? 2 : 1.25),anyEnabled ? 5809789 : (cardHover ? 4571599 : 12901856),1);
         param1.graphics.drawRoundRect(0,0,cardW,cardH,9,9);
         param1.graphics.endFill();
         try
         {
            dot = Object(param1).fgehEnabledDot as Shape;
            if(dot != null)
            {
               dot.graphics.clear();
               dot.graphics.beginFill(anyEnabled ? 6924169 : 16777215,1);
               dot.graphics.lineStyle(1,10140593,1);
               dot.graphics.drawCircle(0,0,5);
               dot.graphics.endFill();
            }
         }
         catch(eDot:Error)
         {
         }
         if(!param3)
         {
            return;
         }
         hoverVariant = -1;
         try
         {
            hoverVariant = int(Object(param1).fgehHoverVariantIndex);
         }
         catch(eHoverIndex:Error)
         {
            hoverVariant = -1;
         }
         try
         {
            swatches = Object(param1).fgehColorSwatches as Array;
            if(swatches != null)
            {
               i = 0;
               while(i < swatches.length)
               {
                  swatch = swatches[i] as Sprite;
                  if(swatch != null)
                  {
                     swatchVariantIndex = int(Object(swatch).fgehVariantIndex);
                     swatchColor = String(Object(swatch).fgehSwatchColor);
                     this.PaintCASProductSwatch(swatch,swatchVariantIndex,swatchVariantIndex == enabledVariant,swatchVariantIndex == hoverVariant,swatchColor);
                  }
                  i++;
               }
            }
         }
         catch(eSwatches:Error)
         {
         }
      }
      
      private function PaintCASProductSwatchAt(param1:MovieClip, param2:int, param3:int, param4:Boolean) : void
      {
         var swatches:Array;
         var swatch:Sprite;
         var enabledVariant:int;
         if(param1 == null || param3 < 0)
         {
            return;
         }
         try
         {
            swatches = Object(param1).fgehColorSwatches as Array;
            if(swatches == null || param3 >= swatches.length)
            {
               return;
            }
            swatch = swatches[param3] as Sprite;
            if(swatch == null)
            {
               return;
            }
            enabledVariant = -9999;
            try
            {
               enabledVariant = int(Object(param1).fgehEnabledVariantIndex);
            }
            catch(eCachedEnabled:Error)
            {
            }
            if(enabledVariant == -9999)
            {
               enabledVariant = this.GetLinkedProductEnabledVariant(param2);
               try
               {
                  Object(param1).fgehEnabledVariantIndex = enabledVariant;
               }
               catch(eStoreEnabled:Error)
               {
               }
            }
            this.PaintCASProductSwatch(swatch,param3,param3 == enabledVariant,param4,String(Object(swatch).fgehSwatchColor));
         }
         catch(e:Error)
         {
         }
      }
      
      private function EnsureCASProductHoverPanel(param1:MovieClip, param2:int, param3:int, param4:int, param5:Number, param6:Number) : MovieClip
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function CancelPendingCASProductHover() : void
      {
         if(this.mLinkedCASHoverTimer != 0)
         {
            try
            {
               clearTimeout(this.mLinkedCASHoverTimer);
            }
            catch(e:Error)
            {
            }
         }
         this.mLinkedCASHoverTimer = 0;
         this.mLinkedCASHoverPending = null;
      }
      
      private function CommitPendingCASProductHover() : void
      {
         var pending:Object = this.mLinkedCASHoverPending;
         this.mLinkedCASHoverTimer = 0;
         this.mLinkedCASHoverPending = null;
         if(pending == null || !this.mLinkedManageMode || this.mLinkedTypeFilter != "cas")
         {
            return;
         }
         var card:MovieClip = pending.card as MovieClip;
         if(card == null || card.parent == null)
         {
            return;
         }
         this.ShowCASProductPreviewNow(card,int(pending.productIndex),int(pending.col),int(pending.row),Number(pending.cardW),Number(pending.cardH));
      }
      
      private function ShowCASProductPreviewNow(param1:MovieClip, param2:int, param3:int, param4:int, param5:Number, param6:Number) : void
      {
         var popup:MovieClip;
         var count:int;
         var chosen:int;
         var enabledVariant:int;
         var previewIndex:int;
         if(param1 == null || param2 < 0)
         {
            return;
         }
         try
         {
            if(param1.parent != null)
            {
               param1.parent.setChildIndex(param1,param1.parent.numChildren - 1);
            }
         }
         catch(eTop:Error)
         {
         }
         popup = this.EnsureCASProductHoverPanel(param1,param2,param3,param4,param5,param6);
         if(popup == null)
         {
            return;
         }
         popup.visible = true;
         count = int(this.GetLinkedProductField(this.mLinkedActiveIndex,param2,3,"0"));
         chosen = this.GetLinkedProductChosenVariant(param2);
         enabledVariant = this.GetLinkedProductEnabledVariant(param2);
         previewIndex = chosen > 0 ? chosen : (enabledVariant > 0 ? enabledVariant : (count > 1 ? 1 : 0));
         this.UpdateCASProductHoverPreview(param1,param2,previewIndex);
      }
      
      private function OnCASProductCardRollOver(param1:MouseEvent) : void
      {
         var card:MovieClip;
         var productIndex:int;
         var col:int;
         var rr:int;
         var cardW:Number;
         var cardH:Number;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         card = param1.currentTarget as MovieClip;
         if(card == null)
         {
            return;
         }
         try
         {
            Object(card).fgehCASCardHover = true;
         }
         catch(eHoverFlag:Error)
         {
         }
         try
         {
            this.PaintCASProductCardShellFast(card,true);
         }
         catch(eHoverPaint:Error)
         {
         }
         productIndex = -1;
         col = 0;
         rr = 0;
         cardW = 0;
         cardH = 0;
         try
         {
            productIndex = int(Object(card).fgehProductIndex);
            col = int(Object(card).fgehCardCol);
            rr = int(Object(card).fgehCardRow);
            cardW = Number(Object(card).fgehCardW);
            cardH = Number(Object(card).fgehCardH);
         }
         catch(e:Error)
         {
            return;
         }
         if(this.mLinkedCASPreviewPanel != null && this.mLinkedCASPreviewProductIndex == productIndex)
         {
            return;
         }
         this.CancelPendingCASSwatchRestore();
         this.CancelPendingCASProductHover();
         this.mLinkedCASHoverPending = {
            "card":card,
            "productIndex":productIndex,
            "col":col,
            "row":rr,
            "cardW":cardW,
            "cardH":cardH
         };
         this.mLinkedCASHoverTimer = setTimeout(this.CommitPendingCASProductHover,120);
      }
      
      private function OnCASProductCardRollOut(param1:MouseEvent) : void
      {
         var hoverCard:MovieClip;
         if(param1 != null && param1.currentTarget != null)
         {
            try
            {
               hoverCard = param1.currentTarget as MovieClip;
               if(hoverCard != null)
               {
                  Object(hoverCard).fgehCASCardHover = false;
                  this.PaintCASProductCardShellFast(hoverCard,false);
               }
            }
            catch(eHoverPaint:Error)
            {
            }
            try
            {
               if(this.mLinkedCASHoverPending != null && this.mLinkedCASHoverPending.card === param1.currentTarget)
               {
                  this.CancelPendingCASProductHover();
               }
            }
            catch(e:Error)
            {
            }
         }
      }
      
      private function CancelPendingCASSwatchHover() : void
      {
         if(this.mLinkedCASSwatchHoverTimer != 0)
         {
            try
            {
               clearTimeout(this.mLinkedCASSwatchHoverTimer);
            }
            catch(e:Error)
            {
            }
         }
         this.mLinkedCASSwatchHoverTimer = 0;
         this.mLinkedCASSwatchHoverPending = null;
      }
      
      private function CommitPendingCASSwatchHover() : void
      {
         var pending:Object = this.mLinkedCASSwatchHoverPending;
         this.mLinkedCASSwatchHoverTimer = 0;
         this.mLinkedCASSwatchHoverPending = null;
         if(pending == null || pending.card == null || !this.mLinkedManageMode || this.mLinkedTypeFilter != "cas")
         {
            return;
         }
         var card:MovieClip = pending.card as MovieClip;
         if(card == null || card.parent == null)
         {
            return;
         }
         this.UpdateCASProductHoverPreview(card,int(pending.productIndex),int(pending.variantIndex));
      }
      
      private function CancelPendingCASSwatchRestore() : void
      {
         if(this.mLinkedCASSwatchRestoreTimer != 0)
         {
            try
            {
               clearTimeout(this.mLinkedCASSwatchRestoreTimer);
            }
            catch(e:Error)
            {
            }
         }
         this.mLinkedCASSwatchRestoreTimer = 0;
      }
      
      private function RestoreCASSwatchPreviewAfterTravel() : void
      {
         this.mLinkedCASSwatchRestoreTimer = 0;
         var card:MovieClip = this.mLinkedCASPreviewCard;
         var productIndex:int = this.mLinkedCASPreviewProductIndex;
         if(card == null || card.parent == null || productIndex < 0)
         {
            return;
         }
         var fallback:int = this.GetLinkedProductEnabledVariant(productIndex);
         if(fallback < 0)
         {
            fallback = 0;
         }
         this.UpdateCASProductHoverPreview(card,productIndex,fallback);
      }
      
      private function OnCASProductSwatchRollOver(param1:MouseEvent) : void
      {
         var swatch:Object;
         var productIndex:int;
         var variantIndex:int;
         var card:MovieClip;
         var oldHoverVariant:int;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         swatch = Object(param1.currentTarget);
         productIndex = -1;
         variantIndex = -1;
         card = null;
         try
         {
            productIndex = int(swatch.fgehProductIndex);
            variantIndex = int(swatch.fgehVariantIndex);
            card = swatch.fgehProductCard as MovieClip;
         }
         catch(e:Error)
         {
            return;
         }
         if(productIndex < 0 || variantIndex < 0 || card == null)
         {
            return;
         }
         oldHoverVariant = -1;
         try
         {
            oldHoverVariant = int(Object(card).fgehHoverVariantIndex);
            Object(card).fgehHoverVariantIndex = variantIndex;
         }
         catch(eStore:Error)
         {
         }
         if(oldHoverVariant >= 0 && oldHoverVariant != variantIndex)
         {
            this.PaintCASProductSwatchAt(card,productIndex,oldHoverVariant,false);
         }
         this.PaintCASProductSwatchAt(card,productIndex,variantIndex,true);
         this.CancelPendingCASSwatchRestore();
         this.CancelPendingCASSwatchHover();
         this.mLinkedCASSwatchHoverPending = {
            "card":card,
            "productIndex":productIndex,
            "variantIndex":variantIndex
         };
         this.mLinkedCASSwatchHoverTimer = setTimeout(this.CommitPendingCASSwatchHover,45);
      }
      
      private function OnCASProductSwatchRollOut(param1:MouseEvent) : void
      {
         var swatch:Object;
         var productIndex:int;
         var card:MovieClip;
         var related:Object;
         var oldHoverVariant:int;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         swatch = Object(param1.currentTarget);
         productIndex = -1;
         card = null;
         try
         {
            productIndex = int(swatch.fgehProductIndex);
            card = swatch.fgehProductCard as MovieClip;
         }
         catch(e:Error)
         {
            return;
         }
         if(productIndex < 0 || card == null)
         {
            return;
         }
         this.CancelPendingCASSwatchHover();
         try
         {
            related = param1.relatedObject == null ? null : Object(param1.relatedObject);
            if(related != null && related.hasOwnProperty("fgehProductIndex") && int(related.fgehProductIndex) == productIndex)
            {
               return;
            }
         }
         catch(eRelated:Error)
         {
         }
         oldHoverVariant = -1;
         try
         {
            oldHoverVariant = int(Object(card).fgehHoverVariantIndex);
            Object(card).fgehHoverVariantIndex = -1;
         }
         catch(eClear:Error)
         {
         }
         if(oldHoverVariant >= 0)
         {
            this.PaintCASProductSwatchAt(card,productIndex,oldHoverVariant,false);
         }
         this.CancelPendingCASSwatchRestore();
         this.mLinkedCASSwatchRestoreTimer = setTimeout(this.RestoreCASSwatchPreviewAfterTravel,180);
      }
      
      private function OnCASProductSwatchClick(param1:MouseEvent) : void
      {
         var swatchButton:int;
         var swatch:Object;
         var itemId:String;
         var productIndex:int;
         var variantIndex:int;
         var card:MovieClip;
         var wasEnabled:Boolean;
         var variantCount:int;
         var vi:int;
         var siblingItemId:String;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         swatchButton = 0;
         try
         {
            if(Object(param1).hasOwnProperty("buttonIdx"))
            {
               swatchButton = int(Object(param1).buttonIdx);
            }
            else if(Object(param1).hasOwnProperty("buttonIndex"))
            {
               swatchButton = int(Object(param1).buttonIndex);
            }
         }
         catch(eButton:Error)
         {
            swatchButton = 0;
         }
         if(swatchButton != 0)
         {
            return;
         }
         param1.stopImmediatePropagation();
         this.CancelPendingCASSwatchHover();
         this.CancelPendingCASSwatchRestore();
         swatch = Object(param1.currentTarget);
         itemId = "0";
         productIndex = -1;
         variantIndex = -1;
         card = null;
         try
         {
            while(true)
            {
               if(swatch.name != "fgehCASVariantPrevArrow")
               {
                  if(swatch.name != "fgehCASVariantNextArrow")
                  {
                     itemId = String(swatch.fgehItemId);
                     productIndex = int(swatch.fgehProductIndex);
                     variantIndex = int(swatch.fgehVariantIndex);
                     card = swatch.fgehProductCard as MovieClip;
                     break;
                  }
               }
               productIndex = this.mLinkedCASPreviewProductIndex;
               card = this.mLinkedCASPreviewCard;
               break;
            }
         }
         catch(eFields:Error)
         {
            return;
         }
         if(swatch.name != "fgehCASVariantPrevArrow")
         {
            if(swatch.name == "fgehCASVariantNextArrow")
            {
               swatchButton = int(this.GetLinkedProductField(this.mLinkedActiveIndex,productIndex,3,"0"));
               if(swatchButton > 1)
               {
                  variantIndex = this.GetLinkedProductEnabledVariant(productIndex);
                  if(variantIndex < 0)
                  {
                     variantIndex = this.GetLinkedProductChosenVariant(productIndex);
                  }
                  variantIndex += 1;
                  if(variantIndex >= swatchButton)
                  {
                     variantIndex = 0;
                  }
                  itemId = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,productIndex,variantIndex,1,"0");
               }
            }
         }
         else
         {
            swatchButton = int(this.GetLinkedProductField(this.mLinkedActiveIndex,productIndex,3,"0"));
            if(swatchButton > 1)
            {
               variantIndex = this.GetLinkedProductEnabledVariant(productIndex);
               if(variantIndex < 0)
               {
                  variantIndex = this.GetLinkedProductChosenVariant(productIndex);
               }
               variantIndex -= 1;
               if(variantIndex < 0)
               {
                  variantIndex = swatchButton - 1;
               }
               itemId = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,productIndex,variantIndex,1,"0");
            }
         }
         if(itemId == null || itemId.length == 0 || itemId == "0" || productIndex < 0 || card == null)
         {
            return;
         }
         wasEnabled = this.IsLinkedCASItemEnabled(this.mLinkedActiveIndex,itemId);
         if(wasEnabled)
         {
            if(this.GetV7ActiveNav() == 6)
            {
               if(this.GetLinkedPackId() == "__FGEH_CAS_LIBRARY__")
               {
                  if(this.GetLinkedPoseName(this.mLinkedActiveIndex) == "root_outfits")
                  {
                     return;
                  }
               }
            }
         }
         variantCount = int(this.GetLinkedProductField(this.mLinkedActiveIndex,productIndex,3,"0"));
         vi = 0;
         while(vi < variantCount)
         {
            siblingItemId = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,productIndex,vi,1,"0");
            this.SetLinkedCASItemOverride(this.mLinkedActiveIndex,siblingItemId,false);
            vi++;
         }
         if(!wasEnabled)
         {
            this.SetLinkedCASItemOverride(this.mLinkedActiveIndex,itemId,true);
         }
         this.SetLinkedProductChosenVariant(productIndex,variantIndex);
         CommunicationManager.PostServerCommand("fgeh.linked_toggle_item",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),"cas",itemId);
         this.RefreshCASProductCardVisualState(card,productIndex);
         this.UpdateCASProductHoverPreview(card,productIndex,variantIndex);
         this.RefreshLinkedRowSummary(this.mLinkedActiveIndex);
      }
      
      private function DrawCASProductCardGrid(param1:MovieClip, param2:Number, param3:Number, param4:Array, param5:int) : int
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function PaintObjectStyleChip(param1:MovieClip, param2:Boolean, param3:Boolean) : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.graphics.clear();
         var fill:uint = uint(param2 ? 13626333 : (param3 ? 14284279 : 13229537));
         var border:uint = uint(param2 ? 5217403 : (param3 ? 3520967 : 8563120));
         var thick:Number = param2 ? 2.7 : (param3 ? 2.2 : 1.4);
         param1.graphics.beginFill(fill,1);
         param1.graphics.lineStyle(thick,border,1);
         param1.graphics.drawRoundRect(0,0,18,18,4,4);
         param1.graphics.endFill();
         if(param2)
         {
            param1.graphics.beginFill(5219704,1);
            param1.graphics.drawCircle(9,9,3.2);
            param1.graphics.endFill();
         }
         else if(param3)
         {
            param1.graphics.lineStyle(1.4,3520967,1);
            param1.graphics.drawCircle(9,9,4.2);
         }
      }
      
      private function PaintObjectProductCard(param1:MovieClip, param2:int, param3:Boolean) : void
      {
         var cardW:Number;
         var cardH:Number;
         var selected:Boolean;
         if(param1 == null)
         {
            return;
         }
         cardW = 182;
         cardH = 108;
         try
         {
            cardW = Number(Object(param1).fgehObjectCardW);
            cardH = Number(Object(param1).fgehObjectCardH);
         }
         catch(e:Error)
         {
         }
         selected = this.GetLinkedObjectProductEnabledVariant(param2) >= 0;
         param1.graphics.clear();
         param1.graphics.beginFill(selected ? 15858421 : (param3 ? 15990013 : 16777215),1);
         param1.graphics.lineStyle(selected ? 2.2 : (param3 ? 2 : 1.25),selected ? 5809789 : (param3 ? 4571599 : 12901856),1);
         param1.graphics.drawRoundRect(0,0,cardW,cardH,7,7);
         param1.graphics.endFill();
      }
      
      private function RefreshObjectProductCardVisual(param1:MovieClip, param2:int) : void
      {
         var selected:int;
         var hover:Boolean;
         var chips:Array;
         var i:int;
         var chip:MovieClip;
         if(param1 == null)
         {
            return;
         }
         selected = this.GetLinkedObjectProductEnabledVariant(param2);
         hover = false;
         try
         {
            hover = Boolean(Object(param1).fgehObjectCardHover);
         }
         catch(eHover:Error)
         {
         }
         this.PaintObjectProductCard(param1,param2,hover);
         chips = null;
         try
         {
            chips = Object(param1).fgehObjectStyleChips as Array;
         }
         catch(e:Error)
         {
         }
         if(chips == null)
         {
            return;
         }
         i = 0;
         while(i < chips.length)
         {
            chip = chips[i] as MovieClip;
            if(chip != null)
            {
               this.PaintObjectStyleChip(chip,i == selected,false);
            }
            i++;
         }
      }
      
      private function LoadObjectProductVariantIntoBox(param1:MovieClip, param2:int, param3:int, param4:Number) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function SelectObjectProductVariantFast(param1:int, param2:int, param3:MovieClip) : void
      {
         if(param1 < 0 || param2 < 0)
         {
            return;
         }
         var resourceIndex:int = int(this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,param1,param2,0,"-1"));
         if(resourceIndex < 0)
         {
            return;
         }
         var wasEnabled:Boolean = this.IsLinkedResourceEnabled(this.mLinkedActiveIndex,resourceIndex);
         var variantCount:int = int(this.GetLinkedObjectProductField(this.mLinkedActiveIndex,param1,3,"0"));
         var vi:int = 0;
         while(vi < variantCount)
         {
            var siblingResource:int = int(this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,param1,vi,0,"-1"));
            if(siblingResource >= 0)
            {
               this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,siblingResource)] = false;
            }
            vi++;
         }
         if(!wasEnabled)
         {
            this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,resourceIndex)] = true;
         }
         CommunicationManager.PostServerCommand("fgeh.linked_toggle_item",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),"object",this.GetLinkedResourceField(this.mLinkedActiveIndex,resourceIndex,1,"0"));
         if(param3 != null)
         {
            this.RefreshObjectProductCardVisual(param3,param1);
         }
         this.RefreshLinkedRowSummary(this.mLinkedActiveIndex);
      }
      
      private function OnObjectProductStyleRollOver(param1:MouseEvent) : void
      {
         var chip:MovieClip;
         var productIndex:int;
         var variantIndex:int;
         var card:MovieClip;
         var previewBox:MovieClip;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         chip = param1.currentTarget as MovieClip;
         if(chip == null)
         {
            return;
         }
         productIndex = int(Object(chip).fgehObjectProductIndex);
         variantIndex = int(Object(chip).fgehObjectVariantIndex);
         card = Object(chip).fgehObjectCard as MovieClip;
         previewBox = card != null ? Object(card).fgehObjectPreviewBox as MovieClip : null;
         if(card != null)
         {
            try
            {
               Object(card).fgehObjectHoverVariantIndex = variantIndex;
            }
            catch(eStore:Error)
            {
            }
         }
         this.PaintObjectStyleChip(chip,variantIndex == this.GetLinkedObjectProductEnabledVariant(productIndex),true);
         if(previewBox != null)
         {
            this.LoadObjectProductVariantIntoBox(previewBox,productIndex,variantIndex,64);
         }
      }
      
      private function OnObjectProductStyleRollOut(param1:MouseEvent) : void
      {
         var chip:MovieClip;
         var productIndex:int;
         var variantIndex:int;
         var card:MovieClip;
         var related:Object;
         var fallback:int;
         var previewBox:MovieClip;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         chip = param1.currentTarget as MovieClip;
         if(chip == null)
         {
            return;
         }
         productIndex = int(Object(chip).fgehObjectProductIndex);
         variantIndex = int(Object(chip).fgehObjectVariantIndex);
         this.PaintObjectStyleChip(chip,variantIndex == this.GetLinkedObjectProductEnabledVariant(productIndex),false);
         card = Object(chip).fgehObjectCard as MovieClip;
         if(card == null)
         {
            return;
         }
         try
         {
            related = param1.relatedObject == null ? null : Object(param1.relatedObject);
            if(related != null && related.hasOwnProperty("fgehObjectProductIndex") && int(related.fgehObjectProductIndex) == productIndex)
            {
               return;
            }
         }
         catch(eRelated:Error)
         {
         }
         try
         {
            Object(card).fgehObjectHoverVariantIndex = -1;
         }
         catch(eClear:Error)
         {
         }
         fallback = this.GetLinkedObjectProductEnabledVariant(productIndex);
         if(fallback < 0)
         {
            fallback = 0;
         }
         previewBox = Object(card).fgehObjectPreviewBox as MovieClip;
         if(previewBox != null)
         {
            this.LoadObjectProductVariantIntoBox(previewBox,productIndex,fallback,64);
         }
      }
      
      private function OnObjectProductStyleClick(param1:MouseEvent) : void
      {
         var styleButton:int;
         var chip:MovieClip;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         styleButton = 0;
         try
         {
            if(Object(param1).hasOwnProperty("buttonIdx"))
            {
               styleButton = int(Object(param1).buttonIdx);
            }
            else if(Object(param1).hasOwnProperty("buttonIndex"))
            {
               styleButton = int(Object(param1).buttonIndex);
            }
         }
         catch(eButton:Error)
         {
            styleButton = 0;
         }
         if(styleButton != 0)
         {
            return;
         }
         param1.stopImmediatePropagation();
         chip = param1.currentTarget as MovieClip;
         if(chip == null)
         {
            return;
         }
         this.SelectObjectProductVariantFast(int(Object(chip).fgehObjectProductIndex),int(Object(chip).fgehObjectVariantIndex),Object(chip).fgehObjectCard as MovieClip);
      }
      
      private function RefreshLinkedEditedProductVisuals(param1:String) : void
      {
         var i:int;
         var casCard:MovieClip;
         var casIndex:int;
         var casName:TextField;
         var hoverTitle:TextField;
         var objectCard:MovieClip;
         var objectIndex:int;
         var objectName:TextField;
         if(param1 == null || param1.length == 0)
         {
            return;
         }
         i = 0;
         if(this.mLinkedCASProductCards != null)
         {
            for(; i < this.mLinkedCASProductCards.length; i++)
            {
               casCard = this.mLinkedCASProductCards[i] as MovieClip;
               if(casCard != null)
               {
                  casIndex = int(Object(casCard).fgehProductIndex);
                  if(this.LinkedCASEditKey(casIndex) == param1)
                  {
                     try
                     {
                        casName = Object(casCard).fgehNameField as TextField;
                        if(casName != null)
                        {
                           casName.text = this.GetLinkedCASProductDisplayLabel(casIndex);
                        }
                        hoverTitle = Object(casCard).fgehHoverTitle as TextField;
                        if(hoverTitle != null)
                        {
                           hoverTitle.text = this.GetLinkedCASProductDisplayLabel(casIndex);
                        }
                     }
                     catch(eCASName:Error)
                     {
                     }
                     continue;
                  }
               }
            }
         }
         i = 0;
         if(this.mLinkedObjectProductCards != null)
         {
            for(; i < this.mLinkedObjectProductCards.length; i++)
            {
               objectCard = this.mLinkedObjectProductCards[i] as MovieClip;
               if(objectCard != null)
               {
                  objectIndex = int(Object(objectCard).fgehObjectProductIndex);
                  if(this.LinkedObjectEditKey(objectIndex) == param1)
                  {
                     try
                     {
                        objectName = Object(objectCard).fgehObjectNameField as TextField;
                        if(objectName != null)
                        {
                           objectName.text = this.GetLinkedObjectProductDisplayLabel(objectIndex);
                        }
                     }
                     catch(eObjectName:Error)
                     {
                     }
                     continue;
                  }
               }
            }
         }
      }
      
      private function OnLinkedCASProductMiddleEdit(param1:Event) : void
      {
         var card:MovieClip = param1 != null ? param1.currentTarget as MovieClip : null;
         if(card == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var productIndex:int = int(Object(card).fgehProductIndex);
         var key:String = this.LinkedCASEditKey(productIndex);
         var currentName:String = this.LinkedEditCustomName(key);
         if(currentName.length == 0)
         {
            currentName = this.GetLinkedCASProductDisplayLabel(productIndex);
         }
         this.OpenLinkedEditInfo(key,currentName,this.LinkedEditNote(key));
      }
      
      private function OnLinkedObjectProductMiddleEdit(param1:Event) : void
      {
         var card:MovieClip = param1 != null ? param1.currentTarget as MovieClip : null;
         if(card == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var productIndex:int = int(Object(card).fgehObjectProductIndex);
         var key:String = this.LinkedObjectEditKey(productIndex);
         var currentName:String = this.LinkedEditCustomName(key);
         if(currentName.length == 0)
         {
            currentName = this.GetLinkedObjectProductDisplayLabel(productIndex);
         }
         this.OpenLinkedEditInfo(key,currentName,this.LinkedEditNote(key));
      }
      
      private function OnObjectProductCardRollOver(param1:MouseEvent) : void
      {
         var card:MovieClip = param1 != null ? param1.currentTarget as MovieClip : null;
         if(card == null)
         {
            return;
         }
         try
         {
            Object(card).fgehObjectCardHover = true;
         }
         catch(e:Error)
         {
         }
         this.PaintObjectProductCard(card,int(Object(card).fgehObjectProductIndex),true);
      }
      
      private function OnObjectProductCardRollOut(param1:MouseEvent) : void
      {
         var card:MovieClip = param1 != null ? param1.currentTarget as MovieClip : null;
         if(card == null)
         {
            return;
         }
         try
         {
            Object(card).fgehObjectCardHover = false;
         }
         catch(e:Error)
         {
         }
         this.PaintObjectProductCard(card,int(Object(card).fgehObjectProductIndex),false);
      }
      
      private function OnObjectProductCardClick(param1:MouseEvent) : void
      {
         var cardButton:int;
         var productIndex:int;
         var variantIndex:int;
         var card:MovieClip = param1 != null ? param1.currentTarget as MovieClip : null;
         if(card == null)
         {
            return;
         }
         cardButton = 0;
         try
         {
            if(Object(param1).hasOwnProperty("buttonIdx"))
            {
               cardButton = int(Object(param1).buttonIdx);
            }
            else if(Object(param1).hasOwnProperty("buttonIndex"))
            {
               cardButton = int(Object(param1).buttonIndex);
            }
         }
         catch(eButton:Error)
         {
            cardButton = 0;
         }
         if(cardButton != 0)
         {
            return;
         }
         param1.stopImmediatePropagation();
         productIndex = int(Object(card).fgehObjectProductIndex);
         variantIndex = -1;
         try
         {
            variantIndex = int(Object(card).fgehObjectHoverVariantIndex);
         }
         catch(eHover:Error)
         {
         }
         if(variantIndex < 0)
         {
            variantIndex = this.GetLinkedObjectProductEnabledVariant(productIndex);
         }
         if(variantIndex < 0)
         {
            variantIndex = 0;
         }
         this.SelectObjectProductVariantFast(productIndex,variantIndex,card);
      }
      
      private function DrawObjectProductCardGrid(param1:MovieClip, param2:Number, param3:Number, param4:Array, param5:int) : int
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function DrawCASDirectThumbnailProbe(param1:MovieClip, param2:Number, param3:Number, param4:Array, param5:int) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function UpdateLinkedMultiSelectChrome() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshLinkedSelectionOverlayForDataIndex(param1:int) : void
      {
         if(!this.mLinkedManageMode || !this.HasLinkedDetailExtension() || this.mSelectionOverlays == null)
         {
            return;
         }
         var page:int = this.GetCurrentPage();
         var slot:int = param1 - page * this.ActiveItemsPerPage();
         if(slot < 0 || slot >= this.mSelectionOverlays.length)
         {
            return;
         }
         var overlay:MovieClip = this.mSelectionOverlays[slot] as MovieClip;
         if(overlay == null)
         {
            return;
         }
         var bounds:Rectangle = this.ExactGridHitBounds(slot);
         overlay.x = bounds.x;
         overlay.y = bounds.y;
         var isSource:Boolean = param1 == this.mLinkedActiveIndex;
         var isTarget:Boolean = !isSource && this.IsLinkedPoseSelected(param1);
         overlay.visible = isSource || isTarget;
         overlay.alpha = 1;
         if(overlay.visible)
         {
            this.PaintSelectionOverlayState(overlay,bounds,isSource ? "source" : "target");
         }
         this.KeepLinkedDrawerOnTop();
      }
      
      private function RefreshLinkedMultiSelectStatus() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshVisibleCASProductCards() : void
      {
         var i:int;
         var card:MovieClip;
         if(this.mLinkedCASProductCards == null)
         {
            return;
         }
         i = 0;
         while(i < this.mLinkedCASProductCards.length)
         {
            card = this.mLinkedCASProductCards[i] as MovieClip;
            if(card != null && card.parent != null)
            {
               try
               {
                  this.RefreshCASProductCardVisualState(card,int(Object(card).fgehProductIndex));
               }
               catch(eCard:Error)
               {
               }
            }
            i++;
         }
      }
      
      private function SetLinkedSmallTabLabel(param1:String, param2:String, param3:Number, param4:Boolean) : void
      {
         var tab:Sprite;
         if(this.mLinkedDrawerLayer == null)
         {
            return;
         }
         tab = this.mLinkedDrawerLayer.getChildByName(param1) as Sprite;
         if(tab == null)
         {
            return;
         }
         try
         {
            if(tab.numChildren > 0 && tab.getChildAt(0) is TextField)
            {
               TextField(tab.getChildAt(0)).text = param2;
            }
         }
         catch(eLabel:Error)
         {
         }
         this.PaintSmallTab(tab,param4,param3);
      }
      
      private function HideLinkedCASPreviewForPoseSwitch() : void
      {
         this.CancelPendingCASProductHover();
         this.CancelPendingCASSwatchHover();
         this.CancelPendingCASSwatchRestore();
         this.CancelCASPreviewImageRequest();
         if(this.mLinkedCASPreviewPanel != null)
         {
            try
            {
               this.mLinkedCASPreviewPanel.visible = false;
            }
            catch(eHide:Error)
            {
            }
         }
         this.mLinkedCASPreviewPanel = null;
         this.mLinkedCASPreviewCard = null;
         this.mLinkedCASPreviewProductIndex = -1;
      }
      
      private function TryFastSwitchLinkedPose(param1:int, param2:int) : Boolean
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function RefreshLinkedDrawer() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnLinkedRestoreOriginalOutfit(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            if(param1.currentTarget != null)
            {
               if(param1.currentTarget.name == "fgehLibraryButton")
               {
                  param1.stopImmediatePropagation();
                  CommunicationManager.PostServerCommand("fgeh.caslib_source","back",this.mData.dialog_id);
                  return;
               }
               if(param1.currentTarget.name == "fgehR74SourceLocal")
               {
                  param1.stopImmediatePropagation();
                  CommunicationManager.PostServerCommand("fgeh.caslib_source","local",this.mData.dialog_id);
                  return;
               }
               if(param1.currentTarget.name == "fgehR74SourceExternal")
               {
                  param1.stopImmediatePropagation();
                  CommunicationManager.PostServerCommand("fgeh.caslib_source","external",this.mData.dialog_id);
                  return;
               }
            }
         }
         if(param1 != null)
         {
            if(this.GetLinkedPoseName(this.mLinkedActiveIndex) == "root_outfits")
            {
               if(param1.currentTarget != null)
               {
                  if(param1.currentTarget.name == "fgehR74RemovePart")
                  {
                     param1.stopImmediatePropagation();
                     if(this.mLinkedCASPreviewProductIndex >= 0)
                     {
                        var _loc3_:int = this.GetLinkedProductChosenVariant(this.mLinkedCASPreviewProductIndex);
                        if(_loc3_ < 0)
                        {
                           _loc3_ = 0;
                        }
                        var _loc2_:String = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,this.mLinkedCASPreviewProductIndex,_loc3_,1,"0");
                        CommunicationManager.PostServerCommand("fgeh.outfit_queue_remove",_loc2_,this.mData.dialog_id);
                     }
                     this.PostResponse(700032);
                     return;
                  }
                  if(param1.currentTarget.name == "fgehR74ClearCategory")
                  {
                     param1.stopImmediatePropagation();
                     this.PostResponse(700033);
                     return;
                  }
               }
            }
         }
         if(param1 != null)
         {
            if(this.GetLinkedPoseName(this.mLinkedActiveIndex) == "root_outfits")
            {
               if(param1.currentTarget != null)
               {
                  if(param1.currentTarget.name == "fgehR30SaveOutfit")
                  {
                     param1.stopImmediatePropagation();
                     this.PostResponse(700030);
                     return;
                  }
                  if(param1.currentTarget.name == "fgehR30RefreshPreview")
                  {
                     param1.stopImmediatePropagation();
                     this.PostResponse(700031);
                     return;
                  }
               }
            }
         }
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.mLinkedManageMode)
         {
            return;
         }
         this.PostResponse(RESPONSE_LINKED_RESTORE_OUTFIT);
      }
      
      private function OnLinkedClearGeneratedObjects(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.mLinkedManageMode)
         {
            return;
         }
         this.PostResponse(RESPONSE_LINKED_CLEAR_OBJECTS);
      }
      
      private function OnFixedLinkedManage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
            if(!this.HasLinkedDetailExtension())
            {
               this.PostResponse(650005);
               return;
            }
         }
         this.EnterLinkedManage(-1);
      }
      
      private function OnCASDirectProbeOpen(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mCASDirectProbeOpen = true;
         this.RefreshLinkedDrawer();
      }
      
      private function OnCASDirectProbeClose(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mCASDirectProbeOpen = false;
         this.RefreshLinkedDrawer();
      }
      
      private function OnLinkedInspectorExpand(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.mLinkedInspectorExpanded = !this.mLinkedInspectorExpanded;
         this.mCASDirectProbeOpen = false;
         this.mLinkedResourcePage = 0;
         this.RefreshLinkedDrawer();
      }
      
      private function OnLinkedTypeFilter(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         this.mLinkedTypeFilter = String(param1.currentTarget.name).indexOf("Object") >= 0 ? "object" : "cas";
         this.mCASDirectProbeOpen = false;
         this.mLinkedResourcePage = 0;
         this.RefreshLinkedDrawer();
      }
      
      private function OnLinkedOriginFilter(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var name:String = String(param1.currentTarget.name);
         if(name.indexOf("Local") >= 0)
         {
            this.mLinkedOriginFilter = "local";
         }
         else if(name.indexOf("External") >= 0)
         {
            this.mLinkedOriginFilter = "external";
         }
         else
         {
            this.mLinkedOriginFilter = "all";
         }
         this.mCASDirectProbeOpen = false;
         this.mLinkedResourcePage = 0;
         this.RefreshLinkedDrawer();
      }
      
      private function OnLinkedMultiSelect(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.ToggleLinkedMultiSelect();
      }
      
      private function OnLinkedDone(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.ExitLinkedManage();
      }
      
      private function OnLinkedResourceToggle(param1:MouseEvent) : void
      {
         var resourceIndex:int;
         var key:String;
         var wasEnabled:Boolean;
         var resourceType:String;
         var productIndex:int;
         var variantCount:int;
         var vi:int;
         var siblingResource:int;
         var objectProductIndex:int;
         var objectVariantCount:int;
         var ovi:int;
         var siblingObjectResource:int;
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         resourceIndex = -1;
         try
         {
            resourceIndex = int(Object(param1.currentTarget).fgehResourceIndex);
         }
         catch(e:Error)
         {
            resourceIndex = -1;
         }
         if(resourceIndex < 0)
         {
            return;
         }
         key = this.LinkedResourceKey(this.mLinkedActiveIndex,resourceIndex);
         wasEnabled = this.IsLinkedResourceEnabled(this.mLinkedActiveIndex,resourceIndex);
         resourceType = this.GetLinkedResourceField(this.mLinkedActiveIndex,resourceIndex,0,"");
         if(resourceType == "cas" && this.HasLinkedProductsExtension())
         {
            productIndex = this.FindLinkedProductForResource(this.mLinkedActiveIndex,resourceIndex);
            if(productIndex >= 0)
            {
               variantCount = int(this.GetLinkedProductField(this.mLinkedActiveIndex,productIndex,3,"0"));
               vi = 0;
               while(vi < variantCount)
               {
                  siblingResource = int(this.GetLinkedProductVariantField(this.mLinkedActiveIndex,productIndex,vi,0,"-1"));
                  if(siblingResource >= 0)
                  {
                     this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,siblingResource)] = false;
                  }
                  vi++;
               }
               if(!wasEnabled)
               {
                  this.mLinkedResourceOverrides[key] = true;
               }
            }
            else
            {
               this.mLinkedResourceOverrides[key] = !wasEnabled;
            }
         }
         else
         {
            this.mLinkedResourceOverrides[key] = !wasEnabled;
         }
         if(resourceType == "object" && this.HasLinkedObjectProductsExtension())
         {
            objectProductIndex = this.FindLinkedObjectProductForResource(this.mLinkedActiveIndex,resourceIndex);
            if(objectProductIndex >= 0)
            {
               objectVariantCount = int(this.GetLinkedObjectProductField(this.mLinkedActiveIndex,objectProductIndex,3,"0"));
               ovi = 0;
               while(ovi < objectVariantCount)
               {
                  siblingObjectResource = int(this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,objectProductIndex,ovi,0,"-1"));
                  if(siblingObjectResource >= 0)
                  {
                     this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,siblingObjectResource)] = false;
                  }
                  ovi++;
               }
               if(!wasEnabled)
               {
                  this.mLinkedResourceOverrides[key] = true;
               }
            }
         }
         CommunicationManager.PostServerCommand("fgeh.linked_toggle_item",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),this.GetLinkedResourceField(this.mLinkedActiveIndex,resourceIndex,0,""),this.GetLinkedResourceField(this.mLinkedActiveIndex,resourceIndex,1,"0"));
         this.RefreshLinkedRowSummary(this.mLinkedActiveIndex);
         this.RefreshLinkedDrawer();
      }
      
      private function OnLinkedAutoToggle(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var type:String = String(param1.currentTarget.name).indexOf("Object") >= 0 ? "object" : "cas";
         var key:String = this.LinkedAutoKey(this.mLinkedActiveIndex,type);
         this.mLinkedAutoOverrides[key] = !this.IsLinkedAutoEnabled(this.mLinkedActiveIndex,type);
         CommunicationManager.PostServerCommand("fgeh.linked_toggle_auto",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),type);
         this.RefreshLinkedRowSummary(this.mLinkedActiveIndex);
         this.RefreshLinkedDrawer();
      }
      
      private function OnLinkedSetAll(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         var enabled:Boolean = String(param1.currentTarget.name).indexOf("Disable") < 0;
         var count:int = this.GetLinkedResourceCount(this.mLinkedActiveIndex);
         var i:int = 0;
         while(i < count)
         {
            var type:String = this.GetLinkedResourceField(this.mLinkedActiveIndex,i,0,"");
            this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,i)] = false;
            i++;
         }
         if(enabled)
         {
            if(this.HasLinkedObjectProductsExtension())
            {
               var objectProductCount:int = this.GetLinkedObjectProductCount(this.mLinkedActiveIndex);
               var opi:int = 0;
               while(opi < objectProductCount)
               {
                  var objectChosen:int = this.GetLinkedObjectProductEnabledVariant(opi);
                  if(objectChosen < 0)
                  {
                     objectChosen = 0;
                  }
                  var objectResourceIndex:int = int(this.GetLinkedObjectProductVariantField(this.mLinkedActiveIndex,opi,objectChosen,0,"-1"));
                  if(objectResourceIndex >= 0)
                  {
                     this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,objectResourceIndex)] = true;
                  }
                  opi++;
               }
            }
            else
            {
               i = 0;
               while(i < count)
               {
                  if(this.GetLinkedResourceField(this.mLinkedActiveIndex,i,0,"") == "object")
                  {
                     this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,i)] = true;
                  }
                  i++;
               }
            }
         }
         if(this.HasLinkedProductsExtension())
         {
            var selectedSnapshot:Object = {};
            var productCount:int = this.GetLinkedProductCount(this.mLinkedActiveIndex);
            var pi:int = 0;
            while(pi < productCount)
            {
               var variantCount:int = int(this.GetLinkedProductField(this.mLinkedActiveIndex,pi,3,"0"));
               var chosen:int = this.GetLinkedProductEnabledVariant(pi);
               if(chosen < 0)
               {
                  chosen = this.GetLinkedProductChosenVariant(pi);
               }
               if(chosen < 0 || chosen >= variantCount)
               {
                  chosen = 0;
               }
               if(enabled && variantCount > 0)
               {
                  var chosenItemId:String = this.GetLinkedProductVariantField(this.mLinkedActiveIndex,pi,chosen,1,"0");
                  if(chosenItemId != "0" && chosenItemId.length > 0)
                  {
                     selectedSnapshot[chosenItemId] = true;
                  }
                  this.SetLinkedProductChosenVariant(pi,chosen);
               }
               pi++;
            }
            this.SetLinkedCASRowSnapshotOverride(this.mLinkedActiveIndex,selectedSnapshot);
         }
         else if(enabled)
         {
            i = 0;
            while(i < count)
            {
               if(this.GetLinkedResourceField(this.mLinkedActiveIndex,i,0,"") == "cas")
               {
                  this.mLinkedResourceOverrides[this.LinkedResourceKey(this.mLinkedActiveIndex,i)] = true;
               }
               i++;
            }
         }
         if(enabled)
         {
            this.mLinkedAutoOverrides[this.LinkedAutoKey(this.mLinkedActiveIndex,"cas")] = true;
            this.mLinkedAutoOverrides[this.LinkedAutoKey(this.mLinkedActiveIndex,"object")] = true;
         }
         CommunicationManager.PostServerCommand("fgeh.linked_set_all",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(this.mLinkedActiveIndex)),enabled ? 1 : 0);
         this.RefreshLinkedRowSummary(this.mLinkedActiveIndex);
         if(this.IsCASProductCardMode())
         {
            this.RefreshVisibleCASProductCards();
            this.RefreshLinkedMultiSelectStatus();
         }
         else
         {
            this.RefreshLinkedDrawer();
         }
      }
      
      private function OnLinkedApplyPack(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var uiStarted:int = getTimer();
         var sourceIndex:int = this.mLinkedActiveIndex;
         var sourceCount:int = this.GetLinkedResourceCount(sourceIndex);
         var selected:Object = {};
         var casSelected:Object = {};
         var objectSelected:Object = {};
         var casIds:Array = [];
         var objectIds:Array = [];
         var i:int = 0;
         if(this.HasLinkedProductsExtension())
         {
            var productCount:int = this.GetLinkedProductCount(sourceIndex);
            var pi:int = 0;
            while(pi < productCount)
            {
               var enabledVariant:int = this.GetLinkedProductEnabledVariant(pi);
               if(enabledVariant >= 0)
               {
                  var casId:String = this.GetLinkedProductVariantField(sourceIndex,pi,enabledVariant,1,"0");
                  if(casId != "0" && casId.length > 0)
                  {
                     casIds.push(casId);
                     casSelected[casId] = true;
                  }
               }
               pi++;
            }
         }
         while(i < sourceCount)
         {
            var type:String = this.GetLinkedResourceField(sourceIndex,i,0,"");
            var id:String = this.GetLinkedResourceField(sourceIndex,i,1,"0");
            var signature:String = type + "|" + id;
            var isEnabled:Boolean = this.IsLinkedResourceEnabled(sourceIndex,i);
            selected[signature] = isEnabled;
            if(isEnabled)
            {
               if(type == "object")
               {
                  objectIds.push(id);
                  objectSelected[id] = true;
               }
               else if(type == "cas" && !this.HasLinkedProductsExtension())
               {
                  casIds.push(id);
                  casSelected[id] = true;
               }
            }
            i++;
         }
         var targetPoseNames:Array = [];
         if(this.mLinkedMultiSelectMode)
         {
            targetPoseNames = this.LinkedSelectedPoseNames();
            if(targetPoseNames.length <= 0)
            {
               this.RefreshSelectionOverlays();
               return;
            }
         }
         var serverStarted:int = getTimer();
         CommunicationManager.PostServerCommand("fgeh.linked_apply_snapshot",encodeURIComponent(this.GetLinkedPackId()),encodeURIComponent(this.GetLinkedPoseName(sourceIndex)),this.IsLinkedAutoEnabled(sourceIndex,"cas") ? 1 : 0,this.IsLinkedAutoEnabled(sourceIndex,"object") ? 1 : 0,encodeURIComponent(casIds.join(",")),encodeURIComponent(objectIds.join(",")),encodeURIComponent(targetPoseNames.join("\n")));
         var serverReturnMs:int = getTimer() - serverStarted;
         var rowCount:int = this.GetLinkedRowCount();
         var sourceSummary:String = this.GetLinkedRowSummary(sourceIndex);
         var sourceCatalogIndex:int = this.HasLinkedProductsV2Extension() ? this.GetLinkedV2PoseCatalogIndex(sourceIndex) : -1;
         var rowIndex:int = 0;
         var mirroredRows:int = 0;
         while(rowIndex < rowCount)
         {
            var shouldApply:Boolean = !this.mLinkedMultiSelectMode || this.IsLinkedPoseSelected(rowIndex);
            if(shouldApply && rowIndex != sourceIndex)
            {
               this.SetLinkedObjectRowSnapshotOverride(rowIndex,objectSelected);
               if(this.HasLinkedProductsExtension())
               {
                  this.SetLinkedCASRowSnapshotOverride(rowIndex,casSelected);
               }
               else
               {
                  var targetCount:int = this.GetLinkedResourceCount(rowIndex);
                  var j:int = 0;
                  while(j < targetCount)
                  {
                     if(this.GetLinkedResourceField(rowIndex,j,0,"") == "cas")
                     {
                        var targetSignature:String = "cas|" + this.GetLinkedResourceField(rowIndex,j,1,"0");
                        if(selected.hasOwnProperty(targetSignature))
                        {
                           this.mLinkedResourceOverrides[this.LinkedResourceKey(rowIndex,j)] = Boolean(selected[targetSignature]);
                        }
                     }
                     j++;
                  }
               }
               this.mLinkedAutoOverrides[this.LinkedAutoKey(rowIndex,"cas")] = this.IsLinkedAutoEnabled(sourceIndex,"cas");
               this.mLinkedAutoOverrides[this.LinkedAutoKey(rowIndex,"object")] = this.IsLinkedAutoEnabled(sourceIndex,"object");
               if(this.HasLinkedProductsV2Extension() && this.GetLinkedV2PoseCatalogIndex(rowIndex) == sourceCatalogIndex)
               {
                  this.SetLinkedRowSummaryFast(rowIndex,sourceSummary);
               }
               else
               {
                  this.SetLinkedRowSummaryFast(rowIndex,this.GetLinkedRowSummary(rowIndex));
               }
               mirroredRows++;
            }
            rowIndex++;
         }
         this.UpdateLinkedMultiSelectChrome();
      }
      
      private function OnLinkedResourcePrev(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.mLinkedResourcePage > 0)
         {
            --this.mLinkedResourcePage;
            §§push(this);
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehPageOnlyR74"] = true;
            }
            §§pop().RefreshLinkedDrawer();
         }
      }
      
      private function OnLinkedResourceNext(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         var count:int = this.LinkedResourcePageCount();
         if(this.mLinkedResourcePage + 1 < count)
         {
            ++this.mLinkedResourcePage;
            §§push(this);
            if(this.mLinkedDrawerLayer != null)
            {
               this.mLinkedDrawerLayer["fgehPageOnlyR74"] = true;
            }
            §§pop().RefreshLinkedDrawer();
         }
      }
      
      private function BuildFixedTools() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function ApplyExistingUIFont(param1:TextField, param2:String, param3:Number, param4:uint, param5:Boolean = false) : void
      {
         var template:DisplayObject;
         var format:TextFormat;
         if(this.GetV7ActiveNav() == 6)
         {
            if(param2 == "fgehModeLabel")
            {
               param2 = "fgehPackName1";
            }
         }
         if(param1 == null)
         {
            return;
         }
         template = this.Child(param2);
         format = null;
         if(template is TextField)
         {
            try
            {
               format = TextField(template).getTextFormat();
            }
            catch(e:Error)
            {
               format = null;
            }
            try
            {
               param1.embedFonts = TextField(template).embedFonts;
            }
            catch(e2:Error)
            {
            }
            try
            {
               param1.antiAliasType = TextField(template).antiAliasType;
            }
            catch(e3:Error)
            {
            }
            try
            {
               param1.gridFitType = TextField(template).gridFitType;
            }
            catch(e4:Error)
            {
            }
            try
            {
               param1.sharpness = TextField(template).sharpness;
               param1.thickness = TextField(template).thickness;
            }
            catch(e5:Error)
            {
            }
         }
         if(format == null)
         {
            format = new TextFormat("_sans");
         }
         format.size = param3;
         format.color = param4;
         format.bold = param5;
         format.align = "left";
         param1.defaultTextFormat = format;
         try
         {
            param1.setTextFormat(format);
         }
         catch(e6:Error)
         {
         }
      }
      
      private function CreateRuntimeButton(param1:String, param2:String, param3:Number, param4:Number) : Sprite
      {
         var button:Sprite = new Sprite();
         button.name = param1;
         button.buttonMode = true;
         button.mouseEnabled = true;
         button.mouseChildren = false;
         button.graphics.beginFill(16252157,0.98);
         button.graphics.lineStyle(1,12180963,1);
         button.graphics.drawRoundRect(0,0,param3,param4,10,10);
         button.graphics.endFill();
         var label:TextField = new TextField();
         label.mouseEnabled = false;
         label.selectable = false;
         label.width = param3 - 16;
         label.height = param4 - 4;
         label.x = 8;
         label.y = 4;
         this.ApplyExistingUIFont(label,"fgehModeLabel",13,2386808);
         label.text = param2;
         this.ApplyExistingUIFont(label,"fgehModeLabel",13,2386808);
         button.addChild(label);
         button.addEventListener(MouseEvent.MOUSE_OVER,this.OnRuntimeButtonOver,false,0,true);
         button.addEventListener(MouseEvent.MOUSE_OUT,this.OnRuntimeButtonOut,false,0,true);
         return button;
      }
      
      private function SetRuntimeButtonLabel(param1:Sprite, param2:String) : void
      {
         if(param1 == null)
         {
            return;
         }
         var i:int = 0;
         while(i < param1.numChildren)
         {
            var child:DisplayObject = param1.getChildAt(i);
            if(child is TextField)
            {
               TextField(child).text = param2;
               this.ApplyExistingUIFont(TextField(child),"fgehModeLabel",13,2386808);
               return;
            }
            i++;
         }
      }
      
      private function PaintRuntimeButton(param1:Sprite, param2:Boolean) : void
      {
         if(param1 == null)
         {
            return;
         }
         param1.graphics.clear();
         if(param2)
         {
            param1.graphics.beginFill(15005688,1);
            param1.graphics.lineStyle(1,5555409,1);
         }
         else
         {
            param1.graphics.beginFill(16252157,0.98);
            param1.graphics.lineStyle(1,12180963,1);
         }
         param1.graphics.drawRoundRect(0,0,170,34,10,10);
         param1.graphics.endFill();
      }
      
      private function OnRuntimeButtonOver(param1:MouseEvent) : void
      {
         this.PaintRuntimeButton(param1.currentTarget as Sprite,true);
      }
      
      private function OnRuntimeButtonOut(param1:MouseEvent) : void
      {
         var button:Sprite = param1.currentTarget as Sprite;
         if(button == this.mBatchSelectButton && this.mBatchSelectMode)
         {
            this.PaintRuntimeButton(button,true);
            return;
         }
         this.PaintRuntimeButton(button,false);
      }
      
      private function RefreshFixedTools() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function OnFixedSwitchTarget(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(this.HasV7Extension() && this.GetV7ViewKind().indexOf("pack_detail") != 0)
         {
            return;
         }
         this.PostResponse(RESPONSE_SWITCH_TARGET);
      }
      
      private function OnFixedBatchSelect(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || this.GetV7ViewKind().indexOf("pack_detail") != 0 || this.GetV7ViewKind() == "pack_detail_group_edit")
         {
            return;
         }
         this.SetBatchSelectMode(!this.mBatchSelectMode);
      }
      
      private function OnFixedFavoriteToGroup(param1:MouseEvent) : void
      {
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         param1.stopImmediatePropagation();
         if(!this.mBatchSelectMode || this.BatchSelectedPoseNames().length <= 0)
         {
            return;
         }
         var target:DisplayObject = param1.currentTarget as DisplayObject;
         var bounds:Rectangle = target.getBounds(this.mcContent);
         this.OpenBatchFavoriteGroupMenu("pose",bounds.right + 8,bounds.y - 10);
      }
      
      private function OnFixedClearPoseQueue(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || this.GetV7ViewKind().indexOf("pack_detail") != 0 || this.GetV7ViewKind() == "pack_detail_group_edit")
         {
            return;
         }
         CommunicationManager.PostServerCommand("fgeh.clear_pose_queue");
         if(this.mBatchSelectMode)
         {
            this.SetBatchSelectMode(false);
         }
      }
      
      private function OnFixedPlayAll(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         if(!this.HasV7Extension() || this.GetV7ViewKind().indexOf("pack_detail") != 0 || this.GetV7ViewKind() == "pack_detail_group_edit")
         {
            return;
         }
         var selected:Array = this.BatchSelectedPoseNames();
         if(selected.length > 0)
         {
            CommunicationManager.PostServerCommand("fgeh.play_selected_poses",encodeURIComponent(selected.join("\n")));
            this.SetBatchSelectMode(false);
            return;
         }
         if(this.mBatchSelectMode)
         {
            this.SetBatchSelectMode(false);
         }
         this.PostResponse(RESPONSE_PLAY_ALL_VISIBLE);
      }
      
      private function OnFixedGroupManage(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.PostResponse(RESPONSE_PROXY_GROUP_MANAGE);
      }
      
      private function BuildNativeCells() : void
      {
         var NativeClass:Class;
         var i:int;
         var cell:MovieClip;
         var hit:Sprite;
         if(this.mcContent == null)
         {
            return;
         }
         if(this.mNativeLayer != null)
         {
            return;
         }
         this.mNativeCells = [];
         this.mNativeHitRects = [];
         this.mNativeLayer = new MovieClip();
         this.mNativeLayer.name = "fgehNativeCellLayer";
         this.mNativeLayer.mouseEnabled = false;
         this.mNativeLayer.mouseChildren = true;
         this.mcContent.addChild(this.mNativeLayer);
         NativeClass = null;
         try
         {
            NativeClass = getDefinitionByName(NATIVE_CELL_CLASS) as Class;
         }
         catch(e:Error)
         {
            NativeClass = null;
         }
         if(NativeClass == null)
         {
            return;
         }
         i = 0;
         while(i < ITEMS_PER_PAGE)
         {
            cell = null;
            try
            {
               cell = new NativeClass() as MovieClip;
            }
            catch(e2:Error)
            {
               cell = null;
            }
            if(cell != null)
            {
               cell.name = "fgehNativePickerCell" + (i + 1);
               try
               {
                  Object(cell).fgehSlot = i;
               }
               catch(e3:Error)
               {
               }
               try
               {
                  Object(cell).enabled = true;
               }
               catch(e4:Error)
               {
               }
               try
               {
                  Object(cell).buttonMode = true;
               }
               catch(e5:Error)
               {
               }
               this.EnableRightMouseDeep(cell);
               cell.addEventListener("buttonClick",this.OnNativeCellButtonClick,false,10000,true);
               cell.addEventListener("rightClick",this.OnNativeCellRightClickFallback,false,10000,true);
               cell.addEventListener("middleClick",this.OnNativeCellMiddleClickFallback,false,10000,true);
               cell.addEventListener("middleMouseDown",this.OnNativeCellMiddleClickFallback,false,10000,true);
               cell.addEventListener("middleMouseUp",this.OnNativeCellMiddleClickFallback,false,10000,true);
               hit = new Sprite();
               hit.name = "fgehNativeHitRect" + (i + 1);
               hit.mouseEnabled = false;
               hit.mouseChildren = false;
               cell.addChild(hit);
               try
               {
                  cell.hitArea = hit;
               }
               catch(e6:Error)
               {
               }
               cell.alpha = DEBUG_NATIVE_HIT ? 0.45 : 0.01;
               cell.visible = false;
               this.mNativeLayer.addChild(cell);
               this.mNativeCells[i] = cell;
               this.mNativeHitRects[i] = hit;
            }
            else
            {
               this.mNativeCells[i] = null;
               this.mNativeHitRects[i] = null;
            }
            i++;
         }
      }
      
      private function RefreshNativeCells() : void
      {
         var page:int;
         var total:int;
         var pageSize:int;
         var i:int;
         var visibleIndex:int;
         var dataIndex:int;
         var visible:Boolean;
         var cell:MovieClip;
         var hit:Sprite;
         var bounds:Rectangle;
         var _loc7_:int = getTimer();
         var _loc4_:int = getTimer();
         if(this.mNativeLayer == null || this.mNativeCells == null || this.mData == null)
         {
            if(this.mNativeCells != null)
            {
               if(!this.mLinkedManageMode)
               {
                  if(this.GetV7ActiveNav() == 9)
                  {
                     var _loc3_:* = this.mNativeCells[9];
                     if(_loc3_ != null)
                     {
                        _loc3_.visible = false;
                        _loc3_.mouseEnabled = false;
                     }
                     _loc3_ = this.mNativeCells[10];
                     if(_loc3_ != null)
                     {
                        _loc3_.visible = false;
                        _loc3_.mouseEnabled = false;
                     }
                     _loc3_ = this.mNativeCells[11];
                     if(_loc3_ != null)
                     {
                        _loc3_.visible = false;
                        _loc3_.mouseEnabled = false;
                     }
                  }
               }
            }
            if(this.mLinkedManageMode)
            {
               if(this.mNativeCells != null)
               {
                  var _loc6_:* = this.mNativeCells[8];
                  if(_loc6_ != null)
                  {
                     _loc6_.visible = false;
                     _loc6_.mouseEnabled = false;
                  }
                  _loc6_ = this.mNativeCells[9];
                  if(_loc6_ != null)
                  {
                     _loc6_.visible = false;
                     _loc6_.mouseEnabled = false;
                  }
                  _loc6_ = this.mNativeCells[10];
                  if(_loc6_ != null)
                  {
                     _loc6_.visible = false;
                     _loc6_.mouseEnabled = false;
                  }
                  _loc6_ = this.mNativeCells[11];
                  if(_loc6_ != null)
                  {
                     _loc6_.visible = false;
                     _loc6_.mouseEnabled = false;
                  }
               }
            }
            CommunicationManager.PostServerCommand("fgeh.perf_phase","REFRESH_NATIVE" + ":" + (getTimer() - _loc7_),this.mData.dialog_id);
            return;
         }
         this.mNativeLayer.visible = true;
         this.mNativeLayer.mouseEnabled = false;
         this.mNativeLayer.mouseChildren = !this.IsAnyManagerModalOpen();
         try
         {
            this.mcContent.setChildIndex(this.mNativeLayer,this.mcContent.numChildren - 1);
         }
         catch(e:Error)
         {
         }
         page = this.GetCurrentPage();
         total = this.ActiveTotalItems();
         pageSize = this.ActiveItemsPerPage();
         i = 0;
         while(i < this.ActiveItemsPerPage())
         {
            visibleIndex = page * pageSize + i;
            dataIndex = i < pageSize ? this.ActiveDataIndexAtVisible(visibleIndex) : -1;
            visible = i < pageSize && visibleIndex >= 0 && visibleIndex < total && dataIndex >= 0;
            cell = this.mNativeCells[i] as MovieClip;
            hit = this.mNativeHitRects[i] as Sprite;
            if(cell != null)
            {
               if(!visible)
               {
                  cell.visible = false;
                  cell.mouseEnabled = false;
                  cell.mouseChildren = false;
                  try
                  {
                     cell.hitArea = null;
                  }
                  catch(eHidden:Error)
                  {
                  }
                  if(hit != null)
                  {
                     hit.visible = false;
                     hit.graphics.clear();
                  }
               }
               else
               {
                  cell.visible = true;
                  try
                  {
                     Object(cell).fgehSourceIndex = dataIndex;
                  }
                  catch(e2:Error)
                  {
                  }
                  bounds = this.NativeCardHitBounds(i);
                  cell.x = bounds.x;
                  cell.y = bounds.y;
                  cell.mouseEnabled = true;
                  cell.mouseChildren = this.mLinkedManageMode || this.IsAnyMemberEditMode();
                  if(hit != null)
                  {
                     hit.visible = true;
                     hit.graphics.clear();
                     if(DEBUG_NATIVE_HIT)
                     {
                        hit.graphics.beginFill(3332326,0.6);
                     }
                     else
                     {
                        hit.graphics.beginFill(3332326,0.02);
                     }
                     hit.graphics.drawRect(0,0,bounds.width,bounds.height);
                     hit.graphics.endFill();
                     cell.hitArea = hit;
                  }
               }
            }
            i++;
         }
         this.KeepLinkedDrawerOnTop();
         if(this.mNativeCells != null)
         {
            if(!this.mLinkedManageMode)
            {
               if(this.GetV7ActiveNav() == 9)
               {
                  _loc3_ = this.mNativeCells[9];
                  if(_loc3_ != null)
                  {
                     _loc3_.visible = false;
                     _loc3_.mouseEnabled = false;
                  }
                  _loc3_ = this.mNativeCells[10];
                  if(_loc3_ != null)
                  {
                     _loc3_.visible = false;
                     _loc3_.mouseEnabled = false;
                  }
                  _loc3_ = this.mNativeCells[11];
                  if(_loc3_ != null)
                  {
                     _loc3_.visible = false;
                     _loc3_.mouseEnabled = false;
                  }
               }
            }
         }
         if(this.mLinkedManageMode)
         {
            if(this.mNativeCells != null)
            {
               _loc6_ = this.mNativeCells[8];
               if(_loc6_ != null)
               {
                  _loc6_.visible = false;
                  _loc6_.mouseEnabled = false;
               }
               _loc6_ = this.mNativeCells[9];
               if(_loc6_ != null)
               {
                  _loc6_.visible = false;
                  _loc6_.mouseEnabled = false;
               }
               _loc6_ = this.mNativeCells[10];
               if(_loc6_ != null)
               {
                  _loc6_.visible = false;
                  _loc6_.mouseEnabled = false;
               }
               _loc6_ = this.mNativeCells[11];
               if(_loc6_ != null)
               {
                  _loc6_.visible = false;
                  _loc6_.mouseEnabled = false;
               }
            }
         }
         CommunicationManager.PostServerCommand("fgeh.perf_phase","REFRESH_NATIVE" + ":" + (getTimer() - _loc7_),this.mData.dialog_id);
      }
      
      private function ExactGridHitBounds(param1:int) : Rectangle
      {
         if(this.mLinkedManageMode)
         {
            if(param1 < 0 || param1 >= LINKED_ITEMS_PER_PAGE)
            {
               return new Rectangle(-9999,-9999,1,1);
            }
            var linkedCol:int = param1 % 2;
            var linkedRow:int = int(param1 / 2);
            return new Rectangle(-210 + linkedCol * 230 + LINKED_GRID_SHIFT,-195 + linkedRow * 120,220,112);
         }
         var col:int = param1 % 3;
         var row:int = int(param1 / 3);
         return new Rectangle(-210 + col * 230,-195 + row * 120,220,112);
      }
      
      private function NativeCardHitBounds(param1:int) : Rectangle
      {
         if(this.GetV7ViewKind() == "root_outfits")
         {
            return new Rectangle(-210 + int(param1 % 3) * 230,-163 + int(param1 / 3) * 148,120,140);
         }
         return this.ExactGridHitBounds(param1);
      }
      
      private function FallbackCardBounds(param1:int) : Rectangle
      {
         var col:int = param1 % 3;
         var row:int = int(param1 / 3);
         return new Rectangle(-210 + col * 230,-195 + row * 120,220,112);
      }
      
      private function NativeSourceIndex(param1:Object) : int
      {
         if(param1 == null)
         {
            return -1;
         }
         try
         {
            return int(Object(param1).fgehSourceIndex);
         }
         catch(e:Error)
         {
            return -1;
         }
      }
      
      private function EnableRightMouseDeep(param1:DisplayObject) : void
      {
         var clip:MovieClip;
         var i:int;
         if(param1 == null)
         {
            return;
         }
         try
         {
            Object(param1).RightMouseButtonEnabled = true;
         }
         catch(e:Error)
         {
         }
         try
         {
            Object(param1).rightMouseButtonEnabled = true;
         }
         catch(e2:Error)
         {
         }
         if(param1 is MovieClip)
         {
            clip = param1 as MovieClip;
            i = 0;
            while(i < clip.numChildren)
            {
               this.EnableRightMouseDeep(clip.getChildAt(i));
               i++;
            }
         }
      }
      
      private function NativeButtonIndex(param1:Event) : int
      {
         if(param1 == null)
         {
            return 0;
         }
         try
         {
            return int(Object(param1).buttonIdx);
         }
         catch(e:Error)
         {
            return 0;
         }
      }
      
      private function OnNativeCellButtonClick(param1:Event) : void
      {
         if(param1 == null || param1.currentTarget == null || this.mData == null)
         {
            return;
         }
         if(this.IsPointerInsideLinkedDrawer() || getTimer() < this.mLinkedIgnoreNativeUntil)
         {
            param1.stopImmediatePropagation();
            return;
         }
         var index:int = this.NativeSourceIndex(param1.currentTarget);
         var total:int = this.GetTotalItems();
         if(index < 0 || index >= total)
         {
            return;
         }
         var buttonIdx:int = this.NativeButtonIndex(param1);
         param1.stopImmediatePropagation();
         if(this.mBatchSelectMode)
         {
            if(buttonIdx == 0)
            {
               this.SetBatchPoseSelected(index,!this.IsBatchPoseSelected(index));
               this.RefreshSelectionOverlays();
               this.RefreshFixedTools();
               this.RefreshRootTools();
            }
            else if(buttonIdx == 1)
            {
               this.PostBatchFavoriteSelected();
            }
            return;
         }
         if(this.mLinkedManageMode && this.HasLinkedDetailExtension())
         {
            if(buttonIdx == 0)
            {
               if(!this.mLinkedMultiSelectMode)
               {
                  var oldLinkedIndex:int = this.mLinkedActiveIndex;
                  this.mLinkedActiveIndex = index;
                  if(!this.TryFastSwitchLinkedPose(oldLinkedIndex,index))
                  {
                     this.mLinkedResourcePage = 0;
                     this.RefreshSelectionOverlays();
                     this.RefreshLinkedDrawer();
                  }
                  return;
               }
               if(index != this.mLinkedActiveIndex)
               {
                  this.SetLinkedPoseSelected(index,!this.IsLinkedPoseSelected(index));
               }
               if(this.mLinkedMultiSelectMode)
               {
                  this.RefreshLinkedSelectionOverlayForDataIndex(index);
                  this.RefreshLinkedMultiSelectStatus();
                  this.KeepLinkedDrawerOnTop();
               }
            }
            return;
         }
         if(this.IsAnyMemberEditMode())
         {
            if(buttonIdx == 2)
            {
               this.OpenEditInfoOnce(index);
               return;
            }
            if(buttonIdx == 0)
            {
               this.ToggleMemberIndexLocal(index,true);
            }
            return;
         }
         if(buttonIdx == 1)
         {
            if(this.IsPackRightLongPress(index))
            {
               this.OpenSinglePackOrganizerFromCell(index,param1.currentTarget as DisplayObject);
               return;
            }
            this.PostFavoriteOnce(index);
            return;
         }
         if(buttonIdx == 2)
         {
            this.OpenEditInfoOnce(index);
            return;
         }
         this.PostResponse(RESPONSE_ITEM_BASE + index);
      }
      
      private function OnNativeCellRightClickFallback(param1:Event) : void
      {
         if(param1 == null || param1.currentTarget == null || this.mData == null)
         {
            return;
         }
         var index:int = this.NativeSourceIndex(param1.currentTarget);
         var total:int = this.GetTotalItems();
         if(index < 0 || index >= total)
         {
            return;
         }
         param1.stopImmediatePropagation();
         if(getTimer() < this.mSuppressRightFavoriteUntil)
         {
            return;
         }
         if(!this.mBatchSelectMode && !this.IsAnyMemberEditMode() && this.FavoriteScopeForIndex(index) == "pack" && this.IsPackRightLongPress(index))
         {
            this.OpenSinglePackOrganizerFromCell(index,param1.currentTarget as DisplayObject);
            return;
         }
         if(this.mBatchSelectMode)
         {
            this.PostBatchFavoriteSelected();
            return;
         }
         if(this.mLinkedManageMode)
         {
            return;
         }
         if(this.IsAnyMemberEditMode())
         {
            return;
         }
         this.PostFavoriteOnce(index);
      }
      
      private function OnNativeCellMiddleClickFallback(param1:Event) : void
      {
         if(param1 == null || param1.currentTarget == null || this.mData == null)
         {
            return;
         }
         var index:int = this.NativeSourceIndex(param1.currentTarget);
         var total:int = this.GetTotalItems();
         if(index < 0 || index >= total)
         {
            return;
         }
         param1.stopImmediatePropagation();
         if(this.mLinkedManageMode)
         {
            return;
         }
         this.OpenEditInfoOnce(index);
      }
      
      private function OpenEditInfoOnce(param1:int) : void
      {
         var now:int = getTimer();
         if(this.mLastMiddleEditIndex == param1 && now - this.mLastMiddleEditTime < 250)
         {
            return;
         }
         this.mLastMiddleEditIndex = param1;
         this.mLastMiddleEditTime = now;
         this.OpenEditInfo(param1);
      }
      
      private function PostFavoriteOnce(param1:int) : void
      {
         if(this.GetV7ViewKind() == "root_outfits")
         {
            this.PostResponse(400000 + param1);
            return;
         }
         if(!this.CanFavoriteIndex(param1))
         {
            return;
         }
         var now:int = getTimer();
         if(this.mLastFavoriteIndex == param1 && now - this.mLastFavoriteTime < 250)
         {
            return;
         }
         this.mLastFavoriteIndex = param1;
         this.mLastFavoriteTime = now;
         var scope:String = this.FavoriteScopeForIndex(param1);
         var value:String = this.FavoriteValueForIndex(param1);
         var enabled:Boolean = !this.IsRowFavorite(param1);
         this.SetLocalRowFavorite(param1,enabled);
         this.RefreshFavoriteMarkers();
         CommunicationManager.PostServerCommand("fgeh.batch_favorite",encodeURIComponent(scope),encodeURIComponent(value),enabled ? 1 : 0);
      }
      
      private function ToggleVisibleFavoriteGlyph(param1:int) : void
      {
         this.SetLocalRowFavorite(param1,!this.IsRowFavorite(param1));
         this.RefreshFavoriteMarkers();
      }
      
      protected function Draw(param1:UiDialogMessage) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function CapturePackLlamaPlaceholder() : void
      {
         var source:DisplayObject;
         var bounds:Rectangle;
         var widthValue:int;
         var heightValue:int;
         var bitmapData:BitmapData;
         var matrix:Matrix;
         if(this.mPackLlamaBitmapData != null)
         {
            return;
         }
         source = this.Child("fgehPackIcon1");
         if(source == null)
         {
            return;
         }
         try
         {
            bounds = source.getBounds(source);
            widthValue = Math.max(1,int(Math.ceil(bounds.width)));
            heightValue = Math.max(1,int(Math.ceil(bounds.height)));
            bitmapData = new BitmapData(widthValue,heightValue,true,0);
            matrix = new Matrix();
            matrix.translate(-bounds.x,-bounds.y);
            bitmapData.draw(source,matrix);
            this.mPackLlamaBitmapData = bitmapData;
            this.mPackLlamaBounds = bounds;
         }
         catch(eCapture:Error)
         {
            this.mPackLlamaBitmapData = null;
            this.mPackLlamaBounds = null;
         }
      }
      
      private function EnsurePackLlamaOverlay(param1:int) : Bitmap
      {
         var target:DisplayObject;
         var bitmap:Bitmap;
         var targetBounds:Rectangle;
         this.CapturePackLlamaPlaceholder();
         if(this.mPackLlamaBitmapData == null || this.mPackLlamaBounds == null || this.mcContent == null)
         {
            return null;
         }
         target = this.Child("fgehPackIcon" + param1);
         if(target == null)
         {
            return null;
         }
         bitmap = null;
         if(param1 - 1 >= 0 && param1 - 1 < this.mPackLlamaOverlays.length)
         {
            bitmap = this.mPackLlamaOverlays[param1 - 1] as Bitmap;
         }
         if(bitmap == null)
         {
            bitmap = new Bitmap(this.mPackLlamaBitmapData);
            bitmap.name = "fgehLlamaFallback" + param1;
            bitmap.mouseEnabled = false;
            bitmap.visible = false;
            this.mcContent.addChild(bitmap);
            this.mPackLlamaOverlays[param1 - 1] = bitmap;
         }
         else if(bitmap.parent != this.mcContent)
         {
            try
            {
               if(bitmap.parent != null)
               {
                  bitmap.parent.removeChild(bitmap);
               }
               this.mcContent.addChild(bitmap);
            }
            catch(eParent:Error)
            {
               return null;
            }
         }
         try
         {
            targetBounds = target.getBounds(this.mcContent);
            bitmap.x = targetBounds.x;
            bitmap.y = targetBounds.y;
            bitmap.width = Math.max(1,targetBounds.width);
            bitmap.height = Math.max(1,targetBounds.height);
         }
         catch(eBounds:Error)
         {
            return null;
         }
         return bitmap;
      }
      
      private function SetPackLlamaFallback(param1:int, param2:Boolean) : void
      {
         var target:DisplayObject = this.Child("fgehPackIcon" + param1);
         var bitmap:Bitmap = this.EnsurePackLlamaOverlay(param1);
         if(target != null)
         {
            target.visible = !param2;
         }
         if(bitmap == null)
         {
            return;
         }
         bitmap.visible = param2;
         if(param2)
         {
            try
            {
               if(bitmap.parent == this.mcContent)
               {
                  this.mcContent.setChildIndex(bitmap,this.mcContent.numChildren - 1);
               }
            }
            catch(eTop:Error)
            {
            }
         }
      }
      
      private function MakeCardVisualDisplayOnly(param1:int) : void
      {
         var obj:DisplayObject;
         var names:Array = ["fgehPackCard" + param1,"fgehPackIcon" + param1,"fgehPackName" + param1,"fgehPackCreator" + param1,"fgehPackCount" + param1];
         var i:int = 0;
         for(; i < names.length; i++)
         {
            obj = this.Child(String(names[i]));
            if(obj != null)
            {
               try
               {
                  Object(obj).mouseEnabled = false;
               }
               catch(eMouse:Error)
               {
               }
               try
               {
                  Object(obj).buttonMode = false;
               }
               catch(eButton:Error)
               {
               }
               if(obj is MovieClip)
               {
                  try
                  {
                     MovieClip(obj).mouseChildren = false;
                  }
                  catch(eChildren:Error)
                  {
                  }
                  continue;
               }
            }
         }
      }
      
      private function SetCardVisible(param1:int, param2:Boolean) : void
      {
         if(this.mcContent != null)
         {
            var _temp_1:* = Object(this.mcContent)["fgehCASDirectThumbnailProbeOverlay" + param1] as MovieClip;
            §§push(_temp_1);
            if(_temp_1 != null)
            {
               §§pop().visible = false;
            }
            else
            {
               §§pop();
            }
         }
         if(this.GetV7ViewKind() == "root_outfits")
         {
            param2 = false;
         }
         this.SetVisible("fgehPackCard" + param1,param2);
         this.SetVisible("fgehPackIcon" + param1,param2);
         this.SetVisible("fgehPackName" + param1,param2);
         this.SetVisible("fgehPackCreator" + param1,param2);
         this.SetVisible("fgehPackCount" + param1,param2);
         this.MakeCardVisualDisplayOnly(param1);
         this.SetVisible("fgehPackButton" + param1,false);
      }
      
      private function UpdateScrollThumb(param1:int, param2:int) : void
      {
         var y:Number = -195;
         if(param2 > 1)
         {
            y = -195 + param1 * 380 / (param2 - 1);
         }
         var thumb:DisplayObject = this.Child("fgehScrollThumb");
         var hit:DisplayObject = this.Child("fgehScrollThumbHit");
         if(thumb != null)
         {
            thumb.y = y;
         }
         if(hit != null)
         {
            hit.y = y;
         }
         this.SyncScrollGrabOverlay();
         this.ScheduleRootSearchStateSync();
      }
      
      private function OnPoseManagerPointerLost(param1:Event) : void
      {
         if(this.mScrollDragActive)
         {
            this.FinishScrollDrag(null);
         }
         if(this.mLinkedMarqueeDown || this.mLinkedMarqueeDragging)
         {
            this.AbortMarqueeInteraction();
         }
         this.mLinkedRightPressProductIndex = -1;
         this.mLinkedRightPressStartedAt = 0;
      }
      
      private function IsPoseManagerTyping() : Boolean
      {
         var focus:Object;
         if(this.stage == null)
         {
            return false;
         }
         try
         {
            focus = this.stage.focus;
            if(focus is TextField)
            {
               return TextField(focus).type == TextFieldType.INPUT;
            }
         }
         catch(e:Error)
         {
         }
         return false;
      }
      
      private function OnPoseManagerKeyDown(param1:KeyboardEvent) : void
      {
         if(param1 == null || this.IsPoseManagerTyping())
         {
            return;
         }
         if(param1.keyCode == 88)
         {
            if(this.mBatchSelectMode)
            {
               param1.preventDefault();
               param1.stopImmediatePropagation();
               this.SetBatchSelectMode(false);
               return;
            }
            if(this.mLinkedManageMode && this.mLinkedMultiSelectMode)
            {
               param1.preventDefault();
               param1.stopImmediatePropagation();
               this.ToggleLinkedMultiSelect();
               return;
            }
            if(this.IsOuterGroupRemoveManageMode() && this.OuterManageSelectedCount() > 0)
            {
               param1.preventDefault();
               param1.stopImmediatePropagation();
               this.ClearOuterManageSelection();
               return;
            }
            return;
         }
         if(param1.keyCode == Keyboard.SPACE)
         {
            if(this.mBatchSelectMode && this.GetV7ViewKind().indexOf("pack_detail") == 0 && this.GetV7ViewKind() != "pack_detail_group_edit" && this.BatchSelectedPoseNames().length > 0)
            {
               param1.preventDefault();
               param1.stopImmediatePropagation();
               this.OnFixedPlayAll(null);
               return;
            }
         }
      }
      
      private function InstallStageWheelListener() : void
      {
         if(this.stage == null || this.mStageWheelBound)
         {
            return;
         }
         this.stage.addEventListener(MouseEvent.MOUSE_WHEEL,this.OnMouseWheel,true,10000,true);
         this.mStageWheelBound = true;
         if(!this.mStageMiddleBound)
         {
            this.stage.addEventListener("middleMouseDown",this.OnStageMiddleMouse,true,10000,true);
            this.stage.addEventListener("middleMouseUp",this.OnStageMiddleMouse,true,10000,true);
            this.stage.addEventListener("middleClick",this.OnStageMiddleMouse,true,10000,true);
            this.stage.addEventListener(MouseEvent.MOUSE_DOWN,this.OnStageMouseDownProbe,true,9999,true);
            this.stage.addEventListener(MouseEvent.MOUSE_MOVE,this.OnStageScrollDragMove,true,10020,true);
            this.stage.addEventListener(MouseEvent.MOUSE_UP,this.OnStageScrollDragUp,true,10020,true);
            this.stage.addEventListener(MouseEvent.MOUSE_UP,this.OnStageLinkedRightMouseUp,true,10030,true);
            this.stage.addEventListener(MouseEvent.MOUSE_DOWN,this.OnLinkedMarqueeMouseDown,true,10001,true);
            this.stage.addEventListener(MouseEvent.MOUSE_MOVE,this.OnLinkedMarqueeMouseMove,true,10001,true);
            this.stage.addEventListener(MouseEvent.MOUSE_UP,this.OnLinkedMarqueeMouseUp,true,10001,true);
            this.stage.addEventListener(KeyboardEvent.KEY_DOWN,this.OnPoseManagerKeyDown,true,10003,true);
            this.stage.addEventListener(Event.MOUSE_LEAVE,this.OnPoseManagerPointerLost,true,10004,true);
            this.stage.addEventListener(Event.DEACTIVATE,this.OnPoseManagerPointerLost,true,10004,true);
            this.mStageMiddleBound = true;
         }
      }
      
      private function RemoveStageWheelListener() : void
      {
         if(this.stage == null || !this.mStageWheelBound)
         {
            this.mStageWheelBound = false;
            return;
         }
         try
         {
            this.stage.removeEventListener(MouseEvent.MOUSE_WHEEL,this.OnMouseWheel,true);
         }
         catch(e:Error)
         {
         }
         this.mStageWheelBound = false;
         if(this.stage != null && this.mStageMiddleBound)
         {
            try
            {
               this.stage.removeEventListener("middleMouseDown",this.OnStageMiddleMouse,true);
               this.stage.removeEventListener("middleMouseUp",this.OnStageMiddleMouse,true);
               this.stage.removeEventListener("middleClick",this.OnStageMiddleMouse,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_DOWN,this.OnStageMouseDownProbe,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_MOVE,this.OnStageScrollDragMove,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_UP,this.OnStageScrollDragUp,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_UP,this.OnStageLinkedRightMouseUp,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_DOWN,this.OnLinkedMarqueeMouseDown,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_MOVE,this.OnLinkedMarqueeMouseMove,true);
               this.stage.removeEventListener(MouseEvent.MOUSE_UP,this.OnLinkedMarqueeMouseUp,true);
               this.stage.removeEventListener(KeyboardEvent.KEY_DOWN,this.OnPoseManagerKeyDown,true);
               this.stage.removeEventListener(Event.MOUSE_LEAVE,this.OnPoseManagerPointerLost,true);
               this.stage.removeEventListener(Event.DEACTIVATE,this.OnPoseManagerPointerLost,true);
            }
            catch(eMiddle:Error)
            {
            }
         }
         this.mStageMiddleBound = false;
      }
      
      private function NativeIndexUnderStageMouse() : int
      {
         if(this.stage == null || this.mcContent == null || this.mNativeCells == null)
         {
            return -1;
         }
         var total:int = this.GetTotalItems();
         var localX:Number = this.mcContent.mouseX;
         var localY:Number = this.mcContent.mouseY;
         var i:int = 0;
         while(i < this.mNativeCells.length)
         {
            var cell:MovieClip = this.mNativeCells[i] as MovieClip;
            if(cell != null && cell.visible && cell.mouseEnabled)
            {
               var slotBounds:Rectangle = this.NativeCardHitBounds(i);
               if(slotBounds.contains(localX,localY))
               {
                  var index:int = this.NativeSourceIndex(cell);
                  if(index >= 0 && index < total)
                  {
                     return index;
                  }
                  return -1;
               }
            }
            i++;
         }
         return -1;
      }
      
      private function LinkedEditableProductUnderStageMouse() : Object
      {
         if(this.stage == null || !this.mLinkedManageMode)
         {
            return null;
         }
         var sx:Number = Number(this.stage.mouseX);
         var sy:Number = Number(this.stage.mouseY);
         if(this.mLinkedCASPreviewPanel != null && this.mLinkedCASPreviewPanel.visible && this.mLinkedCASPreviewPanel.parent != null && this.mLinkedCASPreviewProductIndex >= 0 && this.mLinkedCASPreviewPanel.hitTestPoint(sx,sy,true))
         {
            return {
               "kind":"cas",
               "index":this.mLinkedCASPreviewProductIndex
            };
         }
         var i:int = 0;
         if(this.mLinkedCASProductCards != null)
         {
            while(i < this.mLinkedCASProductCards.length)
            {
               var casCard:MovieClip = this.mLinkedCASProductCards[i] as MovieClip;
               if(casCard != null && casCard.visible && casCard.parent != null && casCard.hitTestPoint(sx,sy,true))
               {
                  return {
                     "kind":"cas",
                     "index":int(Object(casCard).fgehProductIndex)
                  };
               }
               i++;
            }
         }
         i = 0;
         if(this.mLinkedObjectProductCards != null)
         {
            while(i < this.mLinkedObjectProductCards.length)
            {
               var objectCard:MovieClip = this.mLinkedObjectProductCards[i] as MovieClip;
               if(objectCard != null && objectCard.visible && objectCard.parent != null && objectCard.hitTestPoint(sx,sy,true))
               {
                  return {
                     "kind":"object",
                     "index":int(Object(objectCard).fgehObjectProductIndex)
                  };
               }
               i++;
            }
         }
         return null;
      }
      
      private function OnStageMiddleMouse(param1:Event) : void
      {
         if(param1 == null || this.mData == null || this.IsAnyManagerModalOpen())
         {
            return;
         }
         if(this.mLinkedManageMode)
         {
            var linkedEdit:Object = this.LinkedEditableProductUnderStageMouse();
            if(linkedEdit != null)
            {
               param1.stopImmediatePropagation();
               var linkedIndex:int = int(linkedEdit.index);
               if(String(linkedEdit.kind) == "cas")
               {
                  var casKey:String = this.LinkedCASEditKey(linkedIndex);
                  var casCurrentName:String = this.LinkedEditCustomName(casKey);
                  if(casCurrentName.length == 0)
                  {
                     casCurrentName = this.GetLinkedCASProductDisplayLabel(linkedIndex);
                  }
                  this.OpenLinkedEditInfo(casKey,casCurrentName,this.LinkedEditNote(casKey));
               }
               else
               {
                  var objectKey:String = this.LinkedObjectEditKey(linkedIndex);
                  var objectCurrentName:String = this.LinkedEditCustomName(objectKey);
                  if(objectCurrentName.length == 0)
                  {
                     objectCurrentName = this.GetLinkedObjectProductDisplayLabel(linkedIndex);
                  }
                  this.OpenLinkedEditInfo(objectKey,objectCurrentName,this.LinkedEditNote(objectKey));
               }
            }
            return;
         }
         var index:int = this.NativeIndexUnderStageMouse();
         if(index < 0)
         {
            return;
         }
         param1.stopImmediatePropagation();
         this.OpenEditInfoOnce(index);
      }
      
      private function OnLinkedObjectProductRightRelease(param1:Event) : void
      {
         if(param1 == null || param1.currentTarget == null || this.mLinkedRightPressStartedAt <= 0 || this.mcContent == null)
         {
            return;
         }
         var card:MovieClip = param1.currentTarget as MovieClip;
         if(card == null)
         {
            return;
         }
         var productIndex:int = int(Object(card).fgehObjectProductIndex);
         if(productIndex != this.mLinkedRightPressProductIndex)
         {
            return;
         }
         var elapsed:int = getTimer() - this.mLinkedRightPressStartedAt;
         var dx:Number = this.mcContent.mouseX - this.mLinkedRightPressStartX;
         var dy:Number = this.mcContent.mouseY - this.mLinkedRightPressStartY;
         var moved:Number = Math.sqrt(dx * dx + dy * dy);
         this.mLinkedRightPressProductIndex = -1;
         this.mLinkedRightPressStartedAt = 0;
         if(elapsed >= 520 && moved <= 10)
         {
            param1.stopImmediatePropagation();
            this.OpenLinkedObjectRemoveMenu(productIndex);
         }
      }
      
      private function OnStageLinkedRightMouseUp(param1:MouseEvent) : void
      {
         var idx:int;
         var productIndex:int;
         var elapsed:int;
         var dx:Number;
         var dy:Number;
         var moved:Number;
         var current:Object;
         if(param1 == null || this.mLinkedRightPressStartedAt <= 0)
         {
            return;
         }
         idx = -1;
         try
         {
            if(Object(param1).hasOwnProperty("buttonIdx"))
            {
               idx = int(Object(param1).buttonIdx);
            }
            else if(Object(param1).hasOwnProperty("buttonIndex"))
            {
               idx = int(Object(param1).buttonIndex);
            }
         }
         catch(e:Error)
         {
            idx = -1;
         }
         if(idx < 0)
         {
            return;
         }
         if(idx != 1 || !this.mLinkedManageMode || this.mcContent == null)
         {
            this.mLinkedRightPressProductIndex = -1;
            this.mLinkedRightPressStartedAt = 0;
            return;
         }
         productIndex = this.mLinkedRightPressProductIndex;
         elapsed = getTimer() - this.mLinkedRightPressStartedAt;
         dx = this.mcContent.mouseX - this.mLinkedRightPressStartX;
         dy = this.mcContent.mouseY - this.mLinkedRightPressStartY;
         moved = Math.sqrt(dx * dx + dy * dy);
         this.mLinkedRightPressProductIndex = -1;
         this.mLinkedRightPressStartedAt = 0;
         if(productIndex < 0 || elapsed < 520 || moved > 10)
         {
            return;
         }
         current = this.LinkedEditableProductUnderStageMouse();
         current == null;
         if(int(current.index) != productIndex)
         {
            return;
         }
         param1.stopImmediatePropagation();
         this.OpenLinkedObjectRemoveMenu(productIndex);
      }
      
      private function OnStageMouseDownProbe(param1:MouseEvent) : void
      {
         var idx:int;
         var linkedRight:Object;
         var linkedEdit:Object;
         var linkedIndex:int;
         var casKey:String;
         var casName:String;
         var objectKey:String;
         var objectName:String;
         var cardIndex:int;
         if(this.mData != null)
         {
            if(param1 != null)
            {
               if(this.GetLinkedPoseName(this.mLinkedActiveIndex) == "root_outfits")
               {
                  var _loc4_:* = this.Child("fgehAccessoryLibraryLayer");
                  if(_loc4_ != null)
                  {
                     _loc4_ = _loc4_.getChildByName("fgehOutfitBackButton");
                     if(_loc4_ != null)
                     {
                        if(_loc4_.visible)
                        {
                           if(_loc4_.hitTestPoint(this.stage.mouseX,this.stage.mouseY,true))
                           {
                              param1.stopImmediatePropagation();
                              this.PostResponse(RESPONSE_BACK);
                              return;
                           }
                        }
                     }
                  }
               }
               else if(this.GetV7ActiveNav() == 6)
               {
                  if(this.GetLinkedPackId() == "__FGEH_CAS_LIBRARY__")
                  {
                     _loc4_ = this.Child("fgehAccessoryLibraryLayer");
                     if(_loc4_ != null)
                     {
                        _loc4_ = _loc4_.getChildByName("fgehLibraryButton");
                        if(_loc4_ != null)
                        {
                           if(_loc4_.visible)
                           {
                              if(_loc4_.hitTestPoint(this.stage.mouseX,this.stage.mouseY,true))
                              {
                                 param1.stopImmediatePropagation();
                                 CommunicationManager.PostServerCommand("fgeh.caslib_source","back",this.mData.dialog_id);
                                 return;
                              }
                           }
                        }
                     }
                     _loc4_ = this.Child("fgehAccessoryLibraryLayer");
                     if(_loc4_ != null)
                     {
                        _loc4_ = _loc4_.getChildByName("fgehR74SourceLocal");
                        if(_loc4_ != null)
                        {
                           if(_loc4_.visible)
                           {
                              if(_loc4_.hitTestPoint(this.stage.mouseX,this.stage.mouseY,true))
                              {
                                 param1.stopImmediatePropagation();
                                 CommunicationManager.PostServerCommand("fgeh.caslib_source","local",this.mData.dialog_id);
                                 return;
                              }
                           }
                        }
                     }
                     _loc4_ = this.Child("fgehAccessoryLibraryLayer");
                     if(_loc4_ != null)
                     {
                        _loc4_ = _loc4_.getChildByName("fgehR74SourceExternal");
                        if(_loc4_ != null)
                        {
                           if(_loc4_.visible)
                           {
                              if(_loc4_.hitTestPoint(this.stage.mouseX,this.stage.mouseY,true))
                              {
                                 param1.stopImmediatePropagation();
                                 CommunicationManager.PostServerCommand("fgeh.caslib_source","external",this.mData.dialog_id);
                                 return;
                              }
                           }
                        }
                     }
                     _loc4_ = this.mLinkedCASPreviewPanel;
                     if(_loc4_ != null)
                     {
                        _loc4_ = _loc4_.getChildByName("fgehLinkedRestoreOutfit");
                        if(_loc4_ != null)
                        {
                           if(_loc4_.visible)
                           {
                              if(_loc4_.hitTestPoint(this.stage.mouseX,this.stage.mouseY,true))
                              {
                                 param1.stopImmediatePropagation();
                                 CommunicationManager.PostServerCommand("fgeh.caslib_source","restore",this.mData.dialog_id);
                                 return;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
         if(param1 == null || this.mData == null || this.IsAnyManagerModalOpen())
         {
            return;
         }
         idx = -1;
         try
         {
            if(Object(param1).hasOwnProperty("buttonIdx"))
            {
               idx = int(Object(param1).buttonIdx);
            }
            else if(Object(param1).hasOwnProperty("buttonIndex"))
            {
               idx = int(Object(param1).buttonIndex);
            }
         }
         catch(e:Error)
         {
            idx = -1;
         }
         if(this.mLinkedManageMode)
         {
            if(idx == 1)
            {
               linkedRight = this.LinkedEditableProductUnderStageMouse();
               if(linkedRight != null)
               {
                  this.mLinkedRightPressProductIndex = int(linkedRight.index);
                  this.mLinkedRightPressStartedAt = getTimer();
                  if(this.mcContent != null)
                  {
                     this.mLinkedRightPressStartX = this.mcContent.mouseX;
                     this.mLinkedRightPressStartY = this.mcContent.mouseY;
                  }
               }
               return;
            }
            if(idx == 2)
            {
               linkedEdit = this.LinkedEditableProductUnderStageMouse();
               if(linkedEdit != null)
               {
                  param1.stopImmediatePropagation();
                  linkedIndex = int(linkedEdit.index);
                  if(String(linkedEdit.kind) == "cas")
                  {
                     casKey = this.LinkedCASEditKey(linkedIndex);
                     casName = this.LinkedEditCustomName(casKey);
                     if(casName.length == 0)
                     {
                        casName = this.GetLinkedCASProductDisplayLabel(linkedIndex);
                     }
                     this.OpenLinkedEditInfo(casKey,casName,this.LinkedEditNote(casKey));
                  }
                  else
                  {
                     objectKey = this.LinkedObjectEditKey(linkedIndex);
                     objectName = this.LinkedEditCustomName(objectKey);
                     if(objectName.length == 0)
                     {
                        objectName = this.GetLinkedObjectProductDisplayLabel(linkedIndex);
                     }
                     this.OpenLinkedEditInfo(objectKey,objectName,this.LinkedEditNote(objectKey));
                  }
               }
            }
            return;
         }
         cardIndex = this.NativeIndexUnderStageMouse();
         if(idx == 1 && cardIndex >= 0 && !this.mBatchSelectMode && !this.IsAnyMemberEditMode() && this.FavoriteScopeForIndex(cardIndex) == "pack")
         {
            this.mRightPressIndex = cardIndex;
            this.mRightPressStartedAt = getTimer();
            if(this.mcContent != null)
            {
               this.mRightPressStartX = this.mcContent.mouseX;
               this.mRightPressStartY = this.mcContent.mouseY;
            }
            return;
         }
         if(idx != 2 || cardIndex < 0)
         {
            return;
         }
         param1.stopImmediatePropagation();
         this.OpenEditInfoOnce(cardIndex);
      }
      
      private function IsPackRightLongPress(param1:int) : Boolean
      {
         if(param1 < 0 || this.mRightPressIndex != param1 || this.mRightPressStartedAt <= 0 || this.mcContent == null)
         {
            this.mRightPressIndex = -1;
            this.mRightPressStartedAt = 0;
            return false;
         }
         var elapsed:int = getTimer() - this.mRightPressStartedAt;
         var dx:Number = this.mcContent.mouseX - this.mRightPressStartX;
         var dy:Number = this.mcContent.mouseY - this.mRightPressStartY;
         var moved:Number = Math.sqrt(dx * dx + dy * dy);
         this.mRightPressIndex = -1;
         this.mRightPressStartedAt = 0;
         return elapsed >= 520 && moved <= 10;
      }
      
      private function OpenSinglePackOrganizerFromCell(param1:int, param2:DisplayObject) : void
      {
         if(param1 < 0 || param2 == null || this.mcContent == null)
         {
            return;
         }
         var bounds:Rectangle = param2.getBounds(this.mcContent);
         this.mSuppressRightFavoriteUntil = getTimer() + 450;
         this.OpenPackOrganizeChooser(bounds.right - 34,bounds.y + 18,param1);
      }
      
      private function BuildScrollGrabOverlay() : void
      {
         var thumb:DisplayObject;
         if(this.mcContent == null || this.mScrollGrabOverlay != null)
         {
            return;
         }
         thumb = this.Child("fgehScrollThumb");
         if(thumb == null || thumb.parent == null)
         {
            return;
         }
         this.mScrollGrabOverlay = new Sprite();
         this.mScrollGrabOverlay.name = "fgehScrollGrabOverlay";
         this.mScrollGrabOverlay.mouseEnabled = true;
         this.mScrollGrabOverlay.mouseChildren = false;
         this.mScrollGrabOverlay.buttonMode = true;
         this.mScrollGrabOverlay.useHandCursor = true;
         this.mScrollGrabOverlay.alpha = 1;
         this.mScrollGrabOverlay.addEventListener(MouseEvent.MOUSE_DOWN,this.OnThumbDown,false,10050,true);
         this.mScrollGrabOverlay.addEventListener(MouseEvent.MOUSE_UP,this.OnThumbUp,false,10050,true);
         try
         {
            Object(thumb.parent).addChild(this.mScrollGrabOverlay);
         }
         catch(eAdd:Error)
         {
            this.mScrollGrabOverlay = null;
            return;
         }
         this.SyncScrollGrabOverlay();
      }
      
      private function SyncScrollGrabOverlay() : void
      {
         var thumb:DisplayObject;
         var extraX:Number;
         var extraY:Number;
         var w:Number;
         var h:Number;
         if(this.mScrollGrabOverlay == null)
         {
            this.BuildScrollGrabOverlay();
            if(this.mScrollGrabOverlay == null)
            {
               return;
            }
         }
         thumb = this.Child("fgehScrollThumb");
         if(thumb == null || thumb.parent == null)
         {
            this.mScrollGrabOverlay.visible = false;
            return;
         }
         try
         {
            if(this.mScrollGrabOverlay.parent !== thumb.parent)
            {
               if(this.mScrollGrabOverlay.parent != null)
               {
                  this.mScrollGrabOverlay.parent.removeChild(this.mScrollGrabOverlay);
               }
               Object(thumb.parent).addChild(this.mScrollGrabOverlay);
            }
            extraX = 7;
            extraY = 6;
            w = Math.max(24,thumb.width + extraX * 2);
            h = Math.max(34,thumb.height + extraY * 2);
            this.mScrollGrabOverlay.graphics.clear();
            this.mScrollGrabOverlay.graphics.beginFill(3332326,0.008);
            this.mScrollGrabOverlay.graphics.drawRoundRect(0,0,w,h,10,10);
            this.mScrollGrabOverlay.graphics.endFill();
            this.mScrollGrabOverlay.x = thumb.x - extraX;
            this.mScrollGrabOverlay.y = thumb.y - extraY;
            this.mScrollGrabOverlay.visible = thumb.visible;
            Object(thumb.parent).setChildIndex(this.mScrollGrabOverlay,Object(thumb.parent).numChildren - 1);
         }
         catch(e:Error)
         {
         }
      }
      
      private function IsPointerInsideScrollChrome() : Boolean
      {
         var names:Array;
         var i:int;
         var obj:DisplayObject;
         var bounds:Rectangle;
         if(this.mcContent == null)
         {
            return false;
         }
         names = ["fgehScrollGrabOverlay","fgehScrollThumbHit","fgehScrollThumb","fgehScrollTrackHit","fgehScrollTrack"];
         i = 0;
         while(i < names.length)
         {
            obj = this.Child(String(names[i]));
            if(obj != null && obj.visible)
            {
               try
               {
                  bounds = obj.getBounds(this.mcContent);
                  bounds.inflate(5,5);
                  if(bounds.contains(this.mcContent.mouseX,this.mcContent.mouseY))
                  {
                     return true;
                  }
               }
               catch(eBounds:Error)
               {
               }
            }
            i++;
         }
         return false;
      }
      
      private function ClampPage(param1:int) : int
      {
         var count:int = this.GetPageCount();
         if(count <= 1)
         {
            return 0;
         }
         if(param1 < 0)
         {
            return 0;
         }
         if(param1 >= count)
         {
            return count - 1;
         }
         return param1;
      }
      
      private function NavigatePickerPage(param1:int) : void
      {
         var _loc9_:int = getTimer();
         var page:int = this.ClampPage(param1);
         if(this.mLinkedManageMode)
         {
            this.mLinkedLocalPage = page;
            this.ClearLinkedMarqueeVisual();
            this.Draw(this.mData);
            this.ApplyLinkedManageLayout();
            this.RefreshSelectionOverlays();
            this.RefreshLinkedDrawer();
            this.SyncCardInteractionState();
            CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_NAVIGATE" + ":" + (getTimer() - _loc9_),this.mData.dialog_id);
            return;
         }
         if(this.mBatchSelectMode)
         {
            this.mBatchLocalPage = page;
            this.ClearLinkedMarqueeVisual();
            this.Draw(this.mData);
            this.RefreshSelectionOverlays();
            this.RefreshFixedTools();
            this.RefreshRootTools();
            this.SyncCardInteractionState();
            CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_NAVIGATE" + ":" + (getTimer() - _loc9_),this.mData.dialog_id);
            return;
         }
         if(this.IsOuterGroupRemoveManageMode())
         {
            this.mOuterManageLocalPage = page;
            this.ClearLinkedMarqueeVisual();
            this.Draw(this.mData);
            this.RefreshSelectionOverlays();
            this.RefreshOuterGroupTools();
            this.SyncCardInteractionState();
            CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_NAVIGATE" + ":" + (getTimer() - _loc9_),this.mData.dialog_id);
            return;
         }
         if(!this.IsRootLiveSearchActive())
         {
            if(this.GetV7ViewKind().indexOf("root") == 0)
            {
               if(this.GetV7ActiveNav() <= 5)
               {
                  if(this.GetV7ViewKind() === "root")
                  {
                     if(this.GetV7ActiveNav() <= 4)
                     {
                        §§goto(addr0198);
                     }
                  }
                  §§goto(addr0156);
               }
            }
            addr0198:
            if(this.HasV7Extension())
            {
               if(this.GetV7ViewKind() === "root")
               {
                  if(this.GetV7ActiveNav() <= 4)
                  {
                     this.mRootSearchLocalPage = page;
                     var _loc3_:int = this.GetTotalItems();
                     var _loc4_:* = 0;
                     do
                     {
                        var _loc5_:Number = page * 12 + _loc4_;
                        if(_loc5_ < _loc3_)
                        {
                           this.SetCardVisible(_loc4_ + 1,true);
                           var _loc6_:Number = _loc5_ * 6 + 13;
                           this.SetHtml("fgehPackName" + (_loc4_ + 1),String(this.mData.additional_texts[_loc6_]));
                           this.SetHtml("fgehPackCreator" + (_loc4_ + 1),String(this.mData.additional_texts[_loc6_ + 1]));
                           this.SetHtml("fgehPackCount" + (_loc4_ + 1),String(this.mData.additional_texts[_loc6_ + 2]));
                           var _loc7_:int = int(String(this.mData.additional_texts[_loc6_ + 4]));
                           this.SetPackLlamaFallback(_loc4_ + 1,_loc7_ < 0);
                           if(_loc7_ >= 0)
                           {
                              if(this.mData.icon_infos != null)
                              {
                                 if(_loc5_ < this.mData.icon_infos.length)
                                 {
                                    var _loc8_:DisplayObject = this.Child("fgehPackIcon" + (_loc4_ + 1));
                                    if(_loc8_ != null)
                                    {
                                       ImageUtils.LoadFromIconInfo(_loc8_,this.mData.icon_infos[_loc5_]);
                                    }
                                 }
                              }
                           }
                        }
                        else
                        {
                           this.SetCardVisible(_loc4_ + 1,false);
                        }
                        _loc4_++;
                     }
                     while(_loc4_ < 12);
                     this.UpdateScrollThumb(page,this.GetPageCount());
                     this.RefreshNativeCells();
                     this.RefreshFavoriteMarkers();
                     this.ScheduleRootSearchStateSync();
                     CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_NAVIGATE" + ":" + (getTimer() - _loc9_),this.mData.dialog_id);
                     return;
                  }
               }
            }
            this.PostResponse(RESPONSE_PAGE_BASE + page);
            CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_NAVIGATE" + ":" + (getTimer() - _loc9_),this.mData.dialog_id);
            return;
         }
         addr0156:
         this.mRootSearchLocalPage = page;
         this.Draw(this.mData);
         this.RefreshNativeCells();
         this.RefreshSelectionOverlays();
         this.ScheduleRootSearchStateSync();
         CommunicationManager.PostServerCommand("fgeh.perf_phase","UI_NAVIGATE" + ":" + (getTimer() - _loc9_),this.mData.dialog_id);
      }
      
      private function ScrollDragPageFromY(param1:Number) : int
      {
         var pageCount:int = this.GetPageCount();
         if(pageCount <= 1)
         {
            return 0;
         }
         return this.ClampPage(int(Math.round((param1 + 195) * (pageCount - 1) / 380)));
      }
      
      private function OnStageScrollDragMove(param1:MouseEvent) : void
      {
         var visibleThumb:DisplayObject;
         if(!this.mScrollDragActive || this.mScrollDragTarget == null)
         {
            return;
         }
         try
         {
            visibleThumb = this.Child("fgehScrollThumb");
            if(visibleThumb != null)
            {
               visibleThumb.y = this.mScrollDragTarget.y;
               this.SyncScrollGrabOverlay();
            }
         }
         catch(e:Error)
         {
         }
      }
      
      private function FinishScrollDrag(param1:MouseEvent = null) : void
      {
         var target:DisplayObject;
         var page:int;
         if(!this.mScrollDragActive)
         {
            return;
         }
         target = this.mScrollDragTarget;
         this.mScrollDragActive = false;
         this.mScrollDragTarget = null;
         if(target == null)
         {
            return;
         }
         try
         {
            Object(target).stopDrag();
         }
         catch(eStop:Error)
         {
         }
         page = this.ScrollDragPageFromY(target.y);
         this.NavigatePickerPage(page);
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
      }
      
      private function OnStageScrollDragUp(param1:MouseEvent) : void
      {
         this.FinishScrollDrag(param1);
      }
      
      private function OnMouseWheel(param1:MouseEvent) : void
      {
         var dialogBounds:Rectangle;
         var page:int;
         var pageCount:int;
         if(param1)
         {
            if(this.GetV7ActiveNav() == 6)
            {
               if(this.GetLinkedPackId() == "__FGEH_CAS_LIBRARY__")
               {
                  param1.stopImmediatePropagation();
                  if(param1.delta < 0)
                  {
                     this.OnLinkedResourceNext(param1);
                     return;
                  }
                  this.OnLinkedResourcePrev(param1);
                  return;
               }
            }
         }
         if(this.mLinkedMarqueeDown || this.mLinkedMarqueeDragging)
         {
            this.AbortMarqueeInteraction();
         }
         if(param1 == null || this.mData == null)
         {
            return;
         }
         if(this.stage != null && this.mcContent != null)
         {
            try
            {
               dialogBounds = this.mcContent.getBounds(this.stage);
               if(!dialogBounds.contains(this.stage.mouseX,this.stage.mouseY))
               {
                  return;
               }
            }
            catch(eBounds:Error)
            {
            }
         }
         if(this.mData.additional_texts == null || this.mData.additional_texts.length <= 8 || String(this.mData.additional_texts[8]) != "scroll")
         {
            return;
         }
         page = this.GetCurrentPage();
         pageCount = this.GetPageCount();
         if(param1.delta < 0)
         {
            page++;
         }
         else
         {
            page--;
         }
         if(page < 0)
         {
            page = 0;
         }
         if(page >= pageCount)
         {
            page = pageCount - 1;
         }
         param1.stopImmediatePropagation();
         if(page == this.GetCurrentPage())
         {
            return;
         }
         this.NavigatePickerPage(page);
      }
      
      private function OnThumbDown(param1:MouseEvent) : void
      {
         var dragTarget:DisplayObject;
         var visibleThumb:DisplayObject;
         if(param1 == null)
         {
            return;
         }
         this.AbortMarqueeInteraction();
         dragTarget = this.Child("fgehScrollThumbHit");
         visibleThumb = this.Child("fgehScrollThumb");
         if(dragTarget == null)
         {
            dragTarget = param1.currentTarget as DisplayObject;
         }
         if(dragTarget == null)
         {
            return;
         }
         try
         {
            if(visibleThumb != null)
            {
               dragTarget.y = visibleThumb.y;
            }
         }
         catch(eSync:Error)
         {
         }
         this.mScrollDragActive = true;
         this.mScrollDragTarget = dragTarget;
         try
         {
            Object(dragTarget).startDrag(false,new Rectangle(481 + (this.mLinkedManageMode ? LINKED_SCROLL_SHIFT : 0),-195,0,380));
            param1.stopImmediatePropagation();
         }
         catch(e:Error)
         {
            this.mScrollDragActive = false;
            this.mScrollDragTarget = null;
         }
      }
      
      private function OnThumbUp(param1:MouseEvent) : void
      {
         this.FinishScrollDrag(param1);
      }
      
      private function OnChromeClick(param1:Event) : void
      {
         if(param1 != null)
         {
            if(param1.currentTarget.name == "fgehRemoveLinkedActionR74")
            {
               param1.stopImmediatePropagation();
               this.PostResponse(-10896 + this.mLinkedActiveIndex);
               return;
            }
         }
         if(param1 != null)
         {
            if(param1.currentTarget.name == "fgehOutfitBackButton")
            {
               param1.stopImmediatePropagation();
               this.PostResponse(RESPONSE_BACK);
               return;
            }
         }
         if(param1 == null || param1.currentTarget == null)
         {
            return;
         }
         var name:String = String(param1.currentTarget.name);
         if(name == "fgehLinkedAddFromLibrary")
         {
            this.PostResponse(732000 + 100 + this.mLinkedActiveIndex);
            return;
         }
         if(name == "fgehCloseButton" || name == "btnOk")
         {
            if(this.mEditInfoLayer != null && this.mEditInfoLayer.visible)
            {
               this.OnEditInfoCancel(null);
               return;
            }
            if(this.mOuterGroupManagerLayer != null && this.mOuterGroupManagerLayer.visible)
            {
               this.mOuterGroupManagerLayer.visible = false;
               this.SetCardInteractionBlocked(false);
               return;
            }
            if(this.mGroupManagerLayer != null && this.mGroupManagerLayer.visible)
            {
               this.mGroupManagerLayer.visible = false;
               this.SetCardInteractionBlocked(false);
               return;
            }
            this.CloseDialog();
            return;
         }
         if(name == "fgehLibraryButton")
         {
            this.PostResponse(RESPONSE_BACK);
            return;
         }
         if(name == "fgehScrollTrackHit")
         {
            var count:int = this.GetPageCount();
            var targetPage:int = 0;
            if(count > 1)
            {
               targetPage = int(Math.round((this.mcContent.mouseY + 195) * (count - 1) / 380));
            }
            if(targetPage < 0)
            {
               targetPage = 0;
            }
            if(targetPage >= count)
            {
               targetPage = count - 1;
            }
            this.AbortMarqueeInteraction();
            this.NavigatePickerPage(targetPage);
         }
      }
      
      private function PostResponse(param1:int) : void
      {
         if(this.mData == null)
         {
            return;
         }
         this.SyncRootSearchState();
         CommunicationManager.PostServerCommand("ui.dialog.respond",this.mData.dialog_id,param1);
      }
      
      private function CloseDialog() : void
      {
         this.SyncRootSearchState();
         CommunicationManager.SendUIMessage("Hide" + WidgetName);
         dispatchEvent(new Event(Event.CLOSE));
      }
      
      protected function HandleBackCall() : void
      {
         if(this.mBatchSelectMode)
         {
            this.SetBatchSelectMode(false);
            return;
         }
         if(this.mLinkedManageMode)
         {
            this.ExitLinkedManage();
            return;
         }
         if(this.mEditInfoLayer != null && this.mEditInfoLayer.visible)
         {
            this.OnEditInfoCancel(null);
            return;
         }
         this.CloseDialog();
      }
      
      protected function InitGamepad() : void
      {
         this.mMainInputAdapter = new DynamicOmnidirectionalAdapter(this);
         this.mMainInputAdapter.OnBackCall(this.HandleBackCall);
      }
      
      override public function Enter(param1:EnterParams = null) : IInputFocusable
      {
         return this.mMainInputAdapter.Enter(param1);
      }
      
      override public function Exit() : void
      {
         this.mMainInputAdapter.Exit();
      }
      
      internal function frame22() : *
      {
         stop();
      }
      
      private function FgehCasSendChunksV3(param1:*, param2:*, param3:*, param4:*) : void
      {
         var _loc9_:int = getTimer();
         if(param4 == null)
         {
            param4 = "";
         }
         var _loc5_:int = (param4.length + 119) / 120;
         if(_loc5_ == 0)
         {
            _loc5_ = 1;
         }
         var _loc6_:int = 0;
         while(_loc6_ < _loc5_)
         {
            var _loc7_:* = param4.substr(_loc6_ * 120,120);
            var _loc8_:String = encodeURIComponent(_loc7_);
            CommunicationManager.PostServerCommand("fgeh.cas.collection.chunk",param1,param2,String(param3),String(_loc6_),String(_loc5_),_loc8_);
            _loc6_ += 1;
         }
      }
      
      private function FgehCasExportCollectionV3() : void
      {
         var _loc12_:int = getTimer();
         CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","EXPORT_CALL");
         var _temp_2:* = UISettings.AccountSettings;
         var _temp_1:* = "fgeh.cas.favorites.v3.manifest";
         var _loc14_:int = getTimer();
         var _loc1_:Object = _temp_2.GetValue(_temp_1);
         if(_loc1_ == null)
         {
            CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","MANIFEST_NULL");
         }
         else
         {
            var _loc2_:String = String(_loc1_);
            if(_loc2_.length == 0)
            {
               CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","MANIFEST_EMPTY");
            }
            else
            {
               var _loc3_:Array = _loc2_.split("^");
               if(_loc3_ == null)
               {
                  CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","BAD_MANIFEST");
               }
               else if(_loc3_.length < 2)
               {
                  CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","BAD_MANIFEST");
               }
               else if(String(_loc3_[0]) != "FGCAS_FAVORITES_V3")
               {
                  CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","BAD_MAGIC");
               }
               else
               {
                  var _loc4_:int = int(_loc3_[1]);
                  if(_loc4_ < 0)
                  {
                     CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","BAD_COUNT");
                  }
                  else if(_loc3_.length != _loc4_ + 2)
                  {
                     CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","BAD_COUNT");
                  }
                  else
                  {
                     CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","MANIFEST_OK",String(_loc4_));
                     var _temp_4:* = UISettings.AccountSettings;
                     var _temp_3:* = "fgeh.cas.favorites.groups.v1";
                     _loc14_ = getTimer();
                     var _loc5_:Object = _temp_4.GetValue(_temp_3);
                     var _loc6_:String = "";
                     if(_loc5_ != null)
                     {
                        _loc6_ = String(_loc5_);
                     }
                     var _loc7_:String = "p" + String(getTimer());
                     CommunicationManager.PostServerCommand("fgeh.cas.collection.begin",_loc7_,String(_loc4_));
                     this.FgehCasSendChunksV3(_loc7_,"m","0",_loc2_);
                     var _loc8_:int = 0;
                     while(true)
                     {
                        if(_loc8_ >= _loc4_)
                        {
                           this.FgehCasSendChunksV3(_loc7_,"g","0",_loc6_);
                           CommunicationManager.PostServerCommand("fgeh.cas.collection.commit",_loc7_);
                           CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","COMMIT_SENT",String(_loc4_));
                           break;
                        }
                        var _loc9_:String = String(_loc3_[_loc8_ + 2]);
                        var _temp_6:* = UISettings.AccountSettings;
                        var _temp_5:* = "fgeh.cas.favorites.v3.item." + _loc9_;
                        _loc14_ = getTimer();
                        var _loc10_:Object = _temp_6.GetValue(_temp_5);
                        if(_loc10_ == null)
                        {
                           CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","MISSING_ITEM",_loc9_);
                           CommunicationManager.PostServerCommand("fgeh.cas.collection.abort",_loc7_);
                           break;
                        }
                        var _loc11_:String = String(_loc10_);
                        if(_loc11_.length == 0)
                        {
                           CommunicationManager.PostServerCommand("fgeh.cas.collection.diag","EMPTY_ITEM",_loc9_);
                           CommunicationManager.PostServerCommand("fgeh.cas.collection.abort",_loc7_);
                           break;
                        }
                        this.FgehCasSendChunksV3(_loc7_,"i",_loc9_,_loc11_);
                        _loc8_ += 1;
                     }
                  }
               }
            }
         }
      }
   }
}

