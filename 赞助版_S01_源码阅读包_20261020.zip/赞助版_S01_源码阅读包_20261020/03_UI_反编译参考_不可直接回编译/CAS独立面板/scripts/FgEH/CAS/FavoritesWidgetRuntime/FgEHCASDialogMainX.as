package FgEH.CAS.FavoritesWidgetRuntime
{
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.InteractiveObject;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import flash.utils.getDefinitionByName;
   import gamedata.Dialog.UiDialogMessage;
   import olympus.core.UISettings;
   import olympus.core.widget.WidgetBase;
   import olympus.events.PushButtonEvent;
   import olympus.gamepad.EnterParams;
   import olympus.input.IInputFocusable;
   import olympus.input.adapters.DynamicOmnidirectionalAdapter;
   import olympus.io.CommunicationManager;
   import olympus.localization.KeysGP;
   import olympus.localization.LocKey;
   import olympus.utils.TextUtils;
   import widgets.Dialog.constants.DialogTunables;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol21")]
   public class FgEHCASDialogMainX extends WidgetBase implements IInputFocusable
   {
      
      public static var fgeh0zt6sStaticRequestSequence:int;
      
      public static var fgeh0zt6wFavoriteStore:*;
      
      public static var fgeh0zt6wFavoriteCount:int;
      
      public static var fgeh0zt6xFirstBase:*;
      
      public static var fgeh0zt6xSecondBase:*;
      
      private static var fgeh0zt6x3Order:*;
      
      private static var fgeh0zt6x3Page:int;
      
      public static var fgeh0zt6x15GroupMap:*;
      
      public static var fgeh0zt6x15GroupNames:*;
      
      public static var fgeh0zt6x15ViewOrder:*;
      
      public static var fgeh0zt6x15ActiveGroup:*;
      
      public static var fgeh0zt6x15EditBase:*;
      
      public static var fgeh0zt6x15HoldSlot:*;
      
      public static var fgeh0zt6x15HoldFrames:*;
      
      public static var fgeh0zt6x15HoldLong:*;
      
      public static var fgeh0zt6x15TabPage:*;
      
      public static var fgeh0zt6x15CreateMode:*;
      
      public static var fgeh0zt6x25FavoriteLocalDirty:*;
      
      public static var fgeh0zt6x28EditGroup:*;
      
      public static var fgeh0zt6x56DirtyBases:*;
      
      public var mcContent:MovieClip;
      
      public var mData:UiDialogMessage;
      
      protected var mMainInputAdapter:DynamicOmnidirectionalAdapter;
      
      private var fgeh0pPanel:Sprite = null;
      
      private var fgeh0pFrames:int = 0;
      
      private var fgeh0pShowWasCalled:Boolean = false;
      
      private var fgeh0pLabel:TextField = null;
      
      public var fgeh0zt6wCaption:TextField;
      
      private var fgeh0zt6xViewport:Sprite;
      
      private var fgeh0zt6xCard1:TextField;
      
      private var fgeh0zt6xCard2:TextField;
      
      private var fgeh0zt6x3Card0:TextField;
      
      private var fgeh0zt6x3Card1:TextField;
      
      private var fgeh0zt6x3Card2:TextField;
      
      private var fgeh0zt6x3Card3:TextField;
      
      private var fgeh0zt6x3Status:TextField;
      
      private var fgeh0zt6x3Count:TextField;
      
      private var fgeh0zt6x4ImageHost:*;
      
      private var fgeh0zt6x4Image:*;
      
      private var fgeh0zt6x4Bound:*;
      
      private var fgeh0zt6x5Host1:*;
      
      private var fgeh0zt6x5Image1:*;
      
      private var fgeh0zt6x5Bound1:*;
      
      private var fgeh0zt6x5Host2:*;
      
      private var fgeh0zt6x5Image2:*;
      
      private var fgeh0zt6x5Bound2:*;
      
      private var fgeh0zt6x5Host3:*;
      
      private var fgeh0zt6x5Image3:*;
      
      private var fgeh0zt6x5Bound3:*;
      
      public var fgeh0uiCollapsed:Boolean;
      
      public var fgeh0uiPhotoActive:Boolean;
      
      public var fgeh0uiHotkeyHeld:Boolean;
      
      public var fgeh0uiSaved:Array;
      
      public var fgeh0uiStage:*;
      
      public function FgEHCASDialogMainX()
      {
         addFrameScript(21,this.frame22);
         super();
      }
      
      override public function Initialize() : void
      {
         super.Initialize();
         fgeh0pBuild();
         this.visible = true;
         if(this.mcContent != null)
         {
            this.mcContent.visible = false;
         }
      }
      
      override public function Show(param1:Object = null) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      override public function Hide(param1:Object = null) : void
      {
         this.removeEventListener(Event.ENTER_FRAME,this.fgeh0pOnFrame);
         if(this.fgeh0pPanel != null)
         {
            this.fgeh0pPanel.visible = false;
         }
         super.Hide(param1);
      }
      
      private function fgeh0pBuild() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      private function fgeh0pUpdateLabel() : void
      {
         if(this.fgeh0pLabel == null)
         {
            return;
         }
         this.fgeh0pLabel.text = "FgEH 0P: INIT reached\n" + "Show called: " + String(this.fgeh0pShowWasCalled) + "  frame=" + String(this.fgeh0pFrames);
      }
      
      private function fgeh0pOnFrame(e:Event) : void
      {
         e = this.stage;
         if(e != null)
         {
            this.fgeh0uiStage = e;
            e.addEventListener("keyDown",this.fgeh0uiKeyDown,true,1000);
            e.addEventListener("keyDown",this.fgeh0uiKeyDown,false,1000);
            e.addEventListener("keyUp",this.fgeh0uiKeyUp,true,1000);
            e.addEventListener("keyUp",this.fgeh0uiKeyUp,false,1000);
            e.addEventListener("deactivate",this.fgeh0uiDeactivate);
            this.addEventListener("removedFromStage",this.fgeh0uiRemoved);
         }
         ++this.fgeh0pFrames;
         this.visible = !this.fgeh0uiCollapsed;
         this.alpha = Number(!this.fgeh0uiCollapsed);
         if(this.mcContent != null)
         {
            this.mcContent.visible = false;
         }
         if(this.fgeh0pPanel != null)
         {
            this.fgeh0pPanel.visible = true;
         }
         if(this.fgeh0pFrames == 1 || this.fgeh0pFrames == 30 || this.fgeh0pFrames == 90)
         {
            fgeh0pUpdateLabel();
         }
         if(this.fgeh0pFrames >= 90)
         {
            this.removeEventListener(Event.ENTER_FRAME,this.fgeh0pOnFrame);
         }
      }
      
      protected function Draw(param1:UiDialogMessage) : void
      {
         this.mcContent.mcIcon.LoadImage(param1.icon_info.icon.instance);
         TextUtils.ShrinkTextToTargetHeight(this.mcContent.txtTitle,param1.title.toString(),DialogTunables.GENERIC_DIALOG_MAX_TITLE_HEIGHT,10,DialogTunables.GENERIC_DIALOG_MIN_TITLE_FONT_SIZE);
         this.mcContent.txtDescription.htmlText = param1.text.toString();
         if(param1.additional_texts != null && param1.additional_texts.length > 0)
         {
            this.mcContent.btnOk.htmlText = param1.additional_texts[0].toString();
         }
         else
         {
            this.mcContent.btnOk.htmlText = KeysGP.EPIC_CARD_DIALOG_OK.toString();
         }
      }
      
      private function OnOkButtonClick(param1:PushButtonEvent) : void
      {
         CommunicationManager.SendUIMessage("Hide" + WidgetName);
         dispatchEvent(new Event(Event.CLOSE));
      }
      
      protected function HandleBackCall() : void
      {
         this.OnOkButtonClick(null);
      }
      
      protected function InitGamepad() : void
      {
         this.mMainInputAdapter = new DynamicOmnidirectionalAdapter(this);
         this.mMainInputAdapter.OnBackCall(this.HandleBackCall);
      }
      
      override public function Enter(param1:EnterParams = null) : IInputFocusable
      {
         if(this.mMainInputAdapter == null)
         {
            return this;
         }
         return this.mMainInputAdapter.Enter(param1);
      }
      
      override public function Exit() : void
      {
         if(this.mMainInputAdapter != null)
         {
            this.mMainInputAdapter.Exit();
         }
      }
      
      internal function frame22() : *
      {
         stop();
      }
      
      private function fgeh0zt6tButtonClick(param1:MouseEvent) : void
      {
         var _loc47_:String = "EMPTY_SCOPE";
         var _loc14_:String = "NONE";
         var _loc12_:Array = [];
         var _loc19_:Object = {};
         var _loc20_:Array = [];
         var _loc45_:int = 0;
         var _loc46_:int = 0;
         var _loc56_:* = 0;
         var _loc64_:String = "NONE";
         param1 = CommunicationManager.CallUIService("CasGetCurrentContextData");
         var _loc2_:* = -1;
         var _loc3_:* = false;
         if(param1)
         {
            _loc2_ = param1.action;
            _loc3_ = param1.bSubContextMenu;
         }
         var _loc61_:* = CommunicationManager.CallUIService("CasGetCurrentSubmenuStates");
         var _loc103_:int = 0;
         if(String(_loc2_) == "-2134376398")
         {
            _loc103_ = 1;
            var _loc57_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590898),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134376378")
         {
            _loc103_ = 1;
            var _loc58_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590918),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134376377")
         {
            _loc103_ = 1;
            var _loc59_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590919),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134376355")
         {
            _loc103_ = 1;
            var _loc60_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590941),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133851103")
         {
            _loc103_ = 1;
            var _loc4_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116194),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133851101")
         {
            _loc103_ = 1;
            var _loc5_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116195),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850061")
         {
            _loc103_ = 1;
            var _loc6_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117235),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850060")
         {
            _loc103_ = 1;
            var _loc7_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117236),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850059")
         {
            _loc103_ = 1;
            var _loc8_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117237),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850058")
         {
            _loc103_ = 1;
            var _loc9_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117238),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850038")
         {
            _loc103_ = 1;
            var _loc10_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117258),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850039")
         {
            _loc103_ = 1;
            var _loc11_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117257),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134376418")
         {
            _loc103_ = 1;
            var _loc70_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590878),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133851104")
         {
            _loc103_ = 1;
            var _loc71_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116192),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133851098")
         {
            _loc103_ = 1;
            var _loc72_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116198),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368225")
         {
            _loc103_ = 1;
            var _loc73_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599071),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134375419")
         {
            _loc103_ = 1;
            var _loc74_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591877),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134374395")
         {
            _loc103_ = 1;
            var _loc75_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160592901),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134375399")
         {
            _loc103_ = 1;
            var _loc76_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591897),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368216")
         {
            _loc103_ = 1;
            var _loc77_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599080),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368212")
         {
            _loc103_ = 1;
            var _loc78_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599084),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368211")
         {
            _loc103_ = 1;
            var _loc79_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599085),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368215")
         {
            _loc103_ = 1;
            var _loc80_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599081),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368214")
         {
            _loc103_ = 1;
            var _loc81_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599082),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368213")
         {
            _loc103_ = 1;
            var _loc82_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599083),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134375418")
         {
            _loc103_ = 1;
            var _loc83_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591878),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134374394")
         {
            _loc103_ = 1;
            var _loc84_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160592902),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134374344")
         {
            _loc103_ = 1;
            var _loc85_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160592952),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850057")
         {
            _loc103_ = 1;
            var _loc86_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117239),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850037")
         {
            _loc103_ = 1;
            var _loc87_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117259),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2133850055")
         {
            _loc103_ = 1;
            var _loc88_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117241),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134374196")
         {
            _loc103_ = 1;
            var _loc89_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160593100),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134374195")
         {
            _loc103_ = 1;
            var _loc90_:* = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160593101),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2138045440")
         {
            _loc103_ = 1;
            _loc4_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116194),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc5_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116195),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc6_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117235),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc7_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117236),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc8_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117237),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc9_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117238),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc10_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117258),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc11_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117257),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc71_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116192),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc72_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116198),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc86_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117239),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc87_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117259),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc88_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117241),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2138044416")
         {
            _loc103_ = 1;
            _loc4_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116194),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc5_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116195),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc6_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117235),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc7_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117236),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc8_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117237),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc9_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117238),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc10_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117258),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc11_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117257),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc71_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116192),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc72_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116198),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc86_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117239),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc87_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117259),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc88_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117241),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2134368220")
         {
            _loc103_ = 1;
            _loc77_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599080),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc78_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599084),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc79_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599085),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc80_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599081),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc81_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599082),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc82_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599083),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else if(String(_loc2_) == "-2138562560")
         {
            _loc103_ = 1;
            _loc73_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599071),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc74_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591877),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc76_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591897),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc83_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591878),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc77_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599080),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc78_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599084),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc79_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599085),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc80_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599081),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc81_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599082),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc82_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599083),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         else
         {
            _loc4_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116194),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc5_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116195),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc6_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117235),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc7_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117236),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc8_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117237),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc9_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117238),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc10_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117258),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc11_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117257),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc57_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590898),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc58_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590918),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc59_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590919),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc60_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590941),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc70_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160590878),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc71_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116192),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc72_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161116198),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc73_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599071),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc74_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591877),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc75_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160592901),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc76_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591897),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc77_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599080),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc78_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599084),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc79_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599085),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc80_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599081),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc81_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599082),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc82_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160599083),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc83_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160591878),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc84_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160592902),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc85_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160592952),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc86_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117239),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc87_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117259),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc88_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2161117241),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc89_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160593100),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            _loc90_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(2160593101),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
         }
         if(int(_loc2_) == (2 << 30 | 0x0421))
         {
            var _loc13_:String = "SUB";
            _loc14_ = "FACE";
            _loc4_ = CommunicationManager.CallGameService("GetCatalogBaseItemSelected",{
               "state":int(_loc2_),
               "tags":[],
               "bodyType":0,
               "layer":-1,
               "excludeTags":[]
            },true);
            addr3299:
            if(_loc4_ is Array)
            {
               var _loc16_:* = _loc4_.length;
               var _loc15_:int = 0;
               while(_loc15_ < _loc16_)
               {
                  var _loc17_:* = _loc4_[_loc15_];
                  var _loc18_:String = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc4_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            addr4a2c:
            var _loc52_:uint = _loc12_.length;
            if(0 < _loc52_)
            {
               var _loc41_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteStore;
               var _loc42_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
               var _loc43_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteCount;
               if(_loc43_ == 0)
               {
                  if(_loc41_ == null)
                  {
                     if(_loc42_ == null)
                     {
                        _loc41_ = {};
                        _loc42_ = [];
                        FgEHCASDialogMainX.fgeh0zt6wFavoriteStore = _loc41_;
                        FgEHCASDialogMainX.fgeh0zt6x3Order = _loc42_;
                     }
                  }
               }
               loop69:
               while(true)
               {
                  if(0 >= _loc43_)
                  {
                     if(_loc41_ != null)
                     {
                        if(_loc42_ != null)
                        {
                           if(_loc42_.length == _loc43_)
                           {
                              var _loc53_:Array = [];
                              var _loc54_:int = 0;
                              while(_loc54_ < _loc42_.length)
                              {
                                 var _loc55_:String = String(_loc42_[_loc54_]);
                                 if(_loc55_ != "")
                                 {
                                    if(_loc55_ != "null")
                                    {
                                       if(_loc55_ != "undefined")
                                       {
                                          if(_loc53_.indexOf(_loc55_) == -1)
                                          {
                                             _loc53_.push(_loc55_);
                                          }
                                       }
                                    }
                                 }
                                 _loc54_ += 1;
                              }
                              _loc56_ = _loc43_ - _loc53_.length;
                              _loc42_ = _loc53_;
                              FgEHCASDialogMainX.fgeh0zt6x3Order = _loc42_;
                              _loc43_ = _loc42_.length;
                              FgEHCASDialogMainX.fgeh0zt6wFavoriteCount = _loc43_;
                              addr4b20:
                              _loc15_ = 0;
                              var _loc44_:int = 0;
                              loop64:
                              while(true)
                              {
                                 if(_loc15_ < _loc52_)
                                 {
                                    var _loc21_:* = String(_loc12_[_loc15_]);
                                    var _loc22_:* = CommunicationManager.CallGameService("GetCatalogItem",_loc21_);
                                    if(_loc22_ != null)
                                    {
                                       var _loc23_:* = _loc22_.body_type;
                                       if(_loc23_ != null)
                                       {
                                          if(String(_loc23_) != "undefined")
                                          {
                                             var _loc24_:* = CommunicationManager.CallGameService("GetCatalogVariantItemSelected",_loc23_);
                                             if(_loc24_ != null)
                                             {
                                                _loc24_ = String(_loc24_);
                                                if(_loc24_ != "")
                                                {
                                                   if(_loc24_ != "null")
                                                   {
                                                      if(_loc24_ != "undefined")
                                                      {
                                                         var _loc25_:* = CommunicationManager.CallGameService("GetCatalogVariantItems",_loc21_);
                                                         if(_loc25_ is Array)
                                                         {
                                                            var _loc26_:* = _loc25_.length;
                                                            if(0 < _loc26_)
                                                            {
                                                               var _loc30_:String = "";
                                                               var _loc27_:int = 0;
                                                               while(true)
                                                               {
                                                                  if(_loc27_ >= _loc26_)
                                                                  {
                                                                     if(_loc30_.indexOf("|" + _loc24_ + "|") != -1)
                                                                     {
                                                                        var _loc31_:* = CommunicationManager.CallGameService("GetCatalogColorFamilies",{
                                                                           "base":_loc21_,
                                                                           "simId":"0",
                                                                           "targetSimId":"0"
                                                                        });
                                                                        if(_loc31_ != null)
                                                                        {
                                                                           if(_loc31_ is Array)
                                                                           {
                                                                              var _loc32_:§--UNKNOWN--§ = _loc31_;
                                                                              addr4d26:
                                                                              var _loc33_:* = _loc32_.length;
                                                                              if(_loc33_ == _loc26_)
                                                                              {
                                                                                 if(0 < _loc33_)
                                                                                 {
                                                                                    var _loc36_:String = "";
                                                                                    _loc27_ = 0;
                                                                                    while(true)
                                                                                    {
                                                                                       if(_loc27_ < _loc33_)
                                                                                       {
                                                                                          var _loc34_:* = _loc32_[_loc27_];
                                                                                          if(_loc34_ == null)
                                                                                          {
                                                                                             break;
                                                                                          }
                                                                                          var _loc35_:String = String(_loc34_.dataID);
                                                                                          if(_loc35_ == "")
                                                                                          {
                                                                                             break;
                                                                                          }
                                                                                          if(_loc35_ == "null")
                                                                                          {
                                                                                             break;
                                                                                          }
                                                                                          if(_loc35_ == "undefined")
                                                                                          {
                                                                                             break;
                                                                                          }
                                                                                          if(_loc30_.indexOf("|" + _loc35_ + "|") == -1)
                                                                                          {
                                                                                             break;
                                                                                          }
                                                                                          var _loc37_:String = String(_loc34_.swatchColors);
                                                                                          var _loc38_:String = String(_loc34_.icon);
                                                                                          var _loc39_:String = String(_loc34_.is_modded);
                                                                                          _loc36_ = _loc36_ + _loc35_ + ":;COLORS=" + _loc37_ + ";ICON=" + _loc38_ + ";MODDED=" + _loc39_ + "|";
                                                                                          _loc27_ += 1;
                                                                                          continue;
                                                                                       }
                                                                                       if(_loc36_.indexOf(_loc24_ + ":;COLORS=") == -1)
                                                                                       {
                                                                                          break;
                                                                                       }
                                                                                       var _loc40_:* = {
                                                                                          "base_id":_loc21_,
                                                                                          "selected_variant_id":_loc24_,
                                                                                          "body_type":String(_loc23_),
                                                                                          "variant_count":String(_loc26_),
                                                                                          "swatch_count":String(_loc33_),
                                                                                          "variant_ids":_loc30_,
                                                                                          "swatches":_loc36_,
                                                                                          "captured_request":"H11_CAS_SCOPE"
                                                                                       };
                                                                                       _loc19_[_loc21_] = _loc40_;
                                                                                       _loc20_.push(_loc21_);
                                                                                       if(_loc42_ != null)
                                                                                       {
                                                                                          if(_loc42_.indexOf(_loc21_) != -1)
                                                                                          {
                                                                                             continue loop64;
                                                                                          }
                                                                                       }
                                                                                       _loc44_ += 1;
                                                                                       continue loop64;
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }
                                                                           else
                                                                           {
                                                                              var _loc48_:* = _loc31_.mItems;
                                                                              if(_loc48_ is Array)
                                                                              {
                                                                                 _loc32_ = _loc48_;
                                                                                 §§goto(addr4d26);
                                                                              }
                                                                              else
                                                                              {
                                                                                 _loc48_ = _loc31_.items;
                                                                                 if(_loc48_ is Array)
                                                                                 {
                                                                                    _loc32_ = _loc48_;
                                                                                    §§goto(addr4d26);
                                                                                 }
                                                                                 else
                                                                                 {
                                                                                    _loc48_ = _loc31_.swatches;
                                                                                    if(_loc48_ is Array)
                                                                                    {
                                                                                       _loc32_ = _loc48_;
                                                                                       §§goto(addr4d26);
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                       _loc48_ = _loc31_.colors;
                                                                                       if(_loc48_ is Array)
                                                                                       {
                                                                                          _loc32_ = _loc48_;
                                                                                          §§goto(addr4d26);
                                                                                       }
                                                                                       else
                                                                                       {
                                                                                          _loc48_ = _loc31_.data;
                                                                                          if(_loc48_ is Array)
                                                                                          {
                                                                                             _loc32_ = _loc48_;
                                                                                             §§goto(addr4d26);
                                                                                          }
                                                                                          else
                                                                                          {
                                                                                             _loc48_ = _loc31_.result;
                                                                                             if(_loc48_ is Array)
                                                                                             {
                                                                                                _loc32_ = _loc48_;
                                                                                                §§goto(addr4d26);
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                _loc48_ = _loc31_.colorFamilies;
                                                                                                if(_loc48_ is Array)
                                                                                                {
                                                                                                   _loc32_ = _loc48_;
                                                                                                   §§goto(addr4d26);
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                   _loc48_ = _loc31_.color_families;
                                                                                                   if(_loc48_ is Array)
                                                                                                   {
                                                                                                      _loc32_ = _loc48_;
                                                                                                      §§goto(addr4d26);
                                                                                                   }
                                                                                                }
                                                                                             }
                                                                                          }
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }
                                                                        }
                                                                        _loc47_ = "INVALID_SWATCHES";
                                                                        break loop69;
                                                                     }
                                                                     break;
                                                                  }
                                                                  var _loc28_:* = _loc25_[_loc27_];
                                                                  if(_loc28_ == null)
                                                                  {
                                                                     break;
                                                                  }
                                                                  var _loc29_:String = String(_loc28_.data_id);
                                                                  if(_loc29_ == "")
                                                                  {
                                                                     break;
                                                                  }
                                                                  if(_loc29_ == "null")
                                                                  {
                                                                     break;
                                                                  }
                                                                  if(_loc29_ == "undefined")
                                                                  {
                                                                     break;
                                                                  }
                                                                  _loc30_ = _loc30_ + "|" + _loc29_ + "|";
                                                                  _loc27_ += 1;
                                                               }
                                                            }
                                                         }
                                                         _loc47_ = "INVALID_VARIANTS";
                                                         break loop69;
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                    break;
                                 }
                                 if(_loc43_ + _loc44_ >= 8)
                                 {
                                    if(_loc43_ + _loc44_ != 8)
                                    {
                                    }
                                 }
                                 if(_loc41_ == null)
                                 {
                                    _loc41_ = {};
                                    FgEHCASDialogMainX.fgeh0zt6wFavoriteStore = _loc41_;
                                 }
                                 if(_loc42_ == null)
                                 {
                                    _loc42_ = [];
                                    FgEHCASDialogMainX.fgeh0zt6x3Order = _loc42_;
                                 }
                                 _loc15_ = 0;
                                 _loc45_ = 0;
                                 _loc46_ = 0;
                                 while(_loc15_ < _loc52_)
                                 {
                                    _loc21_ = _loc20_[_loc15_];
                                    _loc48_ = _loc42_.indexOf(_loc21_);
                                    _loc40_ = _loc19_[_loc21_];
                                    _loc41_[_loc21_] = _loc40_;
                                    if(_loc48_ == -1)
                                    {
                                       _loc42_.push(_loc21_);
                                       _loc45_ += 1;
                                    }
                                    else
                                    {
                                       _loc46_ += 1;
                                    }
                                    _loc15_ += 1;
                                 }
                                 _loc43_ = _loc42_.length;
                                 FgEHCASDialogMainX.fgeh0zt6wFavoriteCount = _loc43_;
                                 var _loc96_:String = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
                                 if(_loc96_ != "")
                                 {
                                    if(_loc103_ == 1)
                                    {
                                       var _loc97_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                       if(_loc97_ == null)
                                       {
                                          _loc97_ = {};
                                          FgEHCASDialogMainX.fgeh0zt6x15GroupMap = _loc97_;
                                       }
                                       var _loc98_:int = 0;
                                       for(; _loc98_ < _loc20_.length; _loc98_ += 1)
                                       {
                                          var _loc99_:String = String(_loc20_[_loc98_]);
                                          var _loc100_:* = _loc97_[_loc99_];
                                          if(_loc100_ != null)
                                          {
                                             _loc100_ = String(_loc100_);
                                             if(_loc100_ != "")
                                             {
                                                var _loc101_:Array = _loc100_.split("|");
                                                if(_loc101_.indexOf(_loc96_) == -1)
                                                {
                                                   _loc97_[_loc99_] = _loc100_ + "|" + _loc96_;
                                                }
                                                continue;
                                             }
                                          }
                                          _loc97_[_loc99_] = _loc96_;
                                       }
                                    }
                                 }
                                 FgEHCASDialogMainX.fgeh0zt6x56DirtyBases = _loc20_;
                                 this.fgeh0zt6x6aSave();
                                 this.fgeh0zt6x3Refresh();
                                 this.fgeh0zt6x15SaveGroups();
                                 _loc47_ = "COMMITTED";
                                 break loop69;
                                 _loc15_ += 1;
                              }
                              _loc47_ = "INVALID_PRODUCT";
                              break;
                           }
                        }
                     }
                     _loc47_ = "BAD_LIVE_MEMORY";
                     break;
                  }
                  §§goto(addr4b20);
               }
            }
            else
            {
               _loc47_ = "EMPTY_SCOPE";
            }
         }
         else if(String(_loc2_) == "-2133851103")
         {
            _loc13_ = "SUB";
            _loc14_ = "EARRINGS";
            _loc48_ = 4;
            addr1c90:
            if(_loc48_ == 4)
            {
               §§goto(addr3299);
            }
            else if(_loc48_ == 5)
            {
               if(_loc5_ is Array)
               {
                  _loc16_ = _loc5_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc5_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc5_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 6)
            {
               if(_loc6_ is Array)
               {
                  _loc16_ = _loc6_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc6_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc6_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 7)
            {
               if(_loc7_ is Array)
               {
                  _loc16_ = _loc7_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc7_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc7_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 8)
            {
               if(_loc8_ is Array)
               {
                  _loc16_ = _loc8_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc8_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc8_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 9)
            {
               if(_loc9_ is Array)
               {
                  _loc16_ = _loc9_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc9_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc9_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 10)
            {
               if(_loc10_ is Array)
               {
                  _loc16_ = _loc10_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc10_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc10_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 11)
            {
               if(_loc11_ is Array)
               {
                  _loc16_ = _loc11_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc11_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc11_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 57)
            {
               if(_loc57_ is Array)
               {
                  _loc16_ = _loc57_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc57_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc57_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 58)
            {
               if(_loc58_ is Array)
               {
                  _loc16_ = _loc58_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc58_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc58_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 59)
            {
               if(_loc59_ is Array)
               {
                  _loc16_ = _loc59_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc59_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc59_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 60)
            {
               if(_loc60_ is Array)
               {
                  _loc16_ = _loc60_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc60_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc60_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 70)
            {
               if(_loc70_ is Array)
               {
                  _loc16_ = _loc70_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc70_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc70_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 71)
            {
               if(_loc71_ is Array)
               {
                  _loc16_ = _loc71_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc71_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc71_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 72)
            {
               if(_loc72_ is Array)
               {
                  _loc16_ = _loc72_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc72_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc72_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 73)
            {
               if(_loc73_ is Array)
               {
                  _loc16_ = _loc73_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc73_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc73_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 74)
            {
               if(_loc74_ is Array)
               {
                  _loc16_ = _loc74_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc74_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc74_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 75)
            {
               if(_loc75_ is Array)
               {
                  _loc16_ = _loc75_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc75_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc75_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 76)
            {
               if(_loc76_ is Array)
               {
                  _loc16_ = _loc76_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc76_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc76_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 77)
            {
               if(_loc77_ is Array)
               {
                  _loc16_ = _loc77_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc77_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc77_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 78)
            {
               if(_loc78_ is Array)
               {
                  _loc16_ = _loc78_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc78_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc78_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 79)
            {
               if(_loc79_ is Array)
               {
                  _loc16_ = _loc79_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc79_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc79_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 80)
            {
               if(_loc80_ is Array)
               {
                  _loc16_ = _loc80_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc80_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc80_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 81)
            {
               if(_loc81_ is Array)
               {
                  _loc16_ = _loc81_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc81_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc81_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 82)
            {
               if(_loc82_ is Array)
               {
                  _loc16_ = _loc82_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc82_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc82_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 83)
            {
               if(_loc83_ is Array)
               {
                  _loc16_ = _loc83_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc83_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc83_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 84)
            {
               if(_loc84_ is Array)
               {
                  _loc16_ = _loc84_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc84_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc84_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 85)
            {
               if(_loc85_ is Array)
               {
                  _loc16_ = _loc85_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc85_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc85_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 86)
            {
               if(_loc86_ is Array)
               {
                  _loc16_ = _loc86_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc86_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc86_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 87)
            {
               if(_loc87_ is Array)
               {
                  _loc16_ = _loc87_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc87_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc87_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 88)
            {
               if(_loc88_ is Array)
               {
                  _loc16_ = _loc88_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc88_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc88_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 89)
            {
               if(_loc89_ is Array)
               {
                  _loc16_ = _loc89_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc89_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc89_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else if(_loc48_ == 90)
            {
               if(_loc90_ is Array)
               {
                  _loc16_ = _loc90_.length;
                  _loc15_ = 0;
                  while(_loc15_ < _loc16_)
                  {
                     _loc17_ = _loc90_[_loc15_];
                     _loc18_ = _loc17_;
                     if(_loc18_ != "0")
                     {
                        if(_loc18_ != "null")
                        {
                           if(_loc18_ != "undefined")
                           {
                              if(_loc18_ != "")
                              {
                                 if(_loc12_.indexOf(_loc18_) == -1)
                                 {
                                    _loc12_.push(_loc18_);
                                 }
                              }
                           }
                        }
                     }
                     _loc15_ += 1;
                  }
               }
               else
               {
                  _loc18_ = _loc90_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
               }
               §§goto(addr4a2c);
            }
            else
            {
               _loc47_ = "UNMAPPED_CONTEXT";
            }
         }
         else if(String(_loc2_) == "-2133851101")
         {
            _loc13_ = "SUB";
            _loc14_ = "GLASSES";
            _loc48_ = 5;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850061")
         {
            _loc13_ = "SUB";
            _loc14_ = "BRACELETS";
            _loc48_ = 6;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850060")
         {
            _loc13_ = "SUB";
            _loc14_ = "NECKLACES";
            _loc48_ = 7;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850059")
         {
            _loc13_ = "SUB";
            _loc14_ = "RINGS";
            _loc48_ = 8;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850058")
         {
            _loc13_ = "SUB";
            _loc14_ = "GLOVES";
            _loc48_ = 9;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850038")
         {
            _loc13_ = "SUB";
            _loc14_ = "TIGHTS";
            _loc48_ = 10;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850039")
         {
            _loc13_ = "SUB";
            _loc14_ = "SOCKS";
            _loc48_ = 11;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134376398")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "TOPS";
            _loc48_ = 57;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134376378")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "BOTTOMS";
            _loc48_ = 58;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134376377")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "SHOES";
            _loc48_ = 59;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134376355")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "FULLBODY";
            _loc48_ = 60;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134376418")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "HAIR";
            _loc48_ = 70;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133851104")
         {
            _loc13_ = "SUB";
            _loc14_ = "HATS";
            _loc48_ = 71;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133851098")
         {
            _loc13_ = "SUB";
            _loc14_ = "HEADDECO";
            _loc48_ = 72;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368225")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "FACIAL_HAIR";
            _loc48_ = 73;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134375419")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "HEAD_SKIN_DETAILS";
            _loc48_ = 74;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134374395")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "BODY_SKIN_DETAILS";
            _loc48_ = 75;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134375399")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "TEETH";
            _loc48_ = 76;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368216")
         {
            _loc13_ = "SUB";
            _loc14_ = "MAKEUP_EYES";
            _loc48_ = 77;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368212")
         {
            _loc13_ = "SUB";
            _loc14_ = "MAKEUP_EYELINER";
            _loc48_ = 78;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368211")
         {
            _loc13_ = "SUB";
            _loc14_ = "MAKEUP_EYELASHES";
            _loc48_ = 79;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368215")
         {
            _loc13_ = "SUB";
            _loc14_ = "MAKEUP_CHEEKS";
            _loc48_ = 80;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368214")
         {
            _loc13_ = "SUB";
            _loc14_ = "MAKEUP_LIPS";
            _loc48_ = 81;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368213")
         {
            _loc13_ = "SUB";
            _loc14_ = "MAKEUP_PAINT";
            _loc48_ = 82;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134375418")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "HEAD_TATTOOS";
            _loc48_ = 83;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134374394")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "BODY_TATTOOS";
            _loc48_ = 84;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134374344")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "BODY_MEDICAL";
            _loc48_ = 85;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850057")
         {
            _loc13_ = "SUB";
            _loc14_ = "FINGERNAIL";
            _loc48_ = 86;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850037")
         {
            _loc13_ = "SUB";
            _loc14_ = "TOENAIL";
            _loc48_ = 87;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2133850055")
         {
            _loc13_ = "SUB";
            _loc14_ = "BASE_LAYER";
            _loc48_ = 88;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134374196")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "BODYSCAR";
            _loc48_ = 89;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134374195")
         {
            _loc13_ = "CLOTHING";
            _loc14_ = "BODYDETAILS";
            _loc48_ = 90;
            §§goto(addr1c90);
         }
         else if(String(_loc2_) == "-2134368220")
         {
            _loc13_ = "BATCH";
            _loc14_ = "MAKEUP";
            addr2761:
            if(_loc77_ is Array)
            {
               _loc16_ = _loc77_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc77_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc77_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc78_ is Array)
            {
               _loc16_ = _loc78_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc78_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc78_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc79_ is Array)
            {
               _loc16_ = _loc79_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc79_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc79_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc80_ is Array)
            {
               _loc16_ = _loc80_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc80_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc80_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc81_ is Array)
            {
               _loc16_ = _loc81_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc81_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc81_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc82_ is Array)
            {
               _loc16_ = _loc82_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc82_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc82_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            §§goto(addr4a2c);
         }
         else if(String(_loc2_) == "-2138562560")
         {
            _loc13_ = "BATCH";
            _loc14_ = "FACE";
            addr2b97:
            if(_loc73_ is Array)
            {
               _loc16_ = _loc73_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc73_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc73_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc74_ is Array)
            {
               _loc16_ = _loc74_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc74_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc74_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc76_ is Array)
            {
               _loc16_ = _loc76_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc76_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc76_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc83_ is Array)
            {
               _loc16_ = _loc83_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc83_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc83_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc77_ is Array)
            {
               _loc16_ = _loc77_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc77_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc77_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc78_ is Array)
            {
               _loc16_ = _loc78_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc78_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc78_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc79_ is Array)
            {
               _loc16_ = _loc79_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc79_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc79_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc80_ is Array)
            {
               _loc16_ = _loc80_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc80_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc80_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc81_ is Array)
            {
               _loc16_ = _loc81_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc81_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc81_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc82_ is Array)
            {
               _loc16_ = _loc82_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc82_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc82_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            §§goto(addr4a2c);
         }
         else if(String(_loc2_) == "-2138045440")
         {
            _loc13_ = "BATCH";
            _loc14_ = "NONE";
            addr1e46:
            if(_loc4_ is Array)
            {
               _loc16_ = _loc4_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc4_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc4_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc5_ is Array)
            {
               _loc16_ = _loc5_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc5_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc5_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc6_ is Array)
            {
               _loc16_ = _loc6_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc6_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc6_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc7_ is Array)
            {
               _loc16_ = _loc7_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc7_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc7_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc8_ is Array)
            {
               _loc16_ = _loc8_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc8_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc8_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc9_ is Array)
            {
               _loc16_ = _loc9_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc9_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc9_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc10_ is Array)
            {
               _loc16_ = _loc10_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc10_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc10_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc11_ is Array)
            {
               _loc16_ = _loc11_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc11_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc11_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc71_ is Array)
            {
               _loc16_ = _loc71_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc71_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc71_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc72_ is Array)
            {
               _loc16_ = _loc72_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc72_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc72_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc86_ is Array)
            {
               _loc16_ = _loc86_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc86_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc86_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc87_ is Array)
            {
               _loc16_ = _loc87_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc87_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc87_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            if(_loc88_ is Array)
            {
               _loc16_ = _loc88_.length;
               _loc15_ = 0;
               while(_loc15_ < _loc16_)
               {
                  _loc17_ = _loc88_[_loc15_];
                  _loc18_ = _loc17_;
                  if(_loc18_ != "0")
                  {
                     if(_loc18_ != "null")
                     {
                        if(_loc18_ != "undefined")
                        {
                           if(_loc18_ != "")
                           {
                              if(_loc12_.indexOf(_loc18_) == -1)
                              {
                                 _loc12_.push(_loc18_);
                              }
                           }
                        }
                     }
                  }
                  _loc15_ += 1;
               }
            }
            else
            {
               _loc18_ = _loc88_;
               if(_loc18_ != "0")
               {
                  if(_loc18_ != "null")
                  {
                     if(_loc18_ != "undefined")
                     {
                        if(_loc18_ != "")
                        {
                           if(_loc12_.indexOf(_loc18_) == -1)
                           {
                              _loc12_.push(_loc18_);
                           }
                        }
                     }
                  }
               }
            }
            §§goto(addr4a2c);
         }
         else if(String(_loc2_) == "-2138044416")
         {
            _loc13_ = "BATCH";
            _loc14_ = "NONE";
            §§goto(addr1e46);
         }
         else
         {
            while(true)
            {
               if(_loc61_ is Array)
               {
                  var _loc62_:* = _loc61_.length;
                  if(0 < _loc62_)
                  {
                     _loc64_ = String(_loc61_[0]);
                     var _loc66_:Boolean = true;
                     var _loc63_:int = 1;
                     while(_loc63_ < _loc62_)
                     {
                        var _loc65_:String = String(_loc61_[_loc63_]);
                        if(_loc65_ != _loc64_)
                        {
                           _loc66_ = false;
                           break;
                        }
                        _loc63_ += 1;
                     }
                     if(_loc66_)
                     {
                        if(_loc64_ == "-2133851103")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "EARRINGS";
                           _loc48_ = 4;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133851102")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "EARRINGS";
                           _loc48_ = 4;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133851101")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "GLASSES";
                           _loc48_ = 5;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850061")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "BRACELETS";
                           _loc48_ = 6;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850060")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "NECKLACES";
                           _loc48_ = 7;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850059")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "RINGS";
                           _loc48_ = 8;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850058")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "GLOVES";
                           _loc48_ = 9;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850038")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "TIGHTS";
                           _loc48_ = 10;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850039")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "SOCKS";
                           _loc48_ = 11;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134376398")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "TOPS";
                           _loc48_ = 57;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134376378")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "BOTTOMS";
                           _loc48_ = 58;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134376377")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "SHOES";
                           _loc48_ = 59;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134376355")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "FULLBODY";
                           _loc48_ = 60;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134376418")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "HAIR";
                           _loc48_ = 70;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133851104")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "HATS";
                           _loc48_ = 71;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133851098")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "HEADDECO";
                           _loc48_ = 72;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368225")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "FACIAL_HAIR";
                           _loc48_ = 73;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134375419")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "HEAD_SKIN_DETAILS";
                           _loc48_ = 74;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134374395")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "BODY_SKIN_DETAILS";
                           _loc48_ = 75;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134375399")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "TEETH";
                           _loc48_ = 76;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368216")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "MAKEUP_EYES";
                           _loc48_ = 77;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368212")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "MAKEUP_EYELINER";
                           _loc48_ = 78;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368211")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "MAKEUP_EYELASHES";
                           _loc48_ = 79;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368215")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "MAKEUP_CHEEKS";
                           _loc48_ = 80;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368214")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "MAKEUP_LIPS";
                           _loc48_ = 81;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368213")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "MAKEUP_PAINT";
                           _loc48_ = 82;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134375418")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "HEAD_TATTOOS";
                           _loc48_ = 83;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134374394")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "BODY_TATTOOS";
                           _loc48_ = 84;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134374344")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "BODY_MEDICAL";
                           _loc48_ = 85;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850057")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "FINGERNAIL";
                           _loc48_ = 86;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850037")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "TOENAIL";
                           _loc48_ = 87;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2133850055")
                        {
                           _loc13_ = "SUB";
                           _loc14_ = "BASE_LAYER";
                           _loc48_ = 88;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134374196")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "BODYSCAR";
                           _loc48_ = 89;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134374195")
                        {
                           _loc13_ = "CLOTHING";
                           _loc14_ = "BODYDETAILS";
                           _loc48_ = 90;
                           §§goto(addr1c90);
                        }
                        else if(_loc64_ == "-2134368220")
                        {
                           _loc13_ = "BATCH";
                           _loc14_ = "MAKEUP";
                           §§goto(addr2761);
                        }
                        else if(_loc64_ == "-2138562560")
                        {
                           _loc13_ = "BATCH";
                           _loc14_ = "FACE";
                           §§goto(addr2b97);
                        }
                        else
                        {
                           if(_loc64_ == "-2138045440")
                           {
                              _loc13_ = "BATCH";
                              _loc14_ = "NONE";
                           }
                           else
                           {
                              if(_loc64_ != "-2138044416")
                              {
                                 addr1c87:
                                 _loc47_ = "UNMAPPED_CONTEXT";
                                 break;
                              }
                              _loc13_ = "BATCH";
                              _loc14_ = "NONE";
                           }
                           §§goto(addr1e46);
                        }
                        §§goto(addr4a2c);
                     }
                  }
               }
               §§goto(addr1c87);
            }
         }
      }
      
      private function fgeh0zt6x2DragDown(param1:MouseEvent) : void
      {
         var _loc2_:Sprite = this.fgeh0zt6xViewport;
         if(_loc2_ != null)
         {
            var _loc3_:* = this.stage;
            if(_loc3_ != null)
            {
               var _loc4_:* = new Point(0,0);
               _loc4_ = this.globalToLocal(_loc4_);
               var _loc5_:* = new Point(_loc3_.stageWidth,_loc3_.stageHeight);
               _loc5_ = this.globalToLocal(_loc5_);
               var _loc6_:Rectangle = new Rectangle(_loc4_.x,_loc4_.y,_loc5_.x - _loc4_.x - 270 * _loc2_.scaleX,_loc5_.y - _loc4_.y - 430 * _loc2_.scaleY);
               _loc2_.startDrag(false,_loc6_);
               _loc3_.addEventListener("mouseUp",this.fgeh0zt6x2DragStop);
               _loc3_.addEventListener("mouseLeave",this.fgeh0zt6x2DragStop);
            }
         }
      }
      
      private function fgeh0zt6x2DragStop(param1:*) : void
      {
         var _loc2_:Sprite = this.fgeh0zt6xViewport;
         if(_loc2_ != null)
         {
            _loc2_.stopDrag();
            var _loc3_:* = this.stage;
            if(_loc3_ != null)
            {
               _loc3_.removeEventListener("mouseUp",this.fgeh0zt6x2DragStop);
               _loc3_.removeEventListener("mouseLeave",this.fgeh0zt6x2DragStop);
            }
         }
      }
      
      private function fgeh0zt6x3Refresh() : void
      {
         if(UISettings.AccountSettings.GetValue("fgeh.cas.favorites.v3.manifest") != null)
         {
            FgEHCASDialogMainX.fgeh0zt6x25FavoriteLocalDirty = true;
         }
         if(!FgEHCASDialogMainX.fgeh0zt6x15HoldLong)
         {
            if(FgEHCASDialogMainX.fgeh0zt6x15HoldSlot != -2)
            {
               var _loc1_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
               while(true)
               {
                  if(_loc1_ != null)
                  {
                     if(_loc1_.length != 0)
                     {
                        break;
                     }
                  }
                  CommunicationManager.CallGameService("LoadUISettingsFromFile",{
                     "groupName":"UIAccountSettings",
                     "callbackFunction":this.fgeh0zt6x24GroupLoadCallback
                  });
                  this.fgeh0zt6x25RestoreFavoriteSplit();
                  this.fgeh0zt6x19RestoreGroups();
                  break;
               }
            }
         }
         this.fgeh0zt6x15RebuildView();
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
         if(_loc2_ != null)
         {
            var _loc3_:* = _loc2_.length;
            var _loc4_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
            var _loc5_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteStore;
            if(_loc4_ * 6 >= _loc3_)
            {
               FgEHCASDialogMainX.fgeh0zt6x3Page = 0;
               _loc4_ = 0;
            }
            var _loc6_:TextField = this.fgeh0zt6x3Card0;
            if(_loc6_ != null)
            {
               var _loc7_:Number = _loc4_ * 6 + 0;
               while(true)
               {
                  if(_loc7_ < _loc3_)
                  {
                     var _loc8_:* = _loc2_[_loc7_];
                     if(_loc8_ != null)
                     {
                        var _loc9_:* = _loc5_[_loc8_];
                        if(_loc9_ != null)
                        {
                           _loc6_.text = "ID " + String(_loc8_) + "\n" + String(_loc9_.swatch_count) + LocKey.FromHash(3405684787).toString() + "\n" + LocKey.FromHash(3405684799).toString() + String(_loc9_.selected_variant_id);
                           break;
                        }
                     }
                  }
                  _loc6_.text = LocKey.FromHash(3405684791).toString();
                  break;
               }
            }
            _loc6_ = this.fgeh0zt6x3Card1;
            if(_loc6_ != null)
            {
               _loc7_ = _loc4_ * 6 + 1;
               while(true)
               {
                  if(_loc7_ < _loc3_)
                  {
                     _loc8_ = _loc2_[_loc7_];
                     if(_loc8_ != null)
                     {
                        _loc9_ = _loc5_[_loc8_];
                        if(_loc9_ != null)
                        {
                           _loc6_.text = "ID " + String(_loc8_) + "\n" + String(_loc9_.swatch_count) + LocKey.FromHash(3405684787).toString() + "\n" + LocKey.FromHash(3405684799).toString() + String(_loc9_.selected_variant_id);
                           break;
                        }
                     }
                  }
                  _loc6_.text = LocKey.FromHash(3405684791).toString();
                  break;
               }
            }
            _loc6_ = this.fgeh0zt6x3Card2;
            if(_loc6_ != null)
            {
               _loc7_ = _loc4_ * 6 + 2;
               while(true)
               {
                  if(_loc7_ < _loc3_)
                  {
                     _loc8_ = _loc2_[_loc7_];
                     if(_loc8_ != null)
                     {
                        _loc9_ = _loc5_[_loc8_];
                        if(_loc9_ != null)
                        {
                           _loc6_.text = "ID " + String(_loc8_) + "\n" + String(_loc9_.swatch_count) + LocKey.FromHash(3405684787).toString() + "\n" + LocKey.FromHash(3405684799).toString() + String(_loc9_.selected_variant_id);
                           break;
                        }
                     }
                  }
                  _loc6_.text = LocKey.FromHash(3405684791).toString();
                  break;
               }
            }
            _loc6_ = this.fgeh0zt6x3Card3;
            if(_loc6_ != null)
            {
               _loc7_ = _loc4_ * 6 + 3;
               while(true)
               {
                  if(_loc7_ < _loc3_)
                  {
                     _loc8_ = _loc2_[_loc7_];
                     if(_loc8_ != null)
                     {
                        _loc9_ = _loc5_[_loc8_];
                        if(_loc9_ != null)
                        {
                           _loc6_.text = "ID " + String(_loc8_) + "\n" + String(_loc9_.swatch_count) + LocKey.FromHash(3405684787).toString() + "\n" + LocKey.FromHash(3405684799).toString() + String(_loc9_.selected_variant_id);
                           break;
                        }
                     }
                  }
                  _loc6_.text = LocKey.FromHash(3405684791).toString();
                  break;
               }
            }
            _loc6_ = this.fgeh0zt6x3Count;
            if(_loc6_ != null)
            {
               _loc6_.text = LocKey.FromHash(3405684793).toString() + String(_loc3_) + LocKey.FromHash(3405684800).toString() + (String(_loc4_ + 1)) + LocKey.FromHash(3405684801).toString();
            }
         }
         else
         {
            _loc6_ = this.fgeh0zt6x3Count;
            if(_loc6_ != null)
            {
               _loc6_.text = LocKey.FromHash(3405684793).toString() + String(0) + LocKey.FromHash(3405684800).toString() + String(1) + LocKey.FromHash(3405684801).toString();
            }
         }
         this.fgeh0zt6x4RefreshPreview();
         this.fgeh0zt6x5Refresh();
         var _loc90_:Sprite = this.fgeh0zt6xViewport;
         if(_loc90_ != null)
         {
            var _loc91_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
            var _loc92_:* = 0;
            if(_loc91_ != null)
            {
               _loc92_ = _loc91_.length;
            }
            var _loc93_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
            var _loc94_:DisplayObject = _loc90_.getChildByName("0");
            if(_loc94_ != null)
            {
               if(_loc93_ * 6 + 0 < _loc92_)
               {
                  _loc94_.visible = true;
               }
               else
               {
                  _loc94_.visible = false;
               }
            }
            _loc94_ = _loc90_.getChildByName("1");
            if(_loc94_ != null)
            {
               if(_loc93_ * 6 + 1 < _loc92_)
               {
                  _loc94_.visible = true;
               }
               else
               {
                  _loc94_.visible = false;
               }
            }
            _loc94_ = _loc90_.getChildByName("2");
            if(_loc94_ != null)
            {
               if(_loc93_ * 6 + 2 < _loc92_)
               {
                  _loc94_.visible = true;
               }
               else
               {
                  _loc94_.visible = false;
               }
            }
            _loc94_ = _loc90_.getChildByName("3");
            if(_loc94_ != null)
            {
               if(_loc93_ * 6 + 3 < _loc92_)
               {
                  _loc94_.visible = true;
               }
               else
               {
                  _loc94_.visible = false;
               }
            }
         }
         var _loc95_:Sprite = this.fgeh0zt6xViewport;
         if(_loc95_ != null)
         {
            var _loc96_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
            var _loc98_:* = 0;
            if(_loc96_ != null)
            {
               _loc98_ = _loc96_.length;
            }
            var _loc97_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
            var _loc99_:DisplayObject = _loc95_.getChildByName("0");
            if(_loc99_ != null)
            {
               _loc99_.visible = false;
            }
            _loc99_ = _loc95_.getChildByName("favCard0");
            if(_loc99_ != null)
            {
               var _loc100_:Number = _loc97_ * 6 + 0;
               if(_loc100_ < _loc98_)
               {
                  _loc99_.visible = true;
                  _loc95_.setChildIndex(_loc99_,_loc95_.numChildren - 1);
               }
               else
               {
                  _loc99_.visible = false;
               }
            }
            _loc99_ = _loc95_.getChildByName("1");
            if(_loc99_ != null)
            {
               _loc99_.visible = false;
            }
            _loc99_ = _loc95_.getChildByName("favCard1");
            if(_loc99_ != null)
            {
               _loc100_ = _loc97_ * 6 + 1;
               if(_loc100_ < _loc98_)
               {
                  _loc99_.visible = true;
                  _loc95_.setChildIndex(_loc99_,_loc95_.numChildren - 1);
               }
               else
               {
                  _loc99_.visible = false;
               }
            }
            _loc99_ = _loc95_.getChildByName("2");
            if(_loc99_ != null)
            {
               _loc99_.visible = false;
            }
            _loc99_ = _loc95_.getChildByName("favCard2");
            if(_loc99_ != null)
            {
               _loc100_ = _loc97_ * 6 + 2;
               if(_loc100_ < _loc98_)
               {
                  _loc99_.visible = true;
                  _loc95_.setChildIndex(_loc99_,_loc95_.numChildren - 1);
               }
               else
               {
                  _loc99_.visible = false;
               }
            }
            _loc99_ = _loc95_.getChildByName("3");
            if(_loc99_ != null)
            {
               _loc99_.visible = false;
            }
            _loc99_ = _loc95_.getChildByName("favCard3");
            if(_loc99_ != null)
            {
               _loc100_ = _loc97_ * 6 + 3;
               if(_loc100_ < _loc98_)
               {
                  _loc99_.visible = true;
                  _loc95_.setChildIndex(_loc99_,_loc95_.numChildren - 1);
               }
               else
               {
                  _loc99_.visible = false;
               }
            }
            var _loc101_:Sprite = this.fgeh0zt6xViewport;
            if(_loc101_ != null)
            {
               var _loc102_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
               var _loc103_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteStore;
               var _loc104_:DisplayObject = _loc101_.getChildByName("favCard4");
               if(_loc104_ != null)
               {
                  _loc104_.visible = false;
                  if(_loc102_ != null)
                  {
                     var _loc105_:Number = FgEHCASDialogMainX.fgeh0zt6x3Page * 6 + 4;
                     if(_loc105_ < _loc102_.length)
                     {
                        _loc104_.visible = true;
                        if(_loc103_ != null)
                        {
                           var _loc106_:* = _loc103_[_loc102_[_loc105_]];
                           if(_loc106_ != null)
                           {
                              var _loc107_:String = "img://thumbs/cas/c_" + String(_loc106_.selected_variant_id) + "_l_f";
                              var _loc108_:* = _loc104_.getChildByName("gridThumb");
                              while(true)
                              {
                                 if(_loc108_ == null)
                                 {
                                    if(!ApplicationDomain.currentDomain.hasDefinition("library.Components.GUIImage"))
                                    {
                                       break;
                                    }
                                    var _loc109_:Object = getDefinitionByName("library.Components.GUIImage");
                                    _loc108_ = new _loc109_();
                                    _loc108_.name = "gridThumb";
                                    _loc108_.mouseEnabled = false;
                                    _loc108_.width = 92;
                                    _loc108_.height = 92;
                                    _loc104_.addChild(_loc108_);
                                    _loc104_.setChildIndex(_loc108_,0);
                                 }
                                 _loc108_.LoadImage(_loc107_);
                                 break;
                              }
                           }
                        }
                     }
                  }
               }
               _loc104_ = _loc101_.getChildByName("favCard5");
               if(_loc104_ != null)
               {
                  _loc104_.visible = false;
                  if(_loc102_ != null)
                  {
                     _loc105_ = FgEHCASDialogMainX.fgeh0zt6x3Page * 6 + 5;
                     if(_loc105_ < _loc102_.length)
                     {
                        _loc104_.visible = true;
                        if(_loc103_ != null)
                        {
                           _loc106_ = _loc103_[_loc102_[_loc105_]];
                           if(_loc106_ != null)
                           {
                              _loc107_ = "img://thumbs/cas/c_" + String(_loc106_.selected_variant_id) + "_l_f";
                              _loc108_ = _loc104_.getChildByName("gridThumb");
                              while(true)
                              {
                                 if(_loc108_ == null)
                                 {
                                    if(!ApplicationDomain.currentDomain.hasDefinition("library.Components.GUIImage"))
                                    {
                                       break;
                                    }
                                    _loc109_ = getDefinitionByName("library.Components.GUIImage");
                                    _loc108_ = new _loc109_();
                                    _loc108_.name = "gridThumb";
                                    _loc108_.mouseEnabled = false;
                                    _loc108_.width = 92;
                                    _loc108_.height = 92;
                                    _loc104_.addChild(_loc108_);
                                    _loc104_.setChildIndex(_loc108_,0);
                                 }
                                 _loc108_.LoadImage(_loc107_);
                                 break;
                              }
                           }
                        }
                     }
                  }
               }
            }
            this.fgeh0zt6x15RefreshGroupUI();
         }
         var _loc110_:Sprite = this.fgeh0zt6xViewport;
         if(_loc110_ != null)
         {
            var _loc111_:DisplayObject = _loc110_.getChildByName("favCard0");
            if(_loc111_ != null)
            {
               var _loc112_:* = _loc111_.getChildByName("favStar0");
               if(_loc112_ != null)
               {
                  _loc112_.mouseEnabled = false;
                  _loc112_.buttonMode = false;
               }
            }
            _loc111_ = _loc110_.getChildByName("favCard1");
            if(_loc111_ != null)
            {
               _loc112_ = _loc111_.getChildByName("favStar1");
               if(_loc112_ != null)
               {
                  _loc112_.mouseEnabled = false;
                  _loc112_.buttonMode = false;
               }
            }
            _loc111_ = _loc110_.getChildByName("favCard2");
            if(_loc111_ != null)
            {
               _loc112_ = _loc111_.getChildByName("favStar2");
               if(_loc112_ != null)
               {
                  _loc112_.mouseEnabled = false;
                  _loc112_.buttonMode = false;
               }
            }
            _loc111_ = _loc110_.getChildByName("favCard3");
            if(_loc111_ != null)
            {
               _loc112_ = _loc111_.getChildByName("favStar3");
               if(_loc112_ != null)
               {
                  _loc112_.mouseEnabled = false;
                  _loc112_.buttonMode = false;
               }
            }
         }
         _loc111_ = _loc110_.getChildByName("favCard4");
         if(_loc111_ != null)
         {
            _loc112_ = _loc111_.getChildByName("favStar4");
            if(_loc112_ != null)
            {
               _loc112_.mouseEnabled = false;
               _loc112_.buttonMode = false;
            }
         }
         _loc111_ = _loc110_.getChildByName("favCard5");
         if(_loc111_ != null)
         {
            _loc112_ = _loc111_.getChildByName("favStar5");
            if(_loc112_ != null)
            {
               _loc112_.mouseEnabled = false;
               _loc112_.buttonMode = false;
            }
         }
      }
      
      private function fgeh0zt6x3Next(param1:MouseEvent) : void
      {
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
         if(_loc2_ != null)
         {
            var _loc3_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
            if((_loc3_ + 1) * 6 < _loc2_.length)
            {
               FgEHCASDialogMainX.fgeh0zt6x3Page = _loc3_ + 1;
               this.fgeh0zt6x3Refresh();
            }
         }
      }
      
      private function fgeh0zt6x3Prev(param1:MouseEvent) : void
      {
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
         if(_loc2_ != null)
         {
            var _loc3_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
            if(_loc3_ > 0)
            {
               FgEHCASDialogMainX.fgeh0zt6x3Page = _loc3_ - 1;
               this.fgeh0zt6x3Refresh();
            }
         }
      }
      
      private function fgeh0zt6x3Wheel(param1:MouseEvent) : void
      {
         if(param1 != null)
         {
            if(param1.delta >= 0)
            {
               this.fgeh0zt6x3Prev(param1);
            }
            else
            {
               this.fgeh0zt6x3Next(param1);
            }
         }
      }
      
      private function fgeh0zt6x4RefreshPreview() : void
      {
         var _loc1_:* = this.fgeh0zt6x4ImageHost;
         if(_loc1_ != null)
         {
            var _loc12_:Number = FgEHCASDialogMainX.fgeh0zt6x3Page * 6;
            var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
            while(true)
            {
               if(_loc2_ != null)
               {
                  if(_loc12_ < _loc2_.length)
                  {
                     var _loc3_:* = _loc2_[_loc12_];
                     if(_loc3_ != null)
                     {
                        var _loc4_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteStore;
                        if(_loc4_ != null)
                        {
                           var _loc5_:* = _loc4_[_loc3_];
                           if(_loc5_ != null)
                           {
                              var _loc6_:String = String(_loc5_.selected_variant_id);
                              var _loc7_:String = "img://thumbs/cas/c_" + _loc6_ + "_l_f";
                              if(this.fgeh0zt6x4Bound != _loc7_)
                              {
                                 this.fgeh0zt6x4Bound = _loc7_;
                                 var _loc8_:* = this.fgeh0zt6x4Image;
                                 if(_loc8_ != null)
                                 {
                                    _loc8_.visible = false;
                                    _loc1_.removeChild(_loc8_);
                                    this.fgeh0zt6x4Image = null;
                                 }
                              }
                              else
                              {
                                 _loc8_ = this.fgeh0zt6x4Image;
                                 if(_loc8_ != null)
                                 {
                                    _loc8_.visible = true;
                                    break;
                                 }
                              }
                              var _loc9_:ApplicationDomain = ApplicationDomain.currentDomain;
                              if(_loc9_.hasDefinition("library.Components.GUIImage"))
                              {
                                 var _loc10_:Object = getDefinitionByName("library.Components.GUIImage");
                                 if(_loc10_ != null)
                                 {
                                    var _loc11_:Object = new _loc10_();
                                    _loc11_.mouseEnabled = false;
                                    _loc11_.width = 46;
                                    _loc11_.height = 46;
                                    _loc1_.addChild(_loc11_);
                                    this.fgeh0zt6x4Image = _loc11_;
                                    _loc11_.LoadImage(_loc7_);
                                 }
                              }
                              break;
                           }
                        }
                     }
                  }
               }
               _loc8_ = this.fgeh0zt6x4Image;
               if(_loc8_ != null)
               {
                  _loc8_.visible = false;
               }
               break;
            }
         }
      }
      
      private function fgeh0zt6x5Refresh() : void
      {
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
         var _loc3_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
         var _loc4_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteStore;
         var _loc5_:* = this.fgeh0zt6x5Host1;
         if(_loc5_ != null)
         {
            while(true)
            {
               if(_loc2_ != null)
               {
                  if(_loc4_ != null)
                  {
                     var _loc6_:Number = _loc3_ * 6 + 1;
                     if(_loc6_ < _loc2_.length)
                     {
                        var _loc7_:* = _loc2_[_loc6_];
                        if(_loc7_ != null)
                        {
                           var _loc8_:* = _loc4_[_loc7_];
                           if(_loc8_ != null)
                           {
                              var _loc9_:String = String(_loc8_.selected_variant_id);
                              var _loc10_:String = "img://thumbs/cas/c_" + _loc9_ + "_l_f";
                              if(this.fgeh0zt6x5Bound1 != _loc10_)
                              {
                                 this.fgeh0zt6x5Bound1 = _loc10_;
                                 var _loc11_:* = this.fgeh0zt6x5Image1;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_.visible = false;
                                    _loc5_.removeChild(_loc11_);
                                    this.fgeh0zt6x5Image1 = null;
                                 }
                              }
                              else
                              {
                                 _loc11_ = this.fgeh0zt6x5Image1;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_.visible = true;
                                    break;
                                 }
                              }
                              var _loc12_:ApplicationDomain = ApplicationDomain.currentDomain;
                              if(_loc12_.hasDefinition("library.Components.GUIImage"))
                              {
                                 var _loc13_:Object = getDefinitionByName("library.Components.GUIImage");
                                 if(_loc13_ != null)
                                 {
                                    var _loc14_:Object = new _loc13_();
                                    _loc14_.mouseEnabled = false;
                                    _loc14_.width = 46;
                                    _loc14_.height = 46;
                                    _loc5_.addChild(_loc14_);
                                    this.fgeh0zt6x5Image1 = _loc14_;
                                    _loc14_.LoadImage(_loc10_);
                                 }
                              }
                              break;
                           }
                        }
                     }
                  }
               }
               _loc11_ = this.fgeh0zt6x5Image1;
               if(_loc11_ != null)
               {
                  _loc11_.visible = false;
               }
               break;
            }
         }
         _loc5_ = this.fgeh0zt6x5Host2;
         if(_loc5_ != null)
         {
            while(true)
            {
               if(_loc2_ != null)
               {
                  if(_loc4_ != null)
                  {
                     _loc6_ = _loc3_ * 6 + 2;
                     if(_loc6_ < _loc2_.length)
                     {
                        _loc7_ = _loc2_[_loc6_];
                        if(_loc7_ != null)
                        {
                           _loc8_ = _loc4_[_loc7_];
                           if(_loc8_ != null)
                           {
                              _loc9_ = String(_loc8_.selected_variant_id);
                              _loc10_ = "img://thumbs/cas/c_" + _loc9_ + "_l_f";
                              if(this.fgeh0zt6x5Bound2 != _loc10_)
                              {
                                 this.fgeh0zt6x5Bound2 = _loc10_;
                                 _loc11_ = this.fgeh0zt6x5Image2;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_.visible = false;
                                    _loc5_.removeChild(_loc11_);
                                    this.fgeh0zt6x5Image2 = null;
                                 }
                              }
                              else
                              {
                                 _loc11_ = this.fgeh0zt6x5Image2;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_.visible = true;
                                    break;
                                 }
                              }
                              _loc12_ = ApplicationDomain.currentDomain;
                              if(_loc12_.hasDefinition("library.Components.GUIImage"))
                              {
                                 _loc13_ = getDefinitionByName("library.Components.GUIImage");
                                 if(_loc13_ != null)
                                 {
                                    _loc14_ = new _loc13_();
                                    _loc14_.mouseEnabled = false;
                                    _loc14_.width = 46;
                                    _loc14_.height = 46;
                                    _loc5_.addChild(_loc14_);
                                    this.fgeh0zt6x5Image2 = _loc14_;
                                    _loc14_.LoadImage(_loc10_);
                                 }
                              }
                              break;
                           }
                        }
                     }
                  }
               }
               _loc11_ = this.fgeh0zt6x5Image2;
               if(_loc11_ != null)
               {
                  _loc11_.visible = false;
               }
               break;
            }
         }
         _loc5_ = this.fgeh0zt6x5Host3;
         if(_loc5_ != null)
         {
            while(true)
            {
               if(_loc2_ != null)
               {
                  if(_loc4_ != null)
                  {
                     _loc6_ = _loc3_ * 6 + 3;
                     if(_loc6_ < _loc2_.length)
                     {
                        _loc7_ = _loc2_[_loc6_];
                        if(_loc7_ != null)
                        {
                           _loc8_ = _loc4_[_loc7_];
                           if(_loc8_ != null)
                           {
                              _loc9_ = String(_loc8_.selected_variant_id);
                              _loc10_ = "img://thumbs/cas/c_" + _loc9_ + "_l_f";
                              if(this.fgeh0zt6x5Bound3 != _loc10_)
                              {
                                 this.fgeh0zt6x5Bound3 = _loc10_;
                                 _loc11_ = this.fgeh0zt6x5Image3;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_.visible = false;
                                    _loc5_.removeChild(_loc11_);
                                    this.fgeh0zt6x5Image3 = null;
                                 }
                              }
                              else
                              {
                                 _loc11_ = this.fgeh0zt6x5Image3;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_.visible = true;
                                    break;
                                 }
                              }
                              _loc12_ = ApplicationDomain.currentDomain;
                              if(_loc12_.hasDefinition("library.Components.GUIImage"))
                              {
                                 _loc13_ = getDefinitionByName("library.Components.GUIImage");
                                 if(_loc13_ != null)
                                 {
                                    _loc14_ = new _loc13_();
                                    _loc14_.mouseEnabled = false;
                                    _loc14_.width = 46;
                                    _loc14_.height = 46;
                                    _loc5_.addChild(_loc14_);
                                    this.fgeh0zt6x5Image3 = _loc14_;
                                    _loc14_.LoadImage(_loc10_);
                                 }
                              }
                              break;
                           }
                        }
                     }
                  }
               }
               _loc11_ = this.fgeh0zt6x5Image3;
               if(_loc11_ != null)
               {
                  _loc11_.visible = false;
               }
               break;
            }
         }
      }
      
      private function fgeh0zt6x6aSave() : void
      {
         this.fgeh0zt6x25SaveFavoriteSplit();
      }
      
      private function fgeh0zt6x6aRestore() : void
      {
         var _loc13_:String = "EMPTY";
         if(0 >= FgEHCASDialogMainX.fgeh0zt6wFavoriteCount)
         {
            var _loc1_:* = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.x6g.real.snapshot.v2");
            if(_loc1_ != null)
            {
               _loc1_ = String(_loc1_);
               var _loc2_:Array = _loc1_.split("^");
               _loc13_ = "BAD_HEADER_OR_LENGTH";
               if(_loc2_.length >= 3)
               {
                  if(_loc2_[0] == "FGCAS_FAVORITES_V2")
                  {
                     var _loc3_:int = int(_loc2_[1]);
                     if(0 < _loc3_)
                     {
                        if(_loc2_.length == _loc3_ + 2)
                        {
                           var _loc4_:Object = {};
                           var _loc5_:* = [];
                           var _loc6_:int = 0;
                           while(true)
                           {
                              if(_loc6_ >= _loc3_)
                              {
                                 _loc5_["__fgeh_x6g_first_restore_trace_v1__"] = "V2_RESTORE_COMMITTED";
                                 FgEHCASDialogMainX.fgeh0zt6wFavoriteStore = _loc4_;
                                 FgEHCASDialogMainX.fgeh0zt6x3Order = _loc5_;
                                 FgEHCASDialogMainX.fgeh0zt6wFavoriteCount = _loc3_;
                                 FgEHCASDialogMainX.fgeh0zt6x3Page = 0;
                                 this.fgeh0zt6x3Refresh();
                                 _loc13_ = "RESTORED_FROM_V2";
                                 break;
                              }
                              _loc13_ = "BAD_ROW";
                              var _loc7_:* = _loc2_[_loc6_ + 2];
                              var _loc8_:* = _loc7_.split("~");
                              if(_loc8_.length != 8)
                              {
                                 break;
                              }
                              var _loc9_:* = _loc8_[0];
                              var _loc10_:* = _loc8_[1];
                              if(_loc9_ == "")
                              {
                                 break;
                              }
                              if(_loc10_ == "")
                              {
                                 break;
                              }
                              var _loc12_:int = int(_loc8_[3]);
                              if(0 >= _loc12_)
                              {
                                 break;
                              }
                              if(_loc12_ != 32)
                              {
                                 if(32 < _loc12_)
                                 {
                                    break;
                                 }
                              }
                              if(int(_loc8_[4]) != _loc12_)
                              {
                                 break;
                              }
                              if(("|" + _loc8_[5]).indexOf("|" + _loc10_ + "|") == -1)
                              {
                                 break;
                              }
                              if(("|" + _loc8_[5]).indexOf("|" + _loc9_ + "|") == -1)
                              {
                                 break;
                              }
                              if(_loc8_[6].indexOf(_loc10_ + ":;COLORS=") == -1)
                              {
                                 break;
                              }
                              if(_loc8_[5].split("|").length != _loc12_ * 2 + 1)
                              {
                                 break;
                              }
                              if(_loc8_[6].split("|").length != _loc12_ + 1)
                              {
                                 break;
                              }
                              if(_loc4_[_loc9_] != null)
                              {
                                 break;
                              }
                              var _loc11_:Object = {
                                 "base_id":_loc8_[0],
                                 "selected_variant_id":_loc8_[1],
                                 "body_type":_loc8_[2],
                                 "variant_count":_loc8_[3],
                                 "swatch_count":_loc8_[4],
                                 "variant_ids":_loc8_[5],
                                 "swatches":_loc8_[6],
                                 "captured_request":_loc8_[7]
                              };
                              _loc4_[_loc9_] = _loc11_;
                              _loc5_.push(_loc9_);
                              _loc6_ += 1;
                           }
                        }
                     }
                  }
               }
            }
         }
         else
         {
            _loc5_ = FgEHCASDialogMainX.fgeh0zt6x3Order;
            while(true)
            {
               if(_loc5_ != null)
               {
                  if(_loc5_["__fgeh_x6g_first_restore_trace_v1__"] == "V2_RESTORE_COMMITTED")
                  {
                     _loc13_ = "RESTORED_EARLIER_FROM_V2";
                     break;
                  }
               }
               _loc13_ = "ALREADY_IN_MEMORY";
               break;
            }
         }
         var _temp_2:* = CommunicationManager;
         var _temp_1:* = "CopyToClipboard";
         "FGEH_0ZT6X6G_RESTORE;STATUS=" + _loc13_ + ";COUNT=" + String(FgEHCASDialogMainX.fgeh0zt6wFavoriteCount) + ";KEY=x6g.real.snapshot.v2";
         _temp_1;
         _temp_2;
      }
      
      private function fgeh0zt6x10Delete(param1:MouseEvent) : void
      {
         UISettings.AccountSettings.SetValue("fgeh.cas.ui.trace.v2","H33_DELETE_ENTER");
         CommunicationManager;
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
         while(true)
         {
            if(_loc2_ != null)
            {
               _loc2_ = String(_loc2_);
               if(_loc2_ != "")
               {
                  var _loc3_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
                  if(_loc3_ != null)
                  {
                     var _loc4_:* = _loc3_.indexOf(_loc2_);
                     if(_loc4_ >= 0)
                     {
                        _loc3_.splice(_loc4_,1);
                        var _loc5_:* = _loc3_.length;
                        FgEHCASDialogMainX.fgeh0zt6wFavoriteCount = _loc5_;
                        UISettings.AccountSettings.SetValue("fgeh.cas.ui.trace.v2","H33_DELETE_SPLICE_OK");
                        CommunicationManager;
                        var _loc6_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                        if(_loc6_ != null)
                        {
                           _loc6_[_loc2_] = "";
                        }
                        FgEHCASDialogMainX.fgeh0zt6x15EditBase = "";
                        this.fgeh0zt6x15SaveGroups();
                        this.fgeh0zt6x6aSave();
                        this.fgeh0zt6x15RebuildView();
                        this.fgeh0zt6x3Refresh();
                        this.fgeh0zt6x15RefreshGroupUI();
                        UISettings.AccountSettings.SetValue("fgeh.cas.ui.trace.v2","H33_DELETE_DONE");
                        CommunicationManager;
                        if(param1 != null)
                        {
                           param1.stopImmediatePropagation();
                        }
                        break;
                     }
                     UISettings.AccountSettings.SetValue("fgeh.cas.ui.trace.v2","H33_DELETE_NOT_FOUND");
                     CommunicationManager;
                     break;
                  }
                  UISettings.AccountSettings.SetValue("fgeh.cas.ui.trace.v2","H33_DELETE_NO_ORDER");
                  CommunicationManager;
                  break;
               }
            }
            UISettings.AccountSettings.SetValue("fgeh.cas.ui.trace.v2","H33_DELETE_NO_EDIT");
            CommunicationManager;
            break;
         }
         var _loc30_:String = "FGEH_H38_DELETE_EXPORT;LOCAL=";
         var _loc20_:* = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.v3.manifest");
         if(_loc20_ != null)
         {
            _loc30_ += "LOCAL_SET";
         }
         else
         {
            _loc30_ += "LOCAL_NULL";
         }
         var _loc21_:* = CommunicationManager.CallUIService("GetUIAccountSettings",null);
         _loc30_ += ";SERVICE=";
         if(_loc21_ != null)
         {
            if(_loc21_ != undefined)
            {
               if(_loc21_ is Array)
               {
                  _loc30_ += "ARRAY";
                  var _loc22_:* = 0;
                  var _loc26_:* = 0;
                  var _loc27_:* = 0;
                  var _loc28_:* = 0;
                  for(; _loc22_ < _loc21_.length; _loc22_ += 1)
                  {
                     var _loc23_:* = _loc21_[_loc22_];
                     if(_loc23_ is Array)
                     {
                        if(_loc23_.length == 2)
                        {
                           var _loc24_:* = _loc23_[0];
                           if(_loc24_ != null)
                           {
                              if(_loc24_ != undefined)
                              {
                                 _loc24_ = String(_loc24_);
                                 var _loc31_:int = _loc24_.indexOf("#fgeh.cas.favorites.v3.manifest#string");
                                 if(_loc31_ >= 0)
                                 {
                                    if(_loc31_ + "#fgeh.cas.favorites.v3.manifest#string".length == _loc24_.length)
                                    {
                                       _loc26_ += 1;
                                       var _loc25_:* = _loc23_[1];
                                       if(_loc25_ == _loc20_)
                                       {
                                          _loc27_ += 1;
                                       }
                                    }
                                 }
                                 continue;
                              }
                           }
                        }
                     }
                     _loc28_ += 1;
                  }
                  var _loc29_:String = "MISSING";
                  if(_loc26_ != 0)
                  {
                     if(_loc26_ == 1)
                     {
                        _loc29_ = "STALE";
                        if(_loc27_ == 1)
                        {
                           _loc29_ = "MATCH";
                        }
                     }
                     else
                     {
                        _loc29_ = "DUPLICATE";
                     }
                  }
                  _loc30_ = _loc30_ + ";EXPORT=" + _loc29_ + ";MATCHES=" + String(_loc26_) + ";BAD_ROWS=" + String(_loc28_) + ";ARRAY_LEN=" + String(_loc21_.length);
               }
               else
               {
                  _loc30_ += "NON_ARRAY";
               }
            }
            else
            {
               _loc30_ += "UNDEFINED";
            }
         }
         else
         {
            _loc30_ += "NULL";
         }
         var _temp_2:* = CommunicationManager;
         var _temp_1:* = "CopyToClipboard";
         _loc30_;
         _temp_1;
         _temp_2;
      }
      
      private function fgeh0zt6x15RebuildView() : void
      {
         var _loc1_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
         if(_loc1_ == null)
         {
            var _loc4_:* = [];
            FgEHCASDialogMainX.fgeh0zt6x15ViewOrder = _loc4_;
         }
         else
         {
            while(true)
            {
               if(_loc2_ != null)
               {
                  _loc2_ = String(_loc2_);
                  if(_loc2_ != "")
                  {
                     var _loc3_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                     _loc4_ = [];
                     var _loc5_:int = 0;
                     while(_loc5_ < _loc1_.length)
                     {
                        var _loc6_:String = String(_loc1_[_loc5_]);
                        var _loc7_:* = "";
                        if(_loc3_ != null)
                        {
                           _loc7_ = _loc3_[_loc6_];
                           if(_loc7_ != null)
                           {
                              _loc7_ = String(_loc7_);
                              if(_loc7_ != "")
                              {
                                 var _loc8_:Array = _loc7_.split("|");
                                 if(_loc8_.indexOf(_loc2_) > -1)
                                 {
                                    _loc4_.push(_loc6_);
                                 }
                              }
                           }
                        }
                        _loc5_ += 1;
                     }
                     FgEHCASDialogMainX.fgeh0zt6x15ViewOrder = _loc4_;
                     break;
                  }
               }
               FgEHCASDialogMainX.fgeh0zt6x15ViewOrder = _loc1_;
               break;
            }
         }
         _loc4_ = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
         var _loc9_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
         var _loc10_:* = 0;
         if(_loc4_ != null)
         {
            _loc10_ = _loc4_.length;
            while(_loc9_ > 0)
            {
               if(_loc9_ * 6 < _loc10_)
               {
                  break;
               }
               _loc9_ -= 1;
            }
         }
         else
         {
            _loc9_ = 0;
         }
         FgEHCASDialogMainX.fgeh0zt6x3Page = _loc9_;
      }
      
      private function fgeh0zt6x15RefreshGroupUI() : void
      {
         var _loc1_:Sprite = this.fgeh0zt6xViewport;
         if(_loc1_ != null)
         {
            var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
            var _loc3_:* = FgEHCASDialogMainX.fgeh0zt6x15TabPage;
            var _loc4_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
            var _loc5_:* = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
            var _loc6_:* = FgEHCASDialogMainX.fgeh0zt6x15CreateMode;
            var _loc18_:DisplayObject = _loc1_.getChildByName("manageTint");
            if(_loc18_ != null)
            {
               while(true)
               {
                  if(_loc4_ != null)
                  {
                     var _loc14_:* = String(_loc4_);
                     if(_loc14_ != "")
                     {
                        _loc18_.visible = true;
                        break;
                     }
                  }
                  _loc18_.visible = false;
                  break;
               }
            }
            var _loc7_:DisplayObject = _loc1_.getChildByName("gtAll");
            if(_loc7_ != null)
            {
               var _loc8_:* = _loc7_.getChildByName("label");
               _loc14_ = _loc7_.getChildByName("doneMark");
               while(true)
               {
                  if(_loc4_ != null)
                  {
                     var _loc13_:* = String(_loc4_);
                     if(_loc13_ != "")
                     {
                        if(_loc8_ != null)
                        {
                           _loc8_.text = "";
                        }
                        if(_loc14_ != null)
                        {
                           _loc14_.visible = true;
                        }
                        break;
                     }
                  }
                  if(_loc8_ != null)
                  {
                     _loc8_.text = LocKey.FromHash(3405684798).toString();
                  }
                  if(_loc14_ != null)
                  {
                     _loc14_.visible = false;
                  }
                  break;
               }
               var _loc9_:* = _loc7_.getChildByName("sel");
               if(_loc9_ != null)
               {
                  while(true)
                  {
                     if(_loc4_ == "")
                     {
                        if(_loc5_ != null)
                        {
                           _loc14_ = String(_loc5_);
                           if(_loc14_ != "")
                           {
                              addr0127:
                              _loc9_.visible = false;
                              break;
                           }
                        }
                        _loc9_.visible = true;
                        break;
                     }
                     §§goto(addr0127);
                  }
               }
            }
            _loc7_ = _loc1_.getChildByName("gt0");
            if(_loc7_ != null)
            {
               var _loc10_:Number = _loc3_ * 3 + 0;
               loop3:
               while(true)
               {
                  if(_loc2_ != null)
                  {
                     if(_loc10_ < _loc2_.length)
                     {
                        _loc7_.visible = true;
                        var _loc11_:String = String(_loc2_[_loc10_]);
                        _loc8_ = _loc7_.getChildByName("label");
                        if(_loc8_ != null)
                        {
                           _loc8_.text = _loc11_;
                        }
                        _loc9_ = _loc7_.getChildByName("sel");
                        if(_loc9_ != null)
                        {
                           loop4:
                           while(true)
                           {
                              while(true)
                              {
                                 if(_loc4_ != null)
                                 {
                                    _loc14_ = String(_loc4_);
                                    if(_loc14_ != "")
                                    {
                                       var _loc12_:* = "";
                                       _loc13_ = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                       if(_loc13_ != null)
                                       {
                                          _loc12_ = _loc13_[_loc4_];
                                          if(_loc12_ != null)
                                          {
                                             _loc12_ = String(_loc12_);
                                             if(_loc12_ != "")
                                             {
                                                _loc13_ = _loc12_.split("|");
                                                if(_loc13_.indexOf(_loc11_) > -1)
                                                {
                                                   break;
                                                }
                                             }
                                          }
                                       }
                                       break loop4;
                                    }
                                 }
                                 if(_loc5_ == _loc11_)
                                 {
                                    break;
                                 }
                                 break loop4;
                              }
                              _loc9_.visible = true;
                              break loop3;
                           }
                           _loc9_.visible = false;
                        }
                        break;
                     }
                  }
                  _loc7_.visible = false;
                  break;
               }
            }
            _loc7_ = _loc1_.getChildByName("gt1");
            if(_loc7_ != null)
            {
               _loc10_ = _loc3_ * 3 + 1;
               loop6:
               while(true)
               {
                  if(_loc2_ != null)
                  {
                     if(_loc10_ < _loc2_.length)
                     {
                        _loc7_.visible = true;
                        _loc11_ = String(_loc2_[_loc10_]);
                        _loc8_ = _loc7_.getChildByName("label");
                        if(_loc8_ != null)
                        {
                           _loc8_.text = _loc11_;
                        }
                        _loc9_ = _loc7_.getChildByName("sel");
                        if(_loc9_ != null)
                        {
                           loop7:
                           while(true)
                           {
                              while(true)
                              {
                                 if(_loc4_ != null)
                                 {
                                    _loc14_ = String(_loc4_);
                                    if(_loc14_ != "")
                                    {
                                       _loc12_ = "";
                                       _loc13_ = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                       if(_loc13_ != null)
                                       {
                                          _loc12_ = _loc13_[_loc4_];
                                          if(_loc12_ != null)
                                          {
                                             _loc12_ = String(_loc12_);
                                             if(_loc12_ != "")
                                             {
                                                _loc13_ = _loc12_.split("|");
                                                if(_loc13_.indexOf(_loc11_) > -1)
                                                {
                                                   break;
                                                }
                                             }
                                          }
                                       }
                                       break loop7;
                                    }
                                 }
                                 if(_loc5_ == _loc11_)
                                 {
                                    break;
                                 }
                                 break loop7;
                              }
                              _loc9_.visible = true;
                              break loop6;
                           }
                           _loc9_.visible = false;
                        }
                        break;
                     }
                  }
                  _loc7_.visible = false;
                  break;
               }
            }
            _loc7_ = _loc1_.getChildByName("gt2");
            if(_loc7_ != null)
            {
               _loc10_ = _loc3_ * 3 + 2;
               loop9:
               while(true)
               {
                  if(_loc2_ != null)
                  {
                     if(_loc10_ < _loc2_.length)
                     {
                        _loc7_.visible = true;
                        _loc11_ = String(_loc2_[_loc10_]);
                        _loc8_ = _loc7_.getChildByName("label");
                        if(_loc8_ != null)
                        {
                           _loc8_.text = _loc11_;
                        }
                        _loc9_ = _loc7_.getChildByName("sel");
                        if(_loc9_ != null)
                        {
                           loop10:
                           while(true)
                           {
                              while(true)
                              {
                                 if(_loc4_ != null)
                                 {
                                    _loc14_ = String(_loc4_);
                                    if(_loc14_ != "")
                                    {
                                       _loc12_ = "";
                                       _loc13_ = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                       if(_loc13_ != null)
                                       {
                                          _loc12_ = _loc13_[_loc4_];
                                          if(_loc12_ != null)
                                          {
                                             _loc12_ = String(_loc12_);
                                             if(_loc12_ != "")
                                             {
                                                _loc13_ = _loc12_.split("|");
                                                if(_loc13_.indexOf(_loc11_) > -1)
                                                {
                                                   break;
                                                }
                                             }
                                          }
                                       }
                                       break loop10;
                                    }
                                 }
                                 if(_loc5_ == _loc11_)
                                 {
                                    break;
                                 }
                                 break loop10;
                              }
                              _loc9_.visible = true;
                              break loop9;
                           }
                           _loc9_.visible = false;
                        }
                        break;
                     }
                  }
                  _loc7_.visible = false;
                  break;
               }
            }
            _loc7_ = _loc1_.getChildByName("gtPrev");
            if(_loc7_ != null)
            {
               while(true)
               {
                  if(_loc6_ != true)
                  {
                     if(_loc3_ > 0)
                     {
                        _loc7_.visible = true;
                        break;
                     }
                  }
                  _loc7_.visible = false;
                  break;
               }
            }
            _loc7_ = _loc1_.getChildByName("gtNext");
            if(_loc7_ != null)
            {
               while(true)
               {
                  if(_loc6_ != true)
                  {
                     if(_loc2_ != null)
                     {
                        if((_loc3_ + 1) * 3 < _loc2_.length)
                        {
                           _loc7_.visible = true;
                           break;
                        }
                     }
                  }
                  _loc7_.visible = false;
                  break;
               }
            }
            _loc7_ = _loc1_.getChildByName("groupInput");
            if(_loc7_ != null)
            {
               _loc7_.visible = _loc6_;
            }
            _loc7_ = _loc1_.getChildByName("groupOk");
            if(_loc7_ != null)
            {
               _loc7_.visible = _loc6_;
            }
            _loc7_ = _loc1_.getChildByName("groupCancel");
            if(_loc7_ != null)
            {
               _loc7_.visible = _loc6_;
            }
            var _loc15_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
            var _loc16_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
            _loc7_ = _loc1_.getChildByName("favCard0");
            if(_loc7_ != null)
            {
               _loc9_ = _loc7_.getChildByName("editSel");
               if(_loc9_ != null)
               {
                  while(true)
                  {
                     if(_loc4_ != null)
                     {
                        _loc14_ = String(_loc4_);
                        if(_loc14_ != "")
                        {
                           if(_loc15_ != null)
                           {
                              _loc10_ = _loc16_ * 6 + 0;
                              if(_loc10_ < _loc15_.length)
                              {
                                 var _loc17_:String = String(_loc15_[_loc10_]);
                                 if(_loc17_ == _loc4_)
                                 {
                                    _loc9_.visible = true;
                                    break;
                                 }
                              }
                           }
                        }
                     }
                     _loc9_.visible = false;
                     break;
                  }
               }
            }
            _loc7_ = _loc1_.getChildByName("favCard1");
            if(_loc7_ != null)
            {
               _loc9_ = _loc7_.getChildByName("editSel");
               if(_loc9_ != null)
               {
                  while(true)
                  {
                     if(_loc4_ != null)
                     {
                        _loc14_ = String(_loc4_);
                        if(_loc14_ != "")
                        {
                           if(_loc15_ != null)
                           {
                              _loc10_ = _loc16_ * 6 + 1;
                              if(_loc10_ < _loc15_.length)
                              {
                                 _loc17_ = String(_loc15_[_loc10_]);
                                 if(_loc17_ == _loc4_)
                                 {
                                    _loc9_.visible = true;
                                    break;
                                 }
                              }
                           }
                        }
                     }
                     _loc9_.visible = false;
                     break;
                  }
               }
            }
            _loc7_ = _loc1_.getChildByName("favCard2");
            if(_loc7_ != null)
            {
               _loc9_ = _loc7_.getChildByName("editSel");
               if(_loc9_ != null)
               {
                  while(true)
                  {
                     if(_loc4_ != null)
                     {
                        _loc14_ = String(_loc4_);
                        if(_loc14_ != "")
                        {
                           if(_loc15_ != null)
                           {
                              _loc10_ = _loc16_ * 6 + 2;
                              if(_loc10_ < _loc15_.length)
                              {
                                 _loc17_ = String(_loc15_[_loc10_]);
                                 if(_loc17_ == _loc4_)
                                 {
                                    _loc9_.visible = true;
                                    break;
                                 }
                              }
                           }
                        }
                     }
                     _loc9_.visible = false;
                     break;
                  }
               }
            }
            _loc7_ = _loc1_.getChildByName("favCard3");
            if(_loc7_ != null)
            {
               _loc9_ = _loc7_.getChildByName("editSel");
               if(_loc9_ != null)
               {
                  while(true)
                  {
                     if(_loc4_ != null)
                     {
                        _loc14_ = String(_loc4_);
                        if(_loc14_ != "")
                        {
                           if(_loc15_ != null)
                           {
                              _loc10_ = _loc16_ * 6 + 3;
                              if(_loc10_ < _loc15_.length)
                              {
                                 _loc17_ = String(_loc15_[_loc10_]);
                                 if(_loc17_ == _loc4_)
                                 {
                                    _loc9_.visible = true;
                                    break;
                                 }
                              }
                           }
                        }
                     }
                     _loc9_.visible = false;
                     break;
                  }
               }
            }
         }
         _loc7_ = _loc1_.getChildByName("favCard4");
         if(_loc7_ != null)
         {
            _loc9_ = _loc7_.getChildByName("editSel");
            if(_loc9_ != null)
            {
               while(true)
               {
                  if(_loc4_ != null)
                  {
                     _loc14_ = String(_loc4_);
                     if(_loc14_ != "")
                     {
                        if(_loc15_ != null)
                        {
                           _loc10_ = _loc16_ * 6 + 4;
                           if(_loc10_ < _loc15_.length)
                           {
                              _loc17_ = String(_loc15_[_loc10_]);
                              if(_loc17_ == _loc4_)
                              {
                                 _loc9_.visible = true;
                                 break;
                              }
                           }
                        }
                     }
                  }
                  _loc9_.visible = false;
                  break;
               }
            }
         }
         _loc7_ = _loc1_.getChildByName("favCard5");
         if(_loc7_ != null)
         {
            _loc9_ = _loc7_.getChildByName("editSel");
            if(_loc9_ != null)
            {
               while(true)
               {
                  if(_loc4_ != null)
                  {
                     _loc14_ = String(_loc4_);
                     if(_loc14_ != "")
                     {
                        if(_loc15_ != null)
                        {
                           _loc10_ = _loc16_ * 6 + 5;
                           if(_loc10_ < _loc15_.length)
                           {
                              _loc17_ = String(_loc15_[_loc10_]);
                              if(_loc17_ == _loc4_)
                              {
                                 _loc9_.visible = true;
                                 break;
                              }
                           }
                        }
                     }
                  }
                  _loc9_.visible = false;
                  break;
               }
            }
         }
         _loc1_ = this.fgeh0zt6xViewport;
         if(_loc1_ != null)
         {
            _loc7_ = _loc1_.getChildByName("groupDelete");
            if(_loc7_ != null)
            {
               _loc7_.visible = false;
               if(FgEHCASDialogMainX.fgeh0zt6x15CreateMode == true)
               {
                  _loc15_ = FgEHCASDialogMainX.fgeh0zt6x28EditGroup;
                  if(_loc15_ != null)
                  {
                     _loc15_ = String(_loc15_);
                     if(_loc15_ != "")
                     {
                        _loc7_.visible = true;
                     }
                  }
               }
            }
         }
         var _loc40_:Sprite = this.fgeh0zt6xViewport;
         if(_loc40_ != null)
         {
            var _loc43_:DisplayObject = _loc40_.getChildByName("1");
            if(_loc43_ != null)
            {
               _loc43_.visible = false;
            }
            _loc43_ = _loc40_.getChildByName("2");
            if(_loc43_ != null)
            {
               _loc43_.visible = false;
            }
            _loc43_ = _loc40_.getChildByName("3");
            if(_loc43_ != null)
            {
               _loc43_.visible = false;
            }
            var _loc41_:DisplayObject = _loc40_.getChildByName("0");
            if(_loc41_ != null)
            {
               _loc41_.x = 8;
               _loc41_.y = 8;
               _loc41_.width = 30;
               _loc41_.height = 30;
               _loc41_.visible = false;
               var _loc42_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
               if(_loc42_ != null)
               {
                  _loc42_ = String(_loc42_);
                  if(_loc42_ != "")
                  {
                     _loc41_.visible = true;
                     _loc40_.setChildIndex(_loc41_,_loc40_.numChildren - 1);
                  }
               }
            }
         }
      }
      
      private function fgeh0zt6x15HoldStart(param1:*) : void
      {
         if(param1 != null)
         {
            var _loc9_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
            while(true)
            {
               if(_loc9_ != null)
               {
                  _loc9_ = String(_loc9_);
                  if(_loc9_ != "")
                  {
                     break;
                  }
               }
               var _loc2_:* = param1.currentTarget;
               if(_loc2_ != null)
               {
                  var _loc3_:String = String(_loc2_.name);
                  var _loc4_:int = -1;
                  if(_loc3_ == "favCard0")
                  {
                     _loc4_ = 0;
                  }
                  else if(_loc3_ == "favCard1")
                  {
                     _loc4_ = 1;
                  }
                  else if(_loc3_ == "favCard2")
                  {
                     _loc4_ = 2;
                  }
                  else if(_loc3_ == "favCard3")
                  {
                     _loc4_ = 3;
                  }
                  else if(_loc3_ == "favCard4")
                  {
                     _loc4_ = 4;
                  }
                  else
                  {
                     if(_loc3_ != "favCard5")
                     {
                        break;
                     }
                     _loc4_ = 5;
                  }
                  var _loc5_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
                  var _loc6_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
                  var _loc7_:Number = _loc6_ * 6 + _loc4_;
                  if(_loc5_ != null)
                  {
                     if(_loc7_ < _loc5_.length)
                     {
                        var _loc8_:String = String(_loc5_[_loc7_]);
                        if(_loc8_ != "")
                        {
                           FgEHCASDialogMainX.fgeh0zt6x15EditBase = _loc8_;
                           FgEHCASDialogMainX.fgeh0zt6x15CreateMode = false;
                           this.fgeh0zt6x15RefreshGroupUI();
                           param1.stopImmediatePropagation();
                        }
                     }
                  }
               }
               break;
            }
         }
      }
      
      private function fgeh0zt6x15HoldTick(param1:*) : void
      {
         var _loc10_:int = FgEHCASDialogMainX.fgeh0zt6x15HoldFrames + 1;
         FgEHCASDialogMainX.fgeh0zt6x15HoldFrames = _loc10_;
         if(_loc10_ >= 30)
         {
            FgEHCASDialogMainX.fgeh0zt6x15HoldFrames = 0;
            if(FgEHCASDialogMainX.fgeh0zt6x15HoldLong == true)
            {
               this.fgeh0zt6x15SaveGroups();
            }
            else if(FgEHCASDialogMainX.fgeh0zt6x15HoldSlot != -2)
            {
               this.fgeh0zt6x19RestoreGroups();
               if(FgEHCASDialogMainX.fgeh0zt6x15HoldSlot == -2)
               {
                  this.fgeh0zt6x15RebuildView();
                  this.fgeh0zt6x3Refresh();
                  this.fgeh0zt6x15RefreshGroupUI();
               }
            }
         }
      }
      
      private function fgeh0zt6x15HoldEnd(param1:*) : void
      {
         var _loc13_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
         _loc13_ = String(_loc13_);
         if(_loc13_ == "")
         {
            if(param1 != null)
            {
               var _loc2_:* = param1.currentTarget;
               if(_loc2_ != null)
               {
                  var _loc3_:String = String(_loc2_.name);
                  var _loc4_:int = -1;
                  if(_loc3_ == "favStar0")
                  {
                     _loc4_ = 0;
                     addr0096:
                     var _loc5_:* = FgEHCASDialogMainX.fgeh0zt6x15ViewOrder;
                     var _loc6_:int = FgEHCASDialogMainX.fgeh0zt6x3Page;
                     var _loc7_:Number = _loc6_ * 6 + _loc4_;
                     if(_loc5_ != null)
                     {
                        if(_loc7_ < _loc5_.length)
                        {
                           var _loc8_:String = String(_loc5_[_loc7_]);
                           var _loc9_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
                           if(_loc9_ != null)
                           {
                              var _loc10_:* = _loc9_.indexOf(_loc8_);
                              if(_loc10_ >= 0)
                              {
                                 _loc9_.splice(_loc10_,1);
                                 var _loc12_:* = _loc9_.length;
                                 FgEHCASDialogMainX.fgeh0zt6wFavoriteCount = _loc12_;
                                 var _loc11_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                 if(_loc11_ != null)
                                 {
                                    _loc11_[_loc8_] = "";
                                 }
                                 this.fgeh0zt6x15SaveGroups();
                                 this.fgeh0zt6x6aSave();
                                 this.fgeh0zt6x15RebuildView();
                                 this.fgeh0zt6x3Refresh();
                                 this.fgeh0zt6x15RefreshGroupUI();
                              }
                           }
                        }
                     }
                  }
                  else if(_loc3_ == "favStar1")
                  {
                     _loc4_ = 1;
                     §§goto(addr0096);
                  }
                  else if(_loc3_ == "favStar2")
                  {
                     _loc4_ = 2;
                     §§goto(addr0096);
                  }
                  else if(_loc3_ == "favStar3")
                  {
                     _loc4_ = 3;
                     §§goto(addr0096);
                  }
                  else if(_loc3_ == "favStar4")
                  {
                     _loc4_ = 4;
                     §§goto(addr0096);
                  }
                  else if(_loc3_ == "favStar5")
                  {
                     _loc4_ = 5;
                     §§goto(addr0096);
                  }
               }
            }
         }
      }
      
      private function fgeh0zt6x15HoldCancel(param1:*) : void
      {
         if(param1 != null)
         {
            param1.stopImmediatePropagation();
         }
         this.fgeh0zt6x15RefreshGroupUI();
      }
      
      private function fgeh0zt6x15TabClick(param1:*) : void
      {
         if(param1 != null)
         {
            var _loc2_:* = param1.currentTarget;
            if(_loc2_ != null)
            {
               var _loc3_:String = String(_loc2_.name);
               var _loc4_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
               var _loc5_:* = FgEHCASDialogMainX.fgeh0zt6x15TabPage;
               if(_loc3_ == "groupDelete")
               {
                  var _loc13_:* = FgEHCASDialogMainX.fgeh0zt6x28EditGroup;
                  if(_loc13_ != null)
                  {
                     _loc13_ = String(_loc13_);
                     if(_loc13_ != "")
                     {
                        _loc4_ = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
                        var _loc6_:* = _loc4_.indexOf(_loc13_);
                        if(_loc6_ >= 0)
                        {
                           _loc4_.splice(_loc6_,1);
                        }
                        var _loc9_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                        var _loc15_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
                        var _loc16_:* = 0;
                        while(_loc15_ != null)
                        {
                           if(_loc16_ >= _loc15_.length)
                           {
                              break;
                           }
                           var _loc17_:String = String(_loc15_[_loc16_]);
                           var _loc10_:* = "";
                           if(_loc9_ != null)
                           {
                              _loc10_ = _loc9_[_loc17_];
                              if(_loc10_ != null)
                              {
                                 _loc10_ = String(_loc10_);
                                 if(_loc10_ != "")
                                 {
                                    var _loc11_:Array = _loc10_.split("|");
                                    while(true)
                                    {
                                       var _loc12_:int = _loc11_.indexOf(_loc13_);
                                       if(_loc12_ < 0)
                                       {
                                          break;
                                       }
                                       _loc11_.splice(_loc12_,1);
                                    }
                                    _loc9_[_loc17_] = _loc11_.join("|");
                                 }
                              }
                           }
                           _loc16_ += 1;
                        }
                        _loc13_ = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
                        if(_loc13_ != null)
                        {
                           _loc13_ = String(_loc13_);
                           if(_loc13_ == FgEHCASDialogMainX.fgeh0zt6x28EditGroup)
                           {
                              FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup = "";
                           }
                        }
                        FgEHCASDialogMainX.fgeh0zt6x28EditGroup = "";
                        FgEHCASDialogMainX.fgeh0zt6x15TabPage = 0;
                        this.fgeh0zt6x15SaveGroups();
                        this.fgeh0zt6x15RebuildView();
                        this.fgeh0zt6x3Refresh();
                        this.fgeh0zt6x15RefreshGroupUI();
                     }
                  }
               }
               else if(_loc3_ == "gtAdd")
               {
                  FgEHCASDialogMainX.fgeh0zt6x15CreateMode = true;
                  this.fgeh0zt6x15RefreshGroupUI();
               }
               else if(_loc3_ == "gtPrev")
               {
                  if(_loc5_ > 0)
                  {
                     FgEHCASDialogMainX.fgeh0zt6x15TabPage = _loc5_ - 1;
                     this.fgeh0zt6x15RefreshGroupUI();
                  }
               }
               else if(_loc3_ == "gtNext")
               {
                  if(_loc4_ != null)
                  {
                     if((_loc5_ + 1) * 3 < _loc4_.length)
                     {
                        FgEHCASDialogMainX.fgeh0zt6x15TabPage = _loc5_ + 1;
                        this.fgeh0zt6x15RefreshGroupUI();
                     }
                  }
               }
               else if(_loc3_ == "gtAll")
               {
                  var _loc8_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
                  while(true)
                  {
                     if(_loc8_ != null)
                     {
                        _loc8_ = String(_loc8_);
                        if(_loc8_ != "")
                        {
                           FgEHCASDialogMainX.fgeh0zt6x15EditBase = "";
                           FgEHCASDialogMainX.fgeh0zt6x15CreateMode = false;
                           FgEHCASDialogMainX.fgeh0zt6x28EditGroup = "";
                           this.fgeh0zt6x15RebuildView();
                           this.fgeh0zt6x3Refresh();
                           this.fgeh0zt6x15RefreshGroupUI();
                           break;
                        }
                     }
                     FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup = "";
                     FgEHCASDialogMainX.fgeh0zt6x3Page = 0;
                     this.fgeh0zt6x15RebuildView();
                     this.fgeh0zt6x3Refresh();
                     this.fgeh0zt6x15RefreshGroupUI();
                     break;
                  }
               }
               else
               {
                  _loc6_ = -1;
                  if(_loc3_ == "gt0")
                  {
                     _loc6_ = _loc5_ * 3 + 0;
                     addr028c:
                     if(_loc4_ != null)
                     {
                        if(_loc6_ < _loc4_.length)
                        {
                           var _loc7_:String = String(_loc4_[_loc6_]);
                           _loc8_ = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
                           while(true)
                           {
                              if(_loc8_ != null)
                              {
                                 _loc8_ = String(_loc8_);
                                 if(_loc8_ != "")
                                 {
                                    _loc9_ = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                    if(_loc9_ == null)
                                    {
                                       _loc9_ = {};
                                       FgEHCASDialogMainX.fgeh0zt6x15GroupMap = _loc9_;
                                    }
                                    _loc10_ = _loc9_[_loc8_];
                                    if(_loc10_ == null)
                                    {
                                       _loc11_ = [];
                                    }
                                    else
                                    {
                                       _loc11_ = String(_loc10_).split("|");
                                    }
                                    _loc12_ = _loc11_.indexOf(_loc7_);
                                    if(_loc12_ < 0)
                                    {
                                       _loc11_.push(_loc7_);
                                    }
                                    else
                                    {
                                       _loc11_.splice(_loc12_,1);
                                    }
                                    _loc9_[_loc8_] = _loc11_.join("|");
                                    this.fgeh0zt6x15SaveGroups();
                                    this.fgeh0zt6x15RefreshGroupUI();
                                    break;
                                 }
                              }
                              _loc13_ = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
                              if(_loc13_ != null)
                              {
                                 _loc13_ = String(_loc13_);
                                 if(_loc13_ == _loc7_)
                                 {
                                    break;
                                 }
                              }
                              FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup = _loc7_;
                              FgEHCASDialogMainX.fgeh0zt6x3Page = 0;
                              this.fgeh0zt6x15RebuildView();
                              this.fgeh0zt6x3Refresh();
                              this.fgeh0zt6x15RefreshGroupUI();
                              break;
                           }
                        }
                     }
                  }
                  else if(_loc3_ == "gt1")
                  {
                     _loc6_ = _loc5_ * 3 + 1;
                     §§goto(addr028c);
                  }
                  else if(_loc3_ == "gt2")
                  {
                     _loc6_ = _loc5_ * 3 + 2;
                     §§goto(addr028c);
                  }
               }
            }
         }
         var _loc14_:String = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
         _loc15_ = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.groups.v1");
         _loc16_ = "FGEH_H48_TAB;ACTIVE=" + _loc14_ + ";RAW=" + _loc15_;
         CommunicationManager.CallGameService("CopyToClipboard",_loc16_);
      }
      
      private function fgeh0zt6x15CreateOK(param1:*) : void
      {
         var _loc2_:Sprite = this.fgeh0zt6xViewport;
         if(_loc2_ != null)
         {
            var _loc3_:DisplayObject = _loc2_.getChildByName("groupInput");
            if(_loc3_ != null)
            {
               var _loc4_:String = String(_loc3_.text);
               if(_loc4_ != "")
               {
                  if(_loc4_.indexOf("^") == -1)
                  {
                     if(_loc4_.indexOf("~") == -1)
                     {
                        if(_loc4_.indexOf("|") == -1)
                        {
                           var _loc16_:* = FgEHCASDialogMainX.fgeh0zt6x28EditGroup;
                           while(true)
                           {
                              if(_loc16_ != null)
                              {
                                 _loc16_ = String(_loc16_);
                                 if(_loc16_ != "")
                                 {
                                    var _loc5_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
                                    if(_loc5_ != null)
                                    {
                                       if(_loc4_ == _loc16_)
                                       {
                                          var _loc6_:* = _loc5_.indexOf(_loc4_);
                                          if(_loc6_ < 0)
                                          {
                                             break;
                                          }
                                          _loc6_ = _loc5_.indexOf(_loc16_);
                                          if(_loc6_ >= 0)
                                          {
                                             break;
                                          }
                                          _loc5_[_loc6_] = _loc4_;
                                          var _loc8_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                          var _loc9_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
                                          var _loc10_:int = 0;
                                          while(_loc9_ != null)
                                          {
                                             if(_loc10_ >= _loc9_.length)
                                             {
                                                break;
                                             }
                                             var _loc11_:String = String(_loc9_[_loc10_]);
                                             var _loc12_:* = "";
                                             if(_loc8_ != null)
                                             {
                                                _loc12_ = _loc8_[_loc11_];
                                                if(_loc12_ != null)
                                                {
                                                   _loc12_ = String(_loc12_);
                                                   if(_loc12_ != "")
                                                   {
                                                      var _loc13_:Array = _loc12_.split("|");
                                                      var _loc14_:int = _loc13_.indexOf(_loc16_);
                                                      if(_loc14_ < 0)
                                                      {
                                                         _loc13_[_loc14_] = _loc4_;
                                                         _loc8_[_loc11_] = _loc13_.join("|");
                                                      }
                                                   }
                                                }
                                             }
                                             _loc10_ += 1;
                                          }
                                          var _loc17_:* = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
                                          if(_loc17_ != null)
                                          {
                                             _loc17_ = String(_loc17_);
                                             if(_loc17_ == _loc16_)
                                             {
                                                FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup = _loc4_;
                                             }
                                          }
                                       }
                                       FgEHCASDialogMainX.fgeh0zt6x28EditGroup = "";
                                       FgEHCASDialogMainX.fgeh0zt6x15CreateMode = false;
                                       _loc3_.text = "";
                                       this.fgeh0zt6x15SaveGroups();
                                       this.fgeh0zt6x15RebuildView();
                                       this.fgeh0zt6x3Refresh();
                                       this.fgeh0zt6x15RefreshGroupUI();
                                    }
                                    break;
                                 }
                              }
                              _loc5_ = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
                              if(_loc5_ == null)
                              {
                                 _loc5_ = [];
                                 FgEHCASDialogMainX.fgeh0zt6x15GroupNames = _loc5_;
                              }
                              _loc6_ = _loc5_.indexOf(_loc4_);
                              var _loc7_:Boolean = false;
                              if(_loc6_ < 0)
                              {
                                 _loc5_.push(_loc4_);
                                 _loc6_ = _loc5_.length - 1;
                                 _loc7_ = true;
                              }
                              if(_loc7_ == true)
                              {
                                 _loc8_ = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
                                 _loc9_ = FgEHCASDialogMainX.fgeh0zt6x3Order;
                                 if(_loc8_ != null)
                                 {
                                    if(_loc9_ != null)
                                    {
                                       _loc10_ = 0;
                                       while(_loc10_ < _loc9_.length)
                                       {
                                          _loc11_ = String(_loc9_[_loc10_]);
                                          _loc12_ = _loc8_[_loc11_];
                                          if(_loc12_ != null)
                                          {
                                             _loc12_ = String(_loc12_);
                                             if(_loc12_ != "")
                                             {
                                                _loc13_ = _loc12_.split("|");
                                                while(true)
                                                {
                                                   _loc14_ = _loc13_.indexOf(_loc4_);
                                                   if(_loc14_ < 0)
                                                   {
                                                      break;
                                                   }
                                                   _loc13_.splice(_loc14_,1);
                                                }
                                                _loc8_[_loc11_] = _loc13_.join("|");
                                             }
                                          }
                                          _loc10_ += 1;
                                       }
                                    }
                                 }
                              }
                              FgEHCASDialogMainX.fgeh0zt6x15TabPage = int(_loc6_ / 3);
                              FgEHCASDialogMainX.fgeh0zt6x15CreateMode = false;
                              _loc3_.text = "";
                              this.fgeh0zt6x15SaveGroups();
                              var _loc15_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
                              if(_loc15_ != null)
                              {
                                 _loc15_ = String(_loc15_);
                                 if(_loc15_ != "")
                                 {
                                    this.fgeh0zt6x15RefreshGroupUI();
                                    break;
                                 }
                              }
                              FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup = _loc4_;
                              FgEHCASDialogMainX.fgeh0zt6x3Page = 0;
                              this.fgeh0zt6x15RebuildView();
                              this.fgeh0zt6x3Refresh();
                              this.fgeh0zt6x15RefreshGroupUI();
                              break;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      
      private function fgeh0zt6x15CreateCancel(param1:*) : void
      {
         FgEHCASDialogMainX.fgeh0zt6x15CreateMode = false;
         FgEHCASDialogMainX.fgeh0zt6x28EditGroup = "";
         var _loc2_:Sprite = this.fgeh0zt6xViewport;
         if(_loc2_ != null)
         {
            var _loc3_:DisplayObject = _loc2_.getChildByName("groupInput");
            if(_loc3_ != null)
            {
               _loc3_.text = "";
            }
         }
         this.fgeh0zt6x15RefreshGroupUI();
      }
      
      private function fgeh0zt6x15SaveGroups() : void
      {
         var _loc1_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupNames;
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15GroupMap;
         var _loc3_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
         var _loc4_:String = "FGCAS_GROUPS_V2";
         var _loc5_:int = 0;
         while(_loc1_ != null)
         {
            if(_loc5_ >= _loc1_.length)
            {
               break;
            }
            var _loc6_:String = String(_loc1_[_loc5_]);
            _loc4_ = _loc4_ + "^G~" + _loc6_;
            _loc5_ += 1;
         }
         _loc5_ = 0;
         while(_loc3_ != null)
         {
            if(_loc5_ >= _loc3_.length)
            {
               break;
            }
            _loc6_ = String(_loc3_[_loc5_]);
            var _loc7_:* = "";
            if(_loc2_ != null)
            {
               _loc7_ = _loc2_[_loc6_];
               if(_loc7_ != null)
               {
                  _loc7_ = String(_loc7_);
                  if(_loc7_ != "")
                  {
                     _loc4_ = _loc4_ + "^M~" + _loc6_ + "~" + _loc7_;
                  }
               }
            }
            _loc5_ += 1;
         }
         FgEHCASDialogMainX.fgeh0zt6x15HoldLong = true;
         FgEHCASDialogMainX.fgeh0zt6x15HoldFrames = 0;
         UISettings.AccountSettings.SetValue("fgeh.cas.favorites.groups.v1",_loc4_);
         var _loc8_:* = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.groups.v1");
         if(_loc8_ == _loc4_)
         {
            FgEHCASDialogMainX.fgeh0zt6x15HoldLong = false;
            FgEHCASDialogMainX.fgeh0zt6x15HoldSlot = -2;
         }
      }
      
      private function fgeh0zt6x19RestoreGroups() : void
      {
         if(FgEHCASDialogMainX.fgeh0zt6x15HoldLong != true)
         {
            if(FgEHCASDialogMainX.fgeh0zt6x15HoldSlot != -2)
            {
               var _loc1_:Array = [];
               var _loc2_:Object = {};
               var _loc3_:* = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.groups.v1");
               if(_loc3_ != null)
               {
                  var _loc4_:Array = String(_loc3_).split("^");
                  if(_loc4_ is Array)
                  {
                     if(_loc4_.length >= 1)
                     {
                        var _loc5_:String = String(_loc4_[0]);
                        while(true)
                        {
                           if(_loc5_ != "FGCAS_GROUPS_V2")
                           {
                              if(_loc5_ != "FGCAS_GROUPS_V1")
                              {
                                 break;
                              }
                           }
                           var _loc6_:int = 1;
                           while(_loc6_ < _loc4_.length)
                           {
                              var _loc7_:* = String(_loc4_[_loc6_]);
                              _loc7_ = _loc7_.split("~");
                              if(_loc7_ is Array)
                              {
                                 if(_loc5_ == "FGCAS_GROUPS_V2")
                                 {
                                    if(_loc7_.length >= 2)
                                    {
                                       var _loc8_:String = String(_loc7_[0]);
                                       if(_loc8_ == "G")
                                       {
                                          _loc8_ = String(_loc7_[1]);
                                          if(_loc8_ != "")
                                          {
                                             if(_loc1_.indexOf(_loc8_) < 0)
                                             {
                                                _loc1_.push(_loc8_);
                                             }
                                          }
                                       }
                                       else if(_loc8_ == "M")
                                       {
                                          if(_loc7_.length >= 3)
                                          {
                                             _loc8_ = String(_loc7_[1]);
                                             var _loc9_:String = String(_loc7_[2]);
                                             if(_loc8_ != "")
                                             {
                                                _loc2_[_loc8_] = _loc9_;
                                             }
                                          }
                                       }
                                    }
                                 }
                                 else if(_loc7_.length >= 2)
                                 {
                                    _loc8_ = String(_loc7_[0]);
                                    _loc9_ = String(_loc7_[1]);
                                    if(_loc8_ != "")
                                    {
                                       _loc2_[_loc8_] = _loc9_;
                                       if(_loc1_.indexOf(_loc9_) < 0)
                                       {
                                          _loc1_.push(_loc9_);
                                       }
                                    }
                                 }
                              }
                              _loc6_ += 1;
                           }
                           FgEHCASDialogMainX.fgeh0zt6x15GroupNames = _loc1_;
                           FgEHCASDialogMainX.fgeh0zt6x15GroupMap = _loc2_;
                           FgEHCASDialogMainX.fgeh0zt6x15HoldSlot = -2;
                           FgEHCASDialogMainX.fgeh0zt6x15HoldLong = false;
                           break;
                        }
                     }
                  }
               }
            }
         }
      }
      
      private function fgeh0zt6x24GroupLoadCallback(param1:*, param2:*) : void
      {
         var _loc3_:Array = String(param1).split("#");
         if(_loc3_ != null)
         {
            if(_loc3_.length == 3)
            {
               var _loc4_:String = String(_loc3_[0]);
               var _loc5_:String = String(_loc3_[1]);
               if(_loc5_ == "fgeh.cas.favorites.groups.v1")
               {
                  var _loc6_:* = UISettings.AccountSettings.GetValue(_loc5_);
                  if(_loc6_ == null)
                  {
                     addr0072:
                     UISettings.AccountSettings.SetValue(_loc5_,param2,_loc4_);
                  }
               }
               else
               {
                  while(true)
                  {
                     if(_loc5_ != "fgeh.cas.favorites.v3.manifest")
                     {
                        if(_loc5_.indexOf("fgeh.cas.favorites.v3.item.") != 0)
                        {
                           break;
                        }
                     }
                     if(FgEHCASDialogMainX.fgeh0zt6x25FavoriteLocalDirty)
                     {
                        break;
                     }
                     §§goto(addr0072);
                  }
               }
            }
         }
      }
      
      private function fgeh0zt6x25SaveFavoriteSplit() : void
      {
         var _loc1_:* = FgEHCASDialogMainX.fgeh0zt6x3Order;
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6wFavoriteStore;
         if(_loc1_ == null)
         {
            _loc1_ = [];
         }
         var _loc3_:uint = _loc1_.length;
         var _loc8_:String = "FGCAS_FAVORITES_V3" + "^" + String(_loc3_);
         var _loc4_:int = 0;
         while(_loc4_ < _loc3_)
         {
            var _loc5_:String = String(_loc1_[_loc4_]);
            _loc8_ = _loc8_ + "^" + _loc5_;
            _loc4_ += 1;
         }
         var _loc10_:* = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.v3.manifest");
         while(true)
         {
            if(_loc10_ != null)
            {
               if(String(_loc10_).indexOf("FGCAS_FAVORITES_V3") == 0)
               {
                  var _loc11_:* = FgEHCASDialogMainX.fgeh0zt6x56DirtyBases;
                  if(_loc11_ == null)
                  {
                     _loc11_ = [];
                  }
                  break;
               }
            }
            _loc11_ = _loc1_;
            break;
         }
         var _loc12_:uint = _loc11_.length;
         var _loc13_:int = 0;
         while(_loc13_ < _loc12_)
         {
            _loc5_ = String(_loc11_[_loc13_]);
            if(_loc2_ != null)
            {
               var _loc6_:* = _loc2_[_loc5_];
               if(_loc6_ != null)
               {
                  var _loc7_:String = "";
                  _loc7_ += String(_loc6_.base_id);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.selected_variant_id);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.body_type);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.variant_count);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.swatch_count);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.variant_ids);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.swatches);
                  _loc7_ += "~";
                  _loc7_ += String(_loc6_.captured_request);
                  var _loc9_:String = "fgeh.cas.favorites.v3.item." + _loc5_;
                  UISettings.AccountSettings.SetValue(_loc9_,_loc7_);
               }
            }
            _loc13_ += 1;
         }
         UISettings.AccountSettings.SetValue("fgeh.cas.favorites.v3.manifest",_loc8_);
         FgEHCASDialogMainX.fgeh0zt6x25FavoriteLocalDirty = true;
         FgEHCASDialogMainX.fgeh0zt6x56DirtyBases = null;
      }
      
      private function fgeh0zt6x25RestoreFavoriteSplit() : void
      {
         var _loc1_:* = UISettings.AccountSettings.GetValue("fgeh.cas.favorites.v3.manifest");
         if(_loc1_ != null)
         {
            var _loc2_:Array = String(_loc1_).split("^");
            if(_loc2_ is Array)
            {
               if(_loc2_.length >= 2)
               {
                  if(String(_loc2_[0]) == "FGCAS_FAVORITES_V3")
                  {
                     var _loc3_:int = int(_loc2_[1]);
                     if(_loc3_ > 0)
                     {
                        if(_loc2_.length == _loc3_ + 2)
                        {
                           var _loc8_:Array = [];
                           var _loc9_:Object = {};
                           var _loc4_:int = 0;
                           while(true)
                           {
                              if(_loc4_ >= _loc3_)
                              {
                                 FgEHCASDialogMainX.fgeh0zt6wFavoriteStore = _loc9_;
                                 FgEHCASDialogMainX.fgeh0zt6x3Order = _loc8_;
                                 FgEHCASDialogMainX.fgeh0zt6wFavoriteCount = _loc3_;
                                 FgEHCASDialogMainX.fgeh0zt6x3Page = 0;
                                 break;
                              }
                              var _loc5_:String = String(_loc2_[_loc4_ + 2]);
                              if(_loc5_ == "")
                              {
                                 break;
                              }
                              var _loc11_:String = "fgeh.cas.favorites.v3.item." + _loc5_;
                              var _loc6_:* = UISettings.AccountSettings.GetValue(_loc11_);
                              if(_loc6_ == null)
                              {
                                 break;
                              }
                              var _loc7_:Array = String(_loc6_).split("~");
                              if(!(_loc7_ is Array))
                              {
                                 break;
                              }
                              if(_loc7_.length != 8)
                              {
                                 break;
                              }
                              var _loc10_:Object = {
                                 "base_id":String(_loc7_[0]),
                                 "selected_variant_id":String(_loc7_[1]),
                                 "body_type":String(_loc7_[2]),
                                 "variant_count":String(_loc7_[3]),
                                 "swatch_count":String(_loc7_[4]),
                                 "variant_ids":String(_loc7_[5]),
                                 "swatches":String(_loc7_[6]),
                                 "captured_request":String(_loc7_[7])
                              };
                              _loc9_[_loc5_] = _loc10_;
                              _loc8_.push(_loc5_);
                              _loc4_ += 1;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      
      public function fgeh0uiCollapseClick(param1:*) : void
      {
         this.fgeh0uiCollapsed = !this.fgeh0uiCollapsed;
         this.visible = !this.fgeh0uiCollapsed;
         this.alpha = Number(!this.fgeh0uiCollapsed);
      }
      
      public function fgeh0uiKeyDown(param1:*) : void
      {
         while(true)
         {
            if(param1.keyCode != 74)
            {
               if(param1.keyCode != 75)
               {
                  break;
               }
            }
            if(this.fgeh0uiStage != null)
            {
               var _loc2_:* = this.fgeh0uiStage.focus;
               if(_loc2_ is TextField)
               {
                  if(_loc2_.type == "input")
                  {
                     break;
                  }
               }
               if(!param1.ctrlKey)
               {
                  if(!param1.altKey)
                  {
                     if(!param1.shiftKey)
                     {
                        this.fgeh0uiHotkeyHeld = true;
                     }
                  }
               }
            }
            break;
         }
      }
      
      public function fgeh0uiKeyUp(param1:*) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Tip: You can try enabling "Deobfuscate code" option in Settings
          * Error type: NullPointerException (Cannot invoke "String.length()" because "s" is null)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      public function fgeh0uiPhotoActivate() : void
      {
         if(!this.fgeh0uiPhotoActive)
         {
            var _loc1_:* = this.fgeh0uiStage;
            if(_loc1_ != null)
            {
               var _loc2_:Array = [];
               this.fgeh0uiSaved = _loc2_;
               var _loc3_:int = 0;
               while(_loc3_ < _loc1_.numChildren)
               {
                  var _loc4_:DisplayObject = _loc1_.getChildAt(_loc3_);
                  var _loc5_:Array = [_loc4_,_loc4_.alpha,null,null];
                  if(_loc4_ is InteractiveObject)
                  {
                     _loc5_[2] = InteractiveObject(_loc4_).mouseEnabled;
                  }
                  if(_loc4_ is DisplayObjectContainer)
                  {
                     _loc5_[3] = DisplayObjectContainer(_loc4_).mouseChildren;
                  }
                  _loc2_.push(_loc5_);
                  _loc3_ += 1;
               }
               this.fgeh0uiPhotoActive = true;
               _loc1_.addEventListener("enterFrame",this.fgeh0uiPhotoMask);
               this.fgeh0uiPhotoMask(null);
            }
         }
      }
      
      public function fgeh0uiPhotoMask(param1:*) : void
      {
         if(this.fgeh0uiPhotoActive)
         {
            var _loc2_:* = this.fgeh0uiStage;
            var _loc3_:Array = this.fgeh0uiSaved;
            if(_loc2_ != null)
            {
               loop1:
               while(true)
               {
                  if(_loc3_ != null)
                  {
                     if(_loc2_.numChildren == _loc3_.length)
                     {
                        param1 = 0;
                        while(true)
                        {
                           if(param1 >= _loc3_.length)
                           {
                              break loop1;
                           }
                           var _loc4_:* = _loc3_[param1];
                           var _loc5_:* = _loc4_[0];
                           if(_loc2_.getChildAt(param1) === _loc5_)
                           {
                              _loc5_.alpha = 0;
                              if(_loc5_ is InteractiveObject)
                              {
                                 InteractiveObject(_loc5_).mouseEnabled = false;
                              }
                              if(_loc5_ is DisplayObjectContainer)
                              {
                                 DisplayObjectContainer(_loc5_).mouseChildren = false;
                              }
                              param1 += 1;
                              continue;
                           }
                        }
                        break;
                     }
                  }
                  this.fgeh0uiPhotoRestore();
                  break;
               }
            }
         }
      }
      
      public function fgeh0uiPhotoRestore() : void
      {
         if(this.fgeh0uiPhotoActive)
         {
            this.fgeh0uiPhotoActive = false;
            var _loc2_:Array = this.fgeh0uiSaved;
            if(_loc2_ != null)
            {
               var _loc1_:int = 0;
               while(_loc1_ < _loc2_.length)
               {
                  var _loc3_:* = _loc2_[_loc1_];
                  var _loc4_:* = _loc3_[0];
                  _loc4_.alpha = _loc3_[1];
                  var _loc5_:* = _loc3_[2];
                  if(_loc5_ != null)
                  {
                     if(_loc4_ is InteractiveObject)
                     {
                        InteractiveObject(_loc4_).mouseEnabled = _loc5_;
                     }
                  }
                  _loc5_ = _loc3_[3];
                  if(_loc5_ != null)
                  {
                     if(_loc4_ is DisplayObjectContainer)
                     {
                        DisplayObjectContainer(_loc4_).mouseChildren = _loc5_;
                     }
                  }
                  _loc1_ += 1;
               }
            }
            _loc4_ = this.fgeh0uiStage;
            if(_loc4_ != null)
            {
               _loc4_.removeEventListener("enterFrame",this.fgeh0uiPhotoMask);
            }
            this.fgeh0uiSaved = null;
         }
      }
      
      public function fgeh0uiDeactivate(param1:*) : void
      {
         this.fgeh0uiHotkeyHeld = false;
         this.fgeh0uiPhotoRestore();
      }
      
      public function fgeh0uiRemoved(param1:*) : void
      {
         var _loc2_:* = this.fgeh0uiStage;
         if(_loc2_ != null)
         {
            _loc2_.removeEventListener("keyDown",this.fgeh0uiKeyDown,true);
            _loc2_.removeEventListener("keyDown",this.fgeh0uiKeyDown,false);
            _loc2_.removeEventListener("keyUp",this.fgeh0uiKeyUp,true);
            _loc2_.removeEventListener("keyUp",this.fgeh0uiKeyUp,false);
            _loc2_.removeEventListener("deactivate",this.fgeh0uiDeactivate);
         }
         this.removeEventListener("enterFrame",this.fgeh0pOnFrame);
         this.fgeh0uiStage = null;
      }
      
      public function fgeh0zt6x15EditClick(param1:*) : void
      {
         var _loc2_:* = FgEHCASDialogMainX.fgeh0zt6x15EditBase;
         while(true)
         {
            if(_loc2_ != null)
            {
               _loc2_ = String(_loc2_);
               if(_loc2_ != "")
               {
                  break;
               }
            }
            _loc2_ = FgEHCASDialogMainX.fgeh0zt6x15ActiveGroup;
            if(_loc2_ != null)
            {
               _loc2_ = String(_loc2_);
               if(_loc2_ != "")
               {
                  FgEHCASDialogMainX.fgeh0zt6x28EditGroup = _loc2_;
                  FgEHCASDialogMainX.fgeh0zt6x15CreateMode = true;
                  var _loc3_:Sprite = this.fgeh0zt6xViewport;
                  if(_loc3_ != null)
                  {
                     var _loc4_:DisplayObject = _loc3_.getChildByName("groupInput");
                     if(_loc4_ != null)
                     {
                        _loc4_.text = _loc2_;
                     }
                  }
                  this.fgeh0zt6x15RefreshGroupUI();
               }
            }
            break;
         }
      }
   }
}

