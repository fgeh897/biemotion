package
{
   import FgEH.CAS.FavoritesWidgetRuntime.FgEHCASDialogMainX;
   import flash.display.Sprite;
   
   public class FgEHCASDialogX extends Sprite
   {
      
      public var widget:FgEHCASDialogMainX;
      
      public function FgEHCASDialogX()
      {
         super();
         this.widget = new FgEHCASDialogMainX();
         addChild(this.widget);
      }
   }
}

