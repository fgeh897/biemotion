import datetime
import os
import traceback


ENABLE_POSITIONING_DEBUG_LOG = False
POSITIONING_DEBUG_LOG_MAX_BYTES = 1024 * 1024


def _get_log_paths():
    filename = "fgeh_positioning_debug.log"
    roots = (
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
        os.path.dirname(os.path.abspath(__file__)),
    )
    paths = []
    for root in roots:
        if not root:
            continue
        paths.append(os.path.join(root, filename))
        paths.append(os.path.join(root, "Mods", filename))
    return paths


def _write_line(line):
    return  # R26: release diagnostic/file output disabled.


def positioning_log(message, *args):
    if not ENABLE_POSITIONING_DEBUG_LOG:
        return
    try:
        text = message.format(*args) if args else str(message)
    except Exception:
        text = "{} args={}".format(message, args)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _write_line("[{}] [FGEH_Positioning] {}".format(timestamp, text))


def positioning_log_exception(label):
    positioning_log("{}\n{}", label, traceback.format_exc())
