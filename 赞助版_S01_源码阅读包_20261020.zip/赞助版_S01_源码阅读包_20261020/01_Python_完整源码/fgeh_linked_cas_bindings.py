import json
import os
import time


CAS_BINDINGS_FILENAME = "fgeh_linked_cas_bindings.json"
CAS_BINDINGS_TMP_FILENAME = "fgeh_linked_cas_bindings_tmp"
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))


def _mod_directory():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        return MODULE_DIR


def _candidate_dirs():
    dirs = []
    for folder in (_mod_directory(), MODULE_DIR):
        if folder and folder not in dirs:
            dirs.append(folder)
    if MODULE_DIR not in dirs:
        dirs.append(MODULE_DIR)
    return dirs


def _primary_dir():
    folder = _mod_directory()
    if folder:
        return folder
    return MODULE_DIR


def _path_in(folder, filename):
    return os.path.join(folder, filename)


def _load_json_dict(path):
    try:
        if not path or not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _preferred_json_data(folder, filename, tmp_filename):
    candidates = []
    for name in (filename, tmp_filename):
        path = _path_in(folder, name)
        data = _load_json_dict(path)
        if data is None:
            continue
        try:
            modified = os.path.getmtime(path)
        except Exception:
            modified = 0
        candidates.append((modified, data))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _write_json_atomically(target_path, tmp_path, data):
    with open(tmp_path, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False)
    if _load_json_dict(tmp_path) is None:
        return False
    try:
        os.replace(tmp_path, target_path)
        return True
    except Exception:
        pass
    try:
        with open(target_path, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False)
        if _load_json_dict(target_path) is None:
            return True
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return True
    except Exception:
        return True


def _safe_int(value):
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _text(value):
    return str(value or "").strip()


def _now_text():
    try:
        return time.strftime("%Y-%m-%dT%H:%M:%S")
    except Exception:
        return ""


def _new_binding_id(pack_id, pose_name, outfit_label):
    return "{}::{}::{}::{}".format(
        _text(pack_id),
        _text(pose_name),
        _text(outfit_label) or "outfit",
        int(time.time() * 1000),
    )


def _load_data():
    bindings = []
    outfit_bindings = []
    managed_actions = []
    seen = set()
    seen_outfits = set()
    seen_managed_actions = set()
    schema_version = 1
    for folder in _candidate_dirs():
        try:
            data = _preferred_json_data(folder, CAS_BINDINGS_FILENAME, CAS_BINDINGS_TMP_FILENAME)
            if data is None:
                continue
            try:
                schema_version = max(schema_version, int(data.get("schema_version", 1) or 1))
            except Exception:
                pass
            for binding in data.get("cas_bindings", []) or []:
                if not isinstance(binding, dict):
                    continue
                key = (
                    _text(binding.get("pack_id")),
                    _text(binding.get("pose_name")),
                    _safe_int(binding.get("cas_part_id")),
                    _text(binding.get("outfit_binding_id")),
                )
                if not key[0] or not key[1] or not key[2] or key in seen:
                    continue
                seen.add(key)
                bindings.append(binding)
            for outfit in data.get("outfit_bindings", []) or []:
                if not isinstance(outfit, dict):
                    continue
                outfit_id = _text(outfit.get("outfit_binding_id"))
                key = (
                    _text(outfit.get("pack_id")),
                    _text(outfit.get("pose_name")),
                    outfit_id,
                )
                if not key[0] or not key[1] or not key[2] or key in seen_outfits:
                    continue
                seen_outfits.add(key)
                outfit_bindings.append(outfit)
            for action in data.get("managed_actions", []) or []:
                if not isinstance(action, dict):
                    continue
                key = (
                    _text(action.get("pack_id")),
                    _text(action.get("pose_name")),
                )
                if not key[0] or not key[1] or key in seen_managed_actions:
                    continue
                seen_managed_actions.add(key)
                managed_actions.append(action)
        except Exception:
            continue
    return {
        "schema_version": schema_version,
        "outfit_bindings": outfit_bindings,
        "cas_bindings": bindings,
        "managed_actions": managed_actions,
    }


def _save_data(data):
    try:
        target_dir = _primary_dir()
        target_path = _path_in(target_dir, CAS_BINDINGS_FILENAME)
        tmp_path = _path_in(target_dir, CAS_BINDINGS_TMP_FILENAME)
        _write_json_atomically(target_path, tmp_path, data)
        return True
    except Exception:
        try:
            from fgeh_cas_accessory_outfit_utils import debug_log
            debug_log("CAS binding save failed target_dir={} error={}", locals().get("target_dir", None), traceback_text())
        except Exception:
            pass
        return False


def _save_data_to_folder(folder, data):
    try:
        target_path = _path_in(folder, CAS_BINDINGS_FILENAME)
        tmp_path = _path_in(folder, CAS_BINDINGS_TMP_FILENAME)
        _write_json_atomically(target_path, tmp_path, data)
        return True
    except Exception:
        return False


def traceback_text():
    try:
        import traceback
        return traceback.format_exc()
    except Exception:
        return "unknown"


def iter_saved_cas_bindings():
    data = _load_data()
    for binding in data.get("cas_bindings", []) or []:
        if isinstance(binding, dict):
            yield binding


def iter_saved_outfit_bindings():
    data = _load_data()
    for outfit in data.get("outfit_bindings", []) or []:
        if isinstance(outfit, dict):
            yield outfit


def iter_managed_actions():
    data = _load_data()
    for action in data.get("managed_actions", []) or []:
        if isinstance(action, dict):
            yield action


def _ensure_managed_action_in_data(data, pack_id, pose_name):
    if not isinstance(data, dict):
        return False
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    if not pack_id or not pose_name:
        return False
    actions = data.setdefault("managed_actions", [])
    now = _now_text()
    for action in actions:
        if not isinstance(action, dict):
            continue
        if (
            _text(action.get("pack_id")) == pack_id
            and _text(action.get("pose_name")) == pose_name
        ):
            action["updated_at"] = now
            return False
    actions.append({
        "pack_id": pack_id,
        "pose_name": pose_name,
        "created_in_game": True,
        "created_at": now,
        "updated_at": now,
    })
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 3)
    return True


def ensure_managed_action(pack_id, pose_name):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    if not pack_id or not pose_name:
        return False
    data = _load_data()
    changed = _ensure_managed_action_in_data(data, pack_id, pose_name)
    if changed:
        return _save_data(data)
    # Already registered is still a successful idempotent request.
    return True


def ensure_managed_actions(pack_id, pose_names):
    """Idempotently register many poses from one pack with one JSON save."""
    pack_id = _text(pack_id)
    if not pack_id:
        return False
    names = []
    seen = set()
    for pose_name in pose_names or ():
        pose_name = _text(pose_name)
        if pose_name and pose_name not in seen:
            seen.add(pose_name)
            names.append(pose_name)
    if not names:
        return False
    data = _load_data()
    changed = False
    for pose_name in names:
        if _ensure_managed_action_in_data(data, pack_id, pose_name):
            changed = True
    if changed:
        return _save_data(data)
    # All entries already existed: the bulk request still succeeded.
    return True


def remove_managed_action(pack_id, pose_name):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    if not pack_id or not pose_name:
        return False
    data = _load_data()
    old = data.get("managed_actions", []) or []
    new = [
        row for row in old
        if not (
            isinstance(row, dict)
            and _text(row.get("pack_id")) == pack_id
            and _text(row.get("pose_name")) == pose_name
        )
    ]
    if len(new) == len(old):
        return False
    data["managed_actions"] = new
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 3)
    return _save_data(data)


def is_managed_action(pack_id, pose_name):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    if not pack_id or not pose_name:
        return False
    for action in iter_managed_actions():
        if (
            _text(action.get("pack_id")) == pack_id
            and _text(action.get("pose_name")) == pose_name
        ):
            return True
    return False


def get_or_create_outfit_binding(pack_id, pose_name, outfit_label=None, category=None, category_index=None, part_count=0, body_group=None):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    outfit_label = _text(outfit_label)
    category = _safe_int(category)
    category_index = _safe_int(category_index)
    body_group = _text(body_group) or "all"
    if not pack_id or not pose_name:
        return ""

    data = _load_data()
    outfits = data.setdefault("outfit_bindings", [])
    now = _now_text()
    for outfit in outfits:
        if not isinstance(outfit, dict):
            continue
        if (
            _text(outfit.get("pack_id")) == pack_id
            and _text(outfit.get("pose_name")) == pose_name
            and _text(outfit.get("outfit_label")) == outfit_label
            and _safe_int(outfit.get("category")) == category
            and _safe_int(outfit.get("category_index")) == category_index
            and _text(outfit.get("body_group") or "all") == body_group
        ):
            outfit["part_count"] = _safe_int(part_count) or _safe_int(outfit.get("part_count"))
            outfit["updated_at"] = now
            _save_data(data)
            return _text(outfit.get("outfit_binding_id"))

    outfit_id = _new_binding_id(pack_id, pose_name, outfit_label)
    outfits.append({
        "outfit_binding_id": outfit_id,
        "pack_id": pack_id,
        "pose_name": pose_name,
        "outfit_label": outfit_label,
        "category": category,
        "category_index": category_index,
        "body_group": body_group,
        "part_count": _safe_int(part_count),
        "created_in_game": True,
        "created_at": now,
        "updated_at": now,
    })
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    _save_data(data)
    return outfit_id


def iter_saved_cas_assets():
    seen = set()
    for binding in iter_saved_cas_bindings():
        pack_id = _text(binding.get("pack_id"))
        cas_part_id = _safe_int(binding.get("cas_part_id"))
        key = (pack_id, cas_part_id)
        if not pack_id or not cas_part_id or key in seen:
            continue
        seen.add(key)
        yield {
            "asset_kind": "cas",
            "source_type": binding.get("source_type") or "unknown",
            "source_origin": _text(binding.get("source_origin")) or "local",
            "user_group": binding.get("user_group") or "in_game_binding",
            "pack_id": pack_id,
            "cas_part_id": cas_part_id,
            "body_type": _safe_int(binding.get("body_type")),
            "body_group": binding.get("body_group") or "other",
            "display_name": binding.get("display_name") or "CAS {}".format(cas_part_id),
            "category": binding.get("category") or "cas",
            "outfit_label": binding.get("outfit_label") or "",
            "created_in_game": True,
            "created_at": binding.get("created_at") or "",
            "updated_at": binding.get("updated_at") or "",
        }


def get_saved_cas_part_ids_for_pose(pack_id, pose_name):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    asset_ids = set()
    binding_ids = set()
    if not pack_id:
        return asset_ids, binding_ids
    for binding in iter_saved_cas_bindings():
        if _text(binding.get("pack_id")) != pack_id:
            continue
        cas_part_id = _safe_int(binding.get("cas_part_id"))
        if not cas_part_id:
            continue
        asset_ids.add(cas_part_id)
        if pose_name and _text(binding.get("pose_name")) == pose_name:
            binding_ids.add(cas_part_id)
    return asset_ids, binding_ids


def save_cas_binding(pack_id, pose_name, cas_part_id, body_type=0, display_name=None, category=None, outfit_label=None, source_type="unknown", body_group=None, outfit_binding_id=None):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    cas_part_id = _safe_int(cas_part_id)
    body_type = _safe_int(body_type)
    display_name = _text(display_name)
    category = _text(category) or "cas"
    outfit_label = _text(outfit_label)
    body_group = _text(body_group) or "other"
    outfit_binding_id = _text(outfit_binding_id)
    source_type = _text(source_type).lower() or "unknown"
    if source_type not in ("game", "cc", "unknown"):
        source_type = "unknown"
    if not pack_id or not pose_name or not cas_part_id:
        return False

    data = _load_data()
    _ensure_managed_action_in_data(data, pack_id, pose_name)
    bindings = data.setdefault("cas_bindings", [])
    now = _now_text()
    for binding in bindings:
        if not isinstance(binding, dict):
            continue
        if (
            _text(binding.get("pack_id")) == pack_id
            and _text(binding.get("pose_name")) == pose_name
            and _safe_int(binding.get("cas_part_id")) == cas_part_id
            and _text(binding.get("outfit_binding_id")) == outfit_binding_id
        ):
            binding["body_type"] = body_type or _safe_int(binding.get("body_type"))
            binding["display_name"] = display_name or binding.get("display_name") or "CAS {}".format(cas_part_id)
            binding["category"] = category or binding.get("category") or "cas"
            binding["outfit_label"] = outfit_label or binding.get("outfit_label") or ""
            binding["body_group"] = body_group or binding.get("body_group") or "other"
            binding["outfit_binding_id"] = outfit_binding_id or binding.get("outfit_binding_id") or ""
            binding["source_type"] = source_type
            binding["source_origin"] = "local"
            binding["updated_at"] = now
            return _save_data(data)

    bindings.append({
        "asset_kind": "cas",
        "source_type": source_type,
        "source_origin": "local",
        "user_group": "in_game_binding",
        "pack_id": pack_id,
        "pose_name": pose_name,
        "cas_part_id": cas_part_id,
        "body_type": body_type,
        "display_name": display_name or "CAS {}".format(cas_part_id),
        "category": category,
        "outfit_label": outfit_label,
        "body_group": body_group,
        "outfit_binding_id": outfit_binding_id,
        "created_in_game": True,
        "created_at": now,
        "updated_at": now,
    })
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 1)
    return _save_data(data)




def set_cas_collection_product_for_poses(
    pack_id,
    pose_names,
    sibling_cas_part_ids,
    selected_cas_part_id,
    body_type=0,
    display_name=None,
    source_type="unknown",
    body_group=None,
):
    """Atomically normalize one CAS collection product across many Poses.

    This edits only local `category=cas_collection` rows in this module's JSON.
    Outfit bindings and external/package requirements are intentionally outside
    this API. selected_cas_part_id=0 means remove the product from the scope.
    """
    pack_id = _text(pack_id)
    names = []
    seen_names = set()
    for raw in pose_names or ():
        name = _text(raw)
        if name and name not in seen_names:
            seen_names.add(name)
            names.append(name)
    sibling_ids = set()
    for raw in sibling_cas_part_ids or ():
        value = _safe_int(raw)
        if value:
            sibling_ids.add(value)
    selected = _safe_int(selected_cas_part_id)
    if selected:
        sibling_ids.add(selected)
    if not pack_id or not names or not sibling_ids:
        return False

    source_type = _text(source_type).lower() or "unknown"
    if source_type not in ("game", "cc", "unknown"):
        source_type = "unknown"
    body_type = _safe_int(body_type)
    display_name = _text(display_name) or ("CAS {}".format(selected) if selected else "CAS")
    body_group = _text(body_group) or "other"

    data = _load_data()
    target_names = set(names)
    bindings = []
    changed = False
    for row in data.get("cas_bindings", []) or []:
        if not isinstance(row, dict):
            bindings.append(row)
            continue
        same_local_product = (
            _text(row.get("pack_id")) == pack_id
            and _text(row.get("pose_name")) in target_names
            and _safe_int(row.get("cas_part_id")) in sibling_ids
            and _text(row.get("category")) == "cas_collection"
            and not _text(row.get("outfit_binding_id"))
        )
        if same_local_product:
            changed = True
            continue
        bindings.append(row)

    now = _now_text()
    if selected:
        for pose_name in names:
            _ensure_managed_action_in_data(data, pack_id, pose_name)
            bindings.append({
                "asset_kind": "cas",
                "source_type": source_type,
                "source_origin": "local",
                "user_group": "in_game_binding",
                "pack_id": pack_id,
                "pose_name": pose_name,
                "cas_part_id": selected,
                "body_type": body_type,
                "display_name": display_name,
                "category": "cas_collection",
                "outfit_label": "",
                "body_group": body_group,
                "outfit_binding_id": "",
                "created_in_game": True,
                "created_at": now,
                "updated_at": now,
            })
            changed = True

    data["cas_bindings"] = bindings
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 3)
    return _save_data(data) if changed else True




def set_external_cas_product_for_poses(
    pack_id,
    pose_names,
    sibling_cas_part_ids,
    selected_cas_part_id,
    body_type=0,
    display_name=None,
    source_type="unknown",
    body_group=None,
    external_product_key="",
):
    """Persist one reusable game-external CAS product against one or more Poses.

    The asset originates from the player's existing external/tuning metadata,
    but the *assignment* is authored in game.  Keep source_origin=external so
    Linked Action UI can distinguish it from CAS-library/AccountSettings rows.
    """
    pack_id = _text(pack_id)
    names = []
    seen_names = set()
    for raw in pose_names or ():
        name = _text(raw)
        if name and name not in seen_names:
            seen_names.add(name)
            names.append(name)
    sibling_ids = set()
    for raw in sibling_cas_part_ids or ():
        value = _safe_int(raw)
        if value:
            sibling_ids.add(value)
    selected = _safe_int(selected_cas_part_id)
    if selected:
        sibling_ids.add(selected)
    if not pack_id or not names or not sibling_ids:
        return False

    source_type = _text(source_type).lower() or "unknown"
    if source_type not in ("game", "cc", "unknown"):
        source_type = "unknown"
    body_type = _safe_int(body_type)
    display_name = _text(display_name) or ("CAS {}".format(selected) if selected else "CAS")
    body_group = _text(body_group) or "other"
    external_product_key = _text(external_product_key)

    data = _load_data()
    target_names = set(names)
    bindings = []
    changed = False
    for row in data.get("cas_bindings", []) or []:
        if not isinstance(row, dict):
            bindings.append(row)
            continue
        same_external_product = (
            _text(row.get("pack_id")) == pack_id
            and _text(row.get("pose_name")) in target_names
            and _safe_int(row.get("cas_part_id")) in sibling_ids
            and _text(row.get("category")) == "cas_external_reuse"
            and not _text(row.get("outfit_binding_id"))
        )
        if external_product_key:
            same_external_product = same_external_product and (
                _text(row.get("external_product_key")) in ("", external_product_key)
            )
        if same_external_product:
            changed = True
            continue
        bindings.append(row)

    now = _now_text()
    if selected:
        for pose_name in names:
            _ensure_managed_action_in_data(data, pack_id, pose_name)
            bindings.append({
                "asset_kind": "cas",
                "source_type": source_type,
                "source_origin": "external",
                "user_group": "external_reuse",
                "pack_id": pack_id,
                "pose_name": pose_name,
                "cas_part_id": selected,
                "body_type": body_type,
                "display_name": display_name,
                "category": "cas_external_reuse",
                "outfit_label": "",
                "body_group": body_group,
                "outfit_binding_id": "",
                "external_product_key": external_product_key,
                "created_in_game": True,
                "created_at": now,
                "updated_at": now,
            })
            changed = True

    data["cas_bindings"] = bindings
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 4)
    return _save_data(data) if changed else True

def remove_cas_bindings_for_poses(pack_id, pose_names, cas_part_ids):
    """Remove exact game-created CAS bindings across many Poses in ONE write.

    This only edits this module's local JSON store. External XML/snippet/package
    requirements are never modified. The existing per-Pose storage schema stays
    unchanged; Pack scope is an operation semantic, not a third database.
    """
    pack_id = _text(pack_id)
    names = {_text(value) for value in (pose_names or ()) if _text(value)}
    ids = {_safe_int(value) for value in (cas_part_ids or ()) if _safe_int(value)}
    if not pack_id or not names or not ids:
        return 0
    data = _load_data()
    old = data.get("cas_bindings", []) or []
    new = []
    removed = 0
    removed_outfit_ids = set()
    for row in old:
        if not isinstance(row, dict):
            new.append(row)
            continue
        same = (
            _text(row.get("pack_id")) == pack_id
            and _text(row.get("pose_name")) in names
            and _safe_int(row.get("cas_part_id")) in ids
        )
        # This module is the game-created/local store, but keep the guard
        # explicit so future mixed schemas cannot accidentally erase external data.
        local = (
            row.get("created_in_game") is True
            or _text(row.get("source_origin")).lower() in ("local", "in_game", "ingame", "runtime")
            or _text(row.get("user_group")).lower() in ("in_game_binding", "ingame_binding", "local_binding")
        )
        if same and local:
            removed += 1
            oid = _text(row.get("outfit_binding_id"))
            if oid:
                removed_outfit_ids.add(oid)
            continue
        new.append(row)
    if not removed:
        return 0
    data["cas_bindings"] = new
    if removed_outfit_ids:
        data["outfit_bindings"] = [
            row for row in (data.get("outfit_bindings", []) or [])
            if not (isinstance(row, dict) and _text(row.get("outfit_binding_id")) in removed_outfit_ids)
        ]
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 3)
    return removed if _save_data(data) else 0

def delete_cas_binding(pack_id, pose_name, cas_part_id, outfit_binding_id=None):
    """Delete one exact in-game CAS binding without touching sibling bindings.

    H33 uses this for multi-select accessory binding.  CAS favorites themselves
    are not modified; this only edits fgeh_linked_cas_bindings.json.
    """
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    cas_part_id = _safe_int(cas_part_id)
    outfit_binding_id = _text(outfit_binding_id)
    if not pack_id or not pose_name or not cas_part_id:
        return 0

    removed_total = 0
    saved_any = False
    for folder in _candidate_dirs():
        try:
            path = _path_in(folder, CAS_BINDINGS_FILENAME)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8") as stream:
                data = json.load(stream)
            old_bindings = data.get("cas_bindings", []) or []
            new_bindings = []
            removed_here = 0
            removed_outfit_ids = set()
            for binding in old_bindings:
                if not isinstance(binding, dict):
                    continue
                same = (
                    _text(binding.get("pack_id")) == pack_id
                    and _text(binding.get("pose_name")) == pose_name
                    and _safe_int(binding.get("cas_part_id")) == cas_part_id
                )
                if same and outfit_binding_id:
                    same = _text(binding.get("outfit_binding_id")) == outfit_binding_id
                if same:
                    removed_here += 1
                    oid = _text(binding.get("outfit_binding_id"))
                    if oid:
                        removed_outfit_ids.add(oid)
                    continue
                new_bindings.append(binding)
            if not removed_here:
                continue
            data["cas_bindings"] = new_bindings
            if removed_outfit_ids:
                data["outfit_bindings"] = [
                    row for row in (data.get("outfit_bindings", []) or [])
                    if not (isinstance(row, dict) and _text(row.get("outfit_binding_id")) in removed_outfit_ids)
                ]
            data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
            if _save_data_to_folder(folder, data):
                saved_any = True
                removed_total += removed_here
        except Exception:
            continue
    return removed_total if saved_any else 0

def _clean_pose_refs_from_data(data, refs):
    if not isinstance(data, dict):
        return data, False
    ref_keys = set(
        (_text(pack_id), _text(pose_name))
        for pack_id, pose_name in (refs or [])
        if _text(pack_id) and _text(pose_name)
    )
    if not ref_keys:
        return data, False

    old_bindings = data.get("cas_bindings", []) or []
    old_outfits = data.get("outfit_bindings", []) or []
    removed_outfit_ids = set()

    new_bindings = []
    for binding in old_bindings:
        if not isinstance(binding, dict):
            continue
        key = (_text(binding.get("pack_id")), _text(binding.get("pose_name")))
        if key in ref_keys:
            outfit_id = _text(binding.get("outfit_binding_id"))
            if outfit_id:
                removed_outfit_ids.add(outfit_id)
            continue
        new_bindings.append(binding)

    new_outfits = []
    for outfit in old_outfits:
        if not isinstance(outfit, dict):
            continue
        key = (_text(outfit.get("pack_id")), _text(outfit.get("pose_name")))
        outfit_id = _text(outfit.get("outfit_binding_id"))
        if key in ref_keys or (outfit_id and outfit_id in removed_outfit_ids):
            continue
        new_outfits.append(outfit)

    changed = len(new_bindings) != len(old_bindings) or len(new_outfits) != len(old_outfits)
    if changed:
        data["cas_bindings"] = new_bindings
        data["outfit_bindings"] = new_outfits
        data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    return data, changed


def delete_saved_cas_pose_refs(refs):
    refs = list(refs or [])
    if not refs:
        return 0
    changed_count = 0
    saved_any = False
    for folder in _candidate_dirs():
        try:
            path = _path_in(folder, CAS_BINDINGS_FILENAME)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8") as stream:
                data = json.load(stream)
            old_count = len(data.get("cas_bindings", []) or []) + len(data.get("outfit_bindings", []) or [])
            data, changed = _clean_pose_refs_from_data(data, refs)
            if not changed:
                continue
            new_count = len(data.get("cas_bindings", []) or []) + len(data.get("outfit_bindings", []) or [])
            changed_count += max(0, old_count - new_count)
            if _save_data_to_folder(folder, data):
                saved_any = True
        except Exception:
            continue
    return changed_count if saved_any else 0


def _delete_outfit_binding_from_data(data, pack_id, pose_name, outfit_binding_id):
    if not isinstance(data, dict):
        return data, 0
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    outfit_binding_id = _text(outfit_binding_id)
    if not pack_id or not pose_name or not outfit_binding_id:
        return data, 0

    old_bindings = data.get("cas_bindings", []) or []
    old_outfits = data.get("outfit_bindings", []) or []
    legacy_label = outfit_binding_id[len("legacy::"):] if outfit_binding_id.startswith("legacy::") else ""

    new_bindings = []
    for binding in old_bindings:
        if not isinstance(binding, dict):
            continue
        same_pose = (
            _text(binding.get("pack_id")) == pack_id
            and _text(binding.get("pose_name")) == pose_name
        )
        binding_outfit_id = _text(binding.get("outfit_binding_id"))
        binding_label = _text(binding.get("outfit_label"))
        should_remove = same_pose and (
            binding_outfit_id == outfit_binding_id
            or (legacy_label and not binding_outfit_id and binding_label == legacy_label)
        )
        if should_remove:
            continue
        new_bindings.append(binding)

    new_outfits = []
    for outfit in old_outfits:
        if not isinstance(outfit, dict):
            continue
        same_pose = (
            _text(outfit.get("pack_id")) == pack_id
            and _text(outfit.get("pose_name")) == pose_name
        )
        if same_pose and _text(outfit.get("outfit_binding_id")) == outfit_binding_id:
            continue
        new_outfits.append(outfit)

    removed = (len(old_bindings) - len(new_bindings)) + (len(old_outfits) - len(new_outfits))
    if removed:
        data["cas_bindings"] = new_bindings
        data["outfit_bindings"] = new_outfits
        data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    return data, removed


def delete_saved_outfit_binding(pack_id, pose_name, outfit_binding_id):
    pack_id = _text(pack_id)
    pose_name = _text(pose_name)
    outfit_binding_id = _text(outfit_binding_id)
    if not pack_id or not pose_name or not outfit_binding_id:
        return 0
    changed_count = 0
    saved_any = False
    for folder in _candidate_dirs():
        try:
            path = _path_in(folder, CAS_BINDINGS_FILENAME)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8") as stream:
                data = json.load(stream)
            data, removed = _delete_outfit_binding_from_data(data, pack_id, pose_name, outfit_binding_id)
            if not removed:
                continue
            changed_count += int(removed or 0)
            if _save_data_to_folder(folder, data):
                saved_any = True
        except Exception:
            continue
    return changed_count if saved_any else 0
