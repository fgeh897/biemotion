# -*- coding: utf-8 -*-
"""
FGEH Pose Manager - Navigation V2 legacy interaction bridge
============================================================

Small runtime shim that lets the new custom-UI path stack coexist with the
legacy couplepose1 restore/suppress injections WITHOUT replacing couplepose1.py.

The bridge is installed lazily from fgeh_pose_manager_ui_panel once the real
PoseByPack interaction classes are available.
"""

_INSTALLED = False


def _debug(message, exc=False):
    try:
        import couplepose1 as manager
        logger = getattr(manager, "fgeh_pose_manager_debug_log", None)
        if callable(logger):
            logger("[NAV_V2_BRIDGE] {}".format(message), exc=exc)
    except Exception:
        pass


def ensure_installed():
    global _INSTALLED
    if _INSTALLED:
        return True

    try:
        import injector2
        import poseplayer
        import couplepose1 as manager
        import fgeh_pose_manager_ui_navigation as nav
    except Exception:
        return False

    target_cls = getattr(poseplayer, "PoseByPackInteraction", None)
    detail_cls = getattr(poseplayer, "PoseByPackNameInteraction", None)
    if target_cls is None or isinstance(target_cls, str):
        return False

    try:
        @injector2.inject(target_cls, '_run_interaction_gen', safe=True)
        def _fgeh_nav_v2_restore_outer(original, self, timeline, *args, **kwargs):
            state = getattr(manager, "state", None)
            if state is None:
                return original(self, timeline, *args, **kwargs)

            # Old builds leave a global bool after closing a detail.  Scope it
            # to the SAME interaction instance so it cannot eat a later manual
            # reopen created as a new interaction.
            if bool(getattr(state, "suppress_next_history_restore", False)):
                guarded_id = getattr(
                    state,
                    "_fgeh_nav_v2_guard_interaction_id",
                    None,
                )
                state.suppress_next_history_restore = False
                try:
                    state._fgeh_nav_v2_guard_interaction_id = None
                except Exception:
                    pass

                if guarded_id == id(self):
                    _debug("consume same-interaction internal-return guard")
                    return original(self, timeline, *args, **kwargs)

            # H45: NAV_V2 is the authoritative browser-history model for the
            # custom UI.  Do not let the legacy restore_last_view_on_open
            # switch suppress an already-existing NAV_V2 path.  That legacy
            # switch only controls migration from the old single
            # last_ui_snapshot model when there is no NAV_V2 stack yet.
            #
            # This preserves the core NAV_V2 invariant:
            #   Close != Back. Closing never pops; reopening resumes the top.
            try:
                nav_stack = nav.load_stack(manager)
            except Exception:
                nav_stack = []

            if not nav_stack:
                if bool(getattr(state, "restore_last_view_on_open", False)):
                    try:
                        nav.migrate_legacy_if_needed(manager)
                        nav_stack = nav.load_stack(manager)
                    except Exception:
                        nav_stack = []

            if not nav_stack:
                return original(self, timeline, *args, **kwargs)

            try:
                nav_kind, nav_pack = nav.apply_current(manager)

                if nav_kind == "pack" and nav_pack is not None:
                    _debug("restore pack {}".format(
                        getattr(nav_pack, "__name__", nav_pack)
                    ))
                    self.on_choice_selected(nav_pack)
                    return True

                if nav_kind == "root":
                    # V8.9.59:
                    # Do NOT reuse legacy suppress_next_history_restore here.
                    # In couplepose1 that flag has a second meaning: "this is
                    # the ESC return path, show the original/native picker".
                    # V8.9.58 accidentally triggered that path and produced a
                    # small EA "POSE BY PACK" picker over the custom UI.
                    #
                    # We already have the real root interaction instance here,
                    # so reopen the custom EpicCard root directly and give it
                    # the same on_choice_selected callback the normal root uses.
                    try:
                        from fgeh_pose_manager_ui_panel import show_pose_manager_root

                        owner = getattr(self, "sim", None)
                        if owner is None:
                            owner = getattr(self, "target", None)

                        on_pack_selected = getattr(self, "on_choice_selected", None)
                        if owner is not None:
                            opened = show_pose_manager_root(
                                owner,
                                on_pack_selected=on_pack_selected,
                            )
                            if opened:
                                _debug("restore root directly in custom UI")
                                return True

                        _debug("direct custom root restore unavailable; fallback legacy")
                    except Exception:
                        _debug("direct custom root restore failed; fallback legacy", exc=True)

                    return original(self, timeline, *args, **kwargs)
            except Exception:
                _debug("restore outer failed; fallback legacy", exc=True)

            return original(self, timeline, *args, **kwargs)

        if detail_cls is not None and not isinstance(detail_cls, str):
            @injector2.inject(detail_cls, '_on_picker_selected', safe=True)
            def _fgeh_nav_v2_close_guard_outer(original, self, dialog, *args, **kwargs):
                closed = False
                try:
                    tags = dialog.get_result_tags()
                    closed = not any(tags)
                except Exception:
                    closed = True

                result = original(self, dialog, *args, **kwargs)

                if closed:
                    state = getattr(manager, "state", None)
                    if state is not None:
                        # Preserve compatibility with the old inner wrapper,
                        # but attach ownership to this interaction instance.
                        state.suppress_next_history_restore = True
                        try:
                            state._fgeh_nav_v2_guard_interaction_id = id(self)
                        except Exception:
                            pass
                    try:
                        nav.persist(manager)
                    except Exception:
                        pass
                    _debug("detail close persisted; guard interaction={}".format(id(self)))

                return result

        _INSTALLED = True
        _debug("installed")
        return True
    except Exception:
        _debug("install failed", exc=True)
        return False
