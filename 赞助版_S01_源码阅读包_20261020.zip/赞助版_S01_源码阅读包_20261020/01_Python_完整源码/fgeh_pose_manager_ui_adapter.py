# -*- coding: utf-8 -*-
"""
Small, game-agnostic helpers for the custom Pose Manager UI protocol.

V8.4 notes
-----------
This file deliberately keeps the original public API intact:
- clamp_scroll_row
- encode_pack_response / decode_pack_response
- encode_pack_favorite_response / decode_pack_favorite_response
- encode_page_response / decode_page_response
- clamp_page
- pack_payload

New V7 helpers are additive only.

The JSON/state itself is NOT duplicated here.  fgeh_user_data.json remains
owned by couplepose1.py -> load_favorites() -> state.
"""

SCHEMA_VERSION = "FGEH_POSE_UI_V2"

ROW_FIELD_COUNT = 6
HEADER_FIELD_COUNT = 12

# The AS already owns 12 reusable native cells (3 x 4).
# The old compiled adapter was still PAGE_SIZE = 9, which is why the
# current page view only used 3 x 3 even though the GFX has 12 cells.
PAGE_SIZE = 12

RESPONSE_ITEM_BASE = 100000
RESPONSE_ITEM_FAVORITE_BASE = 400000
RESPONSE_BACK = 700000
RESPONSE_PAGE_BASE = 900000
RESPONSE_MODE_TOGGLE = 800000

# ------------------------------------------------------------------
# V7 root navigation
# ------------------------------------------------------------------
RESPONSE_NAV_BASE = 810000
RESPONSE_NAV_COUNT = 10
# GFX-only nested child under ALL Packs. Index 8 remains reserved for Blank Packs.
RESPONSE_NAV_BLANK_PACKS = RESPONSE_NAV_BASE + 8  # 810008
# Dedicated top-level Outfit Manager. Existing top-level indices 0..7 stay stable.
RESPONSE_NAV_OUTFIT_MANAGER = RESPONSE_NAV_BASE + 9  # 810009

NAV_ALL_PACKS = 0
NAV_FAVORITE_PACKS = 1
NAV_FAVORITE_CREATORS = 2
NAV_GROUPED_PACKS = 3
NAV_FAVORITE_POSES = 4
NAV_LINKED_ACTIONS = 5
NAV_ACCESSORY_LIBRARY = 6
NAV_SETTINGS = 7
NAV_OUTFIT_MANAGER = 9

# ------------------------------------------------------------------
# V7 pack-detail grouping responses
# NOTE: panel callback MUST decode these BEFORE favorite response,
# because 620xxx lies inside the old [400000, 700000) favorite range.
# ------------------------------------------------------------------
RESPONSE_GROUP_MANAGE = 620000
RESPONSE_GROUP_CREATE = 620001
RESPONSE_GROUP_SMART_TWO = 620020
RESPONSE_GROUP_SMART_THREE = 620021

RESPONSE_GROUP_TAB_BASE = 620100
RESPONSE_GROUP_EDIT_BASE = 621000
RESPONSE_GROUP_DELETE_BASE = 622000
RESPONSE_GROUP_RENAME_BASE = 625000

# V8.0 pack-inner group member editing / outer group assignment
RESPONSE_GROUP_SMART_PATTERN = 620030
RESPONSE_GROUP_EDIT_DONE = 620031
RESPONSE_GROUP_MEMBER_TOGGLE_BASE = 623000
RESPONSE_GROUP_OUTER_TOGGLE_BASE = 626000

# ------------------------------------------------------------------
# V7.6 外层动作分组管理：直接操作 user_grouped_packs_groups
# ------------------------------------------------------------------
RESPONSE_OUTER_GROUP_CREATE = 640001
RESPONSE_OUTER_GROUP_DONE = 640002
RESPONSE_OUTER_GROUP_SELECT_ALL = 640003
RESPONSE_OUTER_GROUP_CLEAR = 640004
RESPONSE_OUTER_GROUP_EDIT_BASE = 641000
RESPONSE_OUTER_GROUP_DELETE_BASE = 642000
RESPONSE_OUTER_GROUP_RENAME_BASE = 643000

# ------------------------------------------------------------------
# V8.7 ROOT lightweight toolbar
# 650000 = A→Z / Z→A
# 650001 = 收藏动作包视图：全部 / 作者 / 分组
# ------------------------------------------------------------------
RESPONSE_ROOT_SORT_TOGGLE = 650000
RESPONSE_FAV_PACK_VIEW_TOGGLE = 650001
RESPONSE_FAV_POSE_VIEW_TOGGLE = 650002
RESPONSE_LINKED_VIEW_TOGGLE = 650003
RESPONSE_CREATOR_VIEW_TOGGLE = 650004
RESPONSE_ROOT_SEARCH_APPLY = 650005
RESPONSE_BLANK_PACK_VIEW_TOGGLE = 650006
RESPONSE_EDIT_INFO_REFRESH = 660999

GROUP_INDEX_RANGE = 1000

# ------------------------------------------------------------------
# Optional payload extension.
#
# Old payload:
#   12 header strings + 6 strings per row
#
# Extension begins EXACTLY at:
#   HEADER_FIELD_COUNT + len(rows) * ROW_FIELD_COUNT
# ------------------------------------------------------------------
EXT_MAGIC = "FGEH_POSE_UI_EXT_V1"
MEMBER_EDIT_MAGIC = "FGEH_MEMBER_EDIT_V1"
OUTER_GROUP_MAGIC = "FGEH_OUTER_GROUPS_V1"
ROOT_TOOLS_MAGIC = "FGEH_ROOT_TOOLS_V1"
BATCH_FAVORITE_GROUPS_MAGIC = "FGEH_BATCH_FAVORITE_GROUPS_V1"
EDIT_INFO_MAGIC = "FGEH_EDIT_INFO_V1"
LINKED_DETAIL_MAGIC = "FGEH_LINKED_DETAIL_V1"
LINKED_PRODUCTS_MAGIC = "FGEH_LINKED_PRODUCTS_V1"
LINKED_PRODUCTS_V2_MAGIC = "FGEH_LINKED_PRODUCTS_V2"
LINKED_OBJECT_PRODUCTS_MAGIC = "FGEH_LINKED_OBJECT_PRODUCTS_V1"
LINKED_EDIT_MAGIC = "FGEH_LINKED_EDIT_V1"
GLOBAL_WIDGETS_MAGIC = "FGEH_GLOBAL_WIDGETS_V1"
LOCALIZATION_MAGIC = "FGEH_LOCALIZATION_V2"


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def clamp_scroll_row(value, item_count, columns=3, visible_rows=5):
    try:
        value = int(value)
    except Exception:
        value = 0

    columns = max(1, int(columns))
    visible_rows = max(1, int(visible_rows))
    total_rows = (max(0, int(item_count)) + columns - 1) // columns

    return max(
        0,
        min(
            value,
            max(0, total_rows - visible_rows)
        )
    )


def encode_pack_response(pack_index, scroll_row=0):
    # scroll_row is retained for old call-site compatibility.
    del scroll_row
    pack_index = max(0, int(pack_index))
    return RESPONSE_ITEM_BASE + pack_index


def encode_pack_favorite_response(pack_index, scroll_row=0):
    # scroll_row is retained for old call-site compatibility.
    del scroll_row
    pack_index = max(0, int(pack_index))
    return RESPONSE_ITEM_FAVORITE_BASE + pack_index


def decode_pack_response(response):
    try:
        value = int(response)
    except Exception:
        return None

    if value < RESPONSE_ITEM_BASE or value >= RESPONSE_ITEM_FAVORITE_BASE:
        return None

    return value - RESPONSE_ITEM_BASE


def decode_pack_favorite_response(response):
    try:
        value = int(response)
    except Exception:
        return None

    if value < RESPONSE_ITEM_FAVORITE_BASE or value >= RESPONSE_BACK:
        return None

    return value - RESPONSE_ITEM_FAVORITE_BASE


def encode_page_response(page_index):
    return RESPONSE_PAGE_BASE + max(0, int(page_index))


def decode_page_response(response):
    try:
        value = int(response)
    except Exception:
        return None

    if value < RESPONSE_PAGE_BASE:
        return None

    return value - RESPONSE_PAGE_BASE


def clamp_page(value, item_count, page_size=PAGE_SIZE):
    try:
        value = int(value)
    except Exception:
        value = 0

    page_size = max(1, int(page_size))
    page_count = max(
        1,
        (max(0, int(item_count)) + page_size - 1) // page_size
    )

    return max(0, min(value, page_count - 1))


# ============================================================
# V7 navigation helpers
# ============================================================

def encode_nav_response(nav_index):
    nav_index = max(0, min(int(nav_index), RESPONSE_NAV_COUNT - 1))
    return RESPONSE_NAV_BASE + nav_index


def decode_nav_response(response):
    try:
        value = int(response)
    except Exception:
        return None

    if value < RESPONSE_NAV_BASE:
        return None

    index = value - RESPONSE_NAV_BASE
    if index < 0 or index >= RESPONSE_NAV_COUNT:
        return None

    return index


# ============================================================
# V7 grouping response helper
# ============================================================

def decode_group_response(response):
    """
    Returns:
        None
        ("manage", None)
        ("create", None)
        ("smart_two", None)
        ("smart_three", None)
        ("tab", index)       # index 0 means 全部动作
        ("edit", index)
        ("delete", index)
        ("rename", index)
    """
    try:
        value = int(response)
    except Exception:
        return None

    if value == RESPONSE_GROUP_MANAGE:
        return ("manage", None)

    if value == RESPONSE_GROUP_CREATE:
        return ("create", None)

    if value == RESPONSE_GROUP_SMART_TWO:
        return ("smart_two", None)

    if value == RESPONSE_GROUP_SMART_THREE:
        return ("smart_three", None)

    if value == RESPONSE_GROUP_SMART_PATTERN:
        return ("smart_pattern", None)

    if value == RESPONSE_GROUP_EDIT_DONE:
        return ("edit_done", None)

    # V8.2:
    # RESPONSE_GROUP_TAB_BASE (620100) and RESPONSE_GROUP_EDIT_BASE
    # (621000) overlap if the generic 1000-value range is used.
    # That made 621000 decode as ("tab", 900), so "编辑成员" appeared
    # to do nothing.  Tabs only need the dedicated 620100..620999 band.
    if RESPONSE_GROUP_EDIT_BASE <= value < RESPONSE_GROUP_EDIT_BASE + GROUP_INDEX_RANGE:
        return ("edit", value - RESPONSE_GROUP_EDIT_BASE)

    if RESPONSE_GROUP_TAB_BASE <= value < RESPONSE_GROUP_EDIT_BASE:
        return ("tab", value - RESPONSE_GROUP_TAB_BASE)

    if RESPONSE_GROUP_DELETE_BASE <= value < RESPONSE_GROUP_DELETE_BASE + GROUP_INDEX_RANGE:
        return ("delete", value - RESPONSE_GROUP_DELETE_BASE)

    if RESPONSE_GROUP_MEMBER_TOGGLE_BASE <= value < RESPONSE_GROUP_MEMBER_TOGGLE_BASE + GROUP_INDEX_RANGE:
        return ("member_toggle", value - RESPONSE_GROUP_MEMBER_TOGGLE_BASE)

    if RESPONSE_GROUP_RENAME_BASE <= value < RESPONSE_GROUP_RENAME_BASE + GROUP_INDEX_RANGE:
        return ("rename", value - RESPONSE_GROUP_RENAME_BASE)

    if RESPONSE_GROUP_OUTER_TOGGLE_BASE <= value < RESPONSE_GROUP_OUTER_TOGGLE_BASE + GROUP_INDEX_RANGE:
        return ("outer_toggle", value - RESPONSE_GROUP_OUTER_TOGGLE_BASE)

    return None



def decode_outer_group_response(response):
    """
    Returns:
        None
        ("create", None)
        ("done", None)
        ("select_all", None)
        ("clear", None)
        ("edit", group_index)
        ("delete", group_index)
        ("rename", group_index)
    """
    try:
        value = int(response)
    except Exception:
        return None

    if value == RESPONSE_OUTER_GROUP_CREATE:
        return ("create", None)

    if value == RESPONSE_OUTER_GROUP_DONE:
        return ("done", None)

    if value == RESPONSE_OUTER_GROUP_SELECT_ALL:
        return ("select_all", None)

    if value == RESPONSE_OUTER_GROUP_CLEAR:
        return ("clear", None)

    if (
        RESPONSE_OUTER_GROUP_EDIT_BASE
        <= value
        < RESPONSE_OUTER_GROUP_EDIT_BASE + GROUP_INDEX_RANGE
    ):
        return ("edit", value - RESPONSE_OUTER_GROUP_EDIT_BASE)

    if (
        RESPONSE_OUTER_GROUP_DELETE_BASE
        <= value
        < RESPONSE_OUTER_GROUP_DELETE_BASE + GROUP_INDEX_RANGE
    ):
        return ("delete", value - RESPONSE_OUTER_GROUP_DELETE_BASE)

    if (
        RESPONSE_OUTER_GROUP_RENAME_BASE
        <= value
        < RESPONSE_OUTER_GROUP_RENAME_BASE + GROUP_INDEX_RANGE
    ):
        return ("rename", value - RESPONSE_OUTER_GROUP_RENAME_BASE)

    return None


def payload_extension_base(row_count):
    return HEADER_FIELD_COUNT + max(0, int(row_count)) * ROW_FIELD_COUNT


def _payload_text(value):
    # Keep real LocalizedString protobufs intact until panel converts the
    # flattened payload into UiDialog additional_texts.
    try:
        if getattr(value, "hash", None):
            return value
    except Exception:
        pass
    return str(value if value is not None else "")


def pack_payload(header, rows):
    """
    Flatten header / row dictionaries into AS3-friendly strings.

    Original V2 header indices are preserved:
      0  schema
      1  page
      2  page_count
      3  item_count
      4  page_label
      5  filter
      6  query
      7  len(rows)
      8  navigation_mode
      9  navigation_label
      10 view_title
      11 library_label

    Each row remains exactly 6 fields:
      pack_id, name, creator, pose_count, favorite, icon_index

    If header["enable_v7"] is truthy, an optional extension block is
    appended AFTER all rows.  Old readers can ignore it.
    """
    payload = [
        SCHEMA_VERSION,
        str(header.get("page", 0)),
        str(header.get("page_count", 1)),
        str(header.get("item_count", len(rows))),
        _payload_text(header.get("page_label", "")),
        str(header.get("filter", "all")),
        str(header.get("query", "")),
        str(len(rows)),
        str(header.get("navigation_mode", "scroll")),
        _payload_text(header.get("navigation_label", "滑动")),
        _payload_text(header.get("view_title", "动作库")),
        _payload_text(header.get("library_label", "全部动作包")),
    ]

    for row in rows:
        payload.extend((
            str(row.get("pack_id", "")),
            _payload_text(row.get("name", "")),
            _payload_text(row.get("creator", "")),
            _payload_text(row.get("pose_count", 0)),
            "1" if row.get("favorite") else "0",
            str(row.get("icon_index", -1)),
        ))

    if header.get("enable_v7"):
        raw_group_names = header.get("group_names", ()) or ()
        try:
            group_names = [str(value) for value in raw_group_names]
        except Exception:
            group_names = []

        payload.extend((
            EXT_MAGIC,
            str(header.get("view_kind", "")),
            str(header.get("active_nav", NAV_ALL_PACKS)),
            str(len(group_names)),
            str(header.get("active_group_index", -1)),
        ))
        payload.extend(group_names)

        if header.get("member_edit_mode"):
            payload.extend((
                MEMBER_EDIT_MAGIC,
                str(header.get("member_edit_group_index", -1)),
                str(header.get("member_selected_flags", "")),
            ))

        raw_outer_names = header.get("outer_group_names", ()) or ()
        try:
            outer_names = [str(value) for value in raw_outer_names]
        except Exception:
            outer_names = []

        if outer_names:
            raw_outer_selected = header.get("outer_group_selected", ()) or ()
            selected = [
                bool(raw_outer_selected[index])
                if index < len(raw_outer_selected)
                else False
                for index in range(len(outer_names))
            ]

            payload.extend((
                OUTER_GROUP_MAGIC,
                str(len(outer_names)),
            ))

            for index, name in enumerate(outer_names):
                payload.extend((
                    name,
                    "1" if selected[index] else "0",
                ))

        # V8.7 lightweight toolbar is appended as a self-identifying block.
        # Older AS readers safely ignore it.
        if header.get("root_tools"):
            payload.extend((
                ROOT_TOOLS_MAGIC,
                str(header.get("root_view_label", "")),
                str(header.get("root_sort_label", "A → Z")),
                "1" if header.get("root_view_enabled") else "0",
                "1" if header.get("root_sort_enabled", True) else "0",
            ))

        # V8.9.16:
        # Batch-selection can immediately file favorite Packs / Poses into
        # the user's existing favorite groups.  This block is intentionally
        # independent from the current page/view group tabs.
        raw_pack_groups = header.get("favorite_pack_group_names", ()) or ()
        raw_pose_groups = header.get("favorite_pose_group_names", ()) or ()

        try:
            favorite_pack_groups = [str(value) for value in raw_pack_groups]
        except Exception:
            favorite_pack_groups = []

        try:
            favorite_pose_groups = [str(value) for value in raw_pose_groups]
        except Exception:
            favorite_pose_groups = []

        payload.extend((
            BATCH_FAVORITE_GROUPS_MAGIC,
            str(len(favorite_pack_groups)),
        ))
        payload.extend(favorite_pack_groups)
        payload.append(str(len(favorite_pose_groups)))
        payload.extend(favorite_pose_groups)

        # V8.9.17.3:
        # Favorite folders and action outer-groups are two independent
        # namespaces. Append the action-group names after the old block so
        # old readers still decode the original fields exactly the same way.
        raw_outer_action_groups = header.get(
            "outer_action_group_names",
            (),
        ) or ()
        try:
            outer_action_groups = [
                str(value)
                for value in raw_outer_action_groups
            ]
        except Exception:
            outer_action_groups = []

        payload.append(str(len(outer_action_groups)))
        payload.extend(outer_action_groups)

        # V8.8 middle-click metadata for visible data rows.
        raw_edit_keys = header.get("edit_keys", ()) or ()
        if raw_edit_keys:
            raw_edit_names = header.get("edit_names", ()) or ()
            raw_edit_notes = header.get("edit_notes", ()) or ()
            payload.extend((EDIT_INFO_MAGIC, str(len(rows))))
            for index in range(len(rows)):
                payload.extend((
                    str(raw_edit_keys[index] if index < len(raw_edit_keys) else ""),
                    str(raw_edit_names[index] if index < len(raw_edit_names) else ""),
                    str(raw_edit_notes[index] if index < len(raw_edit_notes) else ""),
                ))

        # V8.9 linked-action detail payload.
        if header.get("linked_detail"):
            linked_rows = header.get("linked_detail_rows", ()) or ()
            payload.extend((
                LINKED_DETAIL_MAGIC,
                str(header.get("linked_pack_id", "")),
                str(len(linked_rows)),
            ))
            for row in linked_rows:
                resources = row.get("resources", ()) or ()
                payload.extend((
                    str(row.get("pose_name", "")),
                    "1" if row.get("cas_auto", True) else "0",
                    "1" if row.get("object_auto", True) else "0",
                    str(len(resources)),
                ))
                for resource in resources:
                    payload.extend((
                        str(resource.get("type", "")),
                        str(resource.get("item_id", 0)),
                        _payload_text(resource.get("label", "")),
                        _payload_text(resource.get("description", "")),
                        "1" if resource.get("enabled") else "0",
                        str(resource.get("icon_index", -1)),
                        str(resource.get("origin", "external")),
                    ))

            # V8.9.31 shared CAS catalog protocol. Static product/variant
            # metadata is emitted ONCE per unique catalog; each Pose carries
            # only catalog_index + CAS auto + selected ids. This removes the
            # old N_poses * N_swatches payload duplication.
            shared_catalogs = header.get("linked_cas_catalogs")
            pose_states = header.get("linked_cas_pose_states")
            if shared_catalogs is not None and pose_states is not None:
                payload.extend((
                    LINKED_PRODUCTS_V2_MAGIC,
                    str(header.get("linked_pack_id", "")),
                    str(len(shared_catalogs or ())),
                ))
                for catalog in shared_catalogs or ():
                    payload.append(str(len(catalog or ())))
                    for product in catalog or ():
                        variants = product.get("variants", ()) or ()
                        payload.extend((
                            str(product.get("product_key", "")),
                            _payload_text(product.get("product_label", "")),
                            str(product.get("key_source", "")),
                            str(len(variants)),
                        ))
                        for variant in variants:
                            payload.extend((
                                str(variant.get("item_id", 0)),
                                _payload_text(variant.get("variant_label", "")),
                                str(variant.get("swatch_index", 0)),
                                str(variant.get("swatch_color", "")),
                                str(variant.get("origin", "external")),
                            ))

                payload.append(str(len(pose_states or ())))
                for pose_state in pose_states or ():
                    selected = [
                        str(value) for value in (pose_state.get("selected_ids", ()) or ())
                    ]
                    payload.extend((
                        str(pose_state.get("pose_name", "")),
                        str(pose_state.get("catalog_index", 0)),
                        "1" if pose_state.get("cas_auto", True) else "0",
                        ",".join(selected),
                    ))
            else:
                # Legacy V1 serialization remains supported for old callers.
                payload.extend((
                    LINKED_PRODUCTS_MAGIC,
                    str(header.get("linked_pack_id", "")),
                    str(len(linked_rows)),
                ))
                for row in linked_rows:
                    products = row.get("cas_products", ()) or ()
                    payload.extend((
                        str(row.get("pose_name", "")),
                        str(len(products)),
                    ))
                    for product in products:
                        variants = product.get("variants", ()) or ()
                        payload.extend((
                            str(product.get("product_key", "")),
                            _payload_text(product.get("product_label", "")),
                            str(product.get("key_source", "")),
                            str(len(variants)),
                        ))
                        for variant in variants:
                            payload.extend((
                                str(variant.get("resource_index", -1)),
                                str(variant.get("item_id", 0)),
                                _payload_text(variant.get("variant_label", "")),
                                str(variant.get("swatch_index", 0)),
                            ))

            # V8.9.35 object product/style grouping. This is an additive
            # extension: old GFX builds simply ignore it, while new builds can
            # collapse several Build/Buy style definitions into one card.
            payload.extend((
                LINKED_OBJECT_PRODUCTS_MAGIC,
                str(header.get("linked_pack_id", "")),
                str(len(linked_rows)),
            ))
            for row in linked_rows:
                products = row.get("object_products", ()) or ()
                payload.extend((
                    str(row.get("pose_name", "")),
                    str(len(products)),
                ))
                for product in products:
                    variants = product.get("variants", ()) or ()
                    payload.extend((
                        str(product.get("product_key", "")),
                        _payload_text(product.get("product_label", "")),
                        str(product.get("key_source", "")),
                        str(len(variants)),
                    ))
                    for variant in variants:
                        payload.extend((
                            str(variant.get("resource_index", -1)),
                            str(variant.get("item_id", 0)),
                            _payload_text(variant.get("variant_label", "")),
                            str(variant.get("swatch_index", 0)),
                            str(variant.get("origin", "external")),
                        ))

            # V8.9.39 additive edit metadata. Product protocols above remain
            # unchanged, so older GFX can safely ignore this trailing block.
            linked_edit_items = header.get("linked_edit_items", ()) or ()
            payload.extend((
                LINKED_EDIT_MAGIC,
                str(len(linked_edit_items)),
            ))
            for item in linked_edit_items:
                payload.extend((
                    str(item.get("key", "")),
                    str(item.get("name", "")),
                    str(item.get("note", "")),
                    _payload_text(item.get("original", "")),
                ))

        # V8.9.53 global lightweight widgets.  Kept as its own trailing
        # self-identifying block so future visual skins can change theme
        # palettes without touching the stable pose/card protocols.
        payload.extend((
            GLOBAL_WIDGETS_MAGIC,
            "1" if header.get("global_plumbob_enabled", True) else "0",
            str(header.get("global_widget_theme", "classic_green")),
        ))

        raw_localization = header.get("ui_localization", ()) or ()
        try:
            localization_entries = list(raw_localization)
        except Exception:
            localization_entries = []
        if localization_entries:
            payload.extend((LOCALIZATION_MAGIC, str(len(localization_entries))))
            for loc_key, loc_value in localization_entries:
                payload.extend((str(loc_key), loc_value))

    def search_signature(header, rows):
        """Fingerprint ordered search input, independent of query/page and object identity."""
        import hashlib
        import json
    
        def stable(value):
            if value is None or isinstance(value, (str, int, float, bool)):
                return value
            if isinstance(value, (list, tuple)):
                return [stable(item) for item in value]
            if isinstance(value, dict):
                return {str(key):stable(item) for key,item in value.items()}
            serialize = getattr(value, 'SerializeToString', None)
            if callable(serialize):
                return {'localized_proto':serialize().hex()}
            raise TypeError('Unstable search signature input')
    
        # Reordering, renaming, notes and identifiers all invalidate the index.
        data = [header.get('view_kind'), header.get('active_nav'),
                [[row.get('pack_id'),row.get('name'),row.get('creator')] for row in rows],
                header.get('edit_keys'),header.get('edit_names'),header.get('edit_notes'),
                header.get('ui_localization')]
        return hashlib.sha256(json.dumps(stable(data),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()

    if header.get('enable_v7'):
        try:
            payload.extend(('FGEH_ROOT_SEARCH_CACHE_F2',search_signature(header,rows)))
        except Exception:
            # Unrepresentable metadata disables caching instead of guessing freshness.
            pass
    return tuple(payload)

