from fgeh_shared_ui_localization import text as _t
# -*- coding: utf-8 -*-
"""Manual positioning panel, session-bound; no persistence or scheduled work."""
import time
import types
import json
import math
import uuid
import re
from urllib.parse import unquote
import services
from fgeh_unified_selection import eligible, position, MAX_SELECTION
import fgeh_unified_selection
from fgeh_unified_history import History
import fgeh_unified_camera
import sims4.commands
from distributor.ops import SendUIMessage
from distributor.system import Distributor

_bound = None
_bound_instance = None
_seen = []
_last = _t('shared_8d42658d64ee')
_ui = False
_entry_generation = 0
_ui_state_received = False
_candidates = []
_token = ''
_wire_debug = _t('shared_e4b0828c2c9e')
_bound_zone = None
_hold = None
_results = {}
_box_candidates = {}
_enrolled = set()
_pool = {}
_people_enabled = True
_objects_enabled = False
_floor = 0
_external_selected = {}
_history=History()
_edit_revision=0
_align_mode='individual'
_pivot_mode='group'
_pivot_object=None
_pivot_xyz=(0.0,0.0,0.0)


def _pairs(session):
    return [(session,n) for n in session.get_positioning_selected_nodes()]+list(_external_selected.values())


def _pivot(session):
    if _pivot_mode=='xyz':
        return _pivot_xyz
    if _pivot_mode=='object':
        owner=services.object_manager().get(_pivot_object)
        if owner is None:
            raise ValueError(_t('shared_f43554f2229d'))
        return position(owner)
    nodes=[node for other,node in _pairs(session)]
    return tuple(sum(position(n.owner)[i] for n in nodes)/len(nodes) for i in range(3)) if nodes else position(session.get_target_sim())


def _rotate_group(session,operation,argument,degrees_override=None,pivot_override=None):
    from types import SimpleNamespace
    from sims4.math import Vector3,Transform,Location,Quaternion
    from andrew_positioning_session import RotationAxisType as A
    pivot=pivot_override if pivot_override is not None else (_hold.get('pivot') if argument and _hold is not None else None)
    if _pivot_mode=='self' and pivot_override is None:
        return _rotate_each(session,operation,argument,degrees_override)
    if pivot is None:
        pivot=_pivot(session)
        if argument and _hold is not None:
            _hold['pivot']=pivot
    # The original session already rotates positions and orientation about a reference transform.
    anchor=SimpleNamespace(location=Location(Transform(Vector3(*pivot),Quaternion.IDENTITY()),session.get_target_sim().routing_surface))
    groups={}
    for other,node in _pairs(session):
        groups.setdefault(other,[]).append(node.key)
    degrees=degrees_override if degrees_override is not None else session.get_positioning_rotation_increment_value()*(1 if operation[2]=='+' else -1)
    for other,keys in groups.items():
        previous=[n.key for n in other.get_positioning_selected_nodes()]
        reference=other.get_reference_center()
        axis=other.get_positioning_rotation_axis_type()
        try:
            other.select_node_keys(keys)
            other.set_positioning_rotation_axis_type({'x':A.PITCH,'y':A.YAW,'z':A.ROLL}[operation[1]])
            if not other.set_reference_center(anchor):
                raise ValueError(_t('shared_6e6755ed300a'))
            other.apply_delta_to_selected_nodes(delta_rotation=degrees)
        finally:
            other.clear_reference_center()
            if reference is not None:
                other.set_reference_center(reference)
            other.set_positioning_rotation_axis_type(axis)
            other.select_node_keys(previous)


def _candidate_session(owner, primary):
    from andrew_positioning_session import get_target_sessions_for_sim,get_all_andrew_positioning_sessions
    active=[s for s in get_target_sessions_for_sim(owner) if not s.is_canceled] if owner.is_sim else [s for s in get_all_andrew_positioning_sessions() if not s.is_canceled and s.get_node_for_owner(owner) is not None]
    other=[s for s in active if s.get_identifier()!=primary.get_identifier()]
    if other:
        if len(active)!=1:
            raise ValueError(_t('shared_b4dc7c12cb58'))
        target=other[0]
        if target.get_node_for_owner(owner) is None:
            if not owner.is_sim or target.get_target_sim() is not owner:
                raise ValueError(_t('shared_1fb20cd7da4b'))
            previous=[n.key for n in target.get_positioning_selected_nodes()]
            try:
                target.add_actor(owner)
            finally:
                target.select_node_keys(previous)
            if target.get_node_for_owner(owner) is None:
                raise ValueError(_t('shared_878f4aa5cb94'))
            _trace('candidate-node-repaired','actor={} session={} selection_preserved=true'.format(owner.id,target.get_identifier()))
    else:
        target=primary
    eligible(owner,target,get_target_sessions_for_sim,allow_new_actors=True)
    return target


def _rebuild_candidates(session):
    # Manual/show refresh only. Persons are independent of the furniture radius
    # and budget; no world polling is introduced.
    selected = {n.owner.id for n in session.get_positioning_selected_nodes()}
    selected.update(_external_selected)
    retained = selected | set(_enrolled)
    if _pivot_mode == 'object' and _pivot_object is not None:
        retained.add(_pivot_object)
    nodes=[n for other,n in _pairs(session)]
    anchor=tuple(sum(position(n.owner)[i] for n in nodes)/len(nodes) for i in range(3)) if nodes else position(session.get_target_sim())
    radius=_nearby_radius()
    people, objects = [], []
    for owner in services.object_manager().get_all():
        try:
            _candidate_session(owner, session)
            distance = sum((a-b)**2 for a,b in zip(position(owner), anchor))
            item = (owner.id not in retained, distance, owner.id, owner)
            if owner.is_sim:
                people.append(item)
            elif distance <= radius*radius or owner.id in retained:
                objects.append(item)
        except Exception as error:
            if getattr(owner, 'is_sim', False):
                _trace('candidate-excluded', '{} {}'.format(getattr(owner, 'id', ''), error))
    people.sort(key=lambda item:item[:3])
    objects.sort(key=lambda item:item[:3])
    _pool.clear()
    _pool.update((str(item[3].id),item[3]) for item in people[:256]+objects[:256])
    _filter_candidates()
    hidden = sum(1 for item in people[:256] if _floor is not None and item[3].routing_surface.secondary_id != _floor)
    text = _t('shared_93831fd867cc').format(sum(bool(o.is_sim) for o in _box_candidates.values()),sum(not bool(o.is_sim) for o in _box_candidates.values()))
    if hidden:
        text += _t('shared_8a9678e3128f').format(hidden)
    if len(people)>256:
        text += _t('shared_ebe81110fbab')
    return text

def _filter_candidates():
    _box_candidates.clear()
    object_count = 0
    for ident, owner in _pool.items():
        if owner.is_sim and not _people_enabled or not owner.is_sim and not _objects_enabled:
            continue
        if _floor is not None and owner.routing_surface.secondary_id != _floor:
            continue
        if not owner.is_sim:
            if object_count >= 64:
                continue
            object_count += 1
        _box_candidates[ident]=owner


def _context(session):
    selected = ','.join(sorted(str(n.key) for n in session.get_positioning_selected_nodes()))+str(sorted((ident,s.get_identifier()) for ident,(s,n) in _external_selected.items()))+str((_edit_revision,_pivot_mode,_pivot_object,_pivot_xyz))
    sim = session.get_target_sim()
    speed = services.game_clock_service().clock_speed
    return '{}:{}:{}:{}:{}:{}'.format(services.current_zone_id(), getattr(sim, 'id', 0),
        selected, session.get_positioning_axis_increment_value(), session.get_positioning_rotation_increment_value(), speed)

def _wire_text(value):
    value = str(value)
    for char in '\u210b\u210e\u210f\u212a\u212b\u212c\u212d\u212e\u2166\u2167\u2168\u2169\ufeff':
        value = value.replace(char, '')
    return value.strip()

def _constant(value):
    def factory(*args, **kwargs):
        return value
    return factory

def _active():
    client = services.client_manager().get_first_client()
    return client.active_sim if client is not None else None

def _session():
    if services.current_zone_id() != _bound_zone:
        raise ValueError(_t('shared_5014fe3dd1e2'))
    if _bound_instance is _free_session and _free_session is not None:
        return _free_session
    from andrew_positioning_session import get_andrew_positioning_session
    session = get_andrew_positioning_session(_bound) if _bound else None
    if session is None or session.is_canceled or session is not _bound_instance:
        raise ValueError(_t('shared_229295a70367'))
    return session

def _clean(value):
    return str(value).replace('\t', ' ').replace('\n', ' ')[:4096 if '\ue000' in str(value) else 120]

def _publish(message=None, request_id='', succeeded=True):
    global _last
    if message is not None:
        _last = _clean(message)
    if not _ui:
        return
    from ui.ui_dialog_labeled_icons import UiDialogIcons
    from sims4.localization import LocalizationHelperTuning
    sim = _active()
    if sim is None:
        return
    texts = [_t('shared_401ff2ed3cf2').format(_last,len(_box_candidates)), '', '', request_id, 'ok' if succeeded else 'error', '']
    try:
        session = _session()
        texts[1] = _token
        texts[5] = _context(session)
        texts[2] = _t('shared_5acb6f2960be').format(session.get_positioning_axis_increment_value(), session.get_positioning_rotation_increment_value(), _t('shared_b4217093bce3') if _people_enabled else _t('shared_a3332f1c9467'), _t('shared_b4217093bce3') if _objects_enabled else _t('shared_a3332f1c9467'), _t('shared_26a30fbc0862') if _floor is None else _t('shared_2427f63eb8c5').format(_floor))
        selected_ids={str(n.owner.id) for other,n in _pairs(session)}
        for ident,owner in _box_candidates.items():
            label=_actor_label(owner) if owner.is_sim else _t('shared_11faaa6381e8').format(owner.id)
            texts.append('{}\t{}\t{}'.format(ident,int(ident in selected_ids),_clean(label)))
        for ident, owner in _box_candidates.items():
            if services.object_manager().get(int(ident)) is owner:
                x,y,z=position(owner)
                node=session.get_node_for_owner(owner)
                texts.append('@{}|{}|{}|{}|{}|{}'.format(ident,int(owner.is_sim),x,y,z,int(str(owner.id) in selected_ids)))
        px,py,pz=_pivot(session)
        texts.append('!{}|{}|{}|{}'.format(_pivot_mode,px,py,pz))
        texts.append('^'+'|'.join(str(v) if v is not None else '' for v in _window_preferences()))
        texts.append('&'+_align_mode)
        texts.append('%'+str(_nearby_radius()))
        texts.append('~{}|{}'.format(session.get_positioning_axis_increment_value(),session.get_positioning_rotation_increment_value()))
    except Exception as error:
        _trace('state-publish-error','{}: {}'.format(type(error).__name__,error))
        texts[0] = _clean(_t('shared_5ebc2744c24b').format(error))
        texts[1] = '';texts[2] = _t('shared_1850c7ceb762');texts[5] = ''
        texts[4] = 'ok' if request_id=='' else 'error'
        del texts[6:]
        texts.append('^'+'|'.join(str(v) if v is not None else '' for v in _window_preferences()))
    texts.append('$flags|{}|{}'.format(int(_people_enabled),int(_objects_enabled)))
    # No responses => UI service does not retain this as an active dialog.
    blank = LocalizationHelperTuning.get_raw_text('')
    from event_testing.resolver import SingleSimResolver
    dialog = UiDialogIcons.TunableFactory().default(sim, resolver=SingleSimResolver(sim.sim_info), title=_constant(blank), text=_constant(blank),
        additional_texts=tuple(_constant(t) for t in __import__("fgeh_shared_ui_localization").pack(texts, not _ui_state_received)),
        show_dialog_message_override='FgEHUnifiedState')
    dialog.set_responses(())
    dialog.show_dialog()

def _resume_panel(session,_connection=None):
    global _token,_ui,_hold,_last,_pivot_mode,_pivot_object
    from andrew_positioning_session import get_target_sessions_for_sim,get_andrew_positioning_session
    def valid(other,node):
        try:
            return (not other.is_canceled and (other is _free_session or get_andrew_positioning_session(other.get_identifier()) is other)
                and services.object_manager().get(node.owner.id) is node.owner
                and other.get_node_for_owner(node.owner) is node
                and eligible(node.owner,other,get_target_sessions_for_sim) is node.owner)
        except Exception:return False
    selected=list(session.get_positioning_selected_nodes())
    kept=[n for n in selected if valid(session,n)]
    session.select_node_keys([n.key for n in kept])
    dropped=len(selected)-len(kept)
    for ident,(other,node) in list(_external_selected.items()):
        if not valid(other,node):del _external_selected[ident];dropped+=1
    for ident,owner in list(_pool.items()):
        try:
            if services.object_manager().get(int(ident)) is not owner:raise ValueError('stale')
            _candidate_session(owner,session)
        except Exception:del _pool[ident]
    # History of departed nodes cannot be restored; retain all surviving records and their initial baselines.
    for ident,record in list(_history.initial.items()):
        if not valid(record['session'],record['node']):del _history.initial[ident]
    steps=[]
    for key,records in _history.steps:
        records={ident:record for ident,record in records.items() if valid(record['session'],record['node'])}
        if records:steps.append((key,records))
    _history.steps=steps
    if _pivot_mode=='object' and str(_pivot_object) not in _pool:
        _pivot_mode='group';_pivot_object=None
    _filter_candidates()
    from andrew_positioning_arrows import remove_arrow_layout
    remove_arrow_layout(session)
    _hold=None
    _token='p2_'+uuid.uuid4().hex
    _seen.clear();_results.clear()
    fgeh_unified_camera.start()
    _ui=True
    _last=_t('shared_d07a6a4b896e')+(_t('shared_cfcecd15a578').format(dropped) if dropped else '')
    _trace('resume','selected={} removed={}'.format(len(kept)+len(_external_selected),dropped))
    Distributor.instance().add_op_with_no_owner(SendUIMessage('ShowFgEHUiLabR01'))
    sims4.commands.CheatOutput(_connection)(_last)
    return True


def _validate_numeric(kind, value):
    low, high = (0.001, 10.0) if kind == 'step' else (0.1, 180.0)
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(_t('shared_b0af3a654095') if kind == 'step' else _t('shared_00ecb2395b2d'))

def _load_numeric_preferences(session):
    try:
        import couplepose1 as manager
        names = getattr(manager.state, 'custom_names', {}) or {}
    except (ImportError, AttributeError):
        names = {}
    for kind, default, setter in (('step', 0.05, session.set_positioning_axis_increment_value), ('angle', 5.0, session.set_positioning_rotation_increment_value)):
        try:
            value = float(names.get('__fgeh_move_'+kind+'__', default))
            _validate_numeric(kind, value)
        except (ValueError, TypeError):
            value = default
        setter(value)

def _save_numeric_preference(kind, value):
    import couplepose1 as manager
    previous = manager.state.custom_names
    names = dict(previous or {})
    names['__fgeh_move_'+kind+'__'] = str(value)
    manager.state.custom_names = names
    try:
        manager.save_favorites()
    except Exception:
        manager.state.custom_names = previous
        raise ValueError(_t('shared_60026f4b7885'))


@sims4.commands.Command('fgeh.unified.refresh', command_type=sims4.commands.CommandType.Live)
def refresh(_connection=None):
    global _hold, _edit_revision
    _disarm_direct()
    if not _ui:
        return True
    try:
        session = _session()
        message = _rebuild_candidates(session)
        if session is _free_session:_sync_free_nodes(session)
        _hold = None
        _edit_revision += 1
        _publish(message)
        return True
    except Exception as error:
        _publish()
        sims4.commands.CheatOutput(_connection)('U21 state: {}'.format(error))
        return False

def _pose(owner):
    location = getattr(owner, 'location', None)
    transform = getattr(location, 'world_transform', None) or getattr(location, 'transform', None)
    if transform is None:
        raise ValueError(_t('shared_00d95fe0ec51'))
    p, q = transform.translation, transform.orientation
    values = tuple(float(getattr(p, k)) for k in ('x', 'y', 'z')) + tuple(float(getattr(q, k)) for k in ('x', 'y', 'z', 'w'))
    if not all(math.isfinite(v) for v in values):
        raise ValueError(_t('shared_66cf29dfee51'))
    return values

def _execute_impl(session, operation, argument):
    packet=argument.split('~')
    argument=packet[0]
    projected=None
    if len(packet)>1:
        if len(packet)!=6:raise ValueError(_t('shared_1237bbd2bfd1'))
        values=tuple(float(v) for v in packet[1:5])
        if not all(math.isfinite(v) for v in values):raise ValueError(_t('shared_1e08123d9f77'))
        lengths=(math.hypot(values[0],values[1]),math.hypot(values[2],values[3]))
        if not all(.9<=v<=1.1 for v in lengths):raise ValueError(_t('shared_22862c1ea1d6'))
        projected={'forward':(values[0],values[1]),'back':(-values[0],-values[1]),'right':(values[2],values[3]),'left':(-values[2],-values[3])}
    global _hold, _people_enabled, _objects_enabled, _floor, _edit_revision, _pivot_mode, _pivot_object, _pivot_xyz, _align_mode
    if operation=='toggle' and session is _free_session and argument in _box_candidates:
        owner=_box_candidates[argument]
        if not owner.is_sim:_enrolled.add(owner.id)
    from andrew_positioning_session import PositioningObjectType as T, RotationAxisType as A, PositioningNodeType
    mapping = {'forward': T.POSITIONING_NORTH, 'back': T.POSITIONING_SOUTH,
        'right': T.POSITIONING_EAST, 'left': T.POSITIONING_WEST, 'up': T.POSITIONING_UP, 'down': T.POSITIONING_DOWN}
    if operation=='alignpoint':
        return _align_native_point(session,argument)
    if operation in ('land','groundalign'):
        return _ground_align(session,argument if operation=='groundalign' else None)
    if operation=='centerself':
        _pivot_mode='self';_hold=None;_edit_revision+=1
        return _t('shared_7d62c2a2093d')
    if operation=='alignmode':
        if argument not in ('individual','group'):raise ValueError(_t('shared_b6046f3749a3'))
        _align_mode=argument;_hold=None;_edit_revision+=1
        return _t('shared_05ac98c4f6bc') if argument=='individual' else _t('shared_f1ecd96e02f9')
    if operation=='aligncancel':
        _disarm_direct()
        return _t('shared_1530a46abd18')
    if operation in ('undo','resetinitial'):
        count=(_history.undo if operation=='undo' else _history.reset)(services.object_manager().get,_history_controller)
        _edit_revision+=1
        _hold=None
        return _t('shared_907fc6c92a90').format(_t('shared_9fcefd8dc81e') if operation=='undo' else _t('shared_0f7dca0dcebb'),count)
    if operation in ('centergroup','centerobject','centerxyz'):
        if operation=='centergroup':
            _pivot_mode='group'
        elif operation=='centerobject':
            ident=str(session.get_target_sim().id) if argument=='primary' else argument
            if ident not in _pool or services.object_manager().get(int(ident)) is not _pool[ident]:
                raise ValueError(_t('shared_4c64cab17f89'))
            _pivot_object=int(ident)
            _pivot_mode='object'
        else:
            values=tuple(float(v) for v in argument.split(','))
            if len(values)!=3 or not all(math.isfinite(v) and abs(v)<100000 for v in values):
                raise ValueError(_t('shared_c257238b0808'))
            _pivot_xyz=values
            _pivot_mode='xyz'
        _edit_revision+=1
        _hold=None
        return _t('shared_ec4cc5dcfe08').format({'group':_t('shared_4786ad9679a3'),'object':_t('shared_d8553b38a487'),'xyz':_t('shared_20122ee06667')}[_pivot_mode])
    if operation=='radius':
        value=float(argument)
        if not math.isfinite(value) or not 1<=value<=256:raise ValueError(_t('shared_b04f54cca050'))
        _save_numeric_preference('radius',value)
        _hold=None;_edit_revision+=1
        return _t('shared_ae02698f25fa').format(value)+_rebuild_candidates(session)
    if operation in ('step', 'angle'):
        value = float(argument)
        _validate_numeric(operation, value)
        _save_numeric_preference(operation, value)
        setter = session.set_positioning_axis_increment_value if operation == 'step' else session.set_positioning_rotation_increment_value
        setter(value)
        return _t('shared_12c8d1494bbb')
    from andrew_positioning_session import get_target_sessions_for_sim
    actors = [n for n in session.get_all_nodes() if n.node_type == PositioningNodeType.ACTOR or n.owner.id in _enrolled]
    if operation in ('peoplefilter','objectfilter','floor'):
        if operation in ('peoplefilter','objectfilter'):
            if argument not in ('0','1'):
                raise ValueError(_t('shared_ad0053943c56'))
            if operation=='peoplefilter':
                _people_enabled=argument=='1'
            else:
                _objects_enabled=argument=='1'
        elif argument=='all':
            _floor=None
        elif argument=='current':
            _floor=session.get_target_sim().routing_surface.secondary_id
        elif argument in ('up','down'):
            _floor=(_floor if _floor is not None else session.get_target_sim().routing_surface.secondary_id)+(1 if argument=='up' else -1)
            _floor=max(-4,min(10,_floor))
        else:
            raise ValueError(_t('shared_18e8c7075c5d'))
        _filter_candidates()
        session.select_node_keys([n.key for n in session.get_positioning_selected_nodes() if str(n.owner.id) in _box_candidates])
        for ident in list(_external_selected):
            if str(ident) not in _box_candidates:
                del _external_selected[ident]
        _hold=None
        return _t('shared_077ce3c1286e')
    if operation == 'boxselect':
        ids=list(dict.fromkeys(argument.split(','))) if argument else []
        if len(ids)>MAX_SELECTION:
            raise ValueError(_t('shared_47c63ffe8388').format(len(ids)))
        if not ids:
            return _t('shared_5c81bac123e4')
        current={str(n.owner.id) for n in session.get_positioning_selected_nodes()}|{str(i) for i in _external_selected}
        should_select=not set(ids).issubset(current)
        final=current.union(ids) if should_select else current.difference(ids)
        if len(final)>MAX_SELECTION:
            raise ValueError(_t('shared_db0d874a27ff').format(len(current),len(ids),len(final)))
        owners=[]
        for ident in ids:
            if re.fullmatch(r'[1-9][0-9]*',ident) is None:
                raise ValueError(_t('shared_3a8811b97e2b'))
            owner=_box_candidates.get(ident)
            if owner is None or services.object_manager().get(int(ident)) is not owner:
                raise ValueError(_t('shared_9176b0fe20c5'))
            owners.append((owner,_candidate_session(owner,session)))
        keys=[n.key for n in session.get_positioning_selected_nodes()]
        external=dict(_external_selected)
        for owner,target_session in owners:
            if not owner.is_sim:_enrolled.add(owner.id)
            if target_session is not session:
                if should_select:
                    external[owner.id]=(target_session,target_session.get_node_for_owner(owner))
                else:
                    external.pop(owner.id,None)
                continue
            node=session.get_node_for_owner(owner)
            if node is None:
                if owner.is_sim:
                    session.add_actor(owner)
                else:
                    session.add_prop(owner,label=_t('shared_50b9a87792f5').format(getattr(owner.definition,'id',owner.id)))
                node=session.get_node_for_owner(owner)
                _enrolled.add(owner.id)
            if should_select:
                if node.key not in keys:
                    keys.append(node.key)
            elif node.key in keys:
                keys.remove(node.key)
        session.select_node_keys(keys)
        _external_selected.clear()
        _external_selected.update(external)
        return _t('shared_d41e25edbaee').format(len(ids),_t('shared_40e7832e307b') if should_select else _t('shared_4d0b4688c787'),len(keys)+len(external))
    if operation == 'clear':
        _external_selected.clear()
        session.select_node_keys([])
        return _t('shared_b665239360a7') 
    if operation == 'catalog':
        _candidates.clear()
        for owner in services.object_manager().get_all():
            if getattr(owner, 'is_sim', False):
                _candidates.append((str(owner.id), '{} {}'.format(getattr(owner, 'first_name', ''), getattr(owner, 'last_name', ''))))
        return _t('shared_bf8e244e6611')
    if operation == 'add':
        from andrew_positioning_session import get_target_sessions_for_sim
        owner = services.object_manager().get(int(argument))
        if owner is None or not getattr(owner, 'is_sim', False):
            raise ValueError(_t('shared_d12f76f7d3ee'))
        if any(s.get_identifier() != session.get_identifier() and not s.is_canceled for s in get_target_sessions_for_sim(owner)):
            raise ValueError(_t('shared_fe50a6522805'))
        if any(n.owner is owner for n in actors):
            raise ValueError(_t('shared_ecb035f751c0'))
        session.add_actor(owner)
        return _t('shared_998b2c3e985b')
    if operation == 'all':
        ids=list(_box_candidates)
        if len(ids)>MAX_SELECTION:raise ValueError(_t('shared_e690e1d468b1'))
        _execute(session,'clear','')
        return _execute(session,'boxselect',','.join(ids))
        keys=[n.key for n in actors if str(n.owner.id) in _box_candidates]
        if len(keys)+len(_external_selected)>MAX_SELECTION:raise ValueError(_t('shared_1f850f9162ac'))
        session.select_node_keys(keys)
        return _t('shared_a45d14aff929')
    if operation == 'primary':
        if str(session.get_target_sim().id) not in _box_candidates:
            raise ValueError(_t('shared_8d1b411041d2'))
        session.select_actor_by_id(session.get_target_sim().id)
        _external_selected.clear()
        return _t('shared_1bfba94d0b6f')
    if operation == 'toggle':
        if argument not in _box_candidates:
            raise ValueError(_t('shared_f452d2d7f23f'))
        if int(argument) in _external_selected:
            del _external_selected[int(argument)]
            return _t('shared_f4bb42f21adf')
        owner=_box_candidates[argument]
        target_session=_candidate_session(owner,session)
        if target_session is not session:
            if len(_pairs(session))>=MAX_SELECTION:raise ValueError(_t('shared_98e577a2f58d'))
            _external_selected[owner.id]=(target_session,target_session.get_node_for_owner(owner))
            return _t('shared_f4bb42f21adf')
        node = next((n for n in actors if str(n.owner.id) == argument), None)
        if node is None:
            raise ValueError(_t('shared_72503d564a60'))
        keys = [n.key for n in session.get_positioning_selected_nodes() if n.node_type == PositioningNodeType.ACTOR or n.owner.id in _enrolled]
        if node.key in keys: keys.remove(node.key)
        else: keys.append(node.key)
        if len(keys)+len(_external_selected)>MAX_SELECTION:raise ValueError(_t('shared_a9d5f6f66662'))
        session.select_node_keys(keys)
        return _t('shared_f4bb42f21adf')
    selected = list(session.get_positioning_selected_nodes())+[n for s,n in _external_selected.values()]
    if len(selected)>MAX_SELECTION:raise ValueError(_t('shared_1fdde7083fa4'))
    if not selected or any(n.node_type != PositioningNodeType.ACTOR and n.owner.id not in _enrolled for n in selected):
        raise ValueError(_t('shared_61ea49f5e0b6'))
    for node in selected:
        if services.object_manager().get(node.owner.id) is not node.owner:
            raise ValueError(_t('shared_0f9a99d5748f'))
        target=_candidate_session(node.owner,session)
        if node.owner.id in _external_selected:
            expected,expected_node=_external_selected[node.owner.id]
            if expected is not target or expected.is_canceled or expected.get_node_for_owner(node.owner) is not expected_node:
                raise ValueError(_t('shared_a83cbc5c2d4b'))
        eligible(node.owner,target,get_target_sessions_for_sim)
    if not math.isfinite(session.get_positioning_axis_increment_value()) or not math.isfinite(session.get_positioning_rotation_increment_value()):
        raise ValueError(_t('shared_b067db933345'))
    if operation=='alignarm':
        if argument not in ('0','1'):raise ValueError(_t('shared_80c301436517'))
        _arm_direct(session,argument)
        return _t('shared_adae0816e1d0')
    if operation=='rebase':
        pairs=_pairs(session)
        from fgeh_unified_history import capture
        records={node.owner.id:capture(other,node) for other,node in pairs}
        _history.initial=records;_history.steps=[]
        _hold=None;_edit_revision+=1
        return _t('shared_3d525d7d21e5')+_rebuild_candidates(session)
    fine=operation in ('forward','back','left','right','up','down','rx+','rx-','ry+','ry-','rz+','rz-') and argument.startswith('f_')
    move_step=session.get_positioning_axis_increment_value()*(0.1 if fine else 1.0)
    before = [_pose(n.owner) for n in selected]
    hold_delta = None
    if argument and operation in ('forward', 'back', 'left', 'right', 'up', 'down', 'rx+', 'rx-', 'ry+', 'ry-', 'rz+', 'rz-'):
        if re.fullmatch(r'(?:f_)?h[0-9]+_[0-9]+', argument) is None:
            raise ValueError(_t('shared_ae5dd654f544'))
        # UI repeats finite single steps; the server never schedules movement.
        # One press locks ground direction at its first accepted request.
        context = _context(session)
        if _hold is None or _hold['id'] != argument:
            _hold = {'id': argument, 'operation': operation, 'context': context, 'delta': None}
            if operation in ('forward', 'back', 'left', 'right'):
                _hold['delta'] = (projected[operation][0]*move_step,0,projected[operation][1]*move_step) if projected is not None else fgeh_unified_camera.delta(operation, move_step)
                _trace('press-start','id={} source={} sample={} delta={} cached={}'.format(argument,'stage-projection' if projected is not None else 'legacy-camera-cache',packet[-1] if projected is not None else '',_hold['delta'],fgeh_unified_camera.describe()))
        elif _hold['operation'] != operation or _hold['context'] != context:
            raise ValueError(_t('shared_9c104c6c2e58'))
        hold_delta = _hold['delta']
    if operation=='align':
        return _align_selected(session,argument)
    motion=('forward','back','left','right','up','down','rx+','rx-','ry+','ry-','rz+','rz-')
    if operation not in motion:
        raise ValueError(_t('shared_fedca63099e7'))
    history_key=(argument if argument else uuid.uuid4().hex,operation,_context(session))
    prepared_delta=(hold_delta if hold_delta is not None else fgeh_unified_camera.delta(operation,move_step)) if operation in ('forward','back','left','right') else None
    _history.begin(history_key,_pairs(session))
    if operation in ('rx+','rx-','ry+','ry-','rz+','rz-'):
        _rotate_group(session,operation,argument,degrees_override=session.get_positioning_rotation_increment_value()*0.1*(1 if operation[2]=='+' else -1) if fine else None)
        return _t('shared_ff7ada53ab57').format(_t('shared_bc4f764327e3') if fine else '',len(selected))
    if operation in ('forward', 'back', 'left', 'right'):
        delta = prepared_delta
        if session.get_positioning_selected_nodes():
            session.apply_delta_to_selected_nodes(delta_position=delta)
    elif operation in mapping:
        from sims4.math import Vector3
        delta=Vector3(0,move_step*(1 if operation=='up' else -1),0)
        if session.get_positioning_selected_nodes():
            session.apply_delta_to_selected_nodes(delta_position=delta)
    elif operation in ('rx+', 'rx-', 'ry+', 'ry-', 'rz+', 'rz-'):
        session.set_positioning_rotation_axis_type({'x': A.PITCH, 'y': A.YAW, 'z': A.ROLL}[operation[1]])
        session.on_positioning_arrow_click(T.ROTATION_CLOCKWISE if operation[2] == '+' else T.ROTATION_COUNTERCLOCKWISE)
    else:
        raise ValueError(_t('shared_fedca63099e7'))
    groups={}
    for other,node in _external_selected.values():
        groups.setdefault(other,[]).append(node.key)
    for other,keys in groups.items():
        previous=[n.key for n in other.get_positioning_selected_nodes()]
        try:
            other.select_node_keys(keys)
            other.apply_delta_to_selected_nodes(delta_position=delta)
        finally:
            other.select_node_keys(previous)
    after = [_pose(n.owner) for n in selected]
    changed = sum(any(abs(a-b)>1e-6 for a,b in zip(old,new)) for old,new in zip(before,after))
    return _t('shared_1264e06a62b5').format(_t('shared_bc4f764327e3') if fine else '',changed, len(selected))

@sims4.commands.Command('fgeh.unified.action', command_type=sims4.commands.CommandType.Live)
def action(session_id: str, request_id: str, operation: str, argument: str = '', _connection=None):
    try:
        if not _ui:
            raise ValueError(_t('shared_8bab71d04a6b'))
        session = _session()
        if session_id != _token:
            raise ValueError(_t('shared_a0122fd192c7'))
        if request_id in _results:
            result, succeeded = _results[request_id]
            _publish(result, request_id, succeeded)
            return False
        _seen.append(request_id)
        for expired in _seen[:-128]:
            _results.pop(expired, None)
        del _seen[:-128]
        result = _execute(session, operation, argument)
        _results[request_id] = (result, True)
        _publish(result, request_id, True)
        return True
    except Exception as error:
        message = _t('shared_2055ebe2839c').format(error)
        if session_id == _token and request_id in _seen:
            _results[request_id] = (message, False)
        try: _publish(message, request_id, False)
        except Exception: pass
        sims4.commands.CheatOutput(_connection)('U21: {}'.format(error))
        return False

@sims4.commands.Command('fgeh.unified.packet', command_type=sims4.commands.CommandType.Live)
def packet(wire: str, _connection=None):
    global _wire_debug
    try:
        if len(wire) > 2048:
            raise ValueError(_t('shared_4d7c1baae697'))
        parts = unquote(str(wire), encoding='utf-8', errors='strict').split('|')
        if len(parts) != 4:
            raise ValueError(_t('shared_d9f40e14c848'))
        token, request, operation, argument = [_wire_text(s) for s in parts]
        _wire_debug = 'token_len={} expected_len={} equal={} chars={}'.format(len(token), len(_token), token == _token,
            ','.join('{:04x}'.format(ord(c)) for c in token[:6]))
        if re.fullmatch(r'p2_[0-9a-f]{32}', token) is None:
            raise ValueError(_t('shared_0ea198b6d124'))
        if re.fullmatch(r'q[0-9]+_[0-9]+', request) is None:
            raise ValueError(_t('shared_6e7a4c723c86'))
        return action(token, request, operation, argument, _connection=_connection)
    except Exception as error:
        try: _publish(_t('shared_2055ebe2839c').format(error), '', False)
        except Exception: pass
        sims4.commands.CheatOutput(_connection)('U21: {}'.format(error))
        return False

@sims4.commands.Command('fgeh.unified.debug', command_type=sims4.commands.CommandType.Live)
def debug(_connection=None):
    for record in _shortcut_events[-12:]:
        sims4.commands.CheatOutput(_connection)('F7 {} {}'.format(record['phase'],record['detail']))
    sims4.commands.CheatOutput(_connection)('U21 {}'.format(_wire_debug))
    return True

@sims4.commands.Command('fgeh.unified.close', command_type=sims4.commands.CommandType.Live)
def close_panel(_connection=None):
    _disarm_direct()
    global _ui, _hold, _entry_generation
    _entry_generation+=1
    _ui = False
    _hold = None
    fgeh_unified_camera.stop()
    Distributor.instance().add_op_with_no_owner(SendUIMessage('FgEHUnifiedConceal'))
    return True

@sims4.commands.Command('fgeh.unified.legacy', command_type=sims4.commands.CommandType.Live)
def legacy(_connection=None):
    global _ui
    try:
        from andrew_positioning_arrows import spawn_arrow_layout
        session = _session()
        spawn_arrow_layout(session)
        _ui = False
        fgeh_unified_camera.stop()
        Distributor.instance().add_op_with_no_owner(SendUIMessage('FgEHUnifiedConceal'))
        return True
    except Exception as error:
        sims4.commands.CheatOutput(_connection)('U21 3D: {}'.format(error))
        return False

@sims4.commands.Command('fgeh.unified.status', command_type=sims4.commands.CommandType.Live)
def status(_connection=None):
    sims4.commands.CheatOutput(_connection)('U21 session={} pool={} candidates={} helper={} | {}'.format(_bound,len(_pool),len(_box_candidates),eligible.__module__,_last+' | hotkey_hook='+(_shortcut_hook_error or 'installed')))
    return True

@sims4.commands.Command('fgeh.unified.event', command_type=sims4.commands.CommandType.Live)
def lifecycle(phase: str, detail: str = '', _connection=None):
    global _ui, _shortcut_loaded, _ui_state_received, _entry_retries
    _trace(phase,detail)
    # Successful user input/state acknowledgement begins a fresh recovery cycle;
    # mere construction/registration must not reset the failure budget.
    if phase in ('key-native-F7', 'key-stage-F7', 'state-applied'):
        _entry_retries = 0
    if phase=='show':_ui_state_received=False
    if phase=='state-applied':_ui_state_received=True
    if phase in ('init', 'native-registered', 'stage-attached'):
        _shortcut_loaded = True
    if phase in ('hide', 'unload'):
        _disarm_direct()
        _shortcut_loaded = False
        _ensure_watch()
        _recover_entry()
    if phase in ('hide', 'unload'):
        _ui = False
        fgeh_unified_camera.stop()
    return True


_shortcut_hook_error=''
_shortcut_events=[]


def _trace(phase,detail=''):
    # Release: memory only; never create diagnostic files.
    import time
    record={'time':time.time(),'phase':str(phase),'detail':str(detail)[:12000]}
    _shortcut_events.append(record)
    del _shortcut_events[:-128]








@sims4.commands.Command('fgeh.unified.toggle', command_type=sims4.commands.CommandType.Live)
def toggle_panel(_connection=None):
    _trace('toggle','close' if _ui else 'open')
    if _ui:
        return close_panel(_connection=_connection)
    return open_panel(_connection=_connection)


def _prime_shortcut():
    # Instantiate only our transparent PLAY widget. Never bind a session or alter poses here.
    if not _ui:
        _trace('prime-request')
        Distributor.instance().add_op_with_no_owner(SendUIMessage('ShowFgEHUiLabR01'))


def install_hotkeys():
    global _shortcut_hook_error
    try:
        import functools
        import andrew_positioning_session as sessions
        register=sessions.register_andrew_positioning_session
        cancel=sessions.AndrewPositioningSession.cancel
        if getattr(register,'_fgeh_unified_u21',False):
            return True
        @functools.wraps(register)
        def on_register(*args,**kwargs):
            result=register(*args,**kwargs)
            try:
                _trace('session-register','id={} target={} source={}'.format(result.get_identifier(),getattr(result.get_target_sim(),'id',None),getattr(result.get_source_sim(),'id',None)))
                _prime_shortcut()
                _ensure_watch()
                _repair_needs()
            except Exception as error:_trace('hook-error',str(error))
            return result
        @functools.wraps(cancel)
        def on_cancel(self,*args,**kwargs):
            _trace('session-cancel','id={} target={} source={}'.format(self.get_identifier(),getattr(self.get_target_sim(),'id',None),getattr(self.get_source_sim(),'id',None)))
            result=cancel(self,*args,**kwargs)
            try:
                if self.get_identifier()==_bound:
                    close_panel()
                if not any(not s.is_canceled for s in sessions.get_all_andrew_positioning_sessions()):
                    _stop_watch()
                    if _bound_instance is not _free_session:
                        close_panel()
                        Distributor.instance().add_op_with_no_owner(SendUIMessage('FgEHUnifiedConceal'))
                    _ensure_watch()
            except Exception as error:_trace('hook-error',str(error))
            return result
        on_register._fgeh_unified_u21=True
        sessions.register_andrew_positioning_session=on_register
        sessions.AndrewPositioningSession.cancel=on_cancel
        _shortcut_hook_error=''
        _trace('hook-installed')
        if any(not s.is_canceled for s in sessions.get_all_andrew_positioning_sessions()):
            _prime_shortcut()
            _ensure_watch()
            _repair_needs()
        return True
    except Exception as error:
        _shortcut_hook_error=str(error)
        _trace('hook-install-error',str(error))
        return False


# Real-time watchdog belongs to the current zone and exists only during posing.
_shortcut_loaded = False
_watch_alarm = None
_watch_zone = None

def _repair_needs():
    try:
        import fgeh_unified_needs
        fgeh_unified_needs.install(_trace)
    except Exception as error:
        _trace('needs-hook-error', str(error))

def _stop_watch():
    global _watch_alarm, _watch_zone, _shortcut_loaded
    if _watch_alarm is not None:
        import alarms
        alarms.cancel_alarm(_watch_alarm)
    _watch_alarm = None
    _watch_zone = None
    _shortcut_loaded = False

def _ensure_watch():
    global _watch_alarm, _watch_zone
    try:
        import alarms, clock, services
        import andrew_positioning_session as sessions
        if _watch_alarm is not None and services.current_zone() is not _watch_zone:
            _stop_watch()
        if _watch_alarm is not None:
            return
        active = [s for s in sessions.get_all_andrew_positioning_sessions() if not s.is_canceled]
        if not active:
            return
        owner = services.current_zone()
        if owner is None:
            return
        _watch_zone = owner
        def check(handle):
            global _watch_alarm, _watch_zone
            if handle is not _watch_alarm:
                return
            _watch_alarm = None
            if services.current_zone() is not owner:
                _watch_zone = None
                return
            live = [s for s in sessions.get_all_andrew_positioning_sessions() if not s.is_canceled]
            if not live:
                _stop_watch()
                return
            try:
                if live and not _shortcut_loaded:
                    _trace('recover-shortcut')
                    _prime_shortcut()
                _repair_needs()
            except Exception as error:
                _trace('watch-error', str(error))
            finally:
                _ensure_watch()
        _watch_alarm = alarms.add_alarm_real_time(owner, clock.interval_in_real_seconds(2), check, use_sleep_time=False)
    except Exception as error:
        _trace('watch-start-error', str(error))

_repair_needs()
install_hotkeys()


def _window_preferences():
    try:
        import couplepose1 as manager
        values=json.loads(manager.state.custom_names.get('__fgeh_move_window__','[1,null,null]'))
        if len(values)!=3 or not 0.6<=float(values[0])<=1.4:
            raise ValueError('scale')
        if any(v is not None and (not math.isfinite(float(v)) or abs(float(v))>100000) for v in values):
            raise ValueError('position')
        return values
    except Exception:
        return [1,None,None]

@sims4.commands.Command('fgeh.unified.window', command_type=sims4.commands.CommandType.Live)
def save_window(wire:str, _connection=None):
    try:
        values=[float(v) for v in wire.split(',')]
        if len(values)!=3 or not all(math.isfinite(v) and abs(v)<=100000 for v in values) or not 0.6<=values[0]<=1.4:
            raise ValueError('window bounds')
        import couplepose1 as manager
        previous=manager.state.custom_names
        names=dict(previous or {})
        names['__fgeh_move_window__']=json.dumps(values)
        manager.state.custom_names=names
        try:
            manager.save_favorites()
        except Exception:
            manager.state.custom_names=previous
            raise
        return True
    except Exception as error:
        _trace('window-save-error',str(error))
        return False


def _yaw(owner):
    x,y,z,w=_pose(owner)[3:]
    length=math.sqrt(x*x+y*y+z*z+w*w)
    if length<1e-8:
        raise ValueError(_t('shared_864edc6c98a2'))
    x,y,z,w=(v/length for v in (x,y,z,w))
    # Heading of local forward on the world X/Z plane; preserve pitch/roll.
    fx,fz=2*(x*z+w*y),1-2*(x*x+y*y)
    if math.hypot(fx,fz)<1e-5:
        raise ValueError(_t('shared_93e3dabc5c15'))
    return math.degrees(math.atan2(fx,fz))

def _align_selected(session,argument):
    global _hold,_edit_revision
    from fgeh_unified_history import capture
    parts=argument.split(',')
    if len(parts)!=2 or re.fullmatch(r'[1-9][0-9]*',parts[0]) is None or parts[1] not in ('0','1'):
        raise ValueError(_t('shared_454ea453693e'))
    target=_pool.get(parts[0])
    if target is None or services.object_manager().get(target.id) is not target:
        raise ValueError(_t('shared_427bec585f49'))
    _candidate_session(target,session)
    pairs=_pairs(session)
    if any(node.owner is target for other,node in pairs):
        raise ValueError(_t('shared_8ba46c3c46ad'))
    anchor=position(pairs[0][1].owner) if len(pairs)==1 or _align_mode=='individual' else _pivot(session)
    target_position=position(target)
    delta=tuple(target_position[i]-anchor[i] for i in range(3))
    if not all(math.isfinite(v) and abs(v)<100000 for v in delta):
        raise ValueError(_t('shared_73a720928353'))
    leader=next((n.owner for other,n in pairs if n.owner is session.get_target_sim()),min((n.owner for other,n in pairs),key=lambda o:o.id))
    degrees=((_yaw(target)-_yaw(leader)+180)%360-180) if parts[1]=='1' else 0.0
    records={node.owner.id:capture(other,node) for other,node in pairs}
    old_initial=dict(_history.initial);old_steps=list(_history.steps)
    _history.begin((uuid.uuid4().hex,'align',_context(session)),pairs)
    try:
        if _align_mode=='individual':
            _align_individual(pairs,target,parts[1]=='1')
            _edit_revision+=1;_hold=None
            return _t('shared_43cabf04f6ff').format(len(pairs),_t('shared_4f73f21089e8') if parts[1]=='1' else '')
        if abs(degrees)>1e-8:
            _rotate_group(session,'ry+','',degrees_override=degrees,pivot_override=anchor)
        groups={}
        for other,node in pairs:groups.setdefault(other,[]).append(node.key)
        for other,keys in groups.items():
            previous=[n.key for n in other.get_positioning_selected_nodes()]
            try:
                other.select_node_keys(keys)
                other.apply_delta_to_selected_nodes(delta_position=delta)
            finally:
                other.select_node_keys(previous)
        for other,node in pairs:
            _pose(node.owner)
    except Exception:
        _history.restore(records,services.object_manager().get,_history_controller)
        _history.initial=old_initial;_history.steps=old_steps
        raise
    _edit_revision+=1;_hold=None
    return _t('shared_52d699598e1f').format(len(pairs),_t('shared_4f73f21089e8') if parts[1]=='1' else '')


_direct_state=None
_direct_hook=None

def _direct_trampoline(*args,**kwargs):
    return _fgeh_move_direct_click_u21(*args,**kwargs)

def _disarm_direct():
    global _direct_state,_direct_hook
    _direct_state=None
    hook=_direct_hook;_direct_hook=None
    if hook is not None:
        function,original,bridge=hook
        if function.__code__ is _direct_trampoline.__code__:
            function.__code__=original.__code__
            if function.__globals__.get('_fgeh_move_direct_click_u21') is bridge:
                del function.__globals__['_fgeh_move_direct_click_u21']

def _arm_direct(session,facing):
    global _direct_state,_direct_hook
    _disarm_direct()
    from server_commands import interaction_commands
    function=interaction_commands.generate_choices
    if not isinstance(function,types.FunctionType) or function.__code__.co_freevars or '_fgeh_move_direct_click_u21' in function.__globals__:
        raise ValueError(_t('shared_2de880991f80'))
    original=types.FunctionType(function.__code__,function.__globals__,function.__name__,function.__defaults__)
    original.__kwdefaults__=function.__kwdefaults__
    def bridge(*args,**kwargs):
        state=_direct_state
        if state is None:
            return original(*args,**kwargs)
        if time.monotonic()>state['until']:
            _disarm_direct()
            return original(*args,**kwargs)
        try:
            current=_session()
            if not _ui or state['token']!=_token or state['context']!=_context(current):
                _disarm_direct()
                return original(*args,**kwargs)
            connection=kwargs.get('_connection',args[14] if len(args)>14 else None)
            if connection is not None:
                client=services.client_manager().get(connection)
                if client is None or client.active_sim is not _active():
                    return original(*args,**kwargs)
            def picked(name,index,default):return kwargs.get(name,args[index] if len(args)>index else default)
            ident=picked('target_id',0,0)
            kind=int(picked('pick_type',1,0))
            x,y,z=(float(picked('x',2,float('nan'))),float(picked('y',3,float('nan'))),float(picked('z',4,float('nan'))))
            level=int(picked('level',6,0))
            _trace('align-pick','type={} id={} xyz={},{},{} level={}'.format(kind,ident,x,y,z,level))
            # Ground picks can refer to a terrain proxy object: classify type first.
            if kind in (5,6,7,12,13,14,15,16,17):
                if not all(math.isfinite(v) and abs(v)<100000 for v in (x,y,z)):
                    raise ValueError(_t('shared_fb23e4ac5228'))
                if any(n.owner.routing_surface.secondary_id!=level for other,n in _pairs(current)):
                    raise ValueError(_t('shared_251b374c8668'))
                token=state['token'];_disarm_direct()
                action(token,'direct_'+uuid.uuid4().hex,'alignpoint','{},{},{},{}'.format(x,y,z,level))
                return True
            if kind not in (1,2,3):raise ValueError(_t('shared_bef752df60e4'))
            target=services.object_manager().get(int(ident or 0))
            if target is None:
                _publish(_t('shared_be96dca64647'))
                return True
            _candidate_session(target,current)
            if any(n.owner is target for other,n in _pairs(current)):
                _publish(_t('shared_202673013cc5'))
                return True
            # Use the actual EA pick ID even when dot filters/radius exclude the target.
            _pool[str(target.id)]=target
            facing=state['facing'];token=state['token']
            _disarm_direct()
            action(token,'direct_'+uuid.uuid4().hex,'align',str(target.id)+','+facing)
            return True
        except Exception as error:
            _publish(_t('shared_6c361bbb4200').format(error))
            return True
    _direct_state={'token':_token,'context':_context(session),'facing':facing,'until':time.monotonic()+30}
    _direct_hook=(function,original,bridge)
    function.__globals__['_fgeh_move_direct_click_u21']=bridge
    # EA command decorator keeps this function in its registered callback closure.
    # Preserve that identity; only change its code while explicit pick mode is armed.
    function.__code__=_direct_trampoline.__code__

@sims4.commands.Command('fgeh.unified.aligncancel',command_type=sims4.commands.CommandType.Live)
def cancel_direct(_connection=None):
    _disarm_direct()
    return True


def _nearby_radius():
    try:
        import couplepose1 as manager
        value=float((manager.state.custom_names or {}).get('__fgeh_move_radius__',12))
        if not math.isfinite(value) or not 1<=value<=256:raise ValueError('radius')
        return value
    except Exception:
        return 12.0


def _align_individual(pairs,target,facing):
    from types import SimpleNamespace
    from sims4.math import Vector3,Transform,Location,Quaternion
    from andrew_positioning_session import RotationAxisType as A
    destination=position(target)
    target_yaw=_yaw(target) if facing else None
    plans=[]
    for other,node in pairs:
        origin=position(node.owner)
        delta=tuple(destination[i]-origin[i] for i in range(3))
        if not all(math.isfinite(v) and abs(v)<100000 for v in delta):raise ValueError(_t('shared_89634e311410'))
        degrees=((target_yaw-_yaw(node.owner)+180)%360-180) if facing else 0.0
        plans.append((other,node,origin,delta,degrees))
    for other,node,origin,delta,degrees in plans:
        previous=[n.key for n in other.get_positioning_selected_nodes()]
        reference=other.get_reference_center();axis=other.get_positioning_rotation_axis_type()
        try:
            other.select_node_keys([node.key])
            other.set_positioning_rotation_axis_type(A.YAW)
            anchor=SimpleNamespace(location=Location(Transform(Vector3(*origin),Quaternion.IDENTITY()),node.owner.routing_surface))
            if not other.set_reference_center(anchor):raise ValueError(_t('shared_567ee5d29004'))
            other.apply_delta_to_selected_nodes(delta_position=delta,delta_rotation=degrees)
            if any(abs(a-b)>0.001 for a,b in zip(position(node.owner),destination)):raise ValueError(_t('shared_1103dffa63a1'))
        finally:
            other.clear_reference_center()
            if reference is not None:other.set_reference_center(reference)
            other.set_positioning_rotation_axis_type(axis)
            other.select_node_keys(previous)

def _rotate_each(session,operation,argument,degrees_override=None):
    from types import SimpleNamespace
    from sims4.math import Vector3,Transform,Location,Quaternion
    from andrew_positioning_session import RotationAxisType as A
    degrees=degrees_override if degrees_override is not None else session.get_positioning_rotation_increment_value()*(1 if operation[2]=='+' else -1)
    for other,node in _pairs(session):
        previous=[n.key for n in other.get_positioning_selected_nodes()]
        reference=other.get_reference_center();axis=other.get_positioning_rotation_axis_type()
        origin=position(node.owner)
        anchor=SimpleNamespace(location=Location(Transform(Vector3(*origin),Quaternion.IDENTITY()),node.owner.routing_surface))
        try:
            other.select_node_keys([node.key]);other.set_positioning_rotation_axis_type({'x':A.PITCH,'y':A.YAW,'z':A.ROLL}[operation[1]])
            if not other.set_reference_center(anchor):raise ValueError(_t('shared_e792c67a4015'))
            other.apply_delta_to_selected_nodes(delta_rotation=degrees)
        finally:
            other.clear_reference_center()
            if reference is not None:other.set_reference_center(reference)
            other.set_positioning_rotation_axis_type(axis);other.select_node_keys(previous)


def _ground_align(session,xyz=None):
    from fgeh_unified_history import capture
    from sims4.math import Vector3
    global _hold,_edit_revision
    pairs=_pairs(session)
    if not pairs:raise ValueError(_t('shared_61ea49f5e0b6'))
    for other,node in pairs:_candidate_session(node.owner,other)
    point=None
    if xyz is not None:
        point=tuple(float(v) for v in xyz.split(','))
        if len(point)!=3 or not all(math.isfinite(v) and abs(v)<100000 for v in point):raise ValueError(_t('shared_7ee44e750865'))
    terrain=services.terrain_service.terrain_object()
    def ground(owner,x,z):
        value=float(terrain.get_routing_surface_height_at(x,z,owner.routing_surface))
        if not math.isfinite(value):raise ValueError(_t('shared_60b7730a0bad'))
        return value
    positions={node.owner.id:position(node.owner) for other,node in pairs}
    destinations={}
    if point is not None and _align_mode=='group':
        anchor=tuple(sum(v[k] for v in positions.values())/len(positions) for k in range(3))
        delta=(point[0]-anchor[0],point[2]-anchor[2])
        for other,node in pairs:
            old=positions[node.owner.id];x=old[0]+delta[0];z=old[2]+delta[1]
            destinations[node.owner.id]=(x,ground(node.owner,x,z),z)
    else:
        for other,node in pairs:
            old=positions[node.owner.id];x=old[0] if point is None else point[0];z=old[2] if point is None else point[2]
            destinations[node.owner.id]=(x,ground(node.owner,x,z),z)
    records={node.owner.id:capture(other,node) for other,node in pairs}
    initial=dict(_history.initial);steps=list(_history.steps)
    _history.begin((uuid.uuid4().hex,'groundalign',_context(session)),pairs)
    try:
        for other,node in pairs:
            previous=[n.key for n in other.get_positioning_selected_nodes()]
            old=positions[node.owner.id];dest=destinations[node.owner.id]
            try:
                other.select_node_keys([node.key]);other.apply_delta_to_selected_nodes(delta_position=Vector3(*(dest[k]-old[k] for k in range(3))))
            finally:other.select_node_keys(previous)
    except Exception:
        _history.restore(records,services.object_manager().get,_history_controller)
        _history.initial=initial;_history.steps=steps
        raise
    _hold=None;_edit_revision+=1
    return _t('shared_188d02e0b59f').format(len(pairs),_t('shared_4ca9ce855001') if point is None else _t('shared_b9bb2c61ef0b'))

def _actor_label(sim):
    return '{} {}'.format(getattr(sim,'first_name',''),getattr(sim,'last_name','')).strip() or str(getattr(sim,'id',_t('shared_d9c32a4c3dda')))


def _live_open_sessions():
    from andrew_positioning_session import get_all_andrew_positioning_sessions,get_andrew_positioning_session
    live=[];snapshot=[]
    for session in get_all_andrew_positioning_sessions():
        try:
            target=session.get_target_sim();ident=session.get_identifier()
            valid=(not session.is_canceled and get_andrew_positioning_session(ident) is session
                   and target is not None and services.object_manager().get(target.id) is target
                   and session.get_node_for_owner(target) is not None)
            snapshot.append({'session':str(ident),'target':str(getattr(target,'id',None)),
                             'source':str(getattr(session.get_source_sim(),'id',None)),
                             'canceled':bool(session.is_canceled),'valid':bool(valid)})
            if valid:live.append(session)
        except Exception as error:snapshot.append({'invalid':str(error)})
    _trace('session-snapshot',json.dumps({'active':str(getattr(_active(),'id',None)), 'sessions':snapshot},ensure_ascii=False))
    return live




@sims4.commands.Command('fgeh.unified.diagnose',command_type=sims4.commands.CommandType.Live)
def diagnose(_connection=None):
    output=sims4.commands.CheatOutput(_connection)
    try:
        live=_live_open_sessions()
        output(_t('shared_4c4684d98424').format(getattr(_active(),'id',None),len(live)))
        for session in live:output(_t('shared_8b2bce176e85').format(_actor_label(session.get_target_sim()),session.get_target_sim().id,session.get_identifier()))
        _trace('diagnose','ui_requested={} state_applied={} shortcut_loaded={} bound={}'.format(_ui,_ui_state_received,_shortcut_loaded,_bound))
        output(_t('shared_15706534bd28').format(_ui,_ui_state_received))
        return True
    except Exception as error:
        _trace('diagnose-failed',str(error));output(_t('shared_4204c5e3ff5f').format(error));return False







_entry_alarm=None
_entry_zone=None
_entry_retries=0
def _entry_loaded():
    global _entry_zone, _entry_retries, _entry_alarm
    current = services.current_zone()
    # A completed load is a new UI lifecycle even if EA reuses the zone object.
    # A prior zone's canceled alarm must not suppress recovery in this one.
    previous = _entry_alarm
    _entry_alarm = None
    if previous is not None:
        try:
            import alarms
            alarms.cancel_alarm(previous)
        except Exception as error:
            _trace('entry-alarm-cancel-error', str(error))
    _entry_zone = current
    _entry_retries = 0
    _trace('entry-prime', 'zone loaded; recovery budget reset')
    _prime_shortcut()


def _recover_entry():
    global _entry_alarm,_entry_retries
    if _entry_alarm is not None or _entry_retries>=3:return
    import alarms,clock
    owner=services.current_zone()
    if owner is None:return
    _entry_retries+=1
    def recover(handle):
        global _entry_alarm
        _entry_alarm=None
        if services.current_zone() is owner and _active() is not None:_prime_shortcut()
    _entry_alarm=alarms.add_alarm_real_time(owner,clock.interval_in_real_seconds(2),recover,use_sleep_time=False)


def _install_entry():
    try:
        import zone,functools
        original=zone.Zone.on_loading_screen_animation_finished
        if not getattr(original,'_fgeh_entry_u24',False):
            @functools.wraps(original)
            def finished(self,*args,**kwargs):
                result=original(self,*args,**kwargs)
                try:_entry_loaded()
                except Exception as error:_trace('entry-prime-error',str(error))
                return result
            finished._fgeh_entry_u24=True
            zone.Zone.on_loading_screen_animation_finished=finished
        build_original = zone.Zone.on_build_buy_exit
        if not getattr(build_original, '_fgeh_play_reentry_r03', False):
            @functools.wraps(build_original)
            def build_finished(self, *args, **kwargs):
                result = build_original(self, *args, **kwargs)
                try:
                    _entry_loaded()
                    # The frontend may finish switching BUILD -> PLAY after this
                    # server callback returns; retain one delayed retry.
                    _recover_entry()
                except Exception as error:
                    _trace('build-exit-prime-error', str(error))
                return result
            build_finished._fgeh_play_reentry_r03 = True
            zone.Zone.on_build_buy_exit = build_finished
        if services.current_zone() is not None and _active() is not None:_entry_loaded()
    except Exception as error:_trace('entry-install-error',str(error))

_install_entry()

_free_session=None


def _free_apply(session,node):
    from andrew_positioning_runtime import apply_session_location
    if not apply_session_location(session,node):raise ValueError(_t('shared_e881fce68505'))
    node._fgeh_last_adjusted_pose=_pose(node.owner)


def _new_free_session(anchor):
    from andrew_positioning_session import AndrewPositioningSession
    # Unregistered: never participates in pose cleanup, needs freeze or pose replay.
    result=AndrewPositioningSession(source_sim=None,target_sim=None,actors=None,
        interaction_instance=None,live_transform_callback=_free_apply)
    result.set_target_sim(anchor)
    result.select_node_keys([])
    result._fgeh_free_adjustment=True
    return result


def _sync_free_nodes(session):
    selected=[n.key for n in session.get_positioning_selected_nodes()]
    from andrew_positioning_session import get_target_sessions_for_sim
    for ident,owner in _pool.items():
        posing=[s for s in get_target_sessions_for_sim(owner) if not s.is_canceled] if owner.is_sim else []
        if posing:continue
        if session.get_node_for_owner(owner) is None:
            if owner.is_sim:session.add_actor(owner)
            else:session.add_prop(owner,label=_t('shared_11faaa6381e8').format(owner.id))
    # Refresh can enroll objects but never selects or moves them.
    valid=[n.key for n in session.get_all_nodes() if n.key in selected
           and str(n.owner.id) in _box_candidates and _candidate_session(n.owner,session) is session]
    session.select_node_keys(valid)
    for ident,(other,node) in list(_external_selected.items()):
        try:
            if other.is_canceled or services.object_manager().get(ident) is not node.owner or other.get_node_for_owner(node.owner) is not node or _candidate_session(node.owner,session) is not other:
                del _external_selected[ident]
        except Exception:del _external_selected[ident]


@sims4.commands.Command('fgeh.unified.open',command_type=sims4.commands.CommandType.Live)
def open_panel(_connection=None):
    global _free_session,_bound_instance,_bound,_bound_zone,_ui,_token,_hold,_last,_entry_generation,_floor
    active=_active()
    if active is None:return False
    _entry_generation+=1
    zone_id=services.current_zone_id()
    if _free_session is not None and _bound_zone==zone_id:
        # Refresh pruning uses controller identity; no pose/session mutation.
        _rebuild_candidates(_free_session);_sync_free_nodes(_free_session)
        _ui=True;_hold=None;_token='p2_'+uuid.uuid4().hex
        _seen.clear();_results.clear();fgeh_unified_camera.start()
        _last=_t('shared_2378c4328604')
    else:
        _free_session=_new_free_session(active)
        _bound_instance=_free_session;_bound=_free_session.get_identifier();_bound_zone=zone_id
        _floor=active.routing_surface.secondary_id
        _external_selected.clear();_history.initial.clear();_history.steps=[];_enrolled.clear()
        _load_numeric_preferences(_free_session)
        _rebuild_candidates(_free_session);_sync_free_nodes(_free_session)
        _free_session.select_node_keys([])
        _ui=True;_hold=None;_token='p2_'+uuid.uuid4().hex
        _seen.clear();_results.clear();fgeh_unified_camera.start()
        _last=_t('shared_5c32ff5af660')
    _trace('free-open','selected={} private_unregistered=true'.format(len(_pairs(_free_session))))
    Distributor.instance().add_op_with_no_owner(SendUIMessage('ShowFgEHUiLabR01'))
    return True


def _execute(session,operation,argument):
    # A free actor may have walked since the last adjustment: start from its
    # actual current transform without resuming animation or restoring old offsets.
    if operation in ('forward','back','left','right','up','down','rx+','rx-','ry+','ry-','rz+','rz-','land','groundalign','align','alignpoint'):
        for other,node in _pairs(session):
            if other is _free_session:
                last=getattr(node,'_fgeh_last_adjusted_pose',None)
                actual=_pose(node.owner)
                if last is not None and any(abs(a-b)>0.0001 for a,b in zip(last,actual)):
                    node.reset();node._fgeh_base_location=node.owner.location
                    node._fgeh_last_adjusted_pose=actual
    return _execute_impl(session,operation,argument)

def _align_native_point(session,argument):
    from fgeh_unified_history import capture
    from sims4.math import Vector3
    global _hold,_edit_revision
    values=argument.split(',')
    if len(values)!=4:raise ValueError(_t('shared_91b7af7c391f'))
    point=tuple(float(v) for v in values[:3]);level=int(values[3])
    if not all(math.isfinite(v) and abs(v)<100000 for v in point):raise ValueError(_t('shared_f56c659deba5'))
    pairs=_pairs(session)
    if not pairs:raise ValueError(_t('shared_46be107ce9b6'))
    for other,node in pairs:
        _candidate_session(node.owner,other)
        if node.owner.routing_surface.secondary_id!=level:raise ValueError(_t('shared_c5d2144dfe1e'))
    originals={node.owner.id:position(node.owner) for other,node in pairs}
    anchor=tuple(sum(v[k] for v in originals.values())/len(originals) for k in range(3))
    destinations={ident:point if _align_mode=='individual' else tuple(v[k]+point[k]-anchor[k] for k in range(3)) for ident,v in originals.items()}
    records={node.owner.id:capture(other,node) for other,node in pairs}
    initial=dict(_history.initial);steps=list(_history.steps)
    _history.begin((uuid.uuid4().hex,'nativepoint',_context(session)),pairs)
    try:
        for other,node in pairs:
            previous=[n.key for n in other.get_positioning_selected_nodes()]
            try:
                other.select_node_keys([node.key]);dest=destinations[node.owner.id];old=originals[node.owner.id]
                other.apply_delta_to_selected_nodes(delta_position=Vector3(*(dest[k]-old[k] for k in range(3))))
            finally:other.select_node_keys(previous)
    except Exception:
        _history.restore(records,services.object_manager().get,_history_controller)
        _history.initial=initial;_history.steps=steps
        raise
    _hold=None;_edit_revision+=1
    return _t('shared_78fda6de31d0').format(len(pairs))


def _history_controller(owner,previous):
    current=_candidate_session(owner,_free_session or previous)
    if current.get_node_for_owner(owner) is None:
        selected=[n.key for n in current.get_positioning_selected_nodes()]
        try:
            if owner.is_sim:current.add_actor(owner)
            else:current.add_prop(owner,label=_t('shared_11faaa6381e8').format(owner.id));_enrolled.add(owner.id)
        finally:current.select_node_keys(selected)
    if current is not previous:_trace('history-controller-changed','actor={} old={} current={}'.format(owner.id,previous.get_identifier(),current.get_identifier()))
    return current
