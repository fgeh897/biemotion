import os
import time
import traceback

try:
    import fgeh_cas_accessory_settings as settings
except Exception:
    settings = None

try:
    from fgeh_linked_object_bindings import get_mod_directory
except Exception:
    get_mod_directory = None


def _loader_log(message):
    return  # R26: release diagnostic/file output disabled.


_loader_log("accessory loader import start")
try:
    if not bool(getattr(settings, "ENABLE_LINKED_ACTIONS_MENU", False)):
        raise ImportError("linked actions disabled for this release profile")
    import fgeh_cas_accessory_injector
    _loader_log("accessory injector imported")
except Exception:
    _loader_log("accessory injector import failed\n{}".format(traceback.format_exc()))
