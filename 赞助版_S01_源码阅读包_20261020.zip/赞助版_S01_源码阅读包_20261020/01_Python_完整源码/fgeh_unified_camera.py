from fgeh_shared_ui_localization import text as _t
"""Observe only after explicit panel open; no files, timers or startup hooks."""
import math
import time
import camera
import services

_original = None
_wrapper = None
_enabled = False
_observed_zone = None
_basis = None
_last_capture=0.0
_updates=0
_last_native_update=0.0
_native_updates=0


def ground_basis(position, target):
    values = [float(getattr(v, axis)) for v in (position, target) for axis in ('x','y','z')]
    if not all(math.isfinite(v) for v in values):
        raise ValueError(_t('shared_f7698cd4b64a'))
    dx, dy, dz = values[3]-values[0], values[4]-values[1], values[5]-values[2]
    horizontal = math.hypot(dx, dz)
    length = math.sqrt(dx*dx+dy*dy+dz*dz)
    if horizontal < 1e-5 or length < 1e-5 or horizontal/length < 0.01:
        raise ValueError(_t('shared_5dcdafa3afba'))
    return (dx/horizontal, dz/horizontal)


def _capture():
    global _basis, _observed_zone, _last_capture, _updates
    _basis = None
    _observed_zone = None
    zone = services.current_zone_id()
    if camera._zone_id != zone:
        return
    _basis = ground_basis(camera._camera_position, camera._target_position)
    _observed_zone = zone
    _last_capture=time.monotonic();_updates+=1


def start():
    global _enabled, _original, _wrapper, _basis, _observed_zone
    _basis = None
    _observed_zone = None
    if _wrapper is not None:
        if camera.update is not _wrapper:
            raise ValueError(_t('shared_cfda3f72bf32'))
        _enabled = True
        try: _capture()
        except Exception: pass
        return
    original = camera.update
    _original = original

    def observe(*args, **kwargs):
        global _last_native_update,_native_updates
        result = original(*args, **kwargs)
        _last_native_update=time.monotonic();_native_updates+=1
        if _enabled:
            try:
                _capture()
            except Exception:
                # Invalid camera data clears readiness, without changing EA behavior.
                pass
        return result

    _wrapper = observe
    _enabled = True
    camera.update = observe
    try: _capture()
    except Exception: pass


def stop():
    global _enabled, _original, _wrapper, _basis, _observed_zone
    _enabled = False
    _basis = None
    _observed_zone = None
    if _wrapper is not None and camera.update is _wrapper:
        camera.update = _original
        _original = None
        _wrapper = None


def delta(operation, step):
    if _enabled:
        try: _capture()
        except Exception: pass
    if not _enabled or _basis is None or _observed_zone != services.current_zone_id():
        raise ValueError(_t('shared_25942a72ab11'))
    if camera.update is not _wrapper or camera._zone_id != _observed_zone:
        raise ValueError(_t('shared_dc46aa380089'))
    # Read current cache at the click as well; prior update proves this open/zone saw live data.
    fx, fz = ground_basis(camera._camera_position, camera._target_position)
    if not math.isfinite(step) or not 0 < step <= 10.0:
        raise ValueError(_t('shared_bbb5c9105dc0'))
    directions = {'forward': (fx,fz), 'back': (-fx,-fz), 'right': (-fz,fx), 'left': (fz,-fx)}
    if operation not in directions:
        raise ValueError(_t('shared_449fbc3297ac'))
    dx, dz = directions[operation]
    return (dx*step, 0.0, dz*step)


def describe():
    return 'zone={} basis={} captures={} native_updates={} native_age_ms={}'.format(_observed_zone,_basis,_updates,_native_updates,int((time.monotonic()-_last_native_update)*1000) if _last_native_update else 'none')
