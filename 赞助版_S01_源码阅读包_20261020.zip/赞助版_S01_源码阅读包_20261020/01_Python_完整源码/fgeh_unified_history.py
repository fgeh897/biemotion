from fgeh_shared_ui_localization import text as _t
# -*- coding: utf-8 -*-
"""In-memory node/location snapshots. A press is one history record."""
import copy
import math
import services

FIELDS=('position_offset','pitch_rotation_offset','rotation_offset','roll_rotation_offset','rotation_steps','_fgeh_base_location','_fgeh_last_adjusted_pose')


def pose(location):
    transform=getattr(location,'world_transform',None) or getattr(location,'transform',None)
    if transform is None:raise ValueError(_t('shared_93a3ba60a346'))
    values=tuple(float(getattr(transform.translation,k)) for k in ('x','y','z'))+tuple(float(getattr(transform.orientation,k)) for k in ('x','y','z','w'))
    if not all(math.isfinite(v) for v in values):raise ValueError(_t('shared_8cca1e2fb733'))
    return values


def capture(session,node):
    fields={name:(getattr(node,name,None) if name=='_fgeh_base_location' else copy.deepcopy(getattr(node,name,None))) for name in FIELDS}
    return {'session':session,'node':node,'owner':node.owner,'location':node.owner.location,'pose':pose(node.owner.location),'fields':fields,'present':set(name for name in FIELDS if hasattr(node,name)),'zone':services.current_zone_id(),'label':str(getattr(node,'label',None) or node.owner.id)}


class History:
    def __init__(self):
        self.initial={}
        self.steps=[]

    def begin(self,key,pairs):
        records={node.owner.id:capture(session,node) for session,node in pairs}
        if len(set(self.initial)|set(records))>256:
            raise ValueError(_t('shared_4357109b04c1'))
        for ident,record in records.items():
            self.initial.setdefault(ident,record)
        if self.steps and self.steps[-1][0]==key:
            for ident,record in records.items():
                self.steps[-1][1].setdefault(ident,record)
        else:
            self.steps.append((key,records))
            del self.steps[:-64]

    def restore(self,records,resolve,validate):
        prepared=[]
        for record in records.values():
            session,node,owner=record['session'],record['node'],record['owner']
            label='{}（{}）'.format(record.get('label',_t('shared_539cb3b0a662')),owner.id)
            if record.get('zone')!=services.current_zone_id():raise ValueError(_t('shared_dbef5962d6ec').format(label))
            if resolve(owner.id) is not owner:raise ValueError(_t('shared_2b503d12f4f6').format(label))
            try:
                current=validate(owner,session)
                # Older validators return the owner. Preserve strict compatibility
                # only when the original controller/node is still usable.
                if not hasattr(current,'get_node_for_owner'):current=session
                current_node=current.get_node_for_owner(owner)
                if current.is_canceled or current_node is None:raise ValueError(_t('shared_10c1c4428384'))
            except Exception as error:raise ValueError(_t('shared_18741ed57e11').format(label,error))
            prepared.append((record,current,current_node,current is session and current_node is node))
        backups=[capture(current,node) for record,current,node,same in prepared]
        try:
            for record,current,node,same in prepared:
                if same:
                    self._restore_fields(node,record)
                else:
                    # World position/orientation history follows the same live
                    # object through controller changes; never restore old poses.
                    node.reset();node._fgeh_base_location=record['location']
                record['owner'].location=record['location']
                node._fgeh_last_adjusted_pose=record['pose']
                actual=pose(record['owner'].location)
                if any(abs(a-b)>0.0001 for a,b in zip(actual,record['pose'])):raise ValueError(_t('shared_91c1684f1990'))
        except Exception:
            for backup in backups:
                self._restore_fields(backup['node'],backup);backup['owner'].location=backup['location']
            raise

    def _restore_fields(self,node,record):
        for name,value in record['fields'].items():
            if name not in record['present']:
                if hasattr(node,name):delattr(node,name)
            else:setattr(node,name,value if name=='_fgeh_base_location' else copy.deepcopy(value))

    def undo(self,resolve,validate):
        if not self.steps:
            raise ValueError(_t('shared_847b2f1676da'))
        records=self.steps[-1][1]
        self.restore(records,resolve,validate)
        self.steps.pop()
        return len(records)

    def reset(self,resolve,validate):
        if not self.initial:
            raise ValueError(_t('shared_0014bedf174f'))
        self.restore(self.initial,resolve,validate)
        self.steps=[]
        return len(self.initial)
