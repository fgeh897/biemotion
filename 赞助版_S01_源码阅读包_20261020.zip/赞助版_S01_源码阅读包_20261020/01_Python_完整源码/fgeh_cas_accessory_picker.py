from fgeh_pose_manager_localization import display_text as _fgeh_hash_ui_text
import os
import time
import traceback

import services
import sims4.localization
import sims4.resources

from interactions import ParticipantType
from interactions.base.immediate_interaction import ImmediateSuperInteraction
from interactions.base.picker_interaction import PickerSuperInteraction
from interactions.context import QueueInsertStrategy
from interactions.utils.tunable import TunableContinuation
from sims4.localization import LocalizationHelperTuning
from sims4.tuning.tunable import OptionalTunable, Tunable
from sims4.tuning.tunable_base import GroupNames
from sims4.utils import flexmethod
from ui.ui_dialog_picker import ObjectPickerRow, OutfitPickerRow, UiOutfitPicker

import fgeh_cas_accessory_settings as settings
from fgeh_config import (
    MY_CUSTOM_ICON,
    STR_LINKED_BACK,
    STR_LINKED_CAS_CATEGORY,
    STR_LINKED_CLEAR_OBJECTS,
    STR_LINKED_DEBUG_LOG,
    STR_LINKED_GROUP_CAS_DESC,
    STR_LINKED_NO_PACK_ITEMS,
    STR_LINKED_OBJECT_CATEGORY,
    STR_LINKED_OBJECT_CATEGORY_DESC,
    STR_LINKED_OBJECT_EXTERNAL,
    STR_LINKED_OBJECT_EXTERNAL_DESC,
    STR_LINKED_OBJECT_LOCAL,
    STR_LINKED_OBJECT_LOCAL_DESC,
    STR_LINKED_RESTORE_OUTFIT,
    STR_LINKED_VIEW_ALL,
)
from fgeh_state import state
from fgeh_cas_accessory_outfit_utils import (
    apply_fixed_cas_accessory_to_sim,
    apply_saved_outfit_to_sim,
    debug_log,
    dump_current_outfit_parts,
    get_body_group_for_body_type,
    get_body_group_name,
    get_sim_info_from_target,
    get_body_type_name,
    iter_all_outfit_cas_parts,
    restore_original_outfit,
)


ACCESSORY_TAG_PREFIX = "FGEH_ACC::"
VARIANT_TAG_PREFIX = "FGEH_ACC_VARIANT::"
RESTORE_TAG = "FGEH_ACC_RESTORE"
CLEAR_LINKED_OBJECTS_TAG = "FGEH_ACC_CLEAR_LINKED_OBJECTS"
LOG_TAG = "FGEH_ACC_LOG"
SHOW_LINKED_DEBUG_LOG_ROW = False
BACK_TAG = "FGEH_ACC_BACK"
PACK_UNKNOWN = "Unknown"
ALL_ACCESSORIES_TAG = "FGEH_ACC_ALL"
VIEW_ROOT = "root"
VIEW_CAS = "cas"
VIEW_CAS_LOCAL = "cas_local"
VIEW_CAS_EXTERNAL = "cas_external"
VIEW_CAS_BIND_CATEGORY = "cas_bind_category"
VIEW_CAS_BIND_OUTFIT = "cas_bind_outfit"
VIEW_CAS_BIND_PARTS = "cas_bind_parts"
VIEW_OBJECT = "object"
VIEW_OBJECT_LOCAL = "object_local"
VIEW_OBJECT_EXTERNAL = "object_external"
CATEGORY_CAS_TAG = "FGEH_ACC_CATEGORY_CAS"
CATEGORY_OBJECT_TAG = "FGEH_ACC_CATEGORY_OBJECT"
CAS_LOCAL_TAG = "FGEH_ACC_CAS_LOCAL"
CAS_EXTERNAL_TAG = "FGEH_ACC_CAS_EXTERNAL"
CAS_BIND_SCAN_TAG = "FGEH_ACC_CAS_BIND_SCAN"
CAS_BIND_SCAN_PARTS_TAG = "FGEH_ACC_CAS_BIND_SCAN_PARTS"
CAS_DELETE_OUTFIT_TAG = "FGEH_ACC_CAS_DELETE_OUTFIT"
CAS_BIND_CATEGORY_PREFIX = "FGEH_ACC_CAS_BIND_CATEGORY::"
CAS_BIND_OUTFIT_PREFIX = "FGEH_ACC_CAS_BIND_OUTFIT::"
CAS_BIND_ALL_PREFIX = "FGEH_ACC_CAS_BIND_ALL::"
CAS_BIND_BODY_PREFIX = "FGEH_ACC_CAS_BIND_BODY::"
CAS_BIND_PART_PREFIX = "FGEH_ACC_CAS_BIND_PART::"
OBJECT_LOCAL_TAG = "FGEH_ACC_OBJECT_LOCAL"
OBJECT_EXTERNAL_TAG = "FGEH_ACC_OBJECT_EXTERNAL"
VIEW_BACK_TAG = "FGEH_ACC_VIEW_BACK"

DEFAULT_CATEGORY = "uncategorized"
POSEPACK_MENU_ICON_KEY = "00B2D882:00000000:56DE2425304387B6"
POSEPACK_MENU_INTERACTION_ID = 11242396370292691703


def _posepack_menu_debug_enabled():
    try:
        return bool(getattr(settings, "ENABLE_POSEPACK_MENU_DEBUG_LOG", False))
    except Exception:
        return False


def _posepack_menu_debug_paths():
    filename = "fgeh_posepack_accessory_menu_debug.log"
    paths = []
    seen = set()

    def add_path(path):
        if not path:
            return
        try:
            normalized = os.path.normcase(os.path.abspath(path))
        except Exception:
            normalized = path
        if normalized not in seen:
            seen.add(normalized)
            paths.append(path)

    for sims_dir in (
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
    ):
        try:
            if sims_dir and os.path.isdir(sims_dir):
                add_path(os.path.join(sims_dir, filename))
        except Exception:
            pass
    try:
        add_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), filename))
    except Exception:
        pass
    return paths


def posepack_menu_debug_log(message, *args):
    return  # R26: release diagnostic/file output disabled.


posepack_menu_debug_log(
    "module loaded interaction_id={} expected_pie_menu_icon={}",
    POSEPACK_MENU_INTERACTION_ID,
    POSEPACK_MENU_ICON_KEY,
)


# Runtime-only indexes.  They are rebuilt naturally when the script reloads;
# no package or JSON data is duplicated here.
_POSE_PACK_BY_POSE_NAME = None
_ACCESSORY_SNIPPETS_BY_PACK = None
_ACCESSORY_ENTRIES_CACHE = {}
_THUMBNAIL_KEY_CACHE = {}


class _FgehLinkedRequirementView:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)


def raw_text(text):
    try:
        return _fgeh_hash_ui_text(text)
    except Exception:
        return str(text)


def stbl_text(stbl_id):
    try:
        return sims4.localization._create_localized_string(stbl_id)
    except Exception:
        return raw_text("ID:{:08X}".format(int(stbl_id)))


def _stbl_text_from_hash(value):
    try:
        text = str(value or "").strip()
        if not text.lower().startswith("hash:"):
            return None
        return stbl_text(int(text.split(":", 1)[1].strip(), 0))
    except Exception:
        return None


def picker_text(value, fallback=""):
    if value is None:
        value = fallback
    try:
        if isinstance(value, int):
            return stbl_text(value)
        if isinstance(value, str):
            return _stbl_text_from_hash(value) or raw_text(value)
        raw_value = _fgeh_hash_ui_text(value)
        if raw_value and not str(raw_value).lower().startswith("hash:"):
            return raw_value
        return _stbl_text_from_hash(raw_value) or _stbl_text_from_hash(value) or value
    except Exception:
        return raw_text(str(value or fallback or ""))


def _debug_exception(label):
    debug_log("{}\n{}", label, traceback.format_exc())


def _safe_list(value):
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        return []


def _make_row(name, icon=None, tag=None, description=None, count=0):
    kwargs = {
        "name": picker_text(name),
        "tag": tag,
    }
    if icon is not None:
        kwargs["icon"] = icon
    if description:
        kwargs["row_description"] = picker_text(description)
    if count:
        kwargs["count"] = count
    return ObjectPickerRow(**kwargs)


def _snippet_id(snippet):
    for attr_name in ("guid64", "guid", "instance_id", "tuning_id"):
        value = getattr(snippet, attr_name, None)
        if value:
            return str(value)
    return str(getattr(snippet, "__name__", snippet))


def _get_pose_pack_manager():
    try:
        return services.get_instance_manager(sims4.resources.Types.SNIPPET)
    except Exception:
        return None


def _is_pose_pack(snippet):
    try:
        return str(getattr(snippet, "s4s_mod_type", "")).upper() == "POSE_PACK"
    except Exception:
        return False


def _iter_pose_packs():
    manager = _get_pose_pack_manager()
    if manager is None:
        return
    for snippet in _safe_list(getattr(manager, "_tuned_classes", {}).values()):
        if _is_pose_pack(snippet):
            yield snippet


def _find_pose_pack_for_pose_name(pose_name):
    if not pose_name:
        return None
    pose_name = str(pose_name)

    # The main pose manager already builds this index. Reuse it instead of
    # walking every pose pack from the accessory picker.
    try:
        if not getattr(state, "cache_built", False):
            from couplepose1 import build_cache_safe
            build_cache_safe()
        pose_info = (getattr(state, "all_poses_cache", {}) or {}).get(pose_name)
        if isinstance(pose_info, dict):
            pack = pose_info.get("pack_ref")
            if pack is not None:
                return pack
    except Exception:
        pass

    global _POSE_PACK_BY_POSE_NAME
    if _POSE_PACK_BY_POSE_NAME is None:
        index = {}
        for pack in _iter_pose_packs():
            for pose_item in _safe_list(getattr(pack, "pose_list", None)):
                name = str(getattr(pose_item, "pose_name", "") or "")
                if name:
                    index[name] = pack
        _POSE_PACK_BY_POSE_NAME = index
    pack = _POSE_PACK_BY_POSE_NAME.get(pose_name)
    if pack is not None:
        return pack

    for pack in _iter_pose_packs():
        for pose_item in _safe_list(getattr(pack, "pose_list", None)):
            if str(getattr(pose_item, "pose_name", "")) == pose_name:
                return pack
    return None


def _get_pose_name_from_positioning_session(sim):
    if sim is None:
        return None

    session_getter = None
    try:
        from andrew_positioning_session import get_target_sessions_for_sim
        session_getter = get_target_sessions_for_sim
    except Exception:
        try:
            from object_positioning_session import get_target_sessions_for_sim
            session_getter = get_target_sessions_for_sim
        except Exception:
            return None

    try:
        sessions = list(session_getter(sim))
    except Exception:
        _debug_exception("Failed to read positioning sessions for active pose")
        return None

    for session in reversed(sessions):
        try:
            if getattr(session, "is_canceled", False):
                continue
            pose_name = session.get_pose_name()
            if pose_name:
                debug_log(
                    "Current pose name resolved from positioning session={} pose_name={}",
                    getattr(session, "get_identifier", lambda: None)(),
                    pose_name,
                )
                return pose_name
        except Exception:
            continue

    return None


def _iter_interactions_for_sim(sim):
    if sim is None:
        return
    try:
        for interaction in getattr(sim, "si_state", ()):
            yield interaction
    except Exception:
        pass
    for attr_name in ("queue", "si_state"):
        owner = getattr(sim, attr_name, None)
        if owner is None:
            continue
        for method_name in ("running", "queued_interactions_gen", "all_interactions_gen"):
            method = getattr(owner, method_name, None)
            if not callable(method):
                continue
            try:
                for interaction in method():
                    yield interaction
            except Exception:
                pass
    for attr_name in ("interaction_refs", "_interaction_refs"):
        for interaction in _safe_list(getattr(sim, attr_name, None)):
            yield interaction


def get_current_pose_pack_for_sim(sim):
    for interaction in _iter_interactions_for_sim(sim):
        pose_name = getattr(interaction, "pose_name", None)
        if not pose_name:
            interaction_parameters = getattr(interaction, "interaction_parameters", None)
            if isinstance(interaction_parameters, dict):
                pose_name = interaction_parameters.get("pose_name")
            else:
                pose_name = getattr(interaction_parameters, "pose_name", None)
        pack = _find_pose_pack_for_pose_name(pose_name)
        if pack is not None:
            debug_log("Current pose pack resolved from pose_name={} pack_id={}", pose_name, getattr(pack, "__name__", None))
            return pack

    pose_name = _get_pose_name_from_positioning_session(sim)
    pack = _find_pose_pack_for_pose_name(pose_name)
    if pack is not None:
        debug_log(
            "Current pose pack resolved from positioning session pose_name={} pack_id={}",
            pose_name,
            getattr(pack, "__name__", None),
        )

        return pack

    debug_log("Current pose pack not found from active pose interactions.")
    return None


def get_current_pose_name_for_sim(sim):
    for interaction in _iter_interactions_for_sim(sim):
        pose_name = getattr(interaction, "pose_name", None)
        if not pose_name:
            interaction_parameters = getattr(interaction, "interaction_parameters", None)
            if isinstance(interaction_parameters, dict):
                pose_name = interaction_parameters.get("pose_name")
            else:
                pose_name = getattr(interaction_parameters, "pose_name", None)
        if pose_name:
            return str(pose_name)
    return _get_pose_name_from_positioning_session(sim)


def _get_current_pose_key_for_sim(sim):
    pose_name = get_current_pose_name_for_sim(sim)
    active_pack = get_current_pose_pack_for_sim(sim)
    pack_id = _get_pack_key(active_pack)
    return active_pack, pack_id, pose_name


def _get_selected_manager_pose_key():
    try:
        from couplepose1 import state
    except Exception:
        return None, "", ""
    pack_id = str(getattr(state, "selected_linked_pack_id", None) or "").strip()
    pose_name = str(getattr(state, "selected_linked_style_pose_name", None) or "").strip()
    if not pack_id or not pose_name:
        return None, "", ""
    pack = None
    try:
        pack = (getattr(state, "all_packs_cache", {}) or {}).get(pack_id)
    except Exception:
        pack = None
    return pack, pack_id, pose_name


def _resolve_binding_pose_key_for_sim(sim):
    active_pack, pack_id, pose_name = _get_current_pose_key_for_sim(sim)
    if pack_id and pose_name:
        return active_pack, pack_id, pose_name
    manager_pack, manager_pack_id, manager_pose_name = _get_selected_manager_pose_key()
    if manager_pack_id and manager_pose_name:
        debug_log(
            "CAS binding using selected manager pose fallback pack_id={} pose_name={}",
            manager_pack_id,
            manager_pose_name,
        )
        return manager_pack, manager_pack_id, manager_pose_name
    return active_pack, pack_id, pose_name


def _make_local_cas_variant(binding):
    cas_part_id = 0
    body_type = 0
    try:
        cas_part_id = int(binding.get("cas_part_id") or 0)
    except Exception:
        cas_part_id = 0
    try:
        body_type = int(binding.get("body_type") or 0)
    except Exception:
        body_type = 0
    body_group = str(binding.get("body_group") or get_body_group_for_body_type(body_type) or "other")
    label = str(binding.get("display_name") or "CAS {}".format(cas_part_id))
    source_origin = str(binding.get("source_origin") or "local").strip().lower() or "local"
    return _FgehLinkedRequirementView(
        label=label,
        display_name=label,
        variant_label=label,
        description="{} | {} | CAS Part ID: {}".format(get_body_group_name(body_group), get_body_type_name(body_type), cas_part_id),
        cas_part_id=cas_part_id,
        body_type=body_type,
        body_type_name=get_body_type_name(body_type),
        body_group=body_group,
        body_group_name=get_body_group_name(body_group),
        category=binding.get("category") or "cas",
        category_id=binding.get("category") or "cas",
        resource_type="cas",
        asset_kind="cas",
        source_origin=source_origin,
        source_type=binding.get("source_type") or "unknown",
        outfit_label=binding.get("outfit_label") or "",
    )


def get_saved_cas_entries_for_pose(pack_id, pose_name):
    try:
        from fgeh_linked_cas_bindings import iter_saved_cas_bindings
    except Exception:
        return []

    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    if not pack_id or not pose_name:
        return []

    groups = {}
    matched_count = 0
    for binding in iter_saved_cas_bindings():
        if str(binding.get("pack_id") or "").strip() != pack_id:
            continue
        if str(binding.get("pose_name") or "").strip() != pose_name:
            continue
        matched_count += 1
        variant = _make_local_cas_variant(binding)
        if not _entry_cas_part_id(variant):
            continue
        body_type = getattr(variant, "body_type", 0)
        body_group = str(getattr(variant, "body_group", "") or get_body_group_for_body_type(body_type) or "other")
        source_origin = str(getattr(variant, "source_origin", "local") or "local").strip().lower() or "local"
        key = (source_origin, body_group, str(getattr(variant, "outfit_label", "") or ""))
        groups.setdefault(key, []).append(variant)

    entries = []
    for (source_origin, body_group, outfit_label), variants in sorted(groups.items(), key=lambda item: (item[0][0], item[0][1], item[0][2])):
        label = get_body_group_name(body_group)
        if outfit_label:
            label = "{} - {}".format(label, outfit_label)
        entry = _FgehLinkedRequirementView(
            label=label,
            display_name=label,
            description_text=("游戏外复用 CAS" if source_origin == "external" else "游戏内绑定 CAS"),
            category="cas",
            category_id="cas",
            resource_type="cas",
            asset_kind="cas",
            source_origin=source_origin,
            variants=variants,
        )
        entries.append({
            "snippet": None,
            "entry": entry,
            "variants": variants,
            "label": label,
            "description": ("游戏外复用 CAS" if source_origin == "external" else "游戏内绑定 CAS"),
            "category": "cas",
            "resource_type": "cas",
            "source_origin": source_origin,
            "icon": MY_CUSTOM_ICON,
        })
    debug_log(
        "Saved CAS entries lookup pack_id={} pose_name={} matched_bindings={} entry_groups={}",
        pack_id,
        pose_name,
        matched_count,
        len(entries),
    )
    return entries


def _with_source_origin(entries, origin):
    for entry_info in entries:
        try:
            entry_info.setdefault("source_origin", origin)
            setattr(entry_info.get("entry"), "source_origin", origin)
        except Exception:
            pass
        for variant in entry_info.get("variants", ()) or ():
            try:
                setattr(variant, "source_origin", origin)
            except Exception:
                pass
    return entries


def _get_outfit_scan_rows(sim_info):
    try:
        return list(iter_all_outfit_cas_parts(sim_info))
    except Exception:
        _debug_exception("Failed to scan all outfit CAS parts")
        return []


_BINDABLE_OUTFIT_CATEGORIES = frozenset((0, 1, 2, 3, 4, 5, 9, 10, 11))


def _release_feature_enabled(setting_name):
    return bool(getattr(settings, setting_name, False))


def _in_game_cas_binding_enabled():
    return _release_feature_enabled("ENABLE_IN_GAME_CAS_BINDING_WORKFLOWS")


def _external_cas_links_enabled():
    return _release_feature_enabled("ENABLE_EXTERNAL_CAS_LINKS")


def _in_game_object_binding_enabled():
    return _release_feature_enabled("ENABLE_IN_GAME_OBJECT_BINDING")


def _external_object_links_enabled():
    return _release_feature_enabled("ENABLE_EXTERNAL_OBJECT_LINKS")


def _filter_release_cas_entries(entries):
    filtered = []
    for entry_info in entries or ():
        is_local = entry_info.get("source_origin") == "local"
        if is_local and _in_game_cas_binding_enabled():
            filtered.append(entry_info)
        elif not is_local and _external_cas_links_enabled():
            filtered.append(entry_info)
    return filtered


def _is_bindable_outfit_category(category):
    try:
        return int(category) in _BINDABLE_OUTFIT_CATEGORIES
    except Exception:
        return False


def _filter_bindable_outfit_scan_rows(scan_rows):
    rows = [row for row in scan_rows or [] if _is_bindable_outfit_category(row.get("category"))]
    return rows or list(scan_rows or ())


def _get_outfit_categories(scan_rows):
    categories = []
    seen = set()
    for row in scan_rows or []:
        category = row.get("category")
        if category in seen:
            continue
        seen.add(category)
        categories.append({
            "category": category,
            "category_name": row.get("category_name") or str(category),
            "count": len([item for item in scan_rows if item.get("category") == category]),
        })
    return categories


def _get_outfit_row_by_proto_index(scan_rows, proto_index):
    try:
        proto_index = int(proto_index)
    except Exception:
        proto_index = -1
    for row in scan_rows or []:
        if int(row.get("proto_index", -1)) == proto_index:
            return row
    return None


def _get_outfit_row_by_category_index(scan_rows, category, category_index):
    try:
        category = int(category)
        category_index = int(category_index)
    except Exception:
        return None
    for row in scan_rows or []:
        try:
            if int(row.get("category")) == category and int(row.get("category_index")) == category_index:
                return row
        except Exception:
            pass
    return None


def _outfit_choice_id(category, category_index):
    try:
        return 700000 + int(category) * 100 + int(category_index)
    except Exception:
        return 0


def _get_outfit_row_by_choice_tag(scan_rows, choice_tag):
    if isinstance(choice_tag, dict):
        return _get_outfit_row_by_category_index(
            scan_rows,
            choice_tag.get("category"),
            choice_tag.get("category_index"),
        )
    if isinstance(choice_tag, (list, tuple)) and len(choice_tag) >= 2:
        return _get_outfit_row_by_category_index(scan_rows, choice_tag[0], choice_tag[1])
    try:
        choice_id = int(choice_tag)
    except Exception:
        choice_id = 0
    if choice_id:
        for row in scan_rows or []:
            if _outfit_choice_id(row.get("category"), row.get("category_index")) == choice_id:
                return row
    return None


def _parts_for_body_type(outfit_row, body_type):
    try:
        body_type = int(body_type)
    except Exception:
        body_type = 0
    return [
        part for part in (outfit_row or {}).get("parts", ()) or ()
        if int(part.get("body_type") or 0) == body_type
    ]


def _parse_suffix_int(choice_tag, prefix):
    try:
        return int(str(choice_tag)[len(prefix):])
    except Exception:
        return 0


def save_cas_parts_for_pose(pack_id, pose_name, outfit_row, parts, body_group=None):
    if not pack_id or not pose_name or outfit_row is None:
        debug_log("CAS binding skipped: pack_id={} pose_name={} outfit_row={}", pack_id, pose_name, outfit_row)
        return 0

    saved_ids = []
    try:
        from fgeh_linked_cas_bindings import get_or_create_outfit_binding, save_cas_binding
    except Exception:
        _debug_exception("CAS binding save module import failed")
        return 0

    parts = list(parts or ())
    outfit_binding_id = get_or_create_outfit_binding(
        pack_id,
        pose_name,
        outfit_label=outfit_row.get("outfit_label"),
        category=outfit_row.get("category"),
        category_index=outfit_row.get("category_index"),
        part_count=len(parts),
        body_group=body_group or "all",
    )
    debug_log(
        "CAS binding outfit record pack_id={} pose_name={} outfit_binding_id={} parts={} body_group={}",
        pack_id,
        pose_name,
        outfit_binding_id,
        len(parts),
        body_group or "all",
    )

    for part in parts:
        try:
            cas_part_id = int(part.get("cas_part_id") or 0)
        except Exception:
            cas_part_id = 0
        if not cas_part_id:
            continue
        body_type = int(part.get("body_type") or 0)
        part_group = str(body_group or part.get("body_group") or get_body_group_for_body_type(body_type) or "other")
        label = "{} | {} | CAS {}".format(get_body_group_name(part_group), get_body_type_name(body_type), cas_part_id)
        saved = save_cas_binding(
            pack_id,
            pose_name,
            cas_part_id,
            body_type=body_type,
            display_name=label,
            category="cas",
            outfit_label=outfit_row.get("outfit_label"),
            source_type="unknown",
            body_group=part_group,
            outfit_binding_id=outfit_binding_id,
        )
        debug_log(
            "CAS binding part save cas_part_id={} body_type={} body_group={} saved={}",
            cas_part_id,
            body_type,
            part_group,
            saved,
        )
        if saved:
            saved_ids.append(cas_part_id)

    if saved_ids:
        try:
            from fgeh_pose_requirement_registry import clear_requirement_cache
            clear_requirement_cache()
        except Exception:
            pass
        try:
            from couplepose1 import get_enabled_linked_cas_part_ids, set_enabled_linked_cas_part_ids
            current = get_enabled_linked_cas_part_ids(pack_id, pose_name, None)
            cleaned = []
            for value in current or []:
                try:
                    value = int(value or 0)
                except Exception:
                    value = 0
                if value and value not in cleaned:
                    cleaned.append(value)
            for cas_part_id in saved_ids:
                if cas_part_id not in cleaned:
                    cleaned.append(cas_part_id)
            set_enabled_linked_cas_part_ids(pack_id, pose_name, cleaned)
        except Exception:
            _debug_exception("CAS binding selection update failed")
        try:
            from couplepose1 import clear_linked_view_caches
            clear_linked_view_caches()
        except Exception:
            pass
        try:
            _ACCESSORY_ENTRIES_CACHE.clear()
        except Exception:
            pass

    debug_log(
        "CAS binding saved pack_id={} pose_name={} outfit={} saved_count={}",
        pack_id,
        pose_name,
        outfit_row.get("outfit_label"),
        len(saved_ids),
    )
    return len(saved_ids)


def _save_cas_parts_for_current_pose(target_sim, outfit_row, parts, body_group=None):
    active_pack, pack_id, pose_name = _resolve_binding_pose_key_for_sim(target_sim)
    return save_cas_parts_for_pose(pack_id, pose_name, outfit_row, parts, body_group=body_group)


def get_body_grouped_outfit_parts(outfit_row):
    groups = []
    by_group = {}
    for part in (outfit_row or {}).get("parts", ()) or ():
        try:
            body_type = int(part.get("body_type") or 0)
        except Exception:
            body_type = 0
        body_group = str(part.get("body_group") or get_body_group_for_body_type(body_type) or "other")
        by_group.setdefault(body_group, []).append(part)
    order = ("clothing", "hair", "makeup", "accessory", "skin_detail", "other")
    for body_group in order:
        if body_group in by_group:
            groups.append({
                "body_group": body_group,
                "label": get_body_group_name(body_group),
                "parts": by_group.get(body_group) or [],
            })
    for body_group, parts in sorted(by_group.items(), key=lambda item: item[0]):
        if body_group not in order:
            groups.append({
                "body_group": body_group,
                "label": get_body_group_name(body_group),
                "parts": parts,
            })
    return groups


def get_saved_outfit_bindings_for_pose(pack_id, pose_name):
    try:
        from fgeh_linked_cas_bindings import iter_saved_cas_bindings, iter_saved_outfit_bindings
    except Exception:
        return []

    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    if not pack_id or not pose_name:
        return []

    part_counts = {}
    for binding in iter_saved_cas_bindings():
        if str(binding.get("pack_id") or "").strip() != pack_id:
            continue
        if str(binding.get("pose_name") or "").strip() != pose_name:
            continue
        outfit_id = str(binding.get("outfit_binding_id") or "").strip()
        if not outfit_id:
            outfit_id = "legacy::{}".format(str(binding.get("outfit_label") or "CAS"))
        part_counts[outfit_id] = part_counts.get(outfit_id, 0) + 1

    rows = []
    seen = set()
    for outfit in iter_saved_outfit_bindings():
        if str(outfit.get("pack_id") or "").strip() != pack_id:
            continue
        if str(outfit.get("pose_name") or "").strip() != pose_name:
            continue
        outfit_id = str(outfit.get("outfit_binding_id") or "").strip()
        if not outfit_id or outfit_id in seen:
            continue
        seen.add(outfit_id)
        item = dict(outfit)
        item["part_count"] = part_counts.get(outfit_id, int(item.get("part_count") or 0))
        rows.append(item)

    if rows:
        return rows

    legacy = {}
    for binding in iter_saved_cas_bindings():
        if str(binding.get("pack_id") or "").strip() != pack_id:
            continue
        if str(binding.get("pose_name") or "").strip() != pose_name:
            continue
        label = str(binding.get("outfit_label") or "Saved CAS")
        item = legacy.setdefault(label, {
            "outfit_binding_id": "legacy::{}".format(label),
            "pack_id": pack_id,
            "pose_name": pose_name,
            "outfit_label": label,
            "category": 0,
            "category_index": 0,
            "body_group": binding.get("body_group") or "all",
            "part_count": 0,
            "created_at": binding.get("created_at") or "",
        })
        item["part_count"] += 1
    return list(legacy.values())


def show_saved_outfit_bindings_picker(interaction, pack_id, pose_name, target_sim=None, delete_mode=False):
    target_sim = target_sim or getattr(interaction, "target", None)
    sim_info = get_sim_info_from_target(target_sim)
    if sim_info is None:
        return False

    saved_rows = get_saved_outfit_bindings_for_pose(pack_id, pose_name)
    if not saved_rows:
        return False

    try:
        dialog = UiOutfitPicker.TunableFactory().default(
            interaction.sim,
            resolver=interaction.get_resolver(),
            title=lambda *_, **__: raw_text("删除绑定服装" if delete_mode else "已保存的绑定服装"),
        )
    except Exception:
        try:
            dialog = UiOutfitPicker.TunableFactory().default(interaction.sim, interaction.get_resolver())
        except Exception:
            _debug_exception("Create saved outfit binding picker failed")
            return False

    option_id_to_outfit_id = {}
    for index, row in enumerate(saved_rows):
        try:
            category = int(row.get("category") or 0)
            category_index = int(row.get("category_index") or 0)
        except Exception:
            category = 0
            category_index = 0
        option_id = 810000 + index
        option_id_to_outfit_id[option_id] = str(row.get("outfit_binding_id") or "").strip()
        label = row.get("outfit_label") or "Saved Outfit {}".format(index + 1)
        part_count = int(row.get("part_count") or 0)
        body_group = str(row.get("body_group") or "all")
        dialog.add_row(
            OutfitPickerRow(
                option_id=option_id,
                outfit_sim_id=getattr(sim_info, "sim_id", 0),
                outfit_category=category,
                outfit_index=category_index,
                tag=option_id,
                name=picker_text("{} | {}".format(index + 1, label)),
                row_description=picker_text("{} | {} CASP".format(get_body_group_name(body_group), part_count)),
            )
        )

    def _on_saved_outfit_selected(response_dialog):
        try:
            if delete_mode and response_dialog.accepted:
                tags = response_dialog.get_result_tags() or ()
                try:
                    selected_option_id = int(tags[0] if tags else 0)
                except Exception:
                    selected_option_id = 0
                outfit_binding_id = option_id_to_outfit_id.get(selected_option_id, "")
                if outfit_binding_id:
                    try:
                        from fgeh_linked_cas_bindings import delete_saved_outfit_binding
                        removed = delete_saved_outfit_binding(pack_id, pose_name, outfit_binding_id)
                        debug_log(
                            "Deleted saved outfit binding pack_id={} pose_name={} outfit_binding_id={} removed={}",
                            pack_id,
                            pose_name,
                            outfit_binding_id,
                            removed,
                        )
                    except Exception:
                        _debug_exception("Delete saved outfit binding failed")
                    try:
                        clear_requirement_cache()
                    except Exception:
                        pass
                    try:
                        from couplepose1 import clear_linked_view_caches
                        clear_linked_view_caches()
                    except Exception:
                        pass
            interaction._fgeh_linked_view = VIEW_CAS_LOCAL
            interaction._show_picker_dialog(interaction.sim, target_sim=target_sim)
        except Exception:
            _debug_exception("Saved outfit binding picker response failed")

    try:
        dialog.add_listener(_on_saved_outfit_selected)
        dialog.show_dialog()
        return True
    except Exception:
        _debug_exception("Show saved outfit binding picker failed")
        return False


def show_outfit_cas_binding_picker(interaction, pack_id, pose_name, target_sim=None, choose_parts=False):
    target_sim = target_sim or getattr(interaction, "target", None)
    sim_info = get_sim_info_from_target(target_sim)
    debug_log(
        "Full outfit binding picker open pack_id={} pose_name={} target_sim={} choose_parts={}",
        pack_id,
        pose_name,
        target_sim,
        choose_parts,
    )
    if sim_info is None:
        debug_log("Full outfit binding picker skipped: no sim_info target={}", target_sim)
        return False

    scan_rows = _get_outfit_scan_rows(sim_info)
    picker_rows = _filter_bindable_outfit_scan_rows(scan_rows)
    debug_log(
        "Full outfit binding picker scan sim_id={} rows={} picker_rows={}",
        getattr(sim_info, "sim_id", None),
        len(scan_rows),
        len(picker_rows),
    )
    if not picker_rows:
        debug_log("Full outfit binding picker found no outfits sim_id={}", getattr(sim_info, "sim_id", None))
        return False

    try:
        dialog = UiOutfitPicker.TunableFactory().default(
            interaction.sim,
            resolver=interaction.get_resolver(),
            title=lambda *_, **__: raw_text("绑定服装"),
        )
    except Exception:
        try:
            dialog = UiOutfitPicker.TunableFactory().default(
                interaction.sim,
                interaction.get_resolver(),
            )
        except Exception:
            _debug_exception("Create full outfit binding picker failed")
            return False

    try:
        dialog.outfit_category_filters = tuple(sorted(set(row.get("category") for row in picker_rows)))
    except Exception:
        pass

    for row in picker_rows:
        try:
            category = int(row.get("category"))
            category_index = int(row.get("category_index"))
        except Exception:
            continue
        option_id = _outfit_choice_id(category, category_index)
        debug_log(
            "Full outfit binding picker row option_id={} category={} category_index={} proto_index={} parts={}",
            option_id,
            category,
            category_index,
            row.get("proto_index"),
            len(row.get("parts") or ()),
        )
        dialog.add_row(
            OutfitPickerRow(
                option_id=option_id,
                outfit_sim_id=getattr(sim_info, "sim_id", 0),
                outfit_category=category,
                outfit_index=category_index,
                tag=option_id,
                name=picker_text(row.get("outfit_label")),
                row_description=picker_text("整套绑定 {} 个 CAS 部件".format(len(row.get("parts") or ()))),
            )
        )

    def _on_outfit_selected(response_dialog):
        try:
            if not response_dialog.accepted:
                interaction._show_picker_dialog(interaction.sim, target_sim=target_sim)
                return
            tags = response_dialog.get_result_tags() or ()
            if not tags:
                debug_log("Full outfit binding picker accepted with empty result tags")
                interaction._show_picker_dialog(interaction.sim, target_sim=target_sim)
                return
            debug_log("Full outfit binding picker selected tags={}", tags)
            outfit_row = _get_outfit_row_by_choice_tag(_get_outfit_scan_rows(sim_info), tags[0])
            if outfit_row is None:
                debug_log("Full outfit binding picker could not resolve selected tag={}", tags[0])
                interaction._show_picker_dialog(interaction.sim, target_sim=target_sim)
                return
            debug_log(
                "Full outfit binding picker resolved outfit category={} category_index={} proto_index={} parts={}",
                outfit_row.get("category"),
                outfit_row.get("category_index"),
                outfit_row.get("proto_index"),
                len((outfit_row or {}).get("parts") or ()),
            )
            if choose_parts:
                interaction._fgeh_cas_bind_pack_id = pack_id
                interaction._fgeh_cas_bind_pose_name = pose_name
                interaction._fgeh_cas_bind_target_sim = target_sim
                interaction._fgeh_cas_bind_outfit_row = outfit_row
                interaction._fgeh_cas_bind_proto_index = (outfit_row or {}).get("proto_index")
                interaction._fgeh_linked_view = VIEW_CAS_BIND_PARTS
                try:
                    from couplepose1 import state
                    state.selected_linked_requirement_folder = "cas_bind_parts"
                    state.selected_linked_requirement_asset_key = None
                except Exception:
                    pass
                interaction._show_picker_dialog(interaction.sim, target_sim=target_sim)
                return
            saved_count = save_cas_parts_for_pose(
                pack_id,
                pose_name,
                outfit_row,
                (outfit_row or {}).get("parts") or (),
                body_group="all",
            )
            debug_log("Full outfit binding picker saved_count={}", saved_count)
            try:
                from couplepose1 import state
                state.selected_linked_pack_id = pack_id
                state.selected_linked_style_pose_name = pose_name
                state.selected_linked_requirement_folder = "cas_local"
                state.selected_linked_requirement_asset_key = None
            except Exception:
                pass
            interaction._fgeh_linked_view = VIEW_CAS_LOCAL
            if show_saved_outfit_bindings_picker(interaction, pack_id, pose_name, target_sim=target_sim):
                return
            interaction._show_picker_dialog(interaction.sim, target_sim=target_sim)
        except Exception:
            _debug_exception("Full outfit binding picker response failed")

    try:
        dialog.add_listener(_on_outfit_selected)
        dialog.show_dialog()
        return True
    except Exception:
        _debug_exception("Show full outfit binding picker failed")
        return False


def _show_full_outfit_binding_picker(interaction):
    active_pack, pack_id, pose_name = _resolve_binding_pose_key_for_sim(getattr(interaction, "target", None))
    return show_outfit_cas_binding_picker(
        interaction,
        pack_id,
        pose_name,
        target_sim=getattr(interaction, "target", None),
        choose_parts=False,
    )


def get_linked_object_entries_for_interaction(interaction):
    """Read object links through the pose manager without duplicating its registry."""
    target = getattr(interaction, "target", None)
    pose_name = get_current_pose_name_for_sim(target)
    active_pack = get_current_pose_pack_for_sim(target)
    if not pose_name or active_pack is None:
        return []

    pack_id = str(getattr(active_pack, "__name__", "") or getattr(active_pack, "pack_id", "") or "")
    try:
        from couplepose1 import get_linked_object_variant_options
        options = list(get_linked_object_variant_options(pack_id, pose_name))
    except Exception:
        debug_log("Object category lookup failed pack_id={} pose_name={}", pack_id, pose_name)
        return []

    entries = []
    seen = set()
    for option in options:
        definition_id = str(option.get("definition_id") or "")
        if not definition_id or definition_id in seen:
            continue
        seen.add(definition_id)
        label = str(
            option.get("catalog_name")
            or option.get("entry_label")
            or option.get("label")
            or definition_id
        )
        source_origin = str(option.get("source_origin") or "external")
        entries.append({
            "label": label,
            "description": "Object Definition ID: {}".format(definition_id),
            "definition_id": definition_id,
            "source_origin": source_origin,
        })
    return entries


def _is_fgeh_pose_metadata(snippet):
    class_name = snippet.__class__.__name__
    if class_name == "FGEHPoseMetadataSnippet":
        return True
    return hasattr(snippet, "accessory_cas_part_id") or hasattr(snippet, "accessories")


def iter_accessory_metadata_snippets():
    global _ACCESSORY_SNIPPETS_BY_PACK
    if _ACCESSORY_SNIPPETS_BY_PACK is None:
        _build_accessory_snippet_index()
    seen = set()
    for snippets in _ACCESSORY_SNIPPETS_BY_PACK.values():
        for snippet in snippets:
            marker = id(snippet)
            if marker in seen:
                continue
            seen.add(marker)
            yield snippet


def _build_accessory_snippet_index():
    global _ACCESSORY_SNIPPETS_BY_PACK
    index = {}
    manager = _get_pose_pack_manager()
    if manager is None:
        _ACCESSORY_SNIPPETS_BY_PACK = {}
        return _ACCESSORY_SNIPPETS_BY_PACK

    for snippet in _safe_list(getattr(manager, "_tuned_classes", {}).values()):
        if not _is_fgeh_pose_metadata(snippet):
            continue
        if getattr(snippet, "disabled", False):
            continue
        keys = {
            str(getattr(snippet, "pack_id", "") or ""),
            str(getattr(snippet, "source_pose_pack_name", "") or ""),
        }
        for key in keys - {""}:
            index.setdefault(key, []).append(snippet)
    _ACCESSORY_SNIPPETS_BY_PACK = index
    return index


def _get_pack_key(pack):
    if pack is None:
        return ""
    if isinstance(pack, str):
        return str(pack or "")
    return str(getattr(pack, "__name__", "") or getattr(pack, "pack_id", "") or "")


def get_accessory_snippets_for_pose_pack(pack):
    pack_id = _get_pack_key(pack)
    global _ACCESSORY_SNIPPETS_BY_PACK
    if _ACCESSORY_SNIPPETS_BY_PACK is None:
        _build_accessory_snippet_index()
    matches = list((_ACCESSORY_SNIPPETS_BY_PACK or {}).get(pack_id, ())) if pack_id else []
    debug_log("Accessory snippets for pack_id={} count={}", pack_id, len(matches))
    return matches


def _entry_variants(entry):
    variants = _safe_list(getattr(entry, "variants", None))
    legacy_cas_part_id = getattr(entry, "cas_part_id", None)
    if not variants and legacy_cas_part_id:
        return [entry]
    return variants


def _entry_label(entry, fallback):
    return (
        getattr(entry, "label", None)
        or getattr(entry, "display_name", None)
        or fallback
    )


def _entry_description(entry):
    return getattr(entry, "description_text", None) or getattr(entry, "description", None) or ""


def _import_icon_info_data():
    try:
        from distributor.shared_messages import IconInfoData
        return IconInfoData
    except Exception:
        pass

    try:
        from interactions.utils.tunable_icon import IconInfoData
        return IconInfoData
    except Exception:
        pass

    return None


def _make_resource_key(type_id, group, instance):
    # Project-owned icons use Key(type, instance, group).
    try:
        key_class = getattr(sims4.resources, "Key", None)
        if key_class is not None:
            return key_class(type_id, instance, group)
    except Exception as exc:
        debug_log(
            "Key constructor failed type={:08X} group={:08X} instance={:016X}: {}",
            type_id,
            group,
            instance,
            exc,
        )

    return None


def _parse_thumbnail_key(thumbnail_text):
    if not thumbnail_text:
        return None

    text = str(thumbnail_text).strip().replace("-", ":")
    parts = [part.strip() for part in text.split(":") if part.strip()]
    if len(parts) != 3:
        debug_log("Invalid thumbnail key format: {}", thumbnail_text)
        return None

    try:
        type_id = int(parts[0], 16)
        group = int(parts[1], 16)
        instance = int(parts[2], 16)
    except Exception as exc:
        debug_log("Failed to parse thumbnail key {}: {}", thumbnail_text, exc)
        return None

    key = _make_resource_key(type_id, group, instance)
    if key is None:
        debug_log("Failed to create resource key for thumbnail {}", thumbnail_text)
    else:
        debug_log(
            "Thumbnail key parsed text={} type={:08X} group={:08X} instance={:016X} key={}",
            thumbnail_text,
            type_id,
            group,
            instance,
            key,
        )
    return key


def _thumbnail_icon_from_text(thumbnail_text):
    text = str(thumbnail_text or "").strip()
    if not text:
        return None
    if text in _THUMBNAIL_KEY_CACHE:
        return _THUMBNAIL_KEY_CACHE[text]
    key = _parse_thumbnail_key(thumbnail_text)
    _THUMBNAIL_KEY_CACHE[text] = key
    if key is None:
        return None

    # ObjectPickerRow(icon=...) expects a ResourceKey-like object with .type/.group/.instance.
    # Do NOT wrap this in IconInfoData here; ui_dialog_picker will try to access icon.type.
    return key


def _thumbnail_icon_from_entry(entry):
    thumbnail = getattr(entry, "thumbnail", "") or ""
    icon = _thumbnail_icon_from_text(thumbnail)
    debug_log(
        "Thumbnail lookup entry_label={} thumbnail={} resolved_icon={}",
        _entry_label(entry, ""),
        thumbnail,
        icon,
    )
    return icon


def _entry_icon(entry, fallback=None):
    explicit_icon = getattr(entry, "icon", None)
    if explicit_icon is not None:
        debug_log(
            "Icon selected source=explicit entry_label={} icon={}",
            _entry_label(entry, ""),
            explicit_icon,
        )
        return explicit_icon

    thumbnail_icon = _thumbnail_icon_from_entry(entry)
    if thumbnail_icon is not None:
        debug_log(
            "Icon selected source=entry_thumbnail entry_label={} icon={}",
            _entry_label(entry, ""),
            thumbnail_icon,
        )
        return thumbnail_icon

    for variant in _safe_list(getattr(entry, "variants", None)):
        thumbnail_icon = _thumbnail_icon_from_entry(variant)
        if thumbnail_icon is not None:
            debug_log(
                "Icon selected source=first_variant_thumbnail entry_label={} variant_label={} icon={}",
                _entry_label(entry, ""),
                _entry_label(variant, ""),
                thumbnail_icon,
            )
            return thumbnail_icon

    debug_log(
        "Icon selected source=fallback entry_label={} icon={}",
        _entry_label(entry, ""),
        fallback,
    )
    return fallback


def _entry_cas_part_id(entry):
    value = getattr(entry, "cas_part_id", None)
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _entry_object_definition_id(entry):
    for attr_name in ("object_definition_id", "definition_id"):
        value = getattr(entry, attr_name, None)
        try:
            value = int(value) if value else 0
        except Exception:
            value = 0
        if value:
            return value
    return 0


def _entry_object_tuning_id(entry):
    value = getattr(entry, "object_tuning_id", None)
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _normalize_category(value):
    text = str(value or "").strip().lower()
    return text or DEFAULT_CATEGORY


def _entry_category(entry):
    return _normalize_category(
        getattr(entry, "category", None)
        or getattr(entry, "category_id", None)
        or getattr(entry, "asset_kind", None)
        or getattr(entry, "resource_type", None)
    )


def _category_matches(entry, category_filter):
    if not category_filter:
        return True
    category_filter = _normalize_category(category_filter)
    return _entry_category(entry) == category_filter


def _filter_entries_by_category(entries, category_filter):
    if not category_filter:
        return entries
    category_filter = _normalize_category(category_filter)
    filtered = [
        entry_info for entry_info in entries
        if _category_matches(entry_info.get("entry"), category_filter)
    ]
    debug_log(
        "Filtered accessory entries category_filter={} before={} after={}",
        category_filter,
        len(entries),
        len(filtered),
    )
    return filtered


def _entry_pose_names(entry):
    raw_pose_names = getattr(entry, "pose_names", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "poses", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "pose_name", None)

    if raw_pose_names is None:
        return []
    if isinstance(raw_pose_names, str):
        raw_pose_names = [raw_pose_names]

    result = []
    try:
        iterator = list(raw_pose_names)
    except Exception:
        iterator = []

    for pose_name in iterator:
        pose_name = str(pose_name or "").strip()
        if pose_name:
            result.append(pose_name)

    return result


def _entry_matches_pose_name(entry, pose_name):
    pose_name = str(pose_name or "").strip()
    entry_pose_names = _entry_pose_names(entry)
    if not entry_pose_names:
        return True
    return pose_name in entry_pose_names


def _filter_entries_by_pose_name(entries, pose_name):
    if not pose_name:
        return entries
    filtered = [
        entry_info for entry_info in entries
        if _entry_matches_pose_name(entry_info.get("entry"), pose_name)
    ]
    debug_log(
        "Filtered accessory entries pose_name={} before={} after={}",
        pose_name,
        len(entries),
        len(filtered),
    )
    return filtered


def _variant_signature(variant):
    return (
        str(_entry_label(variant, "")),
        str(_entry_description(variant)),
        int(_entry_cas_part_id(variant) or 0),
        int(_entry_object_definition_id(variant) or 0),
        int(_entry_object_tuning_id(variant) or 0),
    )


def _dedupe_variants(variants):
    result = []
    seen = set()

    for variant in variants:
        signature = _variant_signature(variant)
        if signature in seen:
            debug_log(
                "Skipped duplicate accessory variant: label={} cas_part_id={}",
                _entry_label(variant, ""),
                _entry_cas_part_id(variant),
            )
            continue

        seen.add(signature)
        result.append(variant)

    return result


def _entry_signature(label, description, variants):
    cas_part_ids = []
    object_definition_ids = []
    object_tuning_ids = []
    variant_labels = []

    for variant in variants:
        cas_part_id = _entry_cas_part_id(variant)
        if cas_part_id:
            cas_part_ids.append(int(cas_part_id))
        object_definition_id = _entry_object_definition_id(variant)
        if object_definition_id:
            object_definition_ids.append(int(object_definition_id))
        object_tuning_id = _entry_object_tuning_id(variant)
        if object_tuning_id:
            object_tuning_ids.append(int(object_tuning_id))
        variant_labels.append(str(_entry_label(variant, "")))

    return (
        str(label or ""),
        str(description or ""),
        tuple(sorted(set(cas_part_ids))),
        tuple(sorted(set(object_definition_ids))),
        tuple(sorted(set(object_tuning_ids))),
        tuple(sorted(set(variant_labels))),
    )


def _asset_id(asset):
    return str(getattr(asset, "asset_id", "") or "").strip()


def _link_asset_id(link):
    return str(getattr(link, "asset_id", "") or "").strip()


def _get_v3_pose_names(snippet, link):
    target_type = str(getattr(link, "target_type", "") or "").strip().lower()
    target_id = str(getattr(link, "target_id", "") or "").strip()
    pose_name = str(getattr(link, "pose_name", "") or "").strip()
    snippet_pack_ids = set((
        str(getattr(snippet, "pack_id", "") or "").strip(),
        str(getattr(snippet, "source_pose_pack_name", "") or "").strip(),
    ))

    if target_type == "pose":
        return [target_id or pose_name] if (target_id or pose_name) else []
    if target_type == "pack":
        return []
    if pose_name and pose_name not in snippet_pack_ids:
        return [pose_name]
    return []


def _build_v3_accessory_entries(snippet, seen_entries):
    assets = _safe_list(getattr(snippet, "assets", None))
    links = _safe_list(getattr(snippet, "action_links", None))
    if not assets or not links:
        return []

    assets_by_id = {}
    for asset in assets:
        asset_id = _asset_id(asset)
        if asset_id:
            assets_by_id[asset_id] = asset

    result = []
    for link in links:
        asset_id = _link_asset_id(link)
        asset = assets_by_id.get(asset_id)
        if asset is None:
            debug_log(
                "Skipped v3 action link without matching asset: link_id={} asset_id={}",
                getattr(link, "link_id", None),
                asset_id,
            )
            continue

        variants = _dedupe_variants(_safe_list(getattr(asset, "variants", None)))
        if not variants:
            debug_log(
                "Skipped v3 asset without variants: asset_id={} label={}",
                asset_id,
                getattr(asset, "label", None),
            )
            continue

        category = (
            getattr(link, "category_id", None)
            or getattr(asset, "category_id", None)
            or getattr(link, "asset_kind", None)
            or getattr(asset, "asset_kind", None)
            or "cas"
        )
        resource_type = (
            getattr(link, "asset_kind", None)
            or getattr(asset, "asset_kind", None)
            or category
            or "cas"
        )
        label = _entry_label(asset, asset_id or "Linked Asset")
        description = (
            _entry_description(asset)
            or getattr(link, "ui_group", None)
            or getattr(snippet, "binding_display_name", None)
            or ""
        )
        pose_names = _get_v3_pose_names(snippet, link)
        link_id = str(getattr(link, "link_id", "") or "")
        unique_signature = (
            "v3",
            asset_id,
            link_id,
            tuple(pose_names),
            _entry_signature(label, description, variants),
        )
        if unique_signature in seen_entries:
            debug_log(
                "Skipped duplicate v3 linked asset: asset_id={} link_id={}",
                asset_id,
                link_id,
            )
            continue

        seen_entries.add(unique_signature)
        entry = _FgehLinkedRequirementView(
            label=label,
            display_name=label,
            description_text=description,
            category=category,
            category_id=category,
            resource_type=resource_type,
            asset_kind=resource_type,
            asset_id=asset_id,
            link_id=link_id,
            requirement=getattr(link, "requirement", "") or "recommended",
            role=getattr(link, "role", "") or "",
            pose_names=pose_names,
            variants=variants,
        )
        result.append({
            "snippet": snippet,
            "entry": entry,
            "variants": variants,
            "label": label,
            "description": description,
            "category": _normalize_category(category),
            "resource_type": str(resource_type or "").strip().lower(),
            "asset_id": asset_id,
            "link_id": link_id,
            "icon": _entry_icon(asset, getattr(snippet, "icon", None) or MY_CUSTOM_ICON),
        })

    if result:
        debug_log(
            "Built v3 linked entries snippet={} count={}",
            getattr(snippet, "__name__", None),
            len(result),
        )
    return result


def build_accessory_entries(snippets):
    entries = []
    seen_entries = set()

    for snippet in snippets:
        v3_entries = _build_v3_accessory_entries(snippet, seen_entries)
        if v3_entries:
            entries.extend(v3_entries)
            continue

        snippet_entries = _safe_list(getattr(snippet, "accessories", None))

        if not snippet_entries:
            legacy_cas_part_id = getattr(snippet, "accessory_cas_part_id", None)
            if legacy_cas_part_id:
                variants = [snippet]
                label = getattr(snippet, "pack_name", None) or "Accessory"
                description = getattr(snippet, "pack_id", None) or ""

                signature = _entry_signature(label, description, variants)
                if signature in seen_entries:
                    debug_log(
                        "Skipped duplicate legacy accessory entry: label={} cas_part_id={}",
                        label,
                        legacy_cas_part_id,
                    )
                    continue

                seen_entries.add(signature)

                entries.append({
                    "snippet": snippet,
                    "entry": snippet,
                    "variants": variants,
                    "label": label,
                    "description": description,
                    "category": "accessory",
                    "icon": getattr(snippet, "icon", None) or MY_CUSTOM_ICON,
                })

            continue

        for index, entry in enumerate(snippet_entries):
            variants = _dedupe_variants(_entry_variants(entry))
            if not variants:
                continue

            label = _entry_label(entry, "Accessory {}".format(index + 1))
            description = _entry_description(entry)
            icon = _entry_icon(entry, getattr(snippet, "icon", None) or MY_CUSTOM_ICON)

            signature = _entry_signature(label, description, variants)
            if signature in seen_entries:
                debug_log(
                    "Skipped duplicate accessory entry: label={} description={} variant_count={}",
                    label,
                    description,
                    len(variants),
                )
                continue

            seen_entries.add(signature)

            entries.append({
                "snippet": snippet,
                "entry": entry,
                "variants": variants,
                "label": label,
                "description": description,
                "category": _entry_category(entry),
                "icon": icon,
            })

    debug_log("build_accessory_entries deduped result count={}", len(entries))
    return entries


def _build_accessory_entries_cached(snippets):
    snippets = tuple(snippets or ())
    cache_key = tuple(_snippet_id(snippet) for snippet in snippets)
    cached = _ACCESSORY_ENTRIES_CACHE.get(cache_key)
    if cached is None:
        cached = build_accessory_entries(snippets)
        _ACCESSORY_ENTRIES_CACHE[cache_key] = cached
    return cached


def get_picker_entries_for_interaction(interaction):
    target = getattr(interaction, "target", None)
    sim_info = get_sim_info_from_target(target)
    if sim_info is None:
        return None, []

    active_pack, pack_id, pose_name = _resolve_binding_pose_key_for_sim(target)
    snippets = get_accessory_snippets_for_pose_pack(active_pack) if _external_cas_links_enabled() else []
    saved_entries = (
        get_saved_cas_entries_for_pose(pack_id, pose_name)
        if _in_game_cas_binding_enabled()
        else []
    )

    if not snippets:
        debug_log("No active pack metadata matched; saved linked CAS entries count={}", len(saved_entries))
        return active_pack, _filter_entries_by_category(
            _filter_release_cas_entries(saved_entries),
            getattr(interaction, "category_filter", ""),
        )

    entries = list(_with_source_origin(_build_accessory_entries_cached(snippets), "external"))
    entries.extend(saved_entries)
    entries = _filter_entries_by_category(entries, getattr(interaction, "category_filter", ""))
    return active_pack, _filter_release_cas_entries(entries)


def get_all_accessory_entries():
    if not _external_cas_links_enabled():
        return []
    snippets = list(iter_accessory_metadata_snippets())
    debug_log("All accessory snippets count={}", len(snippets))
    return _with_source_origin(_build_accessory_entries_cached(snippets), "external")


def get_entries_for_source_mode(interaction, source_mode):
    if source_mode == "all":
        return _filter_entries_by_category(
            get_all_accessory_entries(),
            getattr(interaction, "category_filter", ""),
        )

    active_pack, entries = get_picker_entries_for_interaction(interaction)
    return entries


def dump_picker_debug_info(interaction):
    target = getattr(interaction, "target", None)
    sim_info = get_sim_info_from_target(target)

    debug_log("========== FGEH ACCESSORY PICKER DEBUG START ==========")
    debug_log("Picker debug target={} sim_info={} sim_id={}", target, sim_info, getattr(sim_info, "sim_id", None))

    active_pack = get_current_pose_pack_for_sim(target)
    debug_log(
        "Picker debug active_pack={} pack_name={} sort_name={}",
        getattr(active_pack, "__name__", None),
        getattr(active_pack, "display_name", None),
        getattr(active_pack, "sort_name", None),
    )

    snippets = get_accessory_snippets_for_pose_pack(active_pack)
    debug_log("Picker debug matched metadata snippets count={}", len(snippets))

    if not snippets:
        fallback_snippets = list(iter_accessory_metadata_snippets())
        debug_log("Picker debug fallback metadata snippets count={}", len(fallback_snippets))
        snippets = fallback_snippets

    for snippet_index, snippet in enumerate(snippets):
        debug_log(
            "Metadata snippet[{}]: name={} binding_display_name={} pack_id={} pack_name={} accessory_cas_part_id={}",
            snippet_index,
            getattr(snippet, "__name__", None),
            getattr(snippet, "binding_display_name", None),
            getattr(snippet, "pack_id", None),
            getattr(snippet, "pack_name", None),
            getattr(snippet, "accessory_cas_part_id", None),
        )

    entries = _build_accessory_entries_cached(snippets)
    debug_log("Picker debug accessory entries count={}", len(entries))

    for entry_index, entry_info in enumerate(entries):
        debug_log(
            "Entry[{}]: label={} description={} variant_count={}",
            entry_index,
            entry_info.get("label"),
            entry_info.get("description"),
            len(entry_info.get("variants", ())),
        )

        for variant_index, variant in enumerate(entry_info.get("variants", ())):
            debug_log(
                "Entry[{}] Variant[{}]: label={} description={} cas_part_id={} thumbnail={}",
                entry_index,
                variant_index,
                _entry_label(variant, "Variant {}".format(variant_index + 1)),
                _entry_description(variant),
                _entry_cas_part_id(variant),
                getattr(variant, "thumbnail", None),
            )

    dump_current_outfit_parts(sim_info)

    debug_log("========== FGEH ACCESSORY PICKER DEBUG END ==========")

class FgehPosePackAccessoryPickerInteraction(PickerSuperInteraction):
    INSTANCE_TUNABLES = {
        "category_filter": Tunable(
            description="Optional requirement category filter for this menu entry. Examples: accessory, hat, other.",
            tunable_type=str,
            default="",
        ),
        "variant_continuation": OptionalTunable(
            description="Continuation pushed after choosing one linked accessory group.",
            tunable=TunableContinuation(locked_args={"actor": ParticipantType.Actor}),
            tuning_group=GroupNames.PICKERTUNING,
        ),
        "all_accessories_continuation": OptionalTunable(
            description="Continuation pushed to show all available accessories.",
            tunable=TunableContinuation(locked_args={"actor": ParticipantType.Actor}),
            tuning_group=GroupNames.PICKERTUNING,
        ),
    }

    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    def _run_interaction_gen(self, timeline):
        posepack_menu_debug_log(
            "run interaction self_class={} class_guid={} target={} sim={} category_filter={} icon_key={}",
            type(self).__name__,
            getattr(type(self), "guid64", None),
            self.target,
            self.sim,
            getattr(self, "category_filter", None),
            POSEPACK_MENU_ICON_KEY,
        )
        debug_log(
            "Opening linked accessory picker interaction={} target={} sim={}",
            self,
            self.target,
            self.sim,
        )
        self._show_picker_dialog(self.sim, target_sim=self.target)
        return True
        if False:
            yield None

    @flexmethod
    def picker_rows_gen(cls, inst, target, context, **kwargs):
        if inst is None:
            return

        view = getattr(inst, "_fgeh_linked_view", VIEW_ROOT)
        active_pack, entries = get_picker_entries_for_interaction(inst)
        posepack_menu_debug_log(
            "picker rows view={} class_guid={} target={} entry_count={} active_pack={}",
            view,
            getattr(cls, "guid64", None),
            target,
            len(entries),
            getattr(active_pack, "__name__", None),
        )
        debug_log(
            "Linked picker rows view={} active_pack={} entry_count={}",
            view,
            getattr(active_pack, "__name__", None),
            len(entries),
        )

        if view == VIEW_ROOT:
            yield _make_row(
                stbl_text(STR_LINKED_RESTORE_OUTFIT),
                icon=MY_CUSTOM_ICON,
                tag=RESTORE_TAG,
                description=stbl_text(STR_LINKED_RESTORE_OUTFIT),
            )
            yield _make_row(
                stbl_text(STR_LINKED_CLEAR_OBJECTS),
                icon=MY_CUSTOM_ICON,
                tag=CLEAR_LINKED_OBJECTS_TAG,
                description=stbl_text(STR_LINKED_CLEAR_OBJECTS),
            )
            yield _make_row(
                stbl_text(STR_LINKED_CAS_CATEGORY),
                icon=MY_CUSTOM_ICON,
                tag=CATEGORY_CAS_TAG,
                description=stbl_text(STR_LINKED_GROUP_CAS_DESC),
                count=len(entries),
            )
            object_entries = get_linked_object_entries_for_interaction(inst)
            yield _make_row(
                stbl_text(STR_LINKED_OBJECT_CATEGORY),
                icon=MY_CUSTOM_ICON,
                tag=CATEGORY_OBJECT_TAG,
                description=stbl_text(STR_LINKED_OBJECT_CATEGORY_DESC),
                count=len(object_entries),
            )
            if SHOW_LINKED_DEBUG_LOG_ROW:
                yield _make_row(stbl_text(STR_LINKED_DEBUG_LOG), icon=MY_CUSTOM_ICON, tag=LOG_TAG, description=stbl_text(STR_LINKED_DEBUG_LOG))
            return

        yield _make_row(stbl_text(STR_LINKED_BACK), tag=VIEW_BACK_TAG)

        if view == VIEW_CAS:
            local_count = len([item for item in entries if item.get("source_origin") == "local"])
            external_count = len(entries) - local_count
            if _in_game_cas_binding_enabled():
                yield _make_row(
                    "选择整套服装绑定",
                    tag=CAS_BIND_SCAN_TAG,
                    description="打开整身缩略图，点一套衣服后整套绑定到当前动作",
                    count=len(_get_outfit_scan_rows(get_sim_info_from_target(target))),
                )
                yield _make_row(
                    "选择服装部位绑定",
                    tag=CAS_BIND_SCAN_PARTS_TAG,
                    description="打开整身缩略图，点一套衣服后再选头发、化妆或配件",
                    count=len(_get_outfit_scan_rows(get_sim_info_from_target(target))),
                )
                yield _make_row(
                    "游戏内绑定 CAS",
                    tag=CAS_LOCAL_TAG,
                    description="查看通过游戏内套装扫描保存的 CAS 联动",
                    count=local_count,
                )
                if local_count:
                    yield _make_row(
                        "删除游戏内绑定服装",
                        tag=CAS_DELETE_OUTFIT_TAG,
                        description="打开已保存服装缩略图，点一套就删除这套游戏内绑定",
                        count=local_count,
                    )
            if _external_cas_links_enabled():
                yield _make_row(
                    "外部联动 CAS",
                    tag=CAS_EXTERNAL_TAG,
                    description="查看外部 XML 或绑定包提供的 CAS 联动",
                    count=external_count,
                )
            yield _make_row(stbl_text(STR_LINKED_VIEW_ALL), tag=ALL_ACCESSORIES_TAG, description=stbl_text(STR_LINKED_VIEW_ALL))
            return

        if view in (VIEW_CAS_LOCAL, VIEW_CAS_EXTERNAL):
            want_local = view == VIEW_CAS_LOCAL
            filtered = [
                (index, entry_info)
                for index, entry_info in enumerate(entries)
                if (entry_info.get("source_origin") == "local") == want_local
            ]
            if not filtered:
                yield _make_row("这个动作还没有游戏内绑定 CAS" if want_local else "这个动作没有外部 CAS 联动", tag=BACK_TAG)
                return
            for index, entry_info in filtered:
                tag = ACCESSORY_TAG_PREFIX + str(index)
                yield _make_row(
                    entry_info["label"],
                    icon=entry_info["icon"],
                    tag=tag,
                    description=entry_info["description"],
                    count=len(entry_info["variants"]),
                )
            return

        if view == VIEW_CAS_BIND_CATEGORY:
            scan_rows = _get_outfit_scan_rows(get_sim_info_from_target(target))
            categories = _get_outfit_categories(scan_rows)
            if not categories:
                yield _make_row("没有读到这个小人的套装", tag=BACK_TAG)
                return
            for category in categories:
                yield _make_row(
                    category.get("category_name"),
                    tag=CAS_BIND_CATEGORY_PREFIX + str(category.get("category")),
                    description="选择这个类别里的第几套衣服",
                    count=category.get("count", 0),
                )
            return

        if view == VIEW_CAS_BIND_OUTFIT:
            scan_rows = _get_outfit_scan_rows(get_sim_info_from_target(target))
            selected_category = getattr(inst, "_fgeh_cas_bind_category", None)
            outfits = [row for row in scan_rows if str(row.get("category")) == str(selected_category)]
            if not outfits:
                yield _make_row("这个类别没有可读取的套装", tag=BACK_TAG)
                return
            for row in outfits:
                desc = "CAS 部件 {} 个".format(len(row.get("parts") or ()))
                if row.get("is_current"):
                    desc = desc + " | 当前穿着"
                yield _make_row(
                    row.get("outfit_label"),
                    tag=CAS_BIND_OUTFIT_PREFIX + str(row.get("proto_index")),
                    description=desc,
                    count=len(row.get("parts") or ()),
                )
            return

        if view == VIEW_CAS_BIND_PARTS:
            scan_rows = _get_outfit_scan_rows(get_sim_info_from_target(target))
            outfit_row = _get_outfit_row_by_proto_index(scan_rows, getattr(inst, "_fgeh_cas_bind_proto_index", -1))
            if outfit_row is None:
                yield _make_row("这套衣服已经找不到了，请返回重选", tag=BACK_TAG)
                return
            parts = list(outfit_row.get("parts") or ())
            if not parts:
                yield _make_row("这套衣服没有可绑定 CAS 部件", tag=BACK_TAG)
                return
            yield _make_row(
                "绑定整套 CAS",
                tag=CAS_BIND_ALL_PREFIX + str(outfit_row.get("proto_index")),
                description="保存这套服装里的全部 CASP",
                count=len(parts),
            )
            for group in get_body_grouped_outfit_parts(outfit_row):
                body_group = group.get("body_group") or "other"
                group_parts = group.get("parts") or []
                yield _make_row(
                    "只绑定: {}".format(group.get("label") or get_body_group_name(body_group)),
                    tag=CAS_BIND_BODY_PREFIX + "{}::{}".format(outfit_row.get("proto_index"), body_group),
                    description="按游戏 BodyType 自动归类，保存这一组 CASP",
                    count=len(group_parts),
                )
            for part in parts:
                cas_part_id = int(part.get("cas_part_id") or 0)
                body_type = int(part.get("body_type") or 0)
                yield _make_row(
                    "{} | CAS {}".format(get_body_type_name(body_type), cas_part_id),
                    tag=CAS_BIND_PART_PREFIX + "{}::{}".format(outfit_row.get("proto_index"), cas_part_id),
                    description="只保存这一个 CASP",
                )
            return

        if view == VIEW_OBJECT:
            object_entries = get_linked_object_entries_for_interaction(inst)
            local_count = len([item for item in object_entries if item.get("source_origin") == "local"])
            external_count = len(object_entries) - local_count
            if _in_game_object_binding_enabled():
                yield _make_row(
                    stbl_text(STR_LINKED_OBJECT_LOCAL),
                    tag=OBJECT_LOCAL_TAG,
                    description=stbl_text(STR_LINKED_OBJECT_LOCAL_DESC),
                    count=local_count,
                )
            if _external_object_links_enabled():
                yield _make_row(
                    stbl_text(STR_LINKED_OBJECT_EXTERNAL),
                    tag=OBJECT_EXTERNAL_TAG,
                    description=stbl_text(STR_LINKED_OBJECT_EXTERNAL_DESC),
                    count=external_count,
                )
            return

        if view in (VIEW_OBJECT_LOCAL, VIEW_OBJECT_EXTERNAL):
            object_entries = get_linked_object_entries_for_interaction(inst)
            source_origin = "local" if view == VIEW_OBJECT_LOCAL else "external"
            for entry in object_entries:
                if (entry.get("source_origin") == "local") != (source_origin == "local"):
                    continue
                yield _make_row(
                    entry["label"],
                    icon=entry.get("icon") or MY_CUSTOM_ICON,
                    description=entry["description"],
                )
            return

        yield _make_row(stbl_text(STR_LINKED_VIEW_ALL), tag=ALL_ACCESSORIES_TAG, description=stbl_text(STR_LINKED_VIEW_ALL))
        if SHOW_LINKED_DEBUG_LOG_ROW:
            yield _make_row(stbl_text(STR_LINKED_DEBUG_LOG), tag=LOG_TAG, description=stbl_text(STR_LINKED_DEBUG_LOG))

        if not entries:
            yield _make_row(stbl_text(STR_LINKED_NO_PACK_ITEMS), tag=BACK_TAG)
            return

        for index, entry_info in enumerate(entries):
            tag = ACCESSORY_TAG_PREFIX + str(index)
            debug_log(
                "Linked picker row image entry_index={} label={} icon={} tag={}",
                index,
                entry_info["label"],
                entry_info["icon"],
                tag,
            )
            yield _make_row(
                entry_info["label"],
                icon=entry_info["icon"],
                tag=tag,
                description=entry_info["description"],
                count=len(entry_info["variants"]),
            )

    def on_multi_choice_selected(self, picked_choice, **kwargs):
        pass

    def on_choice_selected(self, choice_tag, **kwargs):
        debug_log(
            "Linked picker choice received tag={} type={} kwargs={}",
            choice_tag,
            type(choice_tag),
            kwargs,
        )
        sim_info = get_sim_info_from_target(self.target)
        if sim_info is None:
            debug_log("Linked picker choice aborted: target has no sim_info.")
            return

        if choice_tag is None:
            debug_log("Linked picker choice ignored because tag is None target={} sim_id={}", self.target, getattr(sim_info, "sim_id", None))
            return

        local_cas_choice = choice_tag in (
            CAS_LOCAL_TAG,
            CAS_DELETE_OUTFIT_TAG,
            CAS_BIND_SCAN_TAG,
            CAS_BIND_SCAN_PARTS_TAG,
        ) or (
            isinstance(choice_tag, str)
            and choice_tag.startswith((
                CAS_BIND_CATEGORY_PREFIX,
                CAS_BIND_OUTFIT_PREFIX,
                CAS_BIND_ALL_PREFIX,
                CAS_BIND_BODY_PREFIX,
                CAS_BIND_PART_PREFIX,
            ))
        )
        if local_cas_choice and not _in_game_cas_binding_enabled():
            self._fgeh_linked_view = VIEW_CAS
            return self._show_picker_dialog(self.sim, target_sim=self.target)
        if choice_tag == CAS_EXTERNAL_TAG and not _external_cas_links_enabled():
            self._fgeh_linked_view = VIEW_CAS
            return self._show_picker_dialog(self.sim, target_sim=self.target)
        if choice_tag == OBJECT_LOCAL_TAG and not _in_game_object_binding_enabled():
            self._fgeh_linked_view = VIEW_OBJECT
            return self._show_picker_dialog(self.sim, target_sim=self.target)
        if choice_tag == OBJECT_EXTERNAL_TAG and not _external_object_links_enabled():
            self._fgeh_linked_view = VIEW_OBJECT
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CATEGORY_CAS_TAG:
            self._fgeh_linked_view = VIEW_CAS
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CAS_LOCAL_TAG:
            active_pack, pack_id, pose_name = _resolve_binding_pose_key_for_sim(self.target)
            if show_saved_outfit_bindings_picker(self, pack_id, pose_name, target_sim=self.target):
                return
            self._fgeh_linked_view = VIEW_CAS_LOCAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CAS_DELETE_OUTFIT_TAG:
            active_pack, pack_id, pose_name = _resolve_binding_pose_key_for_sim(self.target)
            if show_saved_outfit_bindings_picker(self, pack_id, pose_name, target_sim=self.target, delete_mode=True):
                return
            self._fgeh_linked_view = VIEW_CAS
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CAS_EXTERNAL_TAG:
            self._fgeh_linked_view = VIEW_CAS_EXTERNAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CAS_BIND_SCAN_TAG:
            if _show_full_outfit_binding_picker(self):
                return
            self._fgeh_linked_view = VIEW_CAS_BIND_CATEGORY
            self._fgeh_cas_bind_category = None
            self._fgeh_cas_bind_proto_index = None
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CAS_BIND_SCAN_PARTS_TAG:
            active_pack, pack_id, pose_name = _resolve_binding_pose_key_for_sim(self.target)
            if show_outfit_cas_binding_picker(self, pack_id, pose_name, target_sim=self.target, choose_parts=True):
                return
            self._fgeh_linked_view = VIEW_CAS_BIND_CATEGORY
            self._fgeh_cas_bind_category = None
            self._fgeh_cas_bind_proto_index = None
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if isinstance(choice_tag, str) and choice_tag.startswith(CAS_BIND_CATEGORY_PREFIX):
            self._fgeh_cas_bind_category = choice_tag[len(CAS_BIND_CATEGORY_PREFIX):]
            self._fgeh_linked_view = VIEW_CAS_BIND_OUTFIT
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if isinstance(choice_tag, str) and choice_tag.startswith(CAS_BIND_OUTFIT_PREFIX):
            self._fgeh_cas_bind_proto_index = _parse_suffix_int(choice_tag, CAS_BIND_OUTFIT_PREFIX)
            self._fgeh_linked_view = VIEW_CAS_BIND_PARTS
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if isinstance(choice_tag, str) and choice_tag.startswith(CAS_BIND_ALL_PREFIX):
            scan_rows = _get_outfit_scan_rows(sim_info)
            outfit_row = _get_outfit_row_by_proto_index(scan_rows, _parse_suffix_int(choice_tag, CAS_BIND_ALL_PREFIX))
            _save_cas_parts_for_current_pose(self.target, outfit_row, (outfit_row or {}).get("parts") or ())
            self._fgeh_linked_view = VIEW_CAS_LOCAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if isinstance(choice_tag, str) and choice_tag.startswith(CAS_BIND_BODY_PREFIX):
            raw = choice_tag[len(CAS_BIND_BODY_PREFIX):]
            try:
                proto_text, body_text = raw.split("::", 1)
                proto_index = int(proto_text)
            except Exception:
                proto_index = -1
                body_text = "other"
            scan_rows = _get_outfit_scan_rows(sim_info)
            outfit_row = _get_outfit_row_by_proto_index(scan_rows, proto_index)
            parts = [
                part for part in (outfit_row or {}).get("parts", ()) or ()
                if str(part.get("body_group") or get_body_group_for_body_type(part.get("body_type")) or "other") == str(body_text)
            ]
            _save_cas_parts_for_current_pose(self.target, outfit_row, parts, body_group=body_text)
            self._fgeh_linked_view = VIEW_CAS_LOCAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if isinstance(choice_tag, str) and choice_tag.startswith(CAS_BIND_PART_PREFIX):
            raw = choice_tag[len(CAS_BIND_PART_PREFIX):]
            try:
                proto_text, part_text = raw.split("::", 1)
                proto_index = int(proto_text)
                cas_part_id = int(part_text)
            except Exception:
                proto_index = -1
                cas_part_id = 0
            scan_rows = _get_outfit_scan_rows(sim_info)
            outfit_row = _get_outfit_row_by_proto_index(scan_rows, proto_index)
            parts = [
                part for part in (outfit_row or {}).get("parts", ()) or ()
                if int(part.get("cas_part_id") or 0) == cas_part_id
            ]
            _save_cas_parts_for_current_pose(self.target, outfit_row, parts)
            self._fgeh_linked_view = VIEW_CAS_LOCAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == CATEGORY_OBJECT_TAG:
            self._fgeh_linked_view = VIEW_OBJECT
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == OBJECT_LOCAL_TAG:
            self._fgeh_linked_view = VIEW_OBJECT_LOCAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == OBJECT_EXTERNAL_TAG:
            self._fgeh_linked_view = VIEW_OBJECT_EXTERNAL
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == VIEW_BACK_TAG:
            current_view = getattr(self, "_fgeh_linked_view", VIEW_ROOT)
            if current_view in (VIEW_OBJECT_LOCAL, VIEW_OBJECT_EXTERNAL):
                self._fgeh_linked_view = VIEW_OBJECT
            elif current_view in (VIEW_CAS_LOCAL, VIEW_CAS_EXTERNAL, VIEW_CAS_BIND_CATEGORY):
                self._fgeh_linked_view = VIEW_CAS
            elif current_view == VIEW_CAS_BIND_OUTFIT:
                self._fgeh_linked_view = VIEW_CAS_BIND_CATEGORY
            elif current_view == VIEW_CAS_BIND_PARTS:
                self._fgeh_linked_view = VIEW_CAS_BIND_OUTFIT
            else:
                self._fgeh_linked_view = VIEW_ROOT
            return self._show_picker_dialog(self.sim, target_sim=self.target)

        if choice_tag == RESTORE_TAG:
            debug_log(
                "Accessory picker restore selected target={} sim_info={} sim_id={}",
                self.target,
                sim_info,
                getattr(sim_info, "sim_id", None),
            )
            result = restore_original_outfit(sim_info)
            debug_log("Accessory picker restore result={}", result)
            return

        if choice_tag == CLEAR_LINKED_OBJECTS_TAG:
            debug_log(
                "Accessory picker clear linked objects selected target={} sim_id={}",
                self.target,
                getattr(sim_info, "sim_id", None),
            )
            try:
                from fgeh_linked_object_runtime import destroy_linked_objects_for_sim
                result = destroy_linked_objects_for_sim(self.target)
                debug_log("Accessory picker clear linked objects result={}", result)
            except Exception:
                _debug_exception("Accessory picker clear linked objects failed")
            return

        if choice_tag == LOG_TAG:
            dump_picker_debug_info(self)
            return

        if choice_tag == ALL_ACCESSORIES_TAG:
            if self.all_accessories_continuation is None:
                debug_log("Accessory picker has no all_accessories_continuation tuned.")
                return

            self.push_tunable_continuation(
                self.all_accessories_continuation,
                category_filter=getattr(self, "category_filter", ""),
                insert_strategy=QueueInsertStrategy.LAST,
                actor=self.target,
            )
            return

        if not isinstance(choice_tag, str) or not choice_tag.startswith(ACCESSORY_TAG_PREFIX):
            return

        try:
            index = int(choice_tag[len(ACCESSORY_TAG_PREFIX):])
        except Exception:
            _debug_exception("Failed to parse linked accessory entry index")
            return

        active_pack, entries = get_picker_entries_for_interaction(self)
        debug_log(
            "Linked picker resolved choice index={} active_pack={} entry_count={}",
            index,
            getattr(active_pack, "__name__", None),
            len(entries),
        )

        if 0 <= index < len(entries):
            if self.variant_continuation is None:
                debug_log("Accessory picker has no variant_continuation tuned.")
                return

            try:
                debug_log(
                    "Pushing variant continuation={} entry_index={} source_mode=linked actor={}",
                    self.variant_continuation,
                    index,
                    self.target,
                )
                result = self.push_tunable_continuation(
                    self.variant_continuation,
                    accessory_entry_index=index,
                    accessory_source_mode="linked",
                    category_filter=getattr(self, "category_filter", ""),
                    insert_strategy=QueueInsertStrategy.LAST,
                    actor=self.target,
                )
                debug_log("Variant continuation push returned {}", result)
            except Exception:
                _debug_exception("Variant continuation push failed")
        else:
            debug_log("Linked picker choice index out of range: index={} count={}", index, len(entries))


class FgehAllAccessoryPickerInteraction(PickerSuperInteraction):
    INSTANCE_TUNABLES = {
        "category_filter": Tunable(
            description="Optional requirement category filter for this all-items menu.",
            tunable_type=str,
            default="",
        ),
        "variant_continuation": OptionalTunable(
            description="Continuation pushed after choosing one accessory group from all accessories.",
            tunable=TunableContinuation(locked_args={"actor": ParticipantType.Actor}),
            tuning_group=GroupNames.PICKERTUNING,
        ),
    }

    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    def _run_interaction_gen(self, timeline):
        self._show_picker_dialog(self.sim, target_sim=self.target)
        return True
        if False:
            yield None

    @flexmethod
    def picker_rows_gen(cls, inst, target, context, **kwargs):
        if inst is None:
            return

        entries = _filter_entries_by_category(
            get_all_accessory_entries(),
            getattr(inst, "category_filter", ""),
        )

        if not entries:
            yield _make_row("No linked items found for this pose pack", tag=BACK_TAG)
            return

        for index, entry_info in enumerate(entries):
            tag = ACCESSORY_TAG_PREFIX + str(index)
            debug_log(
                "All-accessories picker row image entry_index={} label={} icon={} tag={}",
                index,
                entry_info["label"],
                entry_info["icon"],
                tag,
            )
            yield _make_row(
                entry_info["label"],
                icon=entry_info["icon"],
                tag=tag,
                description=entry_info["description"],
                count=len(entry_info["variants"]),
            )

    def on_multi_choice_selected(self, picked_choice, **kwargs):
        pass

    def on_choice_selected(self, choice_tag, **kwargs):
        if not isinstance(choice_tag, str) or not choice_tag.startswith(ACCESSORY_TAG_PREFIX):
            return

        try:
            index = int(choice_tag[len(ACCESSORY_TAG_PREFIX):])
        except Exception:
            return

        entries = _filter_entries_by_category(
            get_all_accessory_entries(),
            getattr(self, "category_filter", ""),
        )

        if 0 <= index < len(entries):
            if self.variant_continuation is None:
                debug_log("All accessory picker has no variant_continuation tuned.")
                return

            self.push_tunable_continuation(
                self.variant_continuation,
                accessory_entry_index=index,
                accessory_source_mode="all",
                category_filter=getattr(self, "category_filter", ""),
                insert_strategy=QueueInsertStrategy.LAST,
                actor=self.target,
            )


class FgehPosePackAccessoryVariantPickerInteraction(PickerSuperInteraction):
    INSTANCE_TUNABLES = {
        "accessory_entry_index": Tunable(
            description="Selected first-page accessory index.",
            tunable_type=int,
            default=0,
        ),
        "accessory_source_mode": Tunable(
            description="Accessory source mode: linked or all.",
            tunable_type=str,
            default="linked",
        ),
        "category_filter": Tunable(
            description="Optional requirement category filter carried from the first page.",
            tunable_type=str,
            default="",
        ),
    }

    def __init__(self, *args, accessory_entry_index=0, accessory_source_mode="linked", category_filter="", **kwargs):
        super().__init__(*args, **kwargs)
        self.accessory_entry_index = accessory_entry_index
        self.accessory_source_mode = accessory_source_mode
        self.category_filter = category_filter
        debug_log(
            "Variant picker initialized entry_index={} source_mode={} category_filter={} target={} sim={}",
            accessory_entry_index,
            accessory_source_mode,
            category_filter,
            getattr(self, "target", None),
            getattr(self, "sim", None),
        )

    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    def _run_interaction_gen(self, timeline):
        debug_log(
            "Opening variant picker entry_index={} source_mode={} target={}",
            self.accessory_entry_index,
            self.accessory_source_mode,
            self.target,
        )
        self._show_picker_dialog(self.sim, target_sim=self.target)
        return True
        if False:
            yield None

    def _get_entry_info(self):
        entries = get_entries_for_source_mode(
            self,
            getattr(self, "accessory_source_mode", "linked"),
        )

        try:
            index = int(self.accessory_entry_index)
        except Exception:
            index = 0

        if 0 <= index < len(entries):
            return entries[index]

        return None

    @flexmethod
    def picker_rows_gen(cls, inst, target, context, **kwargs):
        if inst is None:
            return
        entry_info = inst._get_entry_info()
        if entry_info is None:
            debug_log(
                "Variant picker rows found no entry entry_index={} source_mode={}",
                getattr(inst, "accessory_entry_index", None),
                getattr(inst, "accessory_source_mode", None),
            )
            yield _make_row("No linked items found for this pose pack", tag=BACK_TAG)
            return
        variants = entry_info["variants"]
        debug_log(
            "Variant picker rows accessory={} variant_count={} source_mode={}",
            entry_info.get("label"),
            len(variants),
            getattr(inst, "accessory_source_mode", None),
        )
        for index, variant in enumerate(variants):
            cas_part_id = _entry_cas_part_id(variant)
            label = _entry_label(variant, "Variant {}".format(index + 1))
            tag = VARIANT_TAG_PREFIX + str(index)
            icon = _entry_icon(variant, entry_info["icon"])
            debug_log(
                "Variant picker row image variant_index={} label={} thumbnail={} icon={} tag={}",
                index,
                label,
                getattr(variant, "thumbnail", None),
                icon,
                tag,
            )
            yield _make_row(
                label,
                icon=icon,
                tag=tag,
                description=_entry_description(variant) or str(cas_part_id),
            )

    def on_multi_choice_selected(self, picked_choice, **kwargs):
        pass

    def on_choice_selected(self, choice_tag, **kwargs):
        debug_log(
            "Variant picker choice received tag={} type={} kwargs={}",
            choice_tag,
            type(choice_tag),
            kwargs,
        )
        if not isinstance(choice_tag, str) or not choice_tag.startswith(VARIANT_TAG_PREFIX):
            debug_log("Variant picker ignored unexpected tag={}", choice_tag)
            return
        try:
            index = int(choice_tag[len(VARIANT_TAG_PREFIX):])
        except Exception:
            _debug_exception("Failed to parse variant index")
            return
        entry_info = self._get_entry_info()
        if entry_info is None:
            debug_log("Variant picker choice has no entry info.")
            return
        variants = entry_info["variants"]
        if 0 <= index < len(variants):
            cas_part_id = _entry_cas_part_id(variants[index])
            debug_log(
                "Applying picker variant accessory={} variant_index={} cas_part_id={} thumbnail={}",
                entry_info["label"],
                index,
                cas_part_id,
                getattr(variants[index], "thumbnail", None),
            )
            try:
                result = apply_fixed_cas_accessory_to_sim(
                    get_sim_info_from_target(self.target),
                    cas_part_id=cas_part_id,
                )
                debug_log(
                    "Accessory apply returned {} accessory={} variant_index={} cas_part_id={}",
                    result,
                    entry_info["label"],
                    index,
                    cas_part_id,
                )
            except Exception:
                _debug_exception("Accessory apply raised an exception")
        else:
            debug_log("Variant picker choice index out of range: index={} count={}", index, len(variants))


def is_auto_apply_matching_accessories_enabled():
    return bool(getattr(settings, "AUTO_APPLY_MATCHING_ACCESSORIES", False))


def set_auto_apply_matching_accessories_enabled(enabled):
    settings.AUTO_APPLY_MATCHING_ACCESSORIES = bool(enabled)
    debug_log("Auto matching accessory switch set to {}", settings.AUTO_APPLY_MATCHING_ACCESSORIES)
    return settings.AUTO_APPLY_MATCHING_ACCESSORIES


def toggle_auto_apply_matching_accessories():
    return set_auto_apply_matching_accessories_enabled(
        not is_auto_apply_matching_accessories_enabled()
    )


def _first_applyable_variant(entries):
    for entry_info in entries:
        for variant in entry_info.get("variants", ()):
            cas_part_id = _entry_cas_part_id(variant)
            if cas_part_id:
                return entry_info, variant, cas_part_id
    return None, None, 0


def iter_matching_cas_variant_options(pose_name=None, pose_pack=None, category_filter=""):
    pack = pose_pack or _find_pose_pack_for_pose_name(pose_name)
    if pack is None:
        return

    entries = _get_matching_cas_entries_for_pack_pose(pack, pose_name, category_filter)
    seen = set()
    for entry_info in entries:
        entry_label = entry_info.get("label") or "CAS"
        entry_icon = entry_info.get("icon")
        source_origin = entry_info.get("source_origin") or getattr(entry_info.get("entry"), "source_origin", "external")
        for variant in entry_info.get("variants", ()):
            cas_part_id = _entry_cas_part_id(variant)
            if not cas_part_id or cas_part_id in seen:
                continue
            seen.add(cas_part_id)
            variant_label = _entry_label(variant, "")
            variant_icon = _entry_icon(variant, entry_icon)
            label = entry_label
            if variant_label:
                label = "{} - {}".format(entry_label, variant_label)
            yield {
                "cas_part_id": cas_part_id,
                "label": label,
                "entry_label": entry_label,
                "variant_label": variant_label,
                "entry_icon": entry_icon,
                "icon": variant_icon,
                "source_origin": getattr(variant, "source_origin", source_origin),
                "body_type": getattr(variant, "body_type", 0),
                "body_group": getattr(variant, "body_group", None),
                "body_group_name": getattr(variant, "body_group_name", None),
            }


def _get_matching_cas_entries_for_pack_pose(pack, pose_name=None, category_filter=""):
    if pack is None:
        return []
    pack_id = _get_pack_key(pack)
    snippets = get_accessory_snippets_for_pose_pack(pack) if _external_cas_links_enabled() else []
    entries = list(_with_source_origin(_build_accessory_entries_cached(snippets), "external"))
    if _in_game_cas_binding_enabled():
        entries.extend(get_saved_cas_entries_for_pose(pack_id, pose_name))
    entries = _filter_entries_by_category(entries, category_filter)
    entries = _filter_entries_by_pose_name(entries, pose_name)
    return _filter_release_cas_entries(entries)


def _try_apply_saved_full_outfit(sim_info, pack, pose_name, selected_ids):
    if sim_info is None or not selected_ids:
        return False
    pack_id = _get_pack_key(pack)
    if not pack_id or not pose_name:
        return False
    try:
        from fgeh_linked_cas_bindings import iter_saved_cas_bindings, iter_saved_outfit_bindings
    except Exception:
        return False

    parts_by_outfit = {}
    for binding in iter_saved_cas_bindings():
        if str(binding.get("pack_id") or "").strip() != str(pack_id):
            continue
        if str(binding.get("pose_name") or "").strip() != str(pose_name):
            continue
        outfit_binding_id = str(binding.get("outfit_binding_id") or "").strip()
        if not outfit_binding_id:
            continue
        try:
            cas_part_id = int(binding.get("cas_part_id") or 0)
        except Exception:
            cas_part_id = 0
        if cas_part_id:
            parts_by_outfit.setdefault(outfit_binding_id, set()).add(cas_part_id)

    best_outfit = None
    best_overlap = 0
    for outfit in iter_saved_outfit_bindings():
        if str(outfit.get("pack_id") or "").strip() != str(pack_id):
            continue
        if str(outfit.get("pose_name") or "").strip() != str(pose_name):
            continue
        if str(outfit.get("body_group") or "all") != "all":
            continue
        outfit_binding_id = str(outfit.get("outfit_binding_id") or "").strip()
        outfit_part_ids = parts_by_outfit.get(outfit_binding_id, set())
        if not outfit_binding_id or not outfit_part_ids:
            continue
        overlap = len(outfit_part_ids.intersection(selected_ids))
        # R58: partial accessory selection cannot request a whole outfit.
        if overlap != len(outfit_part_ids):
            continue
        best_outfit = outfit
        best_overlap = overlap
        break

    if best_outfit is None:
        debug_log(
            "Saved full outfit apply skipped pack={} pose_name={} selected_count={} reason=no_matching_full_outfit",
            pack_id,
            pose_name,
            len(selected_ids),
        )
        return False

    result = apply_saved_outfit_to_sim(
        sim_info,
        best_outfit.get("category"),
        best_outfit.get("category_index"),
        label=best_outfit.get("outfit_label"),
    )
    debug_log(
        "Saved full outfit apply result={} pack={} pose_name={} outfit={} category={} index={} overlap={}",
        result,
        pack_id,
        pose_name,
        best_outfit.get("outfit_label"),
        best_outfit.get("category"),
        best_outfit.get("category_index"),
        best_overlap,
    )
    return result


def try_auto_apply_matching_accessory(target_sim, pose_name=None, pose_pack=None, category_filter="", selected_cas_part_ids=None):
    if selected_cas_part_ids == []:
        debug_log("Auto matching accessory skipped: per-pose selection is empty.")
        return False

    if selected_cas_part_ids is None and not is_auto_apply_matching_accessories_enabled():
        debug_log("Auto matching accessory skipped: switch is disabled.")
        return False

    sim_info = get_sim_info_from_target(target_sim)
    if sim_info is None:
        debug_log("Auto matching accessory skipped: no sim_info target={}", target_sim)
        return False

    pack = pose_pack or _find_pose_pack_for_pose_name(pose_name)
    if pack is None:
        debug_log("Auto matching accessory skipped: no pose pack pose_name={}", pose_name)
        return False

    entries = _get_matching_cas_entries_for_pack_pose(pack, pose_name, category_filter)
    if selected_cas_part_ids is not None:
        selected_ids = set()
        for value in selected_cas_part_ids or []:
            try:
                value = int(value or 0)
            except Exception:
                value = 0
            if value:
                selected_ids.add(value)

        applied_any = False
        applied_outfit = _try_apply_saved_full_outfit(sim_info, pack, pose_name, selected_ids)
        matched_count = 0
        for entry_info in entries:
            for variant in entry_info.get("variants", ()):
                cas_part_id = _entry_cas_part_id(variant)
                if not cas_part_id or cas_part_id not in selected_ids:
                    continue
                matched_count += 1
                try:
                    if apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id=cas_part_id):
                        applied_any = True
                except Exception:
                    _debug_exception("Auto matching selected accessory apply failed")
        debug_log(
            "Auto matching selected CAS finished pack={} pose_name={} selected_count={} entry_count={} matched_count={} applied={}",
            getattr(pack, "__name__", None),
            pose_name,
            len(selected_ids),
            len(entries),
            matched_count,
            bool(applied_outfit or applied_any),
        )
        return bool(applied_outfit or applied_any)

    entry_info, variant, cas_part_id = _first_applyable_variant(entries)
    if not cas_part_id:
        debug_log(
            "Auto matching accessory found no CASP pack={} pose_name={} category_filter={}",
            getattr(pack, "__name__", None),
            pose_name,
            category_filter,
        )
        return False

    debug_log(
        "Auto applying matching accessory pack={} pose_name={} accessory={} variant={} cas_part_id={}",
        getattr(pack, "__name__", None),
        pose_name,
        entry_info.get("label"),
        _entry_label(variant, ""),
        cas_part_id,
    )
    try:
        return apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id=cas_part_id)
    except Exception:
        _debug_exception("Auto matching accessory apply failed")
        return False


class FgehToggleAutoAccessoryInteraction(ImmediateSuperInteraction):
    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        return super()._test(target, context, **interaction_parameters)

    @classmethod
    def _get_name(cls, *args, **kwargs):
        if is_auto_apply_matching_accessories_enabled():
            return raw_text("Disable automatic matching items")
        return raw_text("Enable automatic matching items")

    def _run_interaction_gen(self, timeline):
        enabled = toggle_auto_apply_matching_accessories()
        debug_log("Toggle auto matching accessory interaction enabled={}", enabled)
        return True
        if False:
            yield None


def show_pose_pack_accessory_picker(interaction):
    try:
        interaction._show_picker_dialog(interaction.sim, target_sim=interaction.target)
        return True
    except Exception as exc:
        debug_log("Failed to show posepack accessory picker: {}", exc)
        return False
