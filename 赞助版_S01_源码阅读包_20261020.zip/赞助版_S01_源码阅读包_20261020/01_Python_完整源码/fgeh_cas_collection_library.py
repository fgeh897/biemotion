# coding: utf-8
"""H33 CAS favorites accessory library for Pose Manager.

CAS remains the authority for favorites/groups.  This module reads the JSON
produced by the verified CAS -> PLAY -> Python bridge and exposes products,
variants, group filtering, real captured thumbnail ResourceKeys, and direct
life-mode try-on using the existing accessory outfit runtime.
"""
import json
import os

JSON_FILENAME = "fgeh_cas_collection.json"
TMP_FILENAME = "fgeh_cas_collection_tmp"
TMP_LEGACY_FILENAME = "fgeh_cas_collection.json.tmp"
BACKUP_FILENAME = "fgeh_cas_collection_backup"
BACKUP_LEGACY_FILENAME = "fgeh_cas_collection.bak"
CAS_THUMBNAIL_TYPE = 0x00B2D882

# H70W7D2R5: file-signature cache.  The CAS collection is read-only on the
# PLAY side; reload only when one of the candidate files actually changes.
_COLLECTION_CACHE_SIGNATURE = None
_COLLECTION_CACHE_DATA = None
_COLLECTION_CACHE_PATH = None


def _candidate_paths():
    result = []
    for folder in _candidate_dirs():
        for name in (JSON_FILENAME, TMP_FILENAME, TMP_LEGACY_FILENAME, BACKUP_FILENAME, BACKUP_LEGACY_FILENAME):
            path = os.path.join(folder, name)
            if path not in result:
                result.append(path)
    return result


def _collection_file_signature(paths):
    signature = []
    for path in paths:
        try:
            stat = os.stat(path)
            mtime_ns = getattr(stat, "st_mtime_ns", None)
            if mtime_ns is None:
                mtime_ns = int(float(stat.st_mtime) * 1000000000.0)
            signature.append((path, int(stat.st_size), int(mtime_ns)))
        except Exception:
            signature.append((path, -1, -1))
    return tuple(signature)


def _module_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return ""


def _mod_directory():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        return _module_dir()


def _candidate_dirs():
    result = []
    for folder in (_mod_directory(), _module_dir()):
        if folder and folder not in result:
            result.append(folder)
    return result


def _load(path):
    try:
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        if isinstance(data, dict) and data.get("schema") == "fgeh.cas.collection.v1":
            return data
    except Exception:
        pass
    return None


def load_collection():
    global _COLLECTION_CACHE_SIGNATURE, _COLLECTION_CACHE_DATA, _COLLECTION_CACHE_PATH

    paths = _candidate_paths()
    signature = _collection_file_signature(paths)
    if (
        _COLLECTION_CACHE_DATA is not None
        and _COLLECTION_CACHE_SIGNATURE == signature
    ):
        return _COLLECTION_CACHE_DATA

    for path in paths:
        data = _load(path)
        if data is not None:
            _COLLECTION_CACHE_SIGNATURE = signature
            _COLLECTION_CACHE_DATA = data
            _COLLECTION_CACHE_PATH = path
            return data

    data = {"schema": "fgeh.cas.collection.v1", "schema_version": 1, "items": [], "groups": {}, "order": []}
    _COLLECTION_CACHE_SIGNATURE = signature
    _COLLECTION_CACHE_DATA = data
    _COLLECTION_CACHE_PATH = None
    return data


def iter_collection_items(group_name=None):
    data = load_collection()
    allowed = None
    if group_name:
        allowed = set(str(x) for x in (data.get("groups", {}).get(str(group_name), []) or []))
    by_base = {}
    for item in data.get("items", []) or []:
        if isinstance(item, dict):
            by_base[str(item.get("base_id") or "")] = item
    seen = set()
    for base_id in data.get("order", []) or []:
        base_id = str(base_id or "")
        if allowed is not None and base_id not in allowed:
            continue
        item = by_base.get(base_id)
        if item is not None:
            seen.add(base_id)
            yield item
    for base_id, item in by_base.items():
        if base_id in seen:
            continue
        if allowed is not None and base_id not in allowed:
            continue
        yield item


def get_collection_item(base_id):
    base_id = str(base_id or "")
    for item in iter_collection_items():
        if str(item.get("base_id") or "") == base_id:
            return item
    return None


def iter_collection_variant_options(group_name=None):
    for item in iter_collection_items(group_name):
        base_id = str(item.get("base_id") or "")
        body_type = int(item.get("body_type") or 0)
        body_group = "body_type_{}".format(body_type)
        entry_label = str(item.get("display_name") or "CAS {}".format(base_id))
        for variant in item.get("variants", []) or []:
            try:
                cas_part_id = int(variant.get("cas_part_id") or 0)
            except Exception:
                cas_part_id = 0
            if not cas_part_id:
                continue
            style_index = int(variant.get("style_index") or 0)
            icon = thumbnail_resource_key(variant.get("icon_key_raw"))
            yield {
                "source_origin": "local",
                "source_type": item.get("source_type") or "unknown",
                "base_id": base_id,
                "cas_part_id": cas_part_id,
                "body_type": body_type,
                "body_group": body_group,
                "body_group_name": body_group,
                "entry_label": entry_label,
                "label": entry_label,
                "variant_label": "Style {}".format(style_index + 1),
                "style_index": style_index,
                "is_selected": bool(variant.get("is_selected")),
                "colors": list(variant.get("colors", []) or []),
                "icon": icon,
                "entry_icon": icon,
                "icon_key_raw": str(variant.get("icon_key_raw") or ""),
                "modded": variant.get("modded"),
                "collection_groups": list(item.get("groups", []) or []),
            }


def thumbnail_resource_key(raw_value):
    try:
        instance_id = int(str(raw_value or "0"), 10)
    except Exception:
        instance_id = 0
    if instance_id <= 0:
        return None
    try:
        import sims4.resources as resources
        cls = getattr(resources, "ResourceKey", None)
        if cls is not None:
            return cls(CAS_THUMBNAIL_TYPE, 0, instance_id)
        return resources.get_resource_key(instance_id, CAS_THUMBNAIL_TYPE)
    except Exception:
        return None


def _sim_info_from_target(target):
    try:
        from fgeh_cas_accessory_outfit_utils import get_sim_info_from_target
        return get_sim_info_from_target(target)
    except Exception:
        return getattr(target, "sim_info", target)


def apply_variant_to_target(target, cas_part_id):
    """Apply a manual library choice and transfer only its slot ownership."""
    try:
        cas_part_id = int(cas_part_id or 0)
        if not cas_part_id:
            return False
        sim_info = _sim_info_from_target(target)
        if sim_info is None:
            return False
        from fgeh_cas_accessory_outfit_utils import (
            apply_fixed_cas_accessory_to_sim, get_caspart_bodytype,
            claim_manual_cas_part,
        )
        if get_caspart_bodytype is None:
            return False
        body_type = get_caspart_bodytype(cas_part_id)
        if body_type is None:
            return False
        body_type = int(body_type)
        applied = bool(apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id))
        if applied:
            claim_manual_cas_part(sim_info, body_type)
        return applied
    except Exception:
        return False



def restore_target_outfit(target):
    sim_info = _sim_info_from_target(target)
    if sim_info is None:
        return False
    try:
        from fgeh_cas_accessory_outfit_utils import restore_original_outfit
        return bool(restore_original_outfit(sim_info))
    except Exception:
        return False
