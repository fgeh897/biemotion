from fgeh_pose_manager_localization import display_text as _fgeh_hash_ui_text
# -*- coding: utf-8 -*-
"""
FGEH Pose Manager - Fixed Tools Live Bridge V5.1

V5.1 重点：
1. 模块顶层不再 import poseplayer / couplepose1 / injector2。
   这些模块如果在游戏脚本加载顺序里还没准备好，会让整个 bridge 在注册命令前直接 import 失败。
2. 所有依赖都改成按钮真正点击时再 lazy import。
3. 分组 Picker 用 bridge 打开时，ESC / X 会被拦截：
   不再执行旧 Picker 自己的 cancel continuation，所以不会跳回原生 root picker。
4. 固定按钮不调用 ui.dialog.respond，因此当前 EpicCard dialog 一直活着。
"""

import sims4.commands

_BRIDGE_MANAGE_INTERACTION = None
_CANCEL_GUARD_INSTALLED = False


def _debug(message):
    try:
        import fgeh_pose_manager_ui_panel as _panel
        logger = getattr(_panel, "fgeh_pose_manager_debug_log", None)
        if callable(logger):
            logger("[FIXED_BRIDGE_V51] {}".format(message))
            return
    except Exception:
        pass

    # 第二条日志路径：如果 couplepose1 已经加载，就借它自己的 logger。
    try:
        import couplepose1 as _pose_main
        logger = getattr(_pose_main, "positioning_log", None)
        if callable(logger):
            logger("[FIXED_BRIDGE_V51] {}", message)
    except Exception:
        pass


def _get_services():
    import services
    return services


def _get_pose_main():
    try:
        import couplepose1
        return couplepose1
    except Exception:
        return None


def _get_state():
    try:
        from fgeh_state import state
        return state
    except Exception:
        return None


def _iter_sim_interactions(sim):
    if sim is None:
        return

    seen = set()

    getter = getattr(sim, "get_all_running_and_queued_interactions", None)
    if callable(getter):
        try:
            for interaction in getter():
                if interaction is None:
                    continue
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                yield interaction
        except Exception:
            pass

    try:
        queue = getattr(sim, "queue", None)
        if queue is not None:
            for interaction in queue:
                if interaction is None:
                    continue
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                yield interaction
    except Exception:
        pass

    try:
        si_state = getattr(sim, "si_state", None)
        if si_state is not None:
            for interaction in si_state:
                if interaction is None:
                    continue
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                yield interaction
    except Exception:
        pass


def _candidate_score(interaction):
    if interaction is None:
        return -1

    selected_pack = getattr(interaction, "selected_pose_pack", None)
    if selected_pack is None:
        return -1

    class_name = interaction.__class__.__name__
    score = 0

    if "PoseByPack" in class_name:
        score += 100

    # Detail 页面通常是真 pack class，而不是 root folder token。
    if not isinstance(selected_pack, str):
        score += 100

    if getattr(interaction, "fgeh_custom_target_id", None):
        score += 10

    return score


def _resolve_pose_manager_interaction():
    services = _get_services()

    candidates = []
    seen = set()

    active_sim = None
    try:
        active_sim = services.get_active_sim()
    except Exception:
        active_sim = None

    if active_sim is not None:
        for interaction in _iter_sim_interactions(active_sim):
            key = id(interaction)
            if key in seen:
                continue
            seen.add(key)
            score = _candidate_score(interaction)
            if score >= 0:
                candidates.append((score, interaction))

    try:
        sim_info_manager = services.sim_info_manager()
        for sim_info in sim_info_manager.instanced_sims_gen():
            try:
                sim = sim_info.get_sim_instance()
            except Exception:
                sim = None

            if sim is None or sim is active_sim:
                continue

            for interaction in _iter_sim_interactions(sim):
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                score = _candidate_score(interaction)
                if score >= 0:
                    candidates.append((score, interaction))
    except Exception:
        pass

    if not candidates:
        _debug("resolve interaction FAILED: no live PoseByPack candidate")
        return None

    candidates.sort(key=lambda item: item[0], reverse=True)
    interaction = candidates[0][1]

    _debug(
        "resolved interaction id={} cls={} selected_pack={}".format(
            getattr(interaction, "id", None),
            interaction.__class__.__name__,
            getattr(
                getattr(interaction, "selected_pose_pack", None),
                "__name__",
                getattr(interaction, "selected_pose_pack", None),
            ),
        )
    )
    return interaction


def _actual_target(interaction):
    if interaction is None:
        return None

    target = getattr(interaction, "target", None)
    custom_target_id = getattr(interaction, "fgeh_custom_target_id", None)

    if custom_target_id:
        try:
            target = _get_services().object_manager().get(custom_target_id) or target
        except Exception:
            pass

    return target


def _cancel_positioning_if_available(interaction):
    pose_main = _get_pose_main()
    if pose_main is None:
        return

    try:
        fn = getattr(pose_main, "cancel_positioning_session_for_interaction", None)
        if callable(fn):
            fn(interaction)
    except Exception:
        pass


def _show_bridge_sim_picker(interaction):
    """
    打开临时 Sim Picker。
    关键：取消/选完后都不 reopen 旧 picker；
    底下 EpicCard 本来就一直活着。
    """
    from ui.ui_dialog_picker import UiSimPicker, SimPickerRow
    from sims4.localization import LocalizationHelperTuning

    services = _get_services()
    pose_main = _get_pose_main()

    if interaction is None:
        return False

    try:
        get_stbl_text = getattr(pose_main, "get_stbl_text", None) if pose_main else None

        if callable(get_stbl_text):
            title_factory = lambda **_: get_stbl_text(0xBE21DE2E)
            text_factory = lambda **_: get_stbl_text(0xA3071EE6)
        else:
            title_factory = lambda **_: _fgeh_hash_ui_text("选择目标小人")
            text_factory = lambda **_: _fgeh_hash_ui_text("选择播放动作的小人")

        dialog = UiSimPicker.TunableFactory().default(
            interaction.sim,
            title=title_factory,
            text=text_factory,
            min_selectable=1,
            max_selectable=1,
            column_count=3,
            should_show_names=True,
        )

        current_target_id = getattr(interaction, "fgeh_custom_target_id", None)

        for sim_info in services.sim_info_manager().instanced_sims_gen():
            if sim_info is None:
                continue

            sim_id = getattr(sim_info, "id", getattr(sim_info, "sim_id", 0))
            first_name = getattr(sim_info, "first_name", None)

            if sim_id and first_name:
                dialog.add_row(
                    SimPickerRow(
                        sim_id=sim_id,
                        select_default=(sim_id == current_target_id),
                        tag=sim_id,
                    )
                )

        def _on_response(response_dialog):
            try:
                if not response_dialog.accepted:
                    _debug("target picker cancelled; EpicCard remains alive")
                    return

                tags = response_dialog.get_result_tags()
                if not tags:
                    _debug("target picker accepted with no tag")
                    return

                selected_sim_id = tags[0]
                interaction.fgeh_custom_target_id = selected_sim_id

                _debug(
                    "target changed interaction={} target_sim_id={}".format(
                        getattr(interaction, "id", None),
                        selected_sim_id,
                    )
                )
            except Exception as exc:
                _debug(
                    "target picker callback FAILED {}: {}".format(
                        type(exc).__name__,
                        exc,
                    )
                )

        dialog.add_listener(_on_response)
        dialog.show_dialog()

        _debug(
            "target picker OPENED interaction={}".format(
                getattr(interaction, "id", None)
            )
        )
        return True

    except Exception as exc:
        _debug(
            "target picker OPEN FAILED {}: {}".format(
                type(exc).__name__,
                exc,
            )
        )
        return False


def _install_manage_cancel_guard():
    """
    安装一次。

    bridge 管理 Picker 遇到 ESC/X 时：
    直接 return，不再调用 original。
    这是 V5.1 和 V5 的关键差别。
    """
    global _CANCEL_GUARD_INSTALLED

    if _CANCEL_GUARD_INSTALLED:
        return True

    try:
        import injector2
        import poseplayer
    except Exception as exc:
        _debug(
            "cancel guard imports unavailable {}: {}".format(
                type(exc).__name__,
                exc,
            )
        )
        return False

    cls = getattr(poseplayer, "PoseByPackNameInteraction", None)
    if cls is None or not hasattr(cls, "_on_picker_selected"):
        _debug("cancel guard target method unavailable")
        return False

    @injector2.inject(cls, "_on_picker_selected", safe=True)
    def _fgeh_fixed_bridge_picker_selected(original, self, dialog, *args, **kwargs):
        global _BRIDGE_MANAGE_INTERACTION

        bridge_active = self is _BRIDGE_MANAGE_INTERACTION
        if not bridge_active:
            return original(self, dialog, *args, **kwargs)

        result_tags = None
        try:
            result_tags = dialog.get_result_tags()
        except Exception:
            result_tags = None

        # 重点：bridge 子 Picker 的 ESC/X 绝对不能调用 original。
        if not result_tags:
            state = _get_state()
            try:
                if state is not None:
                    state.is_in_normal_pack_manage_mode = False
            except Exception:
                pass

            _BRIDGE_MANAGE_INTERACTION = None
            _debug(
                "group manage child picker CANCELLED; old continuation BLOCKED; EpicCard remains alive"
            )
            return None

        # 有真实选择时继续走你原来的全部分组逻辑。
        result = original(self, dialog, *args, **kwargs)

        state = _get_state()
        if state is not None and not bool(
            getattr(state, "is_in_normal_pack_manage_mode", False)
        ):
            _BRIDGE_MANAGE_INTERACTION = None
            _debug("group manage session exited normally")

        return result

    _CANCEL_GUARD_INSTALLED = True
    _debug("group manage cancel guard INSTALLED")
    return True


@sims4.commands.Command(
    "fgeh.pose_manager.fixed_switch_target",
    command_type=sims4.commands.CommandType.Live,
)
def _cmd_fixed_switch_target(_connection=None):
    _debug("COMMAND fixed_switch_target received")

    interaction = _resolve_pose_manager_interaction()
    if interaction is None:
        return False

    _cancel_positioning_if_available(interaction)
    return _show_bridge_sim_picker(interaction)


@sims4.commands.Command(
    "fgeh.pose_manager.fixed_group_manage",
    command_type=sims4.commands.CommandType.Live,
)
def _cmd_fixed_group_manage(_connection=None):
    global _BRIDGE_MANAGE_INTERACTION

    _debug("COMMAND fixed_group_manage received")

    interaction = _resolve_pose_manager_interaction()
    if interaction is None:
        return False

    state = _get_state()
    if state is None:
        _debug("group manage FAILED: fgeh_state unavailable")
        return False

    _install_manage_cancel_guard()

    actual_target = _actual_target(interaction)

    try:
        state.is_in_normal_pack_manage_mode = True
        _BRIDGE_MANAGE_INTERACTION = interaction

        interaction._show_picker_dialog(
            interaction.sim,
            target_sim=actual_target,
        )

        _debug(
            "group manage child picker OPENED interaction={}".format(
                getattr(interaction, "id", None)
            )
        )
        return True

    except Exception as exc:
        state.is_in_normal_pack_manage_mode = False
        _BRIDGE_MANAGE_INTERACTION = None

        _debug(
            "group manage OPEN FAILED {}: {}".format(
                type(exc).__name__,
                exc,
            )
        )
        return False


# 这行必须能在游戏启动日志里出现。
_debug("MODULE LOADED; Live commands registered")

# 尝试预装 guard；失败也没关系，点“分组管理”时会再试一次。
try:
    _install_manage_cancel_guard()
except Exception as exc:
    _debug(
        "initial cancel guard install skipped {}: {}".format(
            type(exc).__name__,
            exc,
        )
    )
