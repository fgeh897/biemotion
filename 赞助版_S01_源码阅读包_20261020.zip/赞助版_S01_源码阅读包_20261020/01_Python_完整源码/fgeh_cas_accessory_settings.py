import sims4.resources


# Release profiles are the only switches that should be changed when building
# public, sponsor, or development packages. Feature flags below are derived
# from this value so unfinished code can stay in the source tree.
RELEASE_PROFILE_PUBLIC = "public"
RELEASE_PROFILE_SPONSOR = "sponsor"
RELEASE_PROFILE_DEVELOPMENT = "development"

# Keep the working tree on DEVELOPMENT. Change only this line before producing
# a release build, then switch it back after the build is finished.
ACTIVE_RELEASE_PROFILE = RELEASE_PROFILE_DEVELOPMENT

_RELEASE_FEATURES = {
    RELEASE_PROFILE_PUBLIC: {
        "pack_custom_names": False,
        "pack_sorting": False,
        "linked_actions_menu": False,
        "linked_requirement_runtime": False,
        "external_cas_links": False,
        "in_game_cas_binding": False,
        "external_object_links": False,
        "in_game_object_binding": False,
        "linked_object_layouts": False,
        "custom_pose_manager_ui": False,
    },
    RELEASE_PROFILE_SPONSOR: {
        "pack_custom_names": False,
        "pack_sorting": False,
        "linked_actions_menu": True,
        "linked_requirement_runtime": True,
        "external_cas_links": True,
        "in_game_cas_binding": False,
        "external_object_links": True,
        "in_game_object_binding": True,
        "linked_object_layouts": False,
        "custom_pose_manager_ui": False,
    },
    RELEASE_PROFILE_DEVELOPMENT: {
        "pack_custom_names": True,
        "pack_sorting": True,
        "linked_actions_menu": True,
        "linked_requirement_runtime": True,
        "external_cas_links": True,
        "in_game_cas_binding": True,
        "external_object_links": True,
        "in_game_object_binding": True,
        "linked_object_layouts": True,
        "custom_pose_manager_ui": True,
    },
}

ACTIVE_RELEASE_PROFILE_VALID = ACTIVE_RELEASE_PROFILE in _RELEASE_FEATURES
_ACTIVE_RELEASE_FEATURES = _RELEASE_FEATURES.get(
    ACTIVE_RELEASE_PROFILE,
    _RELEASE_FEATURES[RELEASE_PROFILE_PUBLIC],
)


def is_release_feature_enabled(feature_name):
    return bool(_ACTIVE_RELEASE_FEATURES.get(str(feature_name or ""), False))


ENABLE_LINKED_ACTIONS_MENU = is_release_feature_enabled("linked_actions_menu")
ENABLE_PACK_CUSTOM_NAMES = is_release_feature_enabled("pack_custom_names")
ENABLE_PACK_SORTING = is_release_feature_enabled("pack_sorting")
ENABLE_LINKED_REQUIREMENT_RUNTIME = is_release_feature_enabled("linked_requirement_runtime")
ENABLE_EXTERNAL_CAS_LINKS = is_release_feature_enabled("external_cas_links")
ENABLE_IN_GAME_CAS_BINDING_WORKFLOWS = is_release_feature_enabled("in_game_cas_binding")
ENABLE_EXTERNAL_OBJECT_LINKS = is_release_feature_enabled("external_object_links")
ENABLE_IN_GAME_OBJECT_BINDING = is_release_feature_enabled("in_game_object_binding")
ENABLE_LINKED_OBJECT_LAYOUTS = is_release_feature_enabled("linked_object_layouts")
ENABLE_CUSTOM_POSE_MANAGER_UI = is_release_feature_enabled("custom_pose_manager_ui")


# Replace this with a real CASP instance id before testing in game.
TEST_CAS_PART_ID = 0xF2254E78DF6105D2

# Value commonly seen in OutfitData.part_shifts.color_shift for normal parts.
DEFAULT_COLOR_SHIFT = 4611686018427387904

# SPECIAL has only a few indexes. Keep the first test on 0.
USE_SPECIAL_OUTFIT_INDEX = 0

# These ids must match the s="" values in the InteractionTuning XML resources.
ALL_ACCESSORY_PICKER_INTERACTION_ID = 11242396370292691705
ACCESSORY_CATEGORY_PICKER_INTERACTION_ID = 11242396370292691706
HAT_CATEGORY_PICKER_INTERACTION_ID = 11242396370292691707
OTHER_REQUIREMENT_PICKER_INTERACTION_ID = 11242396370292691708
TOGGLE_AUTO_ACCESSORY_INTERACTION_ID = 11242396370292691709
ACTION_REQUIREMENTS_PIE_MENU_CATEGORY_ID = 11242396370292691721
ACCESSORY_PIE_MENU_CATEGORY_ID = 11242396370292691720
HAT_PIE_MENU_CATEGORY_ID = 11242396370292691722
OTHER_REQUIREMENT_PIE_MENU_CATEGORY_ID = 11242396370292691723
APPLY_FIXED_CAS_ACCESSORY_INTERACTION_ID = 11242396370292691700
RESTORE_ORIGINAL_OUTFIT_INTERACTION_ID = 11242396370292691701
DUMP_CURRENT_OUTFIT_PARTS_INTERACTION_ID = 11242396370292691702
OPEN_POSEPACK_ACCESSORY_PICKER_INTERACTION_ID = 11242396370292691703
POSEPACK_ACCESSORY_VARIANT_PICKER_INTERACTION_ID = 11242396370292691704
TEST_CAS_ACCESSORY_SNIPPET_ID = 11242396370292691710

# Reuse an existing generic icon for the debug prototype.
DEBUG_ICON = sims4.resources.Key(0x2F7D0004, 0x95840C0388906FDA, 0x00000000)

# Session-level prototype switch. PoseManager can call the picker module's
# auto-apply API before pushing a pose continuation.
AUTO_APPLY_MATCHING_ACCESSORIES = False

# Diagnostic logs are independent from release profiles and must stay disabled
# in distributable builds. Enable only while collecting a targeted game log.
ENABLE_DIAGNOSTIC_LOGS = False
ENABLE_DEBUG_LOG = False
DEBUG_LOG_MAX_BYTES = 1024 * 1024
ENABLE_POSE_MANAGER_DEBUG_LOG = False
ENABLE_LINKED_OBJECT_BINDING_DEBUG_LOG = False

# Narrow temporary log for the "View Pose Accessories" pie-menu entry.
# It only writes module/load/click breadcrumbs, not per-row accessory data.
ENABLE_POSEPACK_MENU_DEBUG_LOG = False
POSEPACK_MENU_DEBUG_LOG_MAX_BYTES = 128 * 1024
