from fgeh_pose_manager_localization import display_text as _fgeh_hash_ui_text
import fgeh_outfit_editor_r30 as _r30_editor
"""Development-only Python bridge for the custom Pose Manager GFX widget."""

import re
import sims4.commands

try:
    import fgeh_pose_manager_ui_navigation as _ui_nav
except Exception:
    _ui_nav = None

try:
    import fgeh_pose_manager_navigation_bridge as _nav_bridge
except Exception:
    _nav_bridge = None


try:
    import fgeh_pose_manager_localization as _ui_loc
except Exception:
    _ui_loc = None

try:
    import fgeh_outfit_manager_phase1 as _outfit_phase1
except Exception:
    _outfit_phase1 = None

from fgeh_pose_manager_ui_adapter import (
    PAGE_SIZE,
    RESPONSE_BACK,
    RESPONSE_MODE_TOGGLE,
    clamp_page,
    decode_pack_favorite_response,
    decode_pack_response,
    decode_page_response,
    decode_nav_response,
    decode_group_response,
    decode_outer_group_response,
    pack_payload,
    NAV_ALL_PACKS,
    NAV_FAVORITE_PACKS,
    NAV_FAVORITE_CREATORS,
    NAV_GROUPED_PACKS,
    NAV_FAVORITE_POSES,
    NAV_LINKED_ACTIONS,
    NAV_ACCESSORY_LIBRARY,
    NAV_SETTINGS,
    NAV_OUTFIT_MANAGER,
    RESPONSE_NAV_BLANK_PACKS,
    RESPONSE_NAV_OUTFIT_MANAGER,
    RESPONSE_ROOT_SORT_TOGGLE,
    RESPONSE_FAV_PACK_VIEW_TOGGLE,
    RESPONSE_FAV_POSE_VIEW_TOGGLE,
    RESPONSE_LINKED_VIEW_TOGGLE,
    RESPONSE_CREATOR_VIEW_TOGGLE,
    RESPONSE_ROOT_SEARCH_APPLY,
    RESPONSE_BLANK_PACK_VIEW_TOGGLE,
    RESPONSE_EDIT_INFO_REFRESH,
)


# The proven wide-window host is still registered through the original
# FgehRomanticJournal widget channel.  Do not switch this to the experimental
# FgehPoseManager/Exchange host: that combination crashes TS4_x64.exe natively.
SHOW_MESSAGE = "ShowFgehRomanticJournal"
UI_BUILD_TAG = "V8.9.69.89-H70W7D3R28_NATIVE_OUTFIT_SWATCH_BRIDGE"
GLOBAL_WIDGET_THEME_ID = "classic_green"
LAST_ERROR = ""
_PENDING_REOPEN_ALARMS = {}

# H70W7D2R5 performance caches are process-local only.  They never change
# persistent schemas and are invalidated by source-object identity/signatures.
_CREATOR_MAP_CACHE_KEY = None
_CREATOR_MAP_CACHE = None
_ROOT_BASE_ROWS_CACHE_KEY = None
_ROOT_BASE_ROWS_CACHE = None
_CASLIB_CATALOG_CACHE_DATA_ID = None
_CASLIB_CATALOG_CACHE = {}
_CASLIB_EFFECTIVE_CATALOG_CACHE = {}

# H70W7D2R6: process-local render caches.  No live dialog/widget owner is
# retained.  Exact payload/icon equality is the invalidation boundary.
_PAYLOAD_FACTORY_CACHE = {}
_PAYLOAD_FACTORY_CACHE_LIMIT = 12000
_LOCALIZED_PAYLOAD_CACHE = []
_LOCALIZED_PAYLOAD_CACHE_LIMIT = 10
_ROOT_ICON_MESSAGES_CACHE = []
_ROOT_ICON_MESSAGES_CACHE_LIMIT = 4


def _perf_now():
    try:
        import time
        return time.perf_counter()
    except Exception:
        return None


def _perf_ms(started):
    if started is None:
        return -1.0
    try:
        import time
        return (time.perf_counter() - started) * 1000.0
    except Exception:
        return -1.0


def _perf_log(manager, message):
    from fgeh_config import ENABLE_PERFORMANCE_LOG
    if not ENABLE_PERFORMANCE_LOG:
        return
    try:
        logger = getattr(manager, "fgeh_pose_manager_perf_log", None)
        if logger is not None:
            logger(message)
    except Exception:
        pass


def _nav_v3_trace(event, detail="", exc=False):
    return  # R26: release diagnostic/file output disabled.


def _nav_v3_node_brief(node):
    if not isinstance(node, dict):
        return "node=None"
    try:
        state = node.get("state", {}) if isinstance(node.get("state"), dict) else {}
        view = node.get("view", {}) if isinstance(node.get("view"), dict) else {}
        return "plain={} search={} query={!r} effective={} gen={}".format(
            view.get("plain_page"),
            view.get("search_page"),
            view.get("query", ""),
            state.get("custom_pose_ui_scroll_row"),
            view.get("generation"),
        )
    except Exception:
        return "node=<brief-failed>"

# H49: narrow always-on trace for the link-register workflow only.
# This bypasses the normal release logger so a runtime failure cannot become
# invisible merely because general Pose Manager debug logging is disabled.
def _h49_trace(message, exc=False):
    return  # R26: release diagnostic/file output disabled.

_h49_trace("IMPORT build={}".format(UI_BUILD_TAG))

# V8.9.6 selected-play server command context.
# Only the latest custom pack-detail dialog can be active at once.
_ACTIVE_PLAY_CONTEXT = None

# H36 accessory-library bridge.  The GFX already has a mature linked CAS
# product-card/swatches renderer.  H36 feeds the CAS collection into that
# renderer through a synthetic linked-detail row, but only while nav 6 is open.
_CAS_LIBRARY_LINKED_PACK_ID = "__FGEH_CAS_LIBRARY__"
_CAS_LIBRARY_LINKED_POSE_NAME = "__FGEH_CAS_LIBRARY__"
_CAS_LIBRARY_TARGET = None
# H33: last root pack callback, used to move pack-detail -> accessory binding library.
_ACTIVE_ROOT_PACK_CALLBACK = None

# V8.6 dedicated response from the fixed left-side “切换目标小人” button.
# It must NOT reuse 100000 because detail rows now contain only real poses.
RESPONSE_SWITCH_TARGET = 730000

# V8.8.2: fixed pack-detail "一键播放".
# Plays every Pose currently represented by the detail view:
# full pack / selected inner group / favorite-pose subset.
RESPONSE_PLAY_ALL_VISIBLE = 731000
RESPONSE_LINKED_RESTORE_OUTFIT = 732000
RESPONSE_LINKED_CLEAR_OBJECTS = 732001
# H55: GFX encodes the currently managed linked-row index as base + index.
RESPONSE_LINKED_ADD_LIBRARY_BASE = 732100

# Development UI routing.  The root must stay on our wide custom widget; the
# Both library and pack-detail views stay inside the wide EpicCard widget.
USE_NATIVE_ROOT_FALLBACK = False
USE_NATIVE_DETAIL_FALLBACK = False

# RELEASE BUILD: disable Pose Manager debug file logging.
# Recovery/UI/favorite behavior remains unchanged.
RELEASE_DEBUG = False

def _release_disable_debug_log(manager):
    # In debug builds, preserve couplepose1's original file logger.
    if RELEASE_DEBUG:
        return
    if manager is None:
        return
    try:
        manager.fgeh_pose_manager_debug_log = lambda *args, **kwargs: None
    except Exception:
        pass

try:
    import couplepose1 as _release_manager
    _release_disable_debug_log(_release_manager)
    try:
        _release_manager.fgeh_pose_manager_debug_log(
            "[DEBUG_BUILD] panel imported build={} release_debug={}".format(
                UI_BUILD_TAG, RELEASE_DEBUG
            )
        )
    except Exception:
        pass
except Exception:
    pass


def _nav_available():
    return _ui_nav is not None


def _nav_sync_root(manager, save=False):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.sync_current_root(manager, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] sync root failed", exc=True)
        except Exception:
            pass
        return None


def _nav_sync_root_view(manager, query=None, page=None, save=False):
    if _ui_nav is None:
        return None
    try:
        sync = getattr(_ui_nav, "sync_root_view", None)
        if sync is None:
            return _nav_sync_root(manager, save=save)
        return sync(manager, query=query, page=page, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V3] sync root view failed", exc=True)
        except Exception:
            pass
        return None


def _nav_sync_pack(manager, pack, page=None, save=False):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.sync_current_pack(manager, pack, page=page, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] sync pack failed", exc=True)
        except Exception:
            pass
        return None


def _nav_push_root(manager, save=False):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.push_root(manager, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] push root failed", exc=True)
        except Exception:
            pass
        return None


def _nav_switch_root(manager, save=False):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.switch_root(manager, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] switch root failed", exc=True)
        except Exception:
            pass
        return None


def _nav_enter_pack(manager, pack, save=False):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.enter_pack(manager, pack, page=None, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] enter pack failed", exc=True)
        except Exception:
            pass
        return None


def _nav_back(manager, save=False):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.back(manager, save=save)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] back failed", exc=True)
        except Exception:
            pass
        return None


def _nav_apply_current(manager):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.apply_current(manager)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] apply current failed", exc=True)
        except Exception:
            pass
        return None


def _nav_can_back(manager):
    if _ui_nav is None:
        return False
    try:
        return bool(_ui_nav.can_back(manager))
    except Exception:
        return False


def _nav_persist(manager):
    if _ui_nav is None:
        return None
    try:
        return _ui_nav.persist(manager)
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log("[NAV_V2] persist failed", exc=True)
        except Exception:
            pass
        return None


def _constant_localized_string(value):
    def _factory(*args, **kwargs):
        del args, kwargs
        return value
    return _factory


def _raw_text(value):
    from sims4.localization import LocalizationHelperTuning
    try:
        if getattr(value, "hash", None):
            return value
    except Exception:
        pass
    return _fgeh_hash_ui_text(str(value or ""))


def _loc(symbol, *args, fallback=""):
    return _ui_loc.localized(symbol, *args)



def _loc_source(symbol, fallback=""):
    if _ui_loc is not None:
        try:
            return _ui_loc.source_text(symbol, fallback)
        except Exception:
            pass
    return str(fallback or "")


def _attach_ui_localization(header):
    header["ui_localization"] = _ui_loc.payload_entries()
    return header



def _payload_localized_value(value):
    """Keep EA LocalizedString protobufs intact; raw values become RAW_TEXT."""
    from sims4.localization import LocalizationHelperTuning

    try:
        if getattr(value, "hash", None):
            return value
    except Exception:
        pass

    return _fgeh_hash_ui_text(str(value or ""))


def _payload_factory_cached(value):
    """Reuse RAW_TEXT wrappers/factories for identical plain payload values."""
    try:
        if getattr(value, "hash", None):
            # LocalizedString protobufs may carry tokens beyond hash; preserve
            # the exact object instead of folding by text/hash.
            return _constant_localized_string(value)
    except Exception:
        pass

    text = str(value or "")
    cached = _PAYLOAD_FACTORY_CACHE.get(text)
    if cached is not None:
        return cached

    from sims4.localization import LocalizationHelperTuning
    factory = _constant_localized_string(
        _fgeh_hash_ui_text(text)
    )
    if len(_PAYLOAD_FACTORY_CACHE) >= _PAYLOAD_FACTORY_CACHE_LIMIT:
        _PAYLOAD_FACTORY_CACHE.clear()
    _PAYLOAD_FACTORY_CACHE[text] = factory
    return factory


def _fgeh_payload_offset_footer(raw_payload):
    # First occurrence matches FindPayloadMagic's existing forward scan.
    offsets = {}
    for index, value in enumerate(raw_payload):
        if isinstance(value, str) and value.startswith('FGEH_') and '|' not in value and '=' not in value:
            offsets.setdefault(value, index)
    return 'FGEH_PAYLOAD_OFFSETS_V1' + ''.join('|{}={}'.format(key, value) for key, value in sorted(offsets.items()))


def _localized_payload_cached(namespace, raw_payload, manager=None):
    """Reuse exact localized payloads; stale content cannot hit by equality."""
    global _LOCALIZED_PAYLOAD_CACHE
    raw_payload = tuple(raw_payload or ())
    if namespace == 'caslib' and manager is not None:
        raw_payload += ('FGEH_CASLIB_SOURCE_V1', _caslib_source(manager))
    raw_payload += (_fgeh_payload_offset_footer(raw_payload),)
    for index in range(len(_LOCALIZED_PAYLOAD_CACHE) - 1, -1, -1):
        ns, cached_raw, cached_localized = _LOCALIZED_PAYLOAD_CACHE[index]
        if ns != namespace:
            continue
        try:
            same = cached_raw == raw_payload
        except Exception:
            same = False
        if not same:
            continue
        if index != len(_LOCALIZED_PAYLOAD_CACHE) - 1:
            _LOCALIZED_PAYLOAD_CACHE.append(
                _LOCALIZED_PAYLOAD_CACHE.pop(index)
            )
        if manager is not None:
            _perf_log(
                manager,
                "PERF PAYLOAD_LOCALIZED_HIT ns={} items={}".format(
                    namespace, len(raw_payload)
                ),
            )
        return cached_localized

    started = _perf_now()
    localized = tuple(_payload_factory_cached(value) for value in raw_payload)
    _LOCALIZED_PAYLOAD_CACHE.append((namespace, raw_payload, localized))
    if len(_LOCALIZED_PAYLOAD_CACHE) > _LOCALIZED_PAYLOAD_CACHE_LIMIT:
        del _LOCALIZED_PAYLOAD_CACHE[0]
    if manager is not None:
        _perf_log(
            manager,
            "PERF PAYLOAD_LOCALIZED_BUILD ns={} ms={:.3f} items={}".format(
                namespace, _perf_ms(started), len(raw_payload)
            ),
        )
    return localized


def _root_icon_messages_cached(icon_keys, create_icon_info_msg, IconInfoData, manager):
    """Reuse immutable Root icon messages for an unchanged icon vector."""
    global _ROOT_ICON_MESSAGES_CACHE
    key = tuple(icon_keys or ())
    for index in range(len(_ROOT_ICON_MESSAGES_CACHE) - 1, -1, -1):
        cached_key, cached_messages = _ROOT_ICON_MESSAGES_CACHE[index]
        try:
            same = cached_key == key
        except Exception:
            same = False
        if not same:
            continue
        if index != len(_ROOT_ICON_MESSAGES_CACHE) - 1:
            _ROOT_ICON_MESSAGES_CACHE.append(
                _ROOT_ICON_MESSAGES_CACHE.pop(index)
            )
        _perf_log(manager, "PERF ROOT_ICON_MESSAGES_HIT count={}".format(len(key)))
        return cached_messages

    started = _perf_now()
    messages = []
    for icon_key in key:
        if icon_key is None:
            messages.append(create_icon_info_msg(IconInfoData()))
            continue
        try:
            messages.append(
                create_icon_info_msg(IconInfoData(icon_resource=icon_key))
            )
        except Exception:
            messages.append(create_icon_info_msg(IconInfoData()))
    result = tuple(messages)
    _ROOT_ICON_MESSAGES_CACHE.append((key, result))
    if len(_ROOT_ICON_MESSAGES_CACHE) > _ROOT_ICON_MESSAGES_CACHE_LIMIT:
        del _ROOT_ICON_MESSAGES_CACHE[0]
    _perf_log(
        manager,
        "PERF ROOT_ICON_MESSAGES_BUILD ms={:.3f} count={}".format(
            _perf_ms(started), len(result)
        ),
    )
    return result


def _valid_icon_resource(manager, icon, context):
    if icon is None:
        return None
    try:
        from distributor.shared_messages import IconInfoData

        IconInfoData(icon_resource=icon)
        return icon
    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "native picker skipped invalid icon context={}".format(context),
            exc=True,
        )
        return None


def _show_native_scroll_picker(
    manager,
    owner,
    title,
    subtitle,
    entries,
    on_selected,
    on_cancel=None,
):
    """Display a native three-column picker with real wheel/drag scrolling."""
    from distributor.shared_messages import IconInfoData
    from event_testing.resolver import SingleSimResolver
    from ui.ui_dialog_picker import ObjectPickerRow, UiObjectPicker

    sim_info = getattr(owner, "sim_info", owner)
    live_owner = getattr(sim_info, "get_sim_instance", lambda: owner)()
    if live_owner is None:
        raise RuntimeError("active Sim instance is unavailable")

    picker_type = UiObjectPicker.UiObjectPickerObjectPickerType.OBJECT_SQUARE
    dialog = UiObjectPicker.TunableFactory().default(
        live_owner,
        resolver=SingleSimResolver(sim_info),
        title=_constant_localized_string(_raw_text(title)),
        text=_constant_localized_string(_raw_text(subtitle)),
        min_selectable=1,
        max_selectable=1,
        picker_type=picker_type,
        num_columns=3,
    )

    for index, entry in enumerate(entries, 1):
        icon = _valid_icon_resource(
            manager,
            entry.get("icon"),
            "{}:{}".format(title, index),
        )
        dialog.add_row(ObjectPickerRow(
            option_id=10000 + index,
            object_id=10000 + index,
            name=_raw_text(entry.get("name", "")),
            row_description=_raw_text(entry.get("description", "")),
            icon=icon,
            tag=entry.get("tag"),
            count=max(0, int(entry.get("count", 0) or 0)),
            is_selected=False,
            is_enable=True,
            use_catalog_product_thumbnails=False,
        ))

    def _on_response(response_dialog):
        try:
            if response_dialog.accepted:
                tags = tuple(response_dialog.get_result_tags() or ())
                if tags:
                    manager.fgeh_pose_manager_debug_log(
                        "native picker selected title={!r} tag={!r}".format(
                            title,
                            tags[0],
                        )
                    )
                    if on_selected is not None:
                        on_selected(tags[0])
                    return
            manager.fgeh_pose_manager_debug_log(
                "native picker cancelled title={!r}".format(title)
            )
            if on_cancel is not None:
                on_cancel()
        except Exception:
            manager.fgeh_pose_manager_debug_log(
                "native picker response failed title={!r}".format(title),
                exc=True,
            )

    manager.fgeh_pose_manager_debug_log(
        "native picker show title={!r} rows={} columns=3".format(
            title,
            len(entries),
        )
    )
    dialog.show_dialog(
        on_response=_on_response,
        icon_override=IconInfoData(obj_instance=sim_info),
    )
    return True


def _show_native_root(manager, owner, on_pack_selected):
    rows, _icon_keys, packs = _build_rows(manager)
    entries = []
    for index, row in enumerate(rows):
        pack = packs[index]
        entries.append({
            "name": row["name"],
            "description": "{} | {} 个动作".format(
                row.get("creator", ""),
                row.get("pose_count", 0),
            ).strip(" |"),
            "icon": getattr(pack, "icon", None),
            "tag": pack,
            "count": row.get("pose_count", 0),
        })
    return _show_native_scroll_picker(
        manager,
        owner,
        _loc("native_library_title", fallback="POSE MANAGER - 动作库"),
        _loc("native_library_desc", fallback="选择动作包查看其中的全部动作"),
        entries,
        on_pack_selected,
    )


def _show_native_pack_detail(
    manager,
    owner,
    pack,
    on_item_selected,
    on_back,
):
    rows, icons, item_tags = _build_pack_detail_rows(manager, pack)
    entries = []
    for index, row in enumerate(rows):
        entries.append({
            "name": row["name"],
            "description": row.get("creator", ""),
            "icon": icons[index] if index < len(icons) else None,
            "tag": item_tags[index],
            "count": row.get("pose_count", 0),
        })
    pack_name = manager.get_pack_display_name(pack, allow_placeholder=True)
    return _show_native_scroll_picker(
        manager,
        owner,
        str(pack_name or "动作包"),
        _loc("native_pack_desc", fallback="选择动作播放；关闭窗口返回动作库"),
        entries,
        on_item_selected,
        on_cancel=on_back,
    )



# ============================================================
# V8.8.1 user metadata — safe persistence through existing save path
# ============================================================

_V881_NOTE_PREFIX = "__fgeh_note__::"


def _v881_note_storage_key(key):
    return "{}{}".format(_V881_NOTE_PREFIX, str(key or ""))


def _v88_ensure_metadata_state(manager):
    """
    Do not write fgeh_user_data.json from this UI panel.
    Reuse couplepose1.save_favorites(), which already persists custom_names.
    """
    if getattr(manager, "_fgeh_v881_metadata_ready", False):
        return

    custom_names = getattr(manager.state, "custom_names", {}) or {}
    notes = {}

    for storage_key, value in list(custom_names.items()):
        storage_key = str(storage_key or "")
        if not storage_key.startswith(_V881_NOTE_PREFIX):
            continue

        logical_key = storage_key[len(_V881_NOTE_PREFIX):]
        if logical_key and value is not None and str(value).strip():
            notes[logical_key] = str(value)

    manager.state.custom_notes = notes
    manager._fgeh_v881_metadata_ready = True


def _v88_custom_name(manager, key, fallback):
    """Return a player's raw custom name, otherwise preserve EA LocalizedString.

    Pack/pose tuning display names are often LocalizedString protobufs owned by
    the creator's own STBL.  Converting them with str() turns them into text
    like ``hash: 3719402909`` before the UiDialog/client localization layer can
    resolve them.  Static Pose Manager chrome uses our CAFE9000 registry;
    dynamic pack/pose names stay on EA's native LocalizedString path.
    """
    value = (getattr(manager.state, "custom_names", {}) or {}).get(str(key))
    if value is None or not str(value).strip():
        return fallback if fallback is not None else ""
    return str(value)


def _v88_custom_note(manager, key):
    logical_key = str(key or "")
    if not logical_key:
        return ""

    runtime_notes = getattr(manager.state, "custom_notes", {}) or {}
    if logical_key in runtime_notes:
        return str(runtime_notes.get(logical_key, "") or "")

    custom_names = getattr(manager.state, "custom_names", {}) or {}
    return str(
        custom_names.get(
            _v881_note_storage_key(logical_key),
            "",
        ) or ""
    )


def _v88_strip_state_prefix(value):
    text = str(value or "")
    for prefix in ("★ ", "☆ ", "✓ ", "○ "):
        if text.startswith(prefix):
            return text[len(prefix):]
    return text



def _v884_group_key_info(key):
    """
    Decode a middle-click group-edit key.

    These are REAL group renames, not cosmetic custom_names aliases:
      group_outer::<name>
      group_fav_pack::<name>
      group_fav_pose::<name>
    """
    key = str(key or "")

    mapping = (
        (
            "group_outer::",
            "user_grouped_packs_groups",
            "custom_pose_ui_selected_macro_group",
            "custom_pose_ui_edit_outer_group",
        ),
        (
            "group_fav_pack::",
            "user_fav_groups",
            "custom_pose_ui_selected_fav_pack_group",
            "custom_pose_ui_edit_fav_pack_group",
        ),
        (
            "group_fav_pose::",
            "user_fav_pose_groups",
            "custom_pose_ui_selected_fav_pose_group",
            "custom_pose_ui_edit_fav_pose_group",
        ),
    )

    for prefix, groups_attr, selected_attr, edit_attr in mapping:
        if key.startswith(prefix):
            return {
                "prefix": prefix,
                "old_name": key[len(prefix):],
                "groups_attr": groups_attr,
                "selected_attr": selected_attr,
                "edit_attr": edit_attr,
            }

    return None


def _v884_rename_group_from_edit_info(
    manager,
    key,
    new_name,
    note,
):
    info = _v884_group_key_info(key)
    if info is None:
        return False

    old_name = str(info["old_name"] or "")
    new_name = str(new_name or "").strip()

    # Empty group names are not allowed.  Unlike pack custom names,
    # blank does NOT mean "restore original", because the group name
    # is the actual dictionary key.
    if not old_name or not new_name:
        manager.fgeh_pose_manager_debug_log(
            "V8.8.4 group middle rename ignored old={!r} new={!r}".format(
                old_name,
                new_name,
            )
        )
        return True

    groups = getattr(
        manager.state,
        info["groups_attr"],
        {},
    ) or {}

    if not isinstance(groups, dict) or old_name not in groups:
        manager.fgeh_pose_manager_debug_log(
            "V8.8.4 group middle rename missing group key={!r}".format(key)
        )
        return True

    if new_name != old_name and new_name in groups:
        manager.fgeh_pose_manager_debug_log(
            "V8.8.4 group middle rename collision old={!r} new={!r}".format(
                old_name,
                new_name,
            )
        )
        return True

    old_note_key = _v881_note_storage_key(key)
    new_key = "{}{}".format(info["prefix"], new_name)
    new_note_key = _v881_note_storage_key(new_key)

    custom_names = getattr(manager.state, "custom_names", {}) or {}
    custom_notes = getattr(manager.state, "custom_notes", {}) or {}

    # V8.9.46: the chosen group thumbnail is keyed by the REAL group name,
    # so a real group rename must migrate that metadata too.
    thumb_mode = (
        "outer" if info["prefix"] == "group_outer::" else
        "fav_pack" if info["prefix"] == "group_fav_pack::" else
        "fav_pose"
    )
    old_thumb_key = _v8946_group_thumb_key(thumb_mode, old_name)
    new_thumb_key = _v8946_group_thumb_key(thumb_mode, new_name)

    if new_name != old_name:
        groups[new_name] = groups.pop(old_name)
        setattr(manager.state, info["groups_attr"], groups)

        for attr_name in (
            info["selected_attr"],
            info["edit_attr"],
        ):
            if getattr(manager.state, attr_name, None) == old_name:
                setattr(manager.state, attr_name, new_name)

        # Migrate an explicitly chosen group thumbnail Pack ID.
        old_thumb_pack = custom_names.pop(old_thumb_key, "")
        if old_thumb_pack:
            custom_names[new_thumb_key] = old_thumb_pack

        # Migrate an existing group note to the new real group key.
        old_note = custom_notes.pop(
            key,
            custom_names.pop(old_note_key, ""),
        )
        if old_note:
            custom_notes[new_key] = old_note
            custom_names[new_note_key] = old_note

    # The edit-info modal still has a note box.  For groups we allow it,
    # but the rename remains a REAL group rename.
    target_key = new_key if new_name != old_name else key
    target_note_key = _v881_note_storage_key(target_key)

    if note:
        custom_notes[target_key] = note
        custom_names[target_note_key] = note
    else:
        custom_notes.pop(target_key, None)
        custom_names.pop(target_note_key, None)

    manager.state.custom_names = custom_names
    manager.state.custom_notes = custom_notes
    manager.save_favorites()

    manager.fgeh_pose_manager_debug_log(
        "V8.8.4 group middle rename saved old={!r} new={!r}".format(
            old_name,
            new_name,
        )
    )
    return True


@sims4.commands.Command("fgeh.pose_edit_info", command_type=sims4.commands.CommandType.Live)
def _v88_save_edit_info(encoded_key="", encoded_name="", encoded_note="", _connection=None):
    del _connection
    try:
        import urllib.parse
        import couplepose1 as manager

        _v88_ensure_metadata_state(manager)

        key = urllib.parse.unquote(str(encoded_key or ""))
        name = urllib.parse.unquote(str(encoded_name or "")).strip()
        note = urllib.parse.unquote(str(encoded_note or "")).strip()

        if not key:
            return False

        # V8.8.4: root group cards use the same middle-click modal,
        # but saving changes the REAL group dictionary key.
        if _v884_group_key_info(key) is not None:
            return _v884_rename_group_from_edit_info(
                manager,
                key,
                name,
                note,
            )

        custom_names = getattr(manager.state, "custom_names", {}) or {}
        custom_notes = getattr(manager.state, "custom_notes", {}) or {}

        if name:
            custom_names[key] = name
        else:
            custom_names.pop(key, None)

        note_storage_key = _v881_note_storage_key(key)

        if note:
            custom_notes[key] = note
            custom_names[note_storage_key] = note
        else:
            custom_notes.pop(key, None)
            custom_names.pop(note_storage_key, None)

        manager.state.custom_names = custom_names
        manager.state.custom_notes = custom_notes

        # Only use the original save path from couplepose1.
        manager.save_favorites()

        manager.fgeh_pose_manager_debug_log(
            "V8.8.1 edit info saved key={!r} name={} note={} safe_storage=True".format(
                key,
                bool(name),
                bool(note),
            )
        )
        return True

    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.8.1 edit info command failed",
                exc=True,
            )
        except Exception:
            pass
        return False


def _creator_map(manager):
    global _CREATOR_MAP_CACHE_KEY, _CREATOR_MAP_CACHE

    all_creators = getattr(manager.state, "all_creators_cache", {}) or {}
    custom_names = getattr(manager.state, "custom_names", {}) or {}
    creator_overrides = tuple(sorted(
        (str(key), str(value))
        for key, value in custom_names.items()
        if str(key).startswith("creator_")
    ))
    cache_key = (id(all_creators), len(all_creators), creator_overrides)
    if _CREATOR_MAP_CACHE_KEY == cache_key and _CREATOR_MAP_CACHE is not None:
        return _CREATOR_MAP_CACHE

    result = {}
    for creator, packs in all_creators.items():
        display_name = manager.get_display_name(creator, "creator_")
        for pack in packs or ():
            pack_id = manager.get_pack_id(pack)
            if pack_id and pack_id not in result:
                result[pack_id] = str(display_name or creator or "")

    _CREATOR_MAP_CACHE_KEY = cache_key
    _CREATOR_MAP_CACHE = result
    return result


def _root_base_rows_cache_key(manager):
    """Small process-local invalidation key for the expensive pack row build.

    H70W7D3: Keep UI/navigation persistence OUT of this key.  NAV V2 stores its
    JSON payload inside ``state.custom_names``; snapshotting the whole dict made
    every page/back/push operation invalidate the expensive root-row cache even
    though no visible pack metadata changed.
    """
    state_obj = manager.state
    all_packs = getattr(state_obj, "all_packs_cache", {}) or {}
    all_creators = getattr(state_obj, "all_creators_cache", {}) or {}
    custom_names = getattr(state_obj, "custom_names", {}) or {}
    custom_notes = getattr(state_obj, "custom_notes", {}) or {}

    try:
        sorting_enabled = bool(manager.is_pack_sorting_enabled())
    except Exception:
        sorting_enabled = True
    try:
        custom_names_enabled = bool(manager.is_pack_custom_names_enabled())
    except Exception:
        custom_names_enabled = True

    try:
        sort_mode = manager.normalize_pack_sort_mode(
            getattr(state_obj, "pack_sort_mode", getattr(manager, "PACK_SORT_NAME", 0))
        )
    except Exception:
        sort_mode = int(getattr(state_obj, "pack_sort_mode", 0) or 0)

    # Favorites are rendered directly on the base pack cards, so they really
    # do invalidate this cache.
    favorite_snapshot = tuple(sorted(
        str(value) for value in (getattr(state_obj, "favorite_packs", ()) or ())
    ))

    # Browse history affects ordering only in the Recent sort mode.  In A-Z,
    # creator, original, etc. it must not punch the hot cache merely because a
    # pack was opened.
    recent_mode = getattr(manager, "PACK_SORT_RECENT", 2)
    history_snapshot = ()
    if sorting_enabled and sort_mode == recent_mode:
        history_snapshot = tuple(
            str(value) for value in (getattr(state_obj, "browse_history_packs", ()) or ())
        )

    # Only metadata that can change a ROOT pack/creator card belongs here.
    # In particular, exclude __fgeh_ui_navigation_stack_v2__ and any other
    # internal UI persistence entries stored in custom_names.
    custom_name_snapshot = tuple(sorted(
        (str(key), str(value))
        for key, value in custom_names.items()
        if str(key).startswith(("pack_", "creator_"))
    ))
    custom_note_snapshot = tuple(sorted(
        (str(key), str(value))
        for key, value in custom_notes.items()
        if str(key).startswith("pack_")
    ))

    return (
        id(all_packs),
        len(all_packs),
        id(all_creators),
        len(all_creators),
        sorting_enabled,
        custom_names_enabled,
        int(sort_mode),
        favorite_snapshot,
        history_snapshot,
        custom_name_snapshot,
        custom_note_snapshot,
    )


def _sort_prebuilt_pack_items(manager, items, creator_by_pack):
    """Equivalent to manager.sort_pack_items(), reusing the already-resolved base name."""
    if not isinstance(items, list):
        items = list(items or ())
    try:
        if not manager.is_pack_sorting_enabled():
            return items
    except Exception:
        pass

    mode = manager.normalize_pack_sort_mode(
        getattr(manager.state, "pack_sort_mode", getattr(manager, "PACK_SORT_NAME", 0))
    )
    original_mode = getattr(manager, "PACK_SORT_ORIGINAL", 3)
    creator_mode = getattr(manager, "PACK_SORT_CREATOR", 1)
    recent_mode = getattr(manager, "PACK_SORT_RECENT", 2)
    name_desc_mode = getattr(manager, "PACK_SORT_NAME_DESC", 4)

    if mode == original_mode or len(items) < 2:
        return items

    history_rank = {}
    if mode == recent_mode:
        history_rank = {
            str(pack_id): index
            for index, pack_id in enumerate(
                getattr(manager.state, "browse_history_packs", ()) or ()
            )
            if pack_id
        }

    def sort_key(item):
        pack = item[0]
        pack_id = manager.get_pack_id(pack) or str(item[1] or "")
        # item[3] is the exact name get_visible_pack_name() would have used for
        # every row that survives the old _build_rows visibility checks.
        pack_name = str(item[3] or pack_id or "").casefold()
        if mode == creator_mode:
            creator_name = str(
                creator_by_pack.get(pack_id, "\uffff") or "\uffff"
            ).casefold()
            return (creator_name, pack_name, pack_id.casefold())
        if mode == recent_mode:
            return (
                history_rank.get(pack_id, len(history_rank)),
                pack_name,
                pack_id.casefold(),
            )
        return (pack_name, pack_id.casefold())

    items.sort(key=sort_key, reverse=(mode == name_desc_mode))
    return items


def _build_rows(manager):
    global _ROOT_BASE_ROWS_CACHE_KEY, _ROOT_BASE_ROWS_CACHE

    started = _perf_now()
    if not getattr(manager.state, "cache_built", False):
        manager.build_cache_safe()

    cache_key = _root_base_rows_cache_key(manager)
    if (
        _ROOT_BASE_ROWS_CACHE_KEY == cache_key
        and _ROOT_BASE_ROWS_CACHE is not None
    ):
        cached_rows, cached_icons, cached_packs = _ROOT_BASE_ROWS_CACHE
        rows = [dict(row) for row in cached_rows]
        icons = list(cached_icons)
        packs = list(cached_packs)
        _perf_log(
            manager,
            "PERF ROOT_BUILD_ROWS_HIT ms={:.3f} rows={} icons={}".format(
                _perf_ms(started), len(rows), len(icons)
            ),
        )
        return rows, icons, packs

    creator_by_pack = _creator_map(manager)
    favorites = set(str(value) for value in (manager.state.favorite_packs or ()))
    items = []

    # Resolve the tuning display name once.  The old path did a visibility
    # resolver call, then the same resolver again for the row, then again in
    # manager.sort_pack_items().
    for pack_id, pack in (manager.state.all_packs_cache or {}).items():
        base_name = manager.get_pack_display_name(pack, allow_placeholder=False)
        if base_name is None:
            # This is equivalent to the old two checks: should_hide_pack_entry
            # could return False when blank filtering was disabled, but the
            # immediately-following get_pack_display_name(None) check still
            # skipped the row.
            continue
        pack_id = str(pack_id)
        row_name = _v88_custom_name(
            manager,
            "pack_{}".format(pack_id),
            base_name,
        )
        # Tuple field 3 deliberately preserves the pre-_v88 name used by the
        # old generic pack sorter.
        items.append((pack, pack_id, row_name, base_name))

    _sort_prebuilt_pack_items(manager, items, creator_by_pack)

    rows = []
    icons = []
    packs = []
    for pack, pack_id, name, _base_name in items:
        icon_index = len(icons)

        # Final IconInfoData validation already happens in
        # show_pose_manager_root(), with the same blank fallback.  Keep the raw
        # icon here so we do not construct IconInfoData twice per pack.
        icons.append(getattr(pack, "icon", None))

        note = _v88_custom_note(manager, "pack_{}".format(pack_id))
        creator_text = creator_by_pack.get(pack_id, "")
        if note:
            creator_text = "{} · {}".format(creator_text, note) if creator_text else note

        raw_sort_name = str(getattr(pack, "sort_name", "") or "").strip()
        custom_key = "pack_{}".format(pack_id)
        has_custom_name = bool(
            str(
                (getattr(manager.state, "custom_names", {}) or {}).get(
                    custom_key,
                    "",
                )
                or ""
            ).strip()
        )
        sort_key = (
            str(name or "")
            if has_custom_name
            else (
                raw_sort_name
                if raw_sort_name
                and raw_sort_name.lower()
                not in (
                    "unknown",
                    "0x00000000",
                    "0x0",
                    "0",
                    "none",
                    "nan",
                )
                else str(name or "")
            )
        )

        rows.append({
            "pack_id": pack_id,
            "name": name,
            "sort_key": sort_key,
            "creator": creator_text,
            "pose_count": len(getattr(pack, "pose_list", ()) or ()),
            "favorite": pack_id in favorites,
            "icon_index": icon_index,
        })
        packs.append(pack)

    try:
        localized_names = sum(
            1 for row in rows if getattr(row.get("name"), "hash", None)
        )
        manager.fgeh_pose_manager_debug_log(
            "[DYNAMIC_TEXT_V1] build={} rows={} ea_localized_names={} raw_names={}".format(
                UI_BUILD_TAG,
                len(rows),
                localized_names,
                len(rows) - localized_names,
            )
        )
    except Exception:
        pass

    # Cache pristine base rows. _build_rows_v7 mutates its returned row dicts
    # (e.g. adds kind), so every hit receives fresh shallow copies.
    _ROOT_BASE_ROWS_CACHE_KEY = cache_key
    _ROOT_BASE_ROWS_CACHE = (
        tuple(dict(row) for row in rows),
        tuple(icons),
        tuple(packs),
    )

    _perf_log(
        manager,
        "PERF ROOT_BUILD_ROWS ms={:.3f} rows={} icons={}".format(
            _perf_ms(started), len(rows), len(icons)
        ),
    )
    return rows, icons, packs


# ============================================================
# V7.2 ROOT DATA ADAPTER
# ============================================================
#
# fgeh_user_data.json is still the single source of truth.
# couplepose1.load_favorites() has already loaded it into manager.state.
# This layer ONLY converts that existing state into custom UI card rows.
# No second favorites/group database is created here.
# ============================================================

# ============================================================
# V8.7 PHASE 1 — lightweight root toolbar / sorting / fav-pack views
# ============================================================

def _v87_sort_mode(manager):
    """Keep legacy pack_sort_mode: 0=A→Z, 1=Z→A."""
    try:
        value = int(getattr(manager.state, "pack_sort_mode", 0))
    except Exception:
        value = 0
    return 1 if value == 1 else 0


def _v87_sort_label(manager):
    return "Z → A" if _v87_sort_mode(manager) == 1 else "A → Z"


def _v87_clean_sort_text(value):
    text = str(value or "").strip()
    while text.startswith(("★", "☆", "✓", "○")):
        text = text[1:].lstrip()
    return text.casefold()



_V898_SORTABLE_ROOT_KINDS = frozenset((
    "pack",
    "favorite_pose_pack",
    "linked_pack",
    "creator",
    "fav_pack_author",
    "fav_pose_author",
    "outer_group_member",
    "fav_pack_group_member",
    "fav_pose_group_member",
))


def _v898_row_sortable(row):
    return str((row or {}).get("kind", "pack") or "pack") in _V898_SORTABLE_ROOT_KINDS


def _v898_rows_support_sort(rows):
    rows = list(rows or ())
    return bool(rows) and all(_v898_row_sortable(row) for row in rows)


def _v87_apply_root_sort(manager, rows, icons, packs):
    if not rows or not _v898_rows_support_sort(rows):
        return rows, icons, packs

    combined = []
    for index, row in enumerate(rows):
        combined.append((
            row,
            icons[index] if index < len(icons) else None,
            packs[index] if index < len(packs) else None,
        ))

    combined.sort(
        key=lambda item: (
            _v87_clean_sort_text(
                item[0].get("sort_key")
                or item[0].get("name", "")
            ),
            str(item[0].get("pack_id", "") or "").casefold(),
        ),
        reverse=(_v87_sort_mode(manager) == 1),
    )

    return (
        [item[0] for item in combined],
        [item[1] for item in combined],
        [item[2] for item in combined],
    )


def _v87_fav_pack_view_mode(manager):
    """Legacy meanings: 0=全部, 1=按作者, 2=我的分组."""
    try:
        value = int(getattr(manager.state, "fav_packs_view_toggle", 0))
    except Exception:
        value = 0
    return value if value in (0, 1, 2) else 0


def _v87_fav_pack_view_label(manager):
    return {
        0: "视图：全部 ▸",
        1: "视图：作者 ▸",
        2: "视图：分组 ▸",
    }.get(_v87_fav_pack_view_mode(manager), "视图：全部 ▸")


def _v87_raw_creator_by_pack(manager):
    result = {}
    all_creators = getattr(manager.state, "all_creators_cache", {}) or {}

    for creator, creator_packs in all_creators.items():
        for pack in creator_packs or ():
            try:
                pack_id = str(manager.get_pack_id(pack) or "")
            except Exception:
                pack_id = str(getattr(pack, "__name__", "") or "")
            if pack_id and pack_id not in result:
                result[pack_id] = str(creator or "Unknown")

    return result


def _v87_build_fav_pack_author_view(manager, base_rows, base_icons, base_packs):
    favorite_ids = set(
        str(value)
        for value in (getattr(manager.state, "favorite_packs", ()) or ())
        if value
    )
    raw_creator_by_pack = _v87_raw_creator_by_pack(manager)

    selected_creator = getattr(
        manager.state,
        "custom_pose_ui_selected_creator",
        None,
    )

    if selected_creator:
        accepted = []
        for row in base_rows:
            pack_id = str(row.get("pack_id", "") or "")
            if (
                pack_id in favorite_ids
                and raw_creator_by_pack.get(pack_id) == str(selected_creator)
            ):
                accepted.append(pack_id)

        return _v7_copy_pack_subset(
            base_rows,
            base_icons,
            base_packs,
            accepted,
        )

    rows = []
    icons = []
    packs = []

    base_index_by_pack_id = {
        str(row.get("pack_id", "") or ""): index
        for index, row in enumerate(base_rows)
        if row.get("pack_id")
    }

    creator_pack_ids = {}
    for pack_id in favorite_ids:
        source_index = base_index_by_pack_id.get(pack_id)
        if source_index is None:
            continue
        creator = raw_creator_by_pack.get(pack_id, "Unknown")
        creator_pack_ids.setdefault(creator, []).append(pack_id)

    for creator, pack_ids in creator_pack_ids.items():
        first_icon = None
        for pack_id in pack_ids:
            source_index = base_index_by_pack_id.get(pack_id)
            if (
                first_icon is None
                and source_index is not None
                and source_index < len(base_icons)
            ):
                first_icon = base_icons[source_index]

        try:
            display_creator = manager.get_display_name(creator, "creator_")
        except Exception:
            display_creator = creator

        rows.append({
            "pack_id": "fav_pack_author::{}".format(creator),
            "name": str(display_creator or creator),
            "creator": "收藏动作包 · 作者",
            "pose_count": len(pack_ids),
            "favorite": False,
            "icon_index": len(icons),
            "kind": "fav_pack_author",
            "value": creator,
        })
        icons.append(first_icon)
        packs.append(None)

    return rows, icons, packs


_V8946_GROUP_THUMB_PREFIX = "__fgeh_group_thumbnail__::"


def _v8946_group_thumb_key(mode, group_name):
    return "{}{}::{}".format(
        _V8946_GROUP_THUMB_PREFIX,
        str(mode or ""),
        str(group_name or ""),
    )


def _v8946_group_thumb_pack_id(manager, mode, group_name):
    """Return the persisted Pack ID chosen as a group cover, if any."""
    custom_names = getattr(manager.state, "custom_names", {}) or {}
    if not isinstance(custom_names, dict):
        return ""
    return str(
        custom_names.get(
            _v8946_group_thumb_key(mode, group_name),
            "",
        ) or ""
    )


def _v8965_is_regular_pack_icon(icon):
    """Use the SAME acceptance rule as ordinary action-pack cards.

    If _build_rows() can send an icon through IconInfoData and the normal pack
    card can display it, group cover resolution must not reject it with extra
    type/instance heuristics.  This fixes packs whose real thumbnails use
    ResourceKey shapes that looked "invalid" to the V8.9.63 strict checker.
    """
    if icon is None:
        return False
    try:
        from distributor.shared_messages import IconInfoData
        IconInfoData(icon_resource=icon)
        return True
    except Exception:
        return False


def _v8965_first_visible_group_pack_id(ordered_pack_ids, base_index=None):
    """First member the user can actually see inside the group, in stored order."""
    for raw_pack_id in (ordered_pack_ids or ()):
        pack_id = str(raw_pack_id or "")
        if not pack_id:
            continue
        if isinstance(base_index, dict) and pack_id not in base_index:
            continue
        return pack_id
    return ""


def _v8963_is_usable_group_icon(icon):
    """Return True only for a real ResourceKey-like group cover icon.

    V8.9.60-62 only checked ``icon is not None``.  TS4 can hand us a
    placeholder/zero ResourceKey object which is non-None but still renders as
    the pale empty square.  Group folders need a stricter contract because the
    AS fallback llama is selected by ``icon_index < 0``.
    """
    if icon is None:
        return False

    candidate = icon
    # Be defensive around wrappers used by some tuning helpers.
    for attr_name in ("icon_resource", "resource_key", "key"):
        try:
            nested = getattr(candidate, attr_name, None)
        except Exception:
            nested = None
        if nested not in (None, "") and nested is not candidate:
            candidate = nested
            break

    try:
        instance_id = getattr(candidate, "instance", None)
        if instance_id is None:
            instance_id = getattr(candidate, "instance_id", None)
        if instance_id is not None and int(instance_id) <= 0:
            return False
    except Exception:
        # If the attribute exists but cannot be interpreted as an ID, reject
        # instead of letting a bad folder icon poison the visible card.
        return False

    try:
        type_id = getattr(candidate, "type", None)
        if type_id is None:
            type_id = getattr(candidate, "type_id", None)
        if type_id is not None and int(type_id) <= 0:
            return False
    except Exception:
        return False

    try:
        from distributor.shared_messages import IconInfoData
        IconInfoData(icon_resource=candidate)
    except Exception:
        return False

    return True


def _v8946_pack_icon_from_id(manager, pack_id, base_index=None, base_icons=None):
    """Resolve a Pack cover exactly the way an ordinary Pack card does.

    When base_rows/base_icons are available they are authoritative: _build_rows
    already ran the normal IconInfoData validation.  Do not add stricter
    ResourceKey heuristics here or a thumbnail that visibly works in the Pack
    browser can be incorrectly rejected for a group folder.
    """
    pack_id = str(pack_id or "")
    if not pack_id:
        return None

    if isinstance(base_index, dict) and base_icons is not None:
        source_index = base_index.get(pack_id)
        if source_index is None:
            # Not a visible Pack in the current base browser.
            return None
        if 0 <= source_index < len(base_icons):
            icon = base_icons[source_index]
            return icon if _v8965_is_regular_pack_icon(icon) else None
        return None

    pack = (getattr(manager.state, "all_packs_cache", {}) or {}).get(pack_id)
    icon = getattr(pack, "icon", None) if pack is not None else None
    return icon if _v8965_is_regular_pack_icon(icon) else None


def _v8946_group_cover_icon(
    manager,
    mode,
    group_name,
    member_pack_ids,
    base_index=None,
    base_icons=None,
    fallback=None,
):
    """
    Group cover policy:
      1. player's explicit chosen child Pack, if it is still a member;
      2. caller-provided legacy/default icon.

    The persisted value is only a Pack ID.  No image data is duplicated.
    """
    member_ids = set(str(v) for v in (member_pack_ids or ()) if v)
    chosen = _v8946_group_thumb_pack_id(manager, mode, group_name)
    if chosen and chosen in member_ids:
        icon = _v8946_pack_icon_from_id(
            manager,
            chosen,
            base_index=base_index,
            base_icons=base_icons,
        )
        if _v8965_is_regular_pack_icon(icon):
            return icon
    return fallback if _v8965_is_regular_pack_icon(fallback) else None



def _v8964_group_placeholder_icon(manager):
    """Return the project's real legacy default Pack icon.

    Older Pose Manager rows already used MY_CUSTOM_ICON whenever a Pack did
    not expose its own thumbnail.  V8.9.64+ reuses that real ResourceKey for
    group-folder fallback instead of asking Scaleform to snapshot an empty
    timeline icon slot.
    """
    candidates = [
        getattr(manager, "MY_CUSTOM_ICON", None),
    ]
    try:
        import fgeh_config as _fgeh_config
        candidates.append(getattr(_fgeh_config, "MY_CUSTOM_ICON", None))
    except Exception:
        pass

    # Last-resort project-owned icons are still preferable to a blank square.
    candidates.extend((
        getattr(manager, "Group_ICON", None),
        getattr(manager, "FOlDER_ICON", None),
    ))

    for candidate in candidates:
        if _v8965_is_regular_pack_icon(candidate):
            return candidate
    return None


def _v8964_icon_signature(icon):
    if icon is None:
        return "none"
    candidate = icon
    for attr_name in ("icon_resource", "resource_key", "key"):
        try:
            nested = getattr(candidate, attr_name, None)
        except Exception:
            nested = None
        if nested not in (None, "") and nested is not candidate:
            candidate = nested
            break
    values = []
    for attr_name in ("type", "group", "instance"):
        try:
            value = getattr(candidate, attr_name, None)
        except Exception:
            value = None
        try:
            values.append("0x{:X}".format(int(value or 0)))
        except Exception:
            values.append(str(value))
    return ":".join(values)


def _v8964_apply_real_group_placeholders(manager, rows, icons):
    """Resolve every group row to an ACTUAL icon resource before AS sees it.

    This is the V8.9.64+ fallback path: fallback is data, not a visual hack.
    Empty groups and groups whose first/manual cover has no valid ResourceKey
    receive MY_CUSTOM_ICON in the same icon_infos array as normal thumbnails.
    """
    group_kinds = {
        "macro_group",
        "fav_pack_group",
        "fav_pose_group",
        "linked_macro_group",
    }
    placeholder = _v8964_group_placeholder_icon(manager)
    placeholder_ok = _v8965_is_regular_pack_icon(placeholder)
    replaced = 0

    while len(icons) < len(rows or ()):
        icons.append(None)

    for index, row in enumerate(rows or ()):
        try:
            kind = str(row.get("kind", "") or "")
            if kind not in group_kinds:
                continue
            icon = icons[index] if index < len(icons) else None
            count = int(row.get("pose_count", 0) or 0)
            needs_placeholder = (
                count <= 0 or not _v8965_is_regular_pack_icon(icon)
            )
            if needs_placeholder and placeholder_ok:
                icons[index] = placeholder
                row["icon_index"] = index
                row["group_placeholder"] = True
                replaced += 1
            elif _v8965_is_regular_pack_icon(icon):
                row["icon_index"] = index
                row["group_placeholder"] = False
            else:
                row["icon_index"] = -1
                row["group_placeholder"] = True
        except Exception:
            try:
                row["icon_index"] = -1
            except Exception:
                pass

    try:
        manager.fgeh_pose_manager_debug_log(
            "[GROUP_PLACEHOLDER_FINAL] build={} placeholder_ok={} signature={} replaced={}".format(
                UI_BUILD_TAG,
                placeholder_ok,
                _v8964_icon_signature(placeholder),
                replaced,
            )
        )
    except Exception:
        pass
    return rows, icons


def _v8960_normalize_missing_icon_indexes(rows, icons):
    """Normalize folder covers before the payload reaches Scaleform.

    Folder rows are deliberately stricter than normal Pack rows:
      * an empty group ALWAYS has icon_index=-1 (llama), regardless of stale
        icon objects or a previously selected cover;
      * a non-empty group only gets a payload icon when the ResourceKey is
        actually usable;
      * normal Pack rows keep their historical behavior.

    This prevents a non-None zero/placeholder ResourceKey from suppressing the
    llama overlay and producing the pale empty square seen in V8.9.62.
    """
    group_kinds = {
        "macro_group",
        "fav_pack_group",
        "fav_pose_group",
        "linked_macro_group",
    }
    for index, row in enumerate(rows or ()):
        try:
            icon = icons[index] if index < len(icons) else None
            row_kind = str(row.get("kind", "") or "")
            is_group = row_kind in group_kinds
            count = int(row.get("pose_count", 0) or 0)

            if is_group:
                # V8.9.64+: empty/invalid group covers have already been replaced
                # by a REAL project ResourceKey (MY_CUSTOM_ICON).  Do not force
                # count==0 back to -1 or AS would fall into the old blank-slot
                # snapshot path again.
                if _v8965_is_regular_pack_icon(icon):
                    row["icon_index"] = index
                else:
                    row["icon_index"] = -1
                continue

            if icon is None:
                row["icon_index"] = -1
            elif int(row.get("icon_index", -1)) < 0:
                row["icon_index"] = index
        except Exception:
            try:
                row["icon_index"] = -1
            except Exception:
                pass
    return rows, icons


def _v8960_first_group_pack_icon(
    manager,
    ordered_pack_ids,
    base_index=None,
    base_icons=None,
):
    """Return the first VISIBLE member Pack's ordinary-card thumbnail.

    Priority is deliberately simple:
      manual chosen cover (handled by _v8946_group_cover_icon)
      > first visible Pack in the group's persisted order
      > project default icon (applied later).

    Importantly, the first Pack uses the exact same icon object that its normal
    action-pack card uses.  No extra ResourceKey type/instance filtering.
    """
    first_pack_id = _v8965_first_visible_group_pack_id(
        ordered_pack_ids,
        base_index=base_index,
    )
    if not first_pack_id:
        return None

    return _v8946_pack_icon_from_id(
        manager,
        first_pack_id,
        base_index=base_index,
        base_icons=base_icons,
    )


def _v87_build_fav_pack_group_view(manager, base_rows, base_icons, base_packs):
    groups = getattr(manager.state, "user_fav_groups", {}) or {}
    if not isinstance(groups, dict):
        groups = {}

    favorite_ids = set(
        str(value)
        for value in (getattr(manager.state, "favorite_packs", ()) or ())
        if value
    )

    selected_group = getattr(
        manager.state,
        "custom_pose_ui_selected_fav_pack_group",
        None,
    )

    if selected_group:
        accepted = [
            str(pack_id)
            for pack_id in (groups.get(selected_group, ()) or ())
            if str(pack_id) in favorite_ids
        ]
        return _v7_copy_pack_subset(
            base_rows,
            base_icons,
            base_packs,
            accepted,
        )

    rows = []
    icons = []
    packs = []

    base_index_by_pack_id = {
        str(row.get("pack_id", "") or ""): index
        for index, row in enumerate(base_rows)
        if row.get("pack_id")
    }

    for group_name, raw_pack_ids in groups.items():
        valid_pack_ids = [
            str(pack_id)
            for pack_id in (raw_pack_ids or ())
            if (
                str(pack_id) in favorite_ids
                and str(pack_id) in base_index_by_pack_id
            )
        ]

        first_icon = _v8960_first_group_pack_icon(
            manager,
            valid_pack_ids,
            base_index=base_index_by_pack_id,
            base_icons=base_icons,
        )

        rows.append({
            "pack_id": "fav_pack_group::{}".format(group_name),
            "name": str(group_name),
            "creator": "收藏动作包分组",
            "pose_count": len(valid_pack_ids),
            "favorite": False,
            "icon_index": len(icons),
            "kind": "fav_pack_group",
            "value": str(group_name),
        })
        first_icon = _v8946_group_cover_icon(
            manager,
            "fav_pack",
            group_name,
            valid_pack_ids,
            base_index=base_index_by_pack_id,
            base_icons=base_icons,
            fallback=first_icon,
        )
        icons.append(first_icon)
        packs.append(None)

    return rows, icons, packs


def _v87_build_favorite_pack_view(manager, base_rows, base_icons, base_packs):
    mode = _v87_fav_pack_view_mode(manager)

    edit_rows = _v88_fav_pack_group_edit_rows(
        manager, base_rows, base_icons, base_packs
    )
    if edit_rows is not None:
        return edit_rows

    if mode == 1:
        return _v87_build_fav_pack_author_view(
            manager,
            base_rows,
            base_icons,
            base_packs,
        )

    if mode == 2:
        return _v87_build_fav_pack_group_view(
            manager,
            base_rows,
            base_icons,
            base_packs,
        )

    return _v7_copy_pack_subset(
        base_rows,
        base_icons,
        base_packs,
        getattr(manager.state, "favorite_packs", ()) or (),
    )




# ============================================================
# V8.8 shared root groups + 收藏动作 3-state view
# ============================================================

def _v88_fav_pose_view_mode(manager):
    # Preserve legacy: 0=全部, 1=分组; add 2=作者.
    try:
        value = int(getattr(manager.state, "fav_poses_view_toggle", 0))
    except Exception:
        value = 0
    return value if value in (0, 1, 2) else 0


def _v88_fav_pose_view_label(manager):
    return {
        0: "视图：全部 ▸",
        1: "视图：分组 ▸",
        2: "视图：作者 ▸",
    }.get(_v88_fav_pose_view_mode(manager), "视图：全部 ▸")


def _v88_group_context(manager):
    nav = _v7_active_nav(manager)
    if nav == NAV_GROUPED_PACKS:
        return {
            "kind": "outer",
            "groups_attr": "user_grouped_packs_groups",
            "selected_attr": "custom_pose_ui_selected_macro_group",
            "edit_attr": "custom_pose_ui_edit_outer_group",
            "browse_kind": "root_grouped_packs",
            "play_kind": "root_grouped_pack_play",
            "edit_kind": "root_grouped_packs_edit",
        }
    if nav == NAV_FAVORITE_PACKS and _v87_fav_pack_view_mode(manager) == 2:
        return {
            "kind": "fav_pack",
            "groups_attr": "user_fav_groups",
            "selected_attr": "custom_pose_ui_selected_fav_pack_group",
            "edit_attr": "custom_pose_ui_edit_fav_pack_group",
            "browse_kind": "root_fav_pack_groups",
            "play_kind": "root_fav_pack_group_play",
            "edit_kind": "root_fav_pack_groups_edit",
        }
    if nav == NAV_FAVORITE_POSES and _v88_fav_pose_view_mode(manager) == 1:
        return {
            "kind": "fav_pose",
            "groups_attr": "user_fav_pose_groups",
            "selected_attr": "custom_pose_ui_selected_fav_pose_group",
            "edit_attr": "custom_pose_ui_edit_fav_pose_group",
            "browse_kind": "root_fav_pose_groups",
            "play_kind": "root_fav_pose_group_play",
            "edit_kind": "root_fav_pose_groups_edit",
        }
    return None


def _v88_context_groups(manager, context):
    if context is None:
        return {}
    value = getattr(manager.state, context["groups_attr"], {}) or {}
    return value if isinstance(value, dict) else {}


def _v88_context_group_names(manager, context):
    return [str(value) for value in _v88_context_groups(manager, context).keys()]


def _v88_context_group_index(manager, context, group_name):
    if not group_name:
        return -1
    names = _v88_context_group_names(manager, context)
    try:
        return names.index(str(group_name))
    except ValueError:
        return -1


def _v88_next_context_group_name(manager, context):
    groups = _v88_context_groups(manager, context)
    number = len(groups) + 1
    name = "Group {}".format(number)
    while name in groups:
        number += 1
        name = "Group {}".format(number)
    return name


def _v88_fav_pack_group_edit_rows(manager, base_rows, base_icons, base_packs):
    context = _v88_group_context(manager)
    if context is None or context["kind"] != "fav_pack":
        return None
    group_name = getattr(manager.state, context["edit_attr"], None)
    if not group_name:
        return None

    groups = _v88_context_groups(manager, context)
    members = set(str(v) for v in (groups.get(group_name, ()) or ()) if v)
    favorites = set(str(v) for v in (manager.state.favorite_packs or ()) if v)
    rows, icons, packs = [], [], []
    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        if pack_id not in favorites:
            continue
        copied = dict(row)
        selected = pack_id in members
        # V8.8.3: do not rely on ✓ / ○ glyphs.
        # Selection is shown by a drawn green frame in AS.
        copied["name"] = _v88_strip_state_prefix(
            copied.get("name", "")
        )
        copied["creator"] = (
            "已加入 {}".format(group_name) if selected
            else "点击加入 {}".format(group_name)
        )
        copied["kind"] = "fav_pack_group_member"
        copied["value"] = pack_id
        copied["member_selected"] = selected
        copied["icon_index"] = len(icons)
        rows.append(copied)
        icons.append(base_icons[index] if index < len(base_icons) else None)
        packs.append(base_packs[index] if index < len(base_packs) else None)
    return rows, icons, packs


def _v88_favorite_pose_subset(manager):
    favorites = _detail_shared_indexes(manager)['favorites']
    mode = _v88_fav_pose_view_mode(manager)
    if mode == 1:
        group_name = getattr(manager.state, "custom_pose_ui_selected_fav_pose_group", None)
        if group_name:
            groups = getattr(manager.state, "user_fav_pose_groups", {}) or {}
            return set(
                str(v) for v in (groups.get(group_name, ()) or ())
                if str(v) in favorites
            )
    if mode == 2:
        author = getattr(manager.state, "custom_pose_ui_selected_fav_pose_author", None)
        if author:
            result = set()
            cache = getattr(manager.state, "all_poses_cache", {}) or {}
            for pose_name in favorites:
                info = cache.get(pose_name)
                creator = str(info.get("pack_name", "") or "") if isinstance(info, dict) else ""
                if not creator and ":" in pose_name:
                    creator = pose_name.split(":", 1)[0]
                if creator == str(author):
                    result.add(pose_name)
            return result
    return favorites


def _v88_build_favorite_pose_pack_cards(manager, base_rows, base_icons, base_packs, pose_names):
    pose_names = set(str(v) for v in (pose_names or ()) if v)
    counts = {}
    cache = getattr(manager.state, "all_poses_cache", {}) or {}
    for pose_name in pose_names:
        info = cache.get(pose_name)
        if not isinstance(info, dict):
            continue
        pack = info.get("pack_ref")
        if pack is None:
            continue
        try:
            pack_id = str(manager.get_pack_id(pack) or "")
        except Exception:
            pack_id = str(getattr(pack, "__name__", "") or "")
        if pack_id:
            counts[pack_id] = counts.get(pack_id, 0) + 1

    rows, icons, packs = [], [], []
    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        count = counts.get(pack_id, 0)
        if count <= 0:
            continue
        copied = dict(row)
        copied["pose_count"] = count
        creator = str(copied.get("creator", "") or "")
        copied["creator"] = "{} · 收藏动作".format(creator) if creator else "收藏动作"
        copied["kind"] = "favorite_pose_pack"
        # A 收藏动作 root card exists because it contains at least one
        # favorite pose.  Do NOT inherit the pack-favorite state here; the
        # GFX uses this flag to decide whether the click means add/remove.
        copied["favorite"] = True
        copied["icon_index"] = len(icons)
        rows.append(copied)
        icons.append(base_icons[index] if index < len(base_icons) else None)
        packs.append(base_packs[index] if index < len(base_packs) else None)
    return rows, icons, packs


def _v88_fav_pose_group_edit_rows(manager):
    context = _v88_group_context(manager)
    if context is None or context["kind"] != "fav_pose":
        return None
    group_name = getattr(manager.state, context["edit_attr"], None)
    if not group_name:
        return None
    groups = _v88_context_groups(manager, context)
    members = set(str(v) for v in (groups.get(group_name, ()) or ()) if v)
    favorites = [str(v) for v in (manager.state.favorite_poses or ()) if v]
    cache = getattr(manager.state, "all_poses_cache", {}) or {}
    rows, icons, packs = [], [], []
    for pose_name in favorites:
        info = cache.get(pose_name)
        if not isinstance(info, dict):
            continue
        pose = info.get("pose")
        if pose is None:
            continue
        try:
            fallback = manager.get_visible_pose_name(pose)
        except Exception:
            fallback = pose_name
        display = _v88_custom_name(manager, "pose_{}".format(pose_name), fallback)
        selected = pose_name in members
        rows.append({
            "pack_id": "fav_pose_member::{}".format(pose_name),
            "name": display,
            "creator": "已加入 {}".format(group_name) if selected else "点击加入 {}".format(group_name),
            "pose_count": 1,
            "favorite": True,
            "icon_index": len(icons),
            "kind": "fav_pose_group_member",
            "value": pose_name,
            "member_selected": selected,
        })
        icons.append(getattr(pose, "icon", None))
        packs.append(None)
    return rows, icons, packs


def _v88_build_fav_pose_group_view(manager, base_rows, base_icons, base_packs):
    edit = _v88_fav_pose_group_edit_rows(manager)
    if edit is not None:
        return edit
    selected = getattr(manager.state, "custom_pose_ui_selected_fav_pose_group", None)
    if selected:
        return _v88_build_favorite_pose_pack_cards(
            manager, base_rows, base_icons, base_packs, _v88_favorite_pose_subset(manager)
        )

    groups = getattr(manager.state, "user_fav_pose_groups", {}) or {}
    if not isinstance(groups, dict):
        groups = {}
    favorites = set(str(v) for v in (manager.state.favorite_poses or ()) if v)
    cache = getattr(manager.state, "all_poses_cache", {}) or {}
    rows, icons, packs = [], [], []
    for group_name, raw_members in groups.items():
        valid = [str(v) for v in (raw_members or ()) if str(v) in favorites and str(v) in cache]
        first_icon = None
        if valid:
            info = cache.get(valid[0])
            if isinstance(info, dict) and info.get("pose") is not None:
                candidate_icon = getattr(info["pose"], "icon", None)
                if _v8965_is_regular_pack_icon(candidate_icon):
                    first_icon = candidate_icon
        rows.append({
            "pack_id": "fav_pose_group::{}".format(group_name),
            "name": str(group_name),
            "creator": "收藏动作分组",
            "pose_count": len(valid),
            "favorite": False,
            "icon_index": len(icons),
            "kind": "fav_pose_group",
            "value": str(group_name),
        })
        icons.append(first_icon)
        packs.append(None)
    return rows, icons, packs


def _v88_build_fav_pose_author_view(manager, base_rows, base_icons, base_packs):
    selected = getattr(manager.state, "custom_pose_ui_selected_fav_pose_author", None)
    if selected:
        return _v88_build_favorite_pose_pack_cards(
            manager, base_rows, base_icons, base_packs, _v88_favorite_pose_subset(manager)
        )

    favorites = set(str(v) for v in (manager.state.favorite_poses or ()) if v)
    cache = getattr(manager.state, "all_poses_cache", {}) or {}
    grouped = {}
    for pose_name in favorites:
        info = cache.get(pose_name)
        if not isinstance(info, dict):
            continue
        creator = str(info.get("pack_name", "") or "")
        if not creator and ":" in pose_name:
            creator = pose_name.split(":", 1)[0]
        creator = creator or "Unknown"
        grouped.setdefault(creator, []).append(pose_name)

    rows, icons, packs = [], [], []
    for creator, pose_names in grouped.items():
        first_icon = None
        if pose_names:
            info = cache.get(pose_names[0])
            if isinstance(info, dict) and info.get("pose") is not None:
                first_icon = getattr(info["pose"], "icon", None)
        try:
            display = manager.get_display_name(creator, "creator_")
        except Exception:
            display = creator
        rows.append({
            "pack_id": "fav_pose_author::{}".format(creator),
            "name": str(display or creator),
            "creator": "收藏动作 · 作者",
            "pose_count": len(pose_names),
            "favorite": False,
            "icon_index": len(icons),
            "kind": "fav_pose_author",
            "value": creator,
        })
        icons.append(first_icon)
        packs.append(None)
    return rows, icons, packs


def _v88_build_favorite_pose_view(manager, base_rows, base_icons, base_packs):
    mode = _v88_fav_pose_view_mode(manager)
    if mode == 1:
        return _v88_build_fav_pose_group_view(manager, base_rows, base_icons, base_packs)
    if mode == 2:
        return _v88_build_fav_pose_author_view(manager, base_rows, base_icons, base_packs)
    return _v88_build_favorite_pose_pack_cards(
        manager, base_rows, base_icons, base_packs,
        set(str(v) for v in (manager.state.favorite_poses or ()) if v),
    )


def _v88_build_edit_metadata(manager, rows):
    keys, names, notes = [], [], []
    custom_names = getattr(manager.state, "custom_names", {}) or {}
    for row in rows:
        kind = str(row.get("kind", "") or "")
        key = ""
        if kind in ("pack", "favorite_pose_pack", "linked_pack", "fav_pack_group_member", "outer_group_member"):
            pack_id = str(row.get("value", row.get("pack_id", "")) or "")
            if pack_id and not pack_id.startswith(("fav_", "macro_", "linked_")):
                key = "pack_{}".format(pack_id)
        elif kind == "fav_pose_group_member":
            pose_name = str(row.get("value", "") or "")
            if pose_name:
                key = "pose_{}".format(pose_name)
        elif kind in ("creator", "fav_pack_author", "fav_pose_author"):
            creator = str(row.get("value", "") or "")
            if creator:
                key = "creator_{}".format(creator)

        # V8.8.4: direct middle-click rename on group cards.
        # These keys are routed to REAL dictionary-key rename logic.
        elif kind == "macro_group":
            group_name = str(row.get("value", "") or "")
            if group_name:
                key = "group_outer::{}".format(group_name)
        elif kind == "fav_pack_group":
            group_name = str(row.get("value", "") or "")
            if group_name:
                key = "group_fav_pack::{}".format(group_name)
        elif kind == "fav_pose_group":
            group_name = str(row.get("value", "") or "")
            if group_name:
                key = "group_fav_pose::{}".format(group_name)

        keys.append(key)

        if key.startswith(("group_outer::", "group_fav_pack::", "group_fav_pose::")):
            # Prefill with the current REAL group name.
            names.append(key.split("::", 1)[1])
        else:
            names.append(str(custom_names.get(key, "") or "") if key else "")

        notes.append(_v88_custom_note(manager, key) if key else "")
    return keys, names, notes

def _v7_active_nav(manager):
    try:
        value = int(
            getattr(
                manager.state,
                "custom_pose_ui_active_nav",
                NAV_ALL_PACKS,
            )
        )
    except Exception:
        value = NAV_ALL_PACKS

    # R17: existing top-level ids 0..7 stay stable; 8 is the Blank Packs
    # child response and 9 is the dedicated Outfit Manager root.
    if value < NAV_ALL_PACKS or value == 8 or value > NAV_OUTFIT_MANAGER:
        value = NAV_ALL_PACKS

    return value


def _v7_reset_subview(manager):
    manager.state.custom_pose_ui_selected_creator = None
    manager.state.custom_pose_ui_selected_macro_group = None
    manager.state.custom_pose_ui_selected_fav_pack_group = None
    manager.state.custom_pose_ui_selected_fav_pose_group = None
    manager.state.custom_pose_ui_selected_fav_pose_author = None
    manager.state.custom_pose_ui_edit_outer_group = None
    manager.state.custom_pose_ui_edit_fav_pack_group = None
    manager.state.custom_pose_ui_edit_fav_pose_group = None
    manager.state.custom_pose_ui_favorite_only = False

    # Linked "分组联动" inherits ACTION outer-group folders.
    # It is a view state, not a separate linked-group database.
    try:
        manager.state.selected_linked_grouped_outer_name = None
    except Exception:
        pass


def _v7_copy_pack_subset(base_rows, base_icons, base_packs, accepted_pack_ids):
    accepted_pack_ids = set(str(value) for value in (accepted_pack_ids or ()) if value)

    rows = []
    icons = []
    packs = []

    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        if pack_id not in accepted_pack_ids:
            continue

        copied = dict(row)
        copied["kind"] = "pack"
        copied["icon_index"] = len(icons)

        rows.append(copied)
        icons.append(base_icons[index] if index < len(base_icons) else None)
        packs.append(base_packs[index] if index < len(base_packs) else None)

    return rows, icons, packs



def _v899_creator_view_mode(manager):
    """
    0 = 收藏作者
    1 = 全部作者

    Entering the 作者 nav resets this to 0, so the first screen is always
    the user's favorite authors as requested.
    """
    try:
        value = int(
            getattr(
                manager.state,
                "custom_pose_ui_creator_view_mode",
                0,
            )
        )
    except Exception:
        value = 0
    return 1 if value == 1 else 0


def _v899_creator_view_label(manager):
    return (
        "全部作者"
        if _v899_creator_view_mode(manager) == 1
        else "收藏作者"
    )


def _v7_build_creator_cards(manager, base_rows, base_icons, base_packs):
    favorite_creators = set(
        str(value)
        for value in (getattr(manager.state, "favorite_creators", ()) or ())
        if value
    )

    selected = getattr(
        manager.state,
        "custom_pose_ui_selected_creator",
        None,
    )

    # Inside one creator -> show that creator's real pose packs.
    if selected:
        raw_packs = (
            getattr(manager.state, "all_creators_cache", {}) or {}
        ).get(selected, ()) or ()

        accepted_pack_ids = []
        for pack in raw_packs:
            try:
                pack_id = str(manager.get_pack_id(pack) or "")
            except Exception:
                pack_id = str(getattr(pack, "__name__", "") or "")
            if pack_id:
                accepted_pack_ids.append(pack_id)

        return _v7_copy_pack_subset(
            base_rows,
            base_icons,
            base_packs,
            accepted_pack_ids,
        )

    # Creator overview:
    # default = 收藏作者；switchable to 全部作者.
    rows = []
    icons = []
    packs = []

    base_index_by_pack_id = {}
    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        if pack_id:
            base_index_by_pack_id[pack_id] = index

    all_creators = getattr(manager.state, "all_creators_cache", {}) or {}

    creator_items = []
    favorite_only = _v899_creator_view_mode(manager) == 0

    for creator in all_creators.keys():
        creator = str(creator)
        if favorite_only and creator not in favorite_creators:
            continue

        try:
            display_creator = manager.get_display_name(creator, "creator_")
        except Exception:
            display_creator = creator

        creator_items.append((
            creator,
            str(display_creator or creator),
        ))

    creator_items.sort(
        key=lambda item: _v87_clean_sort_text(item[1]),
        reverse=_v87_sort_mode(manager) == 1,
    )

    for creator, display_creator in creator_items:
        creator_packs = list(all_creators.get(creator, ()) or ())
        first_icon = None
        visible_count = 0

        for pack in creator_packs:
            try:
                pack_id = str(manager.get_pack_id(pack) or "")
            except Exception:
                pack_id = str(getattr(pack, "__name__", "") or "")

            source_index = base_index_by_pack_id.get(pack_id)
            if source_index is None:
                continue
            visible_count += 1
            if first_icon is None and source_index < len(base_icons):
                first_icon = base_icons[source_index]

        rows.append({
            "pack_id": "creator::{}".format(creator),
            "name": display_creator,
            "creator": "作者",
            "pose_count": visible_count,
            "favorite": creator in favorite_creators,
            "sort_key": display_creator,
            "icon_index": len(icons),
            "kind": "creator",
            "value": creator,
        })
        icons.append(first_icon)
        packs.append(None)

    return rows, icons, packs



def _v76_outer_group_names(manager):
    groups = getattr(manager.state, "user_grouped_packs_groups", {}) or {}
    if not isinstance(groups, dict):
        return []
    # 保留 JSON 原有插入顺序，旧玩家分组顺序不乱。
    return [str(name) for name in groups.keys()]


def _v76_outer_group_index(manager, group_name):
    if not group_name:
        return -1

    names = _v76_outer_group_names(manager)
    try:
        return names.index(str(group_name))
    except ValueError:
        return -1


def _v76_next_outer_group_name(manager):
    groups = getattr(manager.state, "user_grouped_packs_groups", {}) or {}
    if not isinstance(groups, dict):
        groups = {}
        manager.state.user_grouped_packs_groups = groups

    n = len(groups) + 1
    name = "Group {}".format(n)

    while name in groups:
        n += 1
        name = "Group {}".format(n)

    return name


def _v76_build_outer_group_edit_rows(
    manager,
    base_rows,
    base_icons,
    base_packs,
):
    """
    V8.9.17 STEP 1.

    Outer-group management shows CURRENT members only.
    Outer membership is independent from grouped_packs / inner Pose groups.
    Removing outer membership never removes or changes inner-group data.
    """
    edit_group = getattr(
        manager.state,
        "custom_pose_ui_edit_outer_group",
        None,
    )
    if not edit_group:
        return None

    groups = getattr(manager.state, "user_grouped_packs_groups", {}) or {}
    if not isinstance(groups, dict):
        groups = {}

    current_members = set(
        str(value)
        for value in (groups.get(edit_group, ()) or ())
        if value
    )

    rows = []
    icons = []
    packs = []

    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        if pack_id not in current_members:
            continue

        copied = dict(row)
        raw_name = str(copied.get("name", "") or "")
        if raw_name.startswith("★ ") or raw_name.startswith("☆ "):
            raw_name = raw_name[2:]

        copied["name"] = raw_name
        copied["icon_index"] = len(icons)
        copied["kind"] = "outer_group_member"
        copied["value"] = pack_id

        # Green now means temporary management selection.
        copied["member_selected"] = False

        rows.append(copied)
        icons.append(base_icons[index] if index < len(base_icons) else None)
        packs.append(base_packs[index] if index < len(base_packs) else None)

    return rows, icons, packs



def _v7_build_macro_group_cards(manager, base_rows, base_icons, base_packs):
    edit_rows = _v76_build_outer_group_edit_rows(
        manager,
        base_rows,
        base_icons,
        base_packs,
    )
    if edit_rows is not None:
        return edit_rows

    groups = getattr(manager.state, "user_grouped_packs_groups", {}) or {}
    if not isinstance(groups, dict):
        groups = {}

    selected = getattr(
        manager.state,
        "custom_pose_ui_selected_macro_group",
        None,
    )

    # Inside one outer group -> show the real pose packs assigned to it.
    if selected:
        return _v7_copy_pack_subset(
            base_rows,
            base_icons,
            base_packs,
            groups.get(selected, ()) or (),
        )

    rows = []
    icons = []
    packs = []

    base_index_by_pack_id = {}
    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        if pack_id:
            base_index_by_pack_id[pack_id] = index

    # Keep the JSON dict insertion order instead of silently re-sorting
    # the user's custom group layout.
    for group_name, raw_pack_ids in groups.items():
        pack_ids = [
            str(value)
            for value in (raw_pack_ids or ())
            if value
        ]

        visible_count = 0

        for pack_id in pack_ids:
            source_index = base_index_by_pack_id.get(pack_id)
            if source_index is None:
                continue
            visible_count += 1

        # V8.9.65 cover priority:
        #   manual chosen cover > first visible stored member > MY_CUSTOM_ICON.
        # The first member reuses the exact same icon path as normal Pack cards.
        first_icon = None
        if visible_count > 0:
            first_icon = _v8960_first_group_pack_icon(
                manager,
                pack_ids,
                base_index=base_index_by_pack_id,
                base_icons=base_icons,
            )
            first_icon = _v8946_group_cover_icon(
                manager,
                "outer",
                group_name,
                pack_ids,
                base_index=base_index_by_pack_id,
                base_icons=base_icons,
                fallback=first_icon,
            )

        try:
            first_member = _v8965_first_visible_group_pack_id(pack_ids, base_index_by_pack_id)
            chosen_cover = _v8946_group_thumb_pack_id(manager, "outer", group_name)
            manager.fgeh_pose_manager_debug_log(
                "[GROUP_COVER_RESOLVE] build={} group={!r} visible_count={} first_pack={} manual_pack={} usable={}".format(
                    UI_BUILD_TAG,
                    group_name,
                    visible_count,
                    first_member,
                    chosen_cover,
                    _v8965_is_regular_pack_icon(first_icon),
                )
            )
        except Exception:
            pass

        rows.append({
            "pack_id": "macro_group::{}".format(group_name),
            "name": str(group_name),
            "creator": "动作分组",
            "pose_count": visible_count,
            "favorite": False,
            "icon_index": len(icons),
            "kind": "macro_group",
            "value": str(group_name),
        })
        icons.append(first_icon)
        packs.append(None)

    return rows, icons, packs


def _v7_build_favorite_pose_pack_cards(manager, base_rows, base_icons, base_packs):
    favorite_pose_names = set(
        str(value)
        for value in (getattr(manager.state, "favorite_poses", ()) or ())
        if value
    )

    favorite_counts_by_pack_id = {}
    all_poses_cache = getattr(manager.state, "all_poses_cache", {}) or {}

    for pose_name in favorite_pose_names:
        info = all_poses_cache.get(pose_name)
        if not isinstance(info, dict):
            continue

        pack = info.get("pack_ref")
        if pack is None:
            continue

        try:
            pack_id = str(manager.get_pack_id(pack) or "")
        except Exception:
            pack_id = str(getattr(pack, "__name__", "") or "")

        if not pack_id:
            continue

        favorite_counts_by_pack_id[pack_id] = (
            favorite_counts_by_pack_id.get(pack_id, 0) + 1
        )

    rows = []
    icons = []
    packs = []

    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        favorite_count = favorite_counts_by_pack_id.get(pack_id, 0)

        if favorite_count <= 0:
            continue

        copied = dict(row)
        copied["pose_count"] = favorite_count

        creator = str(copied.get("creator", "") or "")
        copied["creator"] = (
            "{} · 收藏动作".format(creator)
            if creator
            else "收藏动作"
        )

        copied["icon_index"] = len(icons)
        copied["kind"] = "favorite_pose_pack"
        copied["favorite"] = True

        rows.append(copied)
        icons.append(base_icons[index] if index < len(base_icons) else None)
        packs.append(base_packs[index] if index < len(base_packs) else None)

    return rows, icons, packs



def _v75_debug_loaded_legacy_data(manager):
    try:
        manager.fgeh_pose_manager_debug_log(
            "V7.5 legacy JSON/state counts fav_packs={} fav_creators={} fav_poses={} "
            "grouped_packs={} grouped_outer_groups={} fav_pack_groups={} "
            "fav_pose_groups={} linked_types={}".format(
                len(getattr(manager.state, "favorite_packs", ()) or ()),
                len(getattr(manager.state, "favorite_creators", ()) or ()),
                len(getattr(manager.state, "favorite_poses", ()) or ()),
                len(getattr(manager.state, "grouped_packs", {}) or {}),
                len(getattr(manager.state, "user_grouped_packs_groups", {}) or {}),
                len(getattr(manager.state, "user_fav_groups", {}) or {}),
                len(getattr(manager.state, "user_fav_pose_groups", {}) or {}),
                len(getattr(manager.state, "linked_groups", {}) or {}),
            )
        )
    except Exception:
        pass


def _v8918_setting_bool(manager, attr_name, default=True):
    try:
        return bool(getattr(manager.state, attr_name, default))
    except Exception:
        return bool(default)


def _v8918_settings_rows(manager):
    """
    Restore the CONFIRMED legacy Global Settings into the custom EpicCard UI.

    These four switches are taken directly from the old couplepose1.py
    GLOBAL_SETTINGS rows/handlers:
      - restore_last_view_on_open
      - auto_apply_linked_requirements
      - auto_destroy_linked_objects
      - replace_linked_objects_on_replay

    Do not invent additional settings here.  Other state fields may exist in
    user JSON, but they are not part of the confirmed old settings route.
    """
    try:
        if not getattr(manager.state, "cache_built", False):
            manager.build_cache_safe()
    except Exception:
        pass

    pack_count = len(getattr(manager.state, "all_packs_cache", {}) or {})
    pose_count = len(getattr(manager.state, "all_poses_cache", {}) or {})

    # Validate the resource, not merely "is not None".  Some manager builds
    # expose SWITCH_ICON as a ResourceKey-like object that cannot actually be
    # serialized by IconInfoData; that was the source of the pale blank cards.
    default_fgeh_icon = _valid_icon_resource(
        manager,
        getattr(manager, "MY_CUSTOM_ICON", None),
        "settings_fgeh_default_icon",
    )
    manage_icon = _valid_icon_resource(
        manager,
        getattr(manager, "MANAGE_ICON", None),
        "settings_manage_icon",
    ) or default_fgeh_icon

    # SWITCH_ICON serializes without throwing on some builds but the client
    # still renders it as a blank pale square.  Use the same proven FgEH
    # placeholder icon used by empty action groups instead of trusting it.
    switch_icon = default_fgeh_icon or manage_icon

    import fgeh_pose_need_freeze as need_freeze
    specs = [
        {
            'key': 'freeze_needs_while_posing',
            'name': 'shared_needs_freeze',
            'description': 'shared_needs_freeze_desc',
            'status': '开' if need_freeze.enabled(manager) else '关',
            'icon': switch_icon,
        },
        {
            "key": "cache_info",
            "name": _loc("settings_info_title", fallback="动作库信息"),
            "description": _loc(
                "tpl_library_counts",
                pack_count,
                pose_count,
                fallback="已读取 {} 个动作包 · {} 个动作",
            ),
            "status": "",
            "icon": manage_icon,
        },
        {
            "key": "restore_last_view_on_open",
            "name": _loc("settings_restore_location", fallback="返回上次浏览位置"),
            "description": _loc("settings_restore_location_desc", fallback="下次打开动作管理器时返回最近浏览的动作包、模块或分组。"),
            "status": _loc("common_on", fallback="开") if _v8918_setting_bool(
                manager, "restore_last_view_on_open", True
            ) else _loc("common_off", fallback="关"),
            "icon": switch_icon,
        },
        {
            "key": "auto_apply_linked_requirements",
            "name": _loc("settings_auto_linked", fallback="播放动作时自动应用联动项"),
            "description": _loc("settings_auto_linked_desc", fallback="关闭后不会自动更换 CAS 或生成联动物体，但手动选择记录仍会保留。"),
            "status": _loc("common_on", fallback="开") if _v8918_setting_bool(
                manager, "auto_apply_linked_requirements", True
            ) else _loc("common_off", fallback="关"),
            "icon": switch_icon,
        },
        {
            "key": "restore_linked_requirements_when_pose_chain_finished",
            "name": "结束动作后恢复联动前服装",
            "description": "整个动作队列结束后，恢复联动修改的 CAS 部位；关闭时保留联动造型。",
            "status": _loc("common_on", fallback="开") if _v8918_setting_bool(
                manager, "restore_linked_requirements_when_pose_chain_finished", False
            ) else _loc("common_off", fallback="关"),
            "icon": switch_icon,
        },
        {
            "key": "auto_destroy_linked_objects",
            "name": _loc("settings_destroy_objects", fallback="结束动作后自动销毁联动物体"),
            "description": _loc("settings_destroy_objects_desc", fallback="关闭后，动作生成的联动物体会保留在场景里。"),
            "status": _loc("common_on", fallback="开") if _v8918_setting_bool(
                manager, "auto_destroy_linked_objects", True
            ) else _loc("common_off", fallback="关"),
            "icon": switch_icon,
        },
        {
            "key": "replace_linked_objects_on_replay",
            "name": _loc("settings_replace_objects", fallback="重复播放前替换旧联动物体"),
            "description": _loc("settings_replace_objects_desc", fallback="开启后，播放新的联动物体动作前会先清理旧联动物体。"),
            "status": _loc("common_on", fallback="开") if _v8918_setting_bool(
                manager, "replace_linked_objects_on_replay", True
            ) else _loc("common_off", fallback="关"),
            "icon": switch_icon,
        },
        {
            "key": "utility_restore_original_outfit",
            "name": _loc("linked_restore_original_outfit", fallback="恢复原始服装"),
            "description": _loc(
                "settings_restore_original_outfit_desc",
                fallback="恢复联动前保存的小人原始服装；用于 CAS 联动异常时手动恢复。",
            ),
            "status": "",
            "icon": manage_icon,
        },
        {
            "key": "utility_clear_linked_objects",
            "name": _loc("linked_clear_generated_objects", fallback="清除联动物体"),
            "description": _loc(
                "settings_clear_linked_objects_desc",
                fallback="强制清理联动系统生成的物体；用于物体卡住或无法在购买模式删除时。",
            ),
            "status": "",
            "icon": manage_icon,
        },
    ]

    try:
        manager.fgeh_pose_manager_debug_log(
            "[LOCALIZATION_V2] build={} module_loaded={} registry_entries={} settings_switch_icon={} settings_manage_icon={} settings_switch_source=MY_CUSTOM_ICON".format(
                UI_BUILD_TAG,
                _ui_loc is not None,
                len(_ui_loc.UI_LOCALIZATION) if _ui_loc is not None else 0,
                switch_icon is not None,
                manage_icon is not None,
            )
        )
    except Exception:
        pass

    rows = []
    icons = []
    packs = []

    for spec in specs:
        key = spec["key"]
        status = spec["status"]
        has_status = bool(status)
        rows.append({
            "pack_id": "setting:{}".format(key),
            "name": spec["name"],
            "creator": (
                _loc("tpl_desc_status", spec["description"], status, fallback="{} · {}")
                if has_status
                else spec["description"]
            ),
            "pose_count": status if has_status else "",
            "favorite": False,
            "icon_index": len(icons),
            "kind": "setting",
            "value": key,
        })
        icons.append(spec["icon"])
        packs.append(None)

    return rows, icons, packs




# ------------------------------------------------------------------
# H70W7D3R15 Outfit Manager - safe integrated read-only surface
# ------------------------------------------------------------------
# The current GFX has exactly eight top-level sidebar slots.  To avoid another
# structural ABC rewrite, R15 reuses the former Settings slot as the top-level
# Outfit surface.  The original Settings page remains reachable as a card from
# this surface.  The package-side label is changed in-place from 设置 -> 服装
# (same UTF-8 byte length); no method body is changed.

_OUTFIT_UI_MODE_ATTR = "custom_pose_ui_outfit_manager_mode"
_OUTFIT_UI_CATEGORY_ATTR = "custom_pose_ui_outfit_manager_category"
_OUTFIT_UI_INDEX_ATTR = "custom_pose_ui_outfit_manager_index"
_OUTFIT_UI_BROWSE_CATEGORY_ATTR = "custom_pose_ui_outfit_manager_browse_category"
_OUTFIT_UI_PART_GROUP_ATTR = "custom_pose_ui_outfit_manager_part_group"
_OUTFIT_EDITOR_POSE_NAME = "root_outfits"


_OUTFIT_CATEGORY_ZH = {
    "EVERYDAY": "日常",
    "FORMAL": "正式",
    "ATHLETIC": "运动",
    "SLEEP": "睡衣",
    "PARTY": "派对",
    "SWIMWEAR": "泳装",
    "HOTWEATHER": "炎热天气",
    "COLDWEATHER": "寒冷天气",
}


def _outfit_ui_mode(manager):
    try:
        value = str(getattr(manager.state, _OUTFIT_UI_MODE_ATTR, "outfits") or "outfits")
    except Exception:
        value = "outfits"
    return value if value in ("outfits", "parts", "settings") else "outfits"


def _outfit_ui_reset(manager):
    try:
        setattr(manager.state, _OUTFIT_UI_MODE_ATTR, "outfits")
        setattr(manager.state, _OUTFIT_UI_CATEGORY_ATTR, None)
        setattr(manager.state, _OUTFIT_UI_INDEX_ATTR, None)
    except Exception:
        pass


def _outfit_ui_has_subview(manager):
    return _outfit_ui_mode(manager) != "outfits"


def _outfit_ui_category_label(category):
    if _outfit_phase1 is None:
        return str(category)
    try:
        name = str(_outfit_phase1._category_name(category) or category)
    except Exception:
        name = str(category)
    return _OUTFIT_CATEGORY_ZH.get(name, name)


def _outfit_ui_browse_category(manager):
    try:
        value = getattr(manager.state, _OUTFIT_UI_BROWSE_CATEGORY_ATTR, None)
    except Exception:
        value = None
    if value in (None, "", -1, "-1"):
        return None
    try:
        return int(value)
    except Exception:
        return None


def _outfit_ui_set_browse_category(manager, category):
    try:
        if category is None:
            setattr(manager.state, _OUTFIT_UI_BROWSE_CATEGORY_ATTR, None)
        else:
            setattr(manager.state, _OUTFIT_UI_BROWSE_CATEGORY_ATTR, int(category))
    except Exception:
        pass


def _outfit_ui_category_tabs(manager):
    """Return (labels, categories, active_index) for real regular Outfit categories.

    The GFX group-tab component automatically supplies tab 0 as '全部'.
    ``group_names`` therefore contains only the real category labels; the
    selected category maps to those labels by index.
    """
    if _outfit_phase1 is None:
        return [], [], -1
    try:
        sim_info = _caslib_target_from_state(manager)
        keys = tuple(_outfit_phase1._real_outfit_keys(sim_info, regular_only=True) or ())
    except Exception:
        keys = ()
    categories = []
    for category, _index in keys:
        try:
            category = int(category)
        except Exception:
            continue
        if category not in categories:
            categories.append(category)
    labels = [_outfit_ui_category_label(category) for category in categories]
    selected = _outfit_ui_browse_category(manager)
    try:
        active_index = categories.index(selected) if selected in categories else -1
    except Exception:
        active_index = -1
    return labels, categories, active_index


def _outfit_ui_part_display_name(body_type_name):
    raw = str(body_type_name or "").strip()
    friendly = {
        "HAIR": "头发",
        "HEAD": "头部",
        "TEETH": "牙齿",
        "UPPER_BODY": "上衣",
        "LOWER_BODY": "下装",
        "FULL_BODY": "全身",
        "SHOES": "鞋子",
        "NECKLACE": "项链",
        "WRIST_RIGHT": "右手腕",
        "WRIST_LEFT": "左手腕",
        "FACIAL_HAIR": "面部毛发",
        "LIPS_TICK": "口红",
        "EYE_SHADOW": "眼影",
        "EYE_LINER": "眼线",
        "EARRINGS": "耳环",
        "GLASSES": "眼镜",
        "HAT": "帽子",
    }
    label = friendly.get(raw.upper())
    if label:
        return "{} · {}".format(label, raw)
    return raw or "服装部件"


def _outfit_ui_part_library_meta(cas_part_id):
    """Best-effort reuse of CAS Library metadata/icon for a saved outfit part.

    This does not scan or synthesize a new CAS database.  If the exact CASPart
    already exists in the user's library projection we reuse its proven icon;
    otherwise the caller keeps the ordinary fallback icon.
    """
    try:
        data = _caslib_load()
        item, variant = _caslib_find_item_by_variant(data, cas_part_id)
    except Exception:
        item, variant = None, None
    if not isinstance(item, dict) or not isinstance(variant, dict):
        return None, None
    label = str(item.get("display_name") or item.get("name") or "").strip() or None
    try:
        from fgeh_cas_collection_library import thumbnail_resource_key
        icon = thumbnail_resource_key(variant.get("icon_key_raw"))
    except Exception:
        icon = None
    return label, icon


def _outfit_ui_part_friendly_name(body_type_name):
    raw = str(body_type_name or "").strip().upper()
    friendly = {
        "HAIR": "头发",
        "HEAD": "头部",
        "TEETH": "牙齿",
        "UPPER_BODY": "上衣",
        "LOWER_BODY": "下装",
        "FULL_BODY": "全身",
        "SHOES": "鞋子",
        "NECKLACE": "项链",
        "WRIST_RIGHT": "右手饰",
        "WRIST_LEFT": "左手饰",
        "FACIAL_HAIR": "面部毛发",
        "LIPS_TICK": "口红",
        "EYE_SHADOW": "眼影",
        "EYE_LINER": "眼线",
        "EARRINGS": "耳环",
        "GLASSES": "眼镜",
        "HAT": "帽子",
        "SOCKS": "袜子",
        "GLOVES": "手套",
    }
    return friendly.get(raw, raw or "服装部件")


def _outfit_ui_part_group(body_type_name):
    raw = str(body_type_name or "").strip().upper()
    if raw in ("HAIR", "HEAD", "TEETH", "FACIAL_HAIR"):
        return "头部"
    if raw in ("UPPER_BODY", "FULL_BODY"):
        return "上装"
    if raw in ("LOWER_BODY",):
        return "下装"
    if raw in ("SHOES", "SOCKS"):
        return "鞋子"
    if raw in ("LIPS_TICK", "EYE_SHADOW", "EYE_LINER", "BLUSH", "FACEPAINT"):
        return "妆容"
    if raw.startswith(("WRIST", "LIP_RING_", "NOSE_RING_", "BROW_RING_", "INDEX_FINGER_", "RING_FINGER_", "MIDDLE_FINGER_")) or raw in (
        "HAT", "EARRINGS", "GLASSES", "NECKLACE", "RING", "GLOVES", "TIGHTS", "BRACELET",
    ):
        return "配饰"
    return "其他"


def _outfit_ui_part_group_order():
    return ("头部", "上装", "下装", "鞋子", "配饰", "妆容", "其他")


def _outfit_ui_selected_part_group(manager):
    try:
        value = str(getattr(manager.state, _OUTFIT_UI_PART_GROUP_ATTR, "") or "").strip()
    except Exception:
        value = ""
    return value or None


def _outfit_ui_set_selected_part_group(manager, value):
    try:
        setattr(manager.state, _OUTFIT_UI_PART_GROUP_ATTR, str(value or "").strip() or None)
    except Exception:
        pass


def _outfit_editor_parts(sim_info, category, index):
    if _outfit_phase1 is None or sim_info is None:
        return ()
    try:
        return tuple(_outfit_phase1._part_rows(sim_info, category, index) or ())
    except Exception:
        return ()


def _outfit_editor_group_names(parts):
    present = set()
    for part in parts or ():
        present.add(_outfit_ui_part_group(part.get("body_type_name", "")))
    return [name for name in _outfit_ui_part_group_order() if name in present]


def _outfit_editor_find_catalog_product(catalog, current_cas_part_id):
    """Return the exact product containing current_cas_part_id.

    This is deliberately identity-based.  Do not guess siblings from body type,
    label text, thumbnail shape, or nearby IDs: those are not validated CAS
    product identities and could silently swap a different item.
    """
    try:
        current_cas_part_id = int(current_cas_part_id or 0)
    except Exception:
        return None
    if not current_cas_part_id:
        return None
    for product in catalog or ():
        if not isinstance(product, dict):
            continue
        for variant in product.get("variants", ()) or ():
            try:
                candidate = int(variant.get("item_id") or 0)
            except Exception:
                candidate = 0
            if candidate == current_cas_part_id:
                return product
    return None


def _outfit_editor_copy_product_variants(product, origin="outfit"):
    result = []
    if not isinstance(product, dict):
        return result
    for fallback_index, raw_variant in enumerate(product.get("variants", ()) or ()):
        try:
            item_id = int(raw_variant.get("item_id") or raw_variant.get("cas_part_id") or 0)
        except Exception:
            item_id = 0
        if not item_id:
            continue
        try:
            swatch_index = int(raw_variant.get("swatch_index") or raw_variant.get("style_index") or 0)
        except Exception:
            swatch_index = 0
        if swatch_index <= 0:
            swatch_index = fallback_index + 1
        result.append({
            "item_id": item_id,
            "variant_label": str(raw_variant.get("variant_label") or "样式 {}".format(swatch_index)),
            "swatch_index": swatch_index,
            "swatch_color": str(raw_variant.get("swatch_color") or ""),
            "origin": str(raw_variant.get("origin") or origin),
        })
    return result


def _outfit_editor_product_variants(data, current_cas_part_id, manager=None):
    """Resolve only verified sibling swatches for one worn CASPart.

    Resolution order is intentionally conservative:
      1. CAS-exported collection snapshot (stable base_id -> all exported swatches)
      2. already-supported external/tuning accessory catalog
      3. current CASPart only

    The function NEVER guesses sibling IDs.  Arbitrary EA/CC items that are not
    represented by either verified source remain current-only until the native
    GetCatalogVariantItems bridge is promoted from diagnostic code to a
    separately validated production path.
    """
    try:
        current_cas_part_id = int(current_cas_part_id or 0)
    except Exception:
        current_cas_part_id = 0

    item = variant = None
    try:
        item, variant = _caslib_find_item_by_variant(data, current_cas_part_id)
    except Exception:
        item = variant = None

    result = []
    source = "current_only"
    product_meta = item if isinstance(item, dict) else None

    # Source 1: exact CAS collection product.  This is the richest source
    # because CAS export already stores all known sibling CASPart IDs + colors.
    if isinstance(item, dict):
        for fallback_index, raw_variant in enumerate(item.get("variants", ()) or ()):
            try:
                item_id = int(raw_variant.get("cas_part_id") or 0)
            except Exception:
                item_id = 0
            if not item_id:
                continue
            try:
                style_index = int(raw_variant.get("style_index", fallback_index) or 0)
            except Exception:
                style_index = fallback_index
            result.append({
                "item_id": item_id,
                "variant_label": "样式 {}".format(style_index + 1),
                "swatch_index": style_index + 1,
                "swatch_color": _caslib_swatch_hex(raw_variant),
                "origin": "outfit_collection",
            })
        if result:
            source = "collection"

    # Source 2: the already-supported external/tuning catalog.  Use it only
    # when it contains this exact concrete CASPart ID and it improves on what
    # the local snapshot knows.  Accessory Library data/caches are read-only.
    try:
        external_catalog, _external_index = _caslib_external_snapshot(manager)
        external_product = _outfit_editor_find_catalog_product(
            external_catalog, current_cas_part_id
        )
    except Exception:
        external_product = None
    if external_product is not None:
        external_variants = _outfit_editor_copy_product_variants(
            external_product, origin="outfit_external"
        )
        if len(external_variants) > len(result):
            result = external_variants
            product_meta = external_product
            source = "external"

    if current_cas_part_id and not any(
        int(v.get("item_id") or 0) == current_cas_part_id for v in result
    ):
        result.insert(0, {
            "item_id": current_cas_part_id,
            "variant_label": "当前样式",
            "swatch_index": 1,
            "swatch_color": "",
            "origin": "outfit_current",
        })

    if not result and current_cas_part_id:
        result = [{
            "item_id": current_cas_part_id,
            "variant_label": "当前样式",
            "swatch_index": 1,
            "swatch_color": "",
            "origin": "outfit_current",
        }]
        source = "current_only"

    # Stable swatch order, without changing product identity.  Do not move the
    # current swatch to the front: the UI uses swatch_index for natural order.
    result.sort(key=lambda row: (
        int(row.get("swatch_index") or 0) if int(row.get("swatch_index") or 0) > 0 else 999999,
        int(row.get("item_id") or 0),
    ))
    return result, product_meta, source

def _outfit_editor_catalog(manager, sim_info, category, index):
    parts = _outfit_editor_parts(sim_info, category, index)
    groups = _outfit_editor_group_names(parts)
    selected_group = _outfit_ui_selected_part_group(manager)
    if selected_group not in groups:
        selected_group = None
        _outfit_ui_set_selected_part_group(manager, None)
    try:
        data = _caslib_load()
    except Exception:
        data = {}
    catalog = []
    selected_ids = []
    for part in parts:
        cas_part_id = int(part.get("cas_part_id") or 0)
        if not cas_part_id:
            continue
        body_type = int(part.get("body_type") or 0)
        body_type_name = str(part.get("body_type_name") or body_type)
        group = _outfit_ui_part_group(body_type_name)
        if selected_group and group != selected_group:
            continue
        variants, item, variant_source = _outfit_editor_product_variants(
            data, cas_part_id, manager=manager
        )
        try:
            manager.fgeh_pose_manager_debug_log(
                "[R28_OUTFIT_SWATCH_SOURCE_PY] part={} id={} source={} variants={}".format(
                    body_type_name, cas_part_id, variant_source, len(variants)
                )
            )
        except Exception:
            pass
        library_label = ""
        if isinstance(item, dict):
            library_label = str(item.get("display_name") or item.get("name") or "").strip()
        friendly = _outfit_ui_part_friendly_name(body_type_name)
        # Keep the player-facing body-type label first.  A useful library name
        # may follow, but never expose HAIR/WRIST_RIGHT debug enum text.
        product_label = friendly if not library_label else "{} · {}".format(friendly, library_label)
        catalog.append({
            "product_key": "outfitpart:{}:{}".format(int(part.get("part_index") or 0), body_type),
            "product_label": product_label,
            "key_source": "outfit:{}".format(group),
            "variants": variants,
        })
        selected_ids.append(cas_part_id)
    return catalog, selected_ids, groups, selected_group, parts


def _schedule_outfit_detail_panel(manager, owner, on_pack_selected, reason):
    import alarms
    from date_and_time import TimeSpan
    holder = {}

    def _reopen(_handle):
        handle = holder.get("handle")
        if handle is not None:
            _PENDING_REOPEN_ALARMS.pop(id(handle), None)
        _show_outfit_detail_panel(owner, on_pack_selected=on_pack_selected)

    try:
        handle = alarms.add_alarm_real_time(owner, TimeSpan.ZERO, _reopen, use_sleep_time=False)
    except Exception:
        handle = alarms.add_alarm(owner, TimeSpan.ZERO, _reopen)
    holder["handle"] = handle
    _PENDING_REOPEN_ALARMS[id(handle)] = handle
    try:
        manager.fgeh_pose_manager_debug_log(
            "[R28_OUTFIT_DETAIL] reopen scheduled reason={} handle={}".format(reason, id(handle))
        )
    except Exception:
        pass


def _show_outfit_detail_panel(owner, on_pack_selected=None):
    """Dedicated Outfit detail page using the already-proven CAS product renderer.

    This creates a NEW outfit-specific data source.  It does not mutate the
    Accessory Library catalog or its saved groups.  The shared GFX component is
    reused as a rendering capability only.
    """
    global LAST_ERROR
    LAST_ERROR = ""
    try:
        import couplepose1 as manager
        from distributor.shared_messages import IconInfoData
        from event_testing.resolver import SingleSimResolver
        from sims4.localization import LocalizationHelperTuning
        from ui.ui_dialog import UiDialogResponse
        from ui.ui_dialog_labeled_icons import UiDialogIcons

        sim_info = _caslib_target_from_state(manager) or _v8944_dialog_portrait_sim_info(owner, on_pack_selected)
        live_owner = getattr(sim_info, "get_sim_instance", lambda: owner)()
        if live_owner is None:
            LAST_ERROR = "active Sim instance is unavailable"
            return False
        key = _outfit_ui_current_key(manager)
        if key is None:
            _schedule_root_reopen(manager, owner, on_pack_selected, "outfit-detail-missing-key")
            return False
        category, index = key
        real_keys = set(_outfit_phase1._real_outfit_keys(sim_info, regular_only=False) or ()) if _outfit_phase1 else set()
        if (int(category), int(index)) not in real_keys:
            _outfit_ui_reset(manager)
            _schedule_root_reopen(manager, owner, on_pack_selected, "outfit-detail-stale-key")
            return False

        # Right-click selects only the save destination. Read/edit current wear.
        # Wearing a saved outfit belongs exclusively to the left-click path.
        _r30_editor.begin(sim_info, (category, index))
        try:
            manager.state.custom_pose_ui_cas_library_target_sim_id = int(getattr(sim_info, "sim_id", 0) or 0)
        except Exception:
            pass

        catalog, selected_ids, groups, selected_group, parts = _outfit_editor_catalog(
            manager, sim_info, *_r30_editor.catalog_key(sim_info, (category, index))
        )
        title = "覆盖目标：{} · 第{}套".format(_outfit_ui_category_label(category), int(index) + 1)
        rows = [{
            "pack_id": "outfit-editor:product-ui",
            "name": "当前服装部件",
            "creator": "{} 个部件 · R49 Native 色卡桥".format(len(catalog)),
            "pose_count": len(catalog),
            "favorite": False,
            "icon_index": -1,
            "kind": "pose",
        }]
        header = {
            "page": 0,
            "page_count": 1,
            "page_label": "",
            "filter": "outfit_editor",
            "query": "",
            "navigation_mode": "scroll",
            "navigation_label": _r30_editor.preview_url(sim_info, category, index),
            "item_count": 1,
            "view_title": "服装详情 · {}".format(title),
            "library_label": "← 返回服装列表 · R49",
            "enable_v7": True,
            # Reuse the proven product/swatch renderer.  active_nav=6 is a
            # presentation contract only; manager.state remains Outfit Manager.
            "view_kind": "pack_detail_linked",
            "active_nav": NAV_ACCESSORY_LIBRARY,
            "group_names": groups,
            "active_group_index": (groups.index(selected_group) if selected_group in groups else -1),
            "outer_group_names": [],
            "outer_group_selected": [],
            "edit_keys": [""],
            "edit_names": [""],
            "edit_notes": [""],
            "linked_detail": True,
            # Use the AccessoryLibrary renderer identity so its mature 4-column
            # cards + fixed preview + swatches are reused byte-for-byte.
            "linked_pack_id": _CASLIB_VIRTUAL_PACK_ID,
            # Existing string already present in GFX and distinct from the real
            # CAS library virtual pose; useful as an Outfit-detail canary marker.
            "linked_detail_rows": [{
                "pose_name": _OUTFIT_EDITOR_POSE_NAME,
                "cas_auto": True,
                "object_auto": False,
                "resources": [],
                "object_products": (),
                "cas_products": (),
            }],
            "linked_cas_catalogs": [catalog],
            "linked_cas_pose_states": [{
                "pose_name": _OUTFIT_EDITOR_POSE_NAME,
                "catalog_index": 0,
                "cas_auto": True,
                # This is a browse/editor surface, not binding mode. Keep the
                # library's selection dots clear; the highlighted product is
                # owned by the existing hover/preview renderer.
                "selected_ids": [],
            }],
            "linked_edit_items": [],
        }
        _v8951_attach_global_widget_state(header, manager)
        _attach_ui_localization(header)
        _perf_log(
            manager,
            "PERF OUTFIT_DETAIL_R49_NATIVE_SWATCH armed=1 parts={} products={} group={!r}".format(
                len(parts), len(catalog), selected_group
            ),
        )
        raw_payload = pack_payload(header, rows)
        localized_payload = _localized_payload_cached("outfit-detail-r35", raw_payload, manager)
        blank = LocalizationHelperTuning.get_raw_text("")
        dialog = UiDialogIcons.TunableFactory().default(
            live_owner,
            resolver=SingleSimResolver(sim_info),
            title=_constant_localized_string(blank),
            text=_constant_localized_string(blank),
            additional_texts=localized_payload,
            show_dialog_message_override=SHOW_MESSAGE,
        )
        dialog.set_responses((UiDialogResponse(dialog_response_id=RESPONSE_BACK),))

        def _leave_editor(reason):
            # Navigation changes only UI state; temporary current wear persists.
            _outfit_ui_set_selected_part_group(manager, None)
            manager.state.custom_pose_ui_outfit_manager_mode = "outfits"
            manager.state.custom_pose_ui_scroll_row = 0
            _schedule_root_reopen(manager, live_owner, on_pack_selected, reason)

        def _on_response(response_dialog):
            try:
                response = getattr(response_dialog, "response", None)
                try:
                    response_value = int(response)
                except Exception:
                    response_value = response

                if response_value in (_r30_editor.REMOVE_RESPONSE, _r30_editor.CLEAR_RESPONSE):
                    try:
                        if response_value == _r30_editor.REMOVE_RESPONSE:
                            success, message = _r30_editor.consume_remove(sim_info, response_dialog.dialog_id, manager, _r30_sys.modules[__name__])
                        else:
                            success, message = _r30_editor.clear_category(sim_info, manager, _r30_sys.modules[__name__])
                    except Exception:
                        success, message = False, "移除未完成：当前服装状态可能已改变，请重新进入"
                        manager.fgeh_pose_manager_debug_log("[R49_REMOVE] failed", exc=True)
                    _r30_editor.notify(live_owner, message)
                    _schedule_outfit_detail_panel(manager, live_owner, on_pack_selected, "r35-remove")
                    return
                if response_value in (_r30_editor.SAVE_RESPONSE, _r30_editor.REFRESH_RESPONSE):
                    if response_value == _r30_editor.SAVE_RESPONSE:
                        success, message = _r30_editor.commit(sim_info, (category, index))
                        _r30_editor.notify(live_owner, message)
                        manager.fgeh_pose_manager_debug_log("[R49_OUTFIT_SAVE] success={} key={} message={}".format(success, (category, index), message))
                    _schedule_outfit_detail_panel(manager, live_owner, on_pack_selected, "r30-save-or-refresh")
                    return
                if response_value == RESPONSE_LINKED_RESTORE_OUTFIT:
                    _v8966_restore_original_outfit(sim_info)
                    _schedule_outfit_detail_panel(manager, live_owner, on_pack_selected, "r30-restore")
                    return
                group_action = decode_group_response(response_value)
                if group_action is not None:
                    action, action_index = group_action
                    if action == "tab":
                        if int(action_index or 0) == 0:
                            _outfit_ui_set_selected_part_group(manager, None)
                        else:
                            gi = int(action_index) - 1
                            _outfit_ui_set_selected_part_group(
                                manager, groups[gi] if 0 <= gi < len(groups) else None
                            )
                        _schedule_outfit_detail_panel(
                            manager, live_owner, on_pack_selected,
                            "outfit-detail-group:{}".format(action_index),
                        )
                    return

                if response_value == RESPONSE_BACK:
                    _leave_editor("outfit-detail-back")
                    return

                nav_index = decode_nav_response(response_value)
                if nav_index is not None:
                    # Sidebar navigation preserves current temporary wear.
                    manager.state.custom_pose_ui_active_nav = nav_index
                    _outfit_ui_set_selected_part_group(manager, None)
                    _v7_reset_subview(manager)
                    _nav_switch_root(manager, save=False)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected,
                        "outfit-detail-nav:{}".format(nav_index),
                    )
                    return

                # Closing the editor preserves current temporary wear.
                _nav_persist(manager)
            except Exception:
                try:
                    manager.fgeh_pose_manager_debug_log("[R49_OUTFIT_DETAIL] response failed", exc=True)
                except Exception:
                    pass

        dialog.show_dialog(
            on_response=_on_response,
            icon_override=IconInfoData(),
            additional_icons=(),
        )
        try:
            manager.fgeh_pose_manager_debug_log(
                "[R49_OUTFIT_DETAIL] shown key=({}, {}) parts={} products={} group={!r}".format(
                    category, index, len(parts), len(catalog), selected_group
                )
            )
        except Exception:
            pass
        return True
    except Exception:
        LAST_ERROR = traceback.format_exc()
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log("[R49_OUTFIT_DETAIL] show failed", exc=True)
        except Exception:
            pass
        return False


def _outfit_ui_current_key(manager):
    try:
        category = int(getattr(manager.state, _OUTFIT_UI_CATEGORY_ATTR))
        index = int(getattr(manager.state, _OUTFIT_UI_INDEX_ATTR))
        if category >= 0 and index >= 0:
            return category, index
    except Exception:
        pass
    return None


def _outfit_ui_icon(manager):
    return _valid_icon_resource(
        manager,
        getattr(manager, "MANAGE_ICON", None),
        "outfit_manager_icon",
    ) or _valid_icon_resource(
        manager,
        getattr(manager, "MY_CUSTOM_ICON", None),
        "outfit_manager_fallback_icon",
    )


def _outfit_ui_thumbnail_url(sim_info, category, index):
    """Return EA's native whole-body Outfit thumbnail URL."""
    try:
        sim_id = str(int(getattr(sim_info, "sim_id", 0) or 0))
        category = int(category)
        index = int(index)
    except Exception:
        return ""
    if sim_id == "0":
        return ""
    return "img://thumbs/sims/w_{}_l_{}_{}".format(sim_id, category, index)



def _outfit_ui_switch_saved_outfit(manager, category, index):
    """Switch the active Sim to one already-saved EA Outfit.

    This is deliberately *not* the CAS Library temporary SPECIAL-outfit path
    and it does not create a restore backup.  It is the same user-level action
    as choosing another already-existing outfit: only the current outfit key
    changes.
    """
    if _outfit_phase1 is None:
        return False
    try:
        sim_info = _caslib_target_from_state(manager)
    except Exception:
        sim_info = None
    if sim_info is None:
        return False
    try:
        category = int(category)
        index = int(index)
        key = (category, index)
        try:
            if hasattr(sim_info, "has_outfit") and not sim_info.has_outfit(key):
                manager.fgeh_pose_manager_debug_log(
                    "[OUTFIT_MANAGER] left-click switch rejected missing key={}".format(key)
                )
                return False
        except TypeError:
            # Some builds expose has_outfit(category, index) rather than tuple.
            try:
                if not sim_info.has_outfit(category, index):
                    return False
            except Exception:
                pass
        result = sim_info.set_current_outfit(key)
        if result is not False:
            from fgeh_cas_accessory_outfit_utils import mark_manual_current_outfit
            mark_manual_current_outfit(sim_info)
        try:
            sim_info.resend_current_outfit()
        except Exception:
            pass
        manager.fgeh_pose_manager_debug_log(
            "[OUTFIT_MANAGER] left-click switched saved outfit key={} result={!r}".format(
                key, result
            )
        )
        return True
    except Exception:
        try:
            manager.fgeh_pose_manager_debug_log(
                "[OUTFIT_MANAGER] left-click switch failed category={} index={}".format(
                    category, index
                ),
                exc=True,
            )
        except Exception:
            pass
        return False

def _outfit_ui_rows(manager):
    """Build the integrated Outfit Manager dataset without mutating EA outfits."""
    if _outfit_ui_mode(manager) == "settings":
        return _v8918_settings_rows(manager)

    rows, icons, packs = [], [], []
    icon = _outfit_ui_icon(manager)
    sim_info = None
    try:
        if _outfit_phase1 is not None:
            sim_info = _caslib_target_from_state(manager)
    except Exception:
        sim_info = None

    if sim_info is None or _outfit_phase1 is None:
        rows.append({
            "pack_id": "outfit:unavailable",
            "name": "当前没有可读取的小人",
            "creator": "请先在生活模式选中一个 Sim。",
            "pose_count": "",
            "favorite": False,
            "icon_index": 0,
            "kind": "outfit_manager_info",
            "value": "unavailable",
        })
        icons.append(icon)
        packs.append(None)
        return rows, icons, packs

    mode = _outfit_ui_mode(manager)
    if mode == "parts":
        key = _outfit_ui_current_key(manager)
        if key is None:
            _outfit_ui_reset(manager)
            return _outfit_ui_rows(manager)
        category, index = key
        try:
            parts = _outfit_phase1._part_rows(sim_info, category, index) or ()
        except Exception:
            parts = ()
        for part in parts:
            part_index = int(part.get("part_index", 0) or 0)
            cas_part_id = int(part.get("cas_part_id", 0) or 0)
            body_type_name = str(part.get("body_type_name", "") or part.get("body_type", ""))
            library_label, library_icon = _outfit_ui_part_library_meta(cas_part_id)
            rows.append({
                "pack_id": "outfitpart:{}:{}:{}".format(category, index, part_index),
                "name": library_label or _outfit_ui_part_display_name(body_type_name),
                "creator": "",
                "pose_count": "",
                "favorite": False,
                "icon_index": len(icons),
                "kind": "outfit_manager_part",
                "value": str(part_index),
                "outfit_body_type": int(part.get("body_type", 0) or 0),
                "outfit_body_type_name": body_type_name,
            })
            icons.append(library_icon or icon)
            packs.append(None)
        if not rows:
            rows.append({
                "pack_id": "outfitparts:empty",
                "name": "没有读取到服装部件",
                "creator": "该 Outfit 的 parts 数据为空或当前版本无法解析。",
                "pose_count": "",
                "favorite": False,
                "icon_index": 0,
                "kind": "outfit_manager_info",
                "value": "empty",
            })
            icons.append(icon)
            packs.append(None)
        return rows, icons, packs

    # Main Outfit list.  IMPORTANT: enumerate only real keys; never probe
    # category slots with get_outfit(), because that can generate missing outfits.
    try:
        keys = tuple(_outfit_phase1._real_outfit_keys(sim_info, regular_only=True) or ())
    except Exception:
        keys = ()

    browse_category = _outfit_ui_browse_category(manager)
    if browse_category is not None:
        keys = tuple(key for key in keys if int(key[0]) == int(browse_category))

    for category, index in keys:
        label = _outfit_ui_category_label(category)
        # R18: transport the three native Outfit-thumbnail identity values
        # separately instead of prebuilding an img:// URL in Python.
        #
        #   pack_id      -> sim_id (string-safe for 64-bit IDs)
        #   icon_index   -> packed category/index token, category*16+index
        #
        # GFX root_outfits calls EA ImageUtils.CreateOutfitImageUrl itself,
        # exactly like the verified native/canary path.  creator/count stay
        # visually empty so the root card is image-first rather than a debug row.
        sim_id_text = str(int(getattr(sim_info, "sim_id", 0) or 0))
        outfit_token = int(category) * 16 + int(index)
        rows.append({
            "pack_id": sim_id_text,
            # R20: EA-picker-style image card.  The OutfitCategory tabs already
            # establish context, so the card itself carries no visible text.
            "name": "",
            "creator": "",
            "pose_count": "",
            "favorite": False,
            "icon_index": outfit_token,
            "kind": "outfit_manager_outfit",
            "value": "{}:{}".format(category, index),
            "sort_key": "outfit:{}:{}".format(category, index),
            "outfit_category": int(category),
            "outfit_index": int(index),
        })
        icons.append(icon)
        packs.append(None)

    # R17: Settings is a true sidebar root again and whole-body thumbnails
    # render directly on Outfit cards, so this page contains only real outfits.

    return rows, icons, packs

def _v8918_toggle_setting(manager, key):
    if key == 'freeze_needs_while_posing':
        import fgeh_pose_need_freeze
        return fgeh_pose_need_freeze.toggle(manager)
    defaults = {
        "restore_last_view_on_open": True,
        "filter_blank_poses": True,
        "auto_apply_linked_requirements": True,
        "restore_linked_requirements_when_pose_chain_finished": False,
        "auto_destroy_linked_objects": True,
        "replace_linked_objects_on_replay": True,
    }

    if key not in defaults:
        return None

    old_value = bool(getattr(manager.state, key, defaults[key]))
    new_value = not old_value
    setattr(manager.state, key, new_value)
    manager.save_favorites()

    manager.fgeh_pose_manager_debug_log(
        "[SETTINGS] build={} key={} old={} new={}".format(
            UI_BUILD_TAG,
            key,
            old_value,
            new_value,
        )
    )
    return new_value



_V8934_LINKED_VIEW_PERSIST_KEY = "__fgeh_ui_linked_view_mode__"


def _v89_linked_view_mode(manager):
    """0 = 全部联动；1 = 分组联动（镜像 grouped_packs）。

    V8.9.34 persists the choice through the existing ``custom_names`` dict so
    old state files remain valid without changing fgeh_state.py.
    """
    try:
        value = int(getattr(manager.state, "custom_pose_ui_linked_view_mode"))
        return 1 if value == 1 else 0
    except Exception:
        pass

    try:
        custom_names = getattr(manager.state, "custom_names", {}) or {}
        value = int(custom_names.get(_V8934_LINKED_VIEW_PERSIST_KEY, 0))
    except Exception:
        value = 0

    value = 1 if value == 1 else 0
    try:
        manager.state.custom_pose_ui_linked_view_mode = value
    except Exception:
        pass
    return value


def _v8934_persist_linked_view_mode(manager, value):
    value = 1 if int(value or 0) == 1 else 0
    try:
        manager.state.custom_pose_ui_linked_view_mode = value
    except Exception:
        pass

    try:
        custom_names = getattr(manager.state, "custom_names", {}) or {}
        if not isinstance(custom_names, dict):
            custom_names = {}
        custom_names[_V8934_LINKED_VIEW_PERSIST_KEY] = str(value)
        manager.state.custom_names = custom_names
        manager.save_favorites()
    except Exception:
        try:
            manager.save_favorites()
        except Exception:
            pass
    return value


def _v89_linked_view_label(manager):
    return (
        "视图：分组联动 ▸"
        if _v89_linked_view_mode(manager) == 1
        else "视图：全部联动 ▸"
    )


def _v89_linked_hidden_keys(manager):
    raw = getattr(manager.state, "linked_library_hidden_refs", {}) or {}
    if not isinstance(raw, dict):
        return set()
    return set(str(value) for value in (raw.get("all", ()) or ()) if value)


def _v89_all_linked_pose_refs(manager):
    if not getattr(manager.state, "cache_built", False):
        try:
            manager.build_cache_safe()
        except Exception:
            pass

    try:
        from fgeh_pose_requirement_registry import iter_linked_pose_refs
    except Exception:
        iter_linked_pose_refs = None

    try:
        refs = list(
            iter_linked_pose_refs(
                getattr(manager.state, "all_packs_cache", {}) or {},
                group_type=None,
            )
        ) if iter_linked_pose_refs is not None else []
    except Exception:
        refs = []

    hidden = _v89_linked_hidden_keys(manager)
    result = []
    seen = set()

    def _append(ref):
        pack_id = str(ref.get("pack_id", "") or "")
        pose_name = str(ref.get("pose_name", "") or "")
        key = (pack_id, pose_name)
        if not pack_id or not pose_name or key in seen:
            return
        if "{}::{}".format(pack_id, pose_name) in hidden:
            return
        seen.add(key)
        result.append(ref)

    for ref in refs:
        if isinstance(ref, dict):
            _append(ref)

    # H41: clicking “添加联动” registers a Pose even before it owns any CAS or
    # object resource.  These refs are merged with the old XML/local-resource
    # registry, so the Pose immediately appears in 联动动作 and opens the same
    # linked-management UI with an initially empty resource list.
    try:
        from fgeh_linked_cas_bindings import iter_managed_actions
        markers = list(iter_managed_actions())
    except Exception:
        markers = []

    cache = getattr(manager.state, "all_packs_cache", {}) or {}
    for marker in markers:
        if not isinstance(marker, dict):
            continue
        pack_id = str(marker.get("pack_id", "") or "")
        pose_name = str(marker.get("pose_name", "") or "")
        if not pack_id or not pose_name or (pack_id, pose_name) in seen:
            continue
        pack = cache.get(pack_id) if isinstance(cache, dict) else None
        if pack is None and isinstance(cache, dict):
            for candidate in cache.values():
                try:
                    candidate_id = str(manager.get_pack_id(candidate) or "")
                except Exception:
                    candidate_id = ""
                if candidate_id == pack_id:
                    pack = candidate
                    break
        if pack is None:
            continue
        pose_item = None
        for candidate in getattr(pack, "pose_list", ()) or ():
            if str(getattr(candidate, "pose_name", "") or "") == pose_name:
                pose_item = candidate
                break
        if pose_item is None:
            continue
        _append({
            "group_type": "managed",
            "pack_id": pack_id,
            "pose_name": pose_name,
            "pack": pack,
            "pose_item": pose_item,
        })

    return result


def _v89_unhide_linked_ref(manager, pack_id, pose_name):
    key = "{}::{}".format(str(pack_id or ""), str(pose_name or ""))
    raw = getattr(manager.state, "linked_library_hidden_refs", {}) or {}
    if not isinstance(raw, dict):
        return False
    values = list(raw.get("all", ()) or ())
    filtered = [value for value in values if str(value) != key]
    if len(filtered) == len(values):
        return False
    updated = dict(raw)
    updated["all"] = filtered
    manager.state.linked_library_hidden_refs = updated
    try:
        manager.save_favorites()
    except Exception:
        pass
    return True


def _register_managed_linked_action(manager, pack_id, pose_name):
    _h49_trace("REGISTER_BEGIN pack={!r} pose={!r}".format(pack_id, pose_name))
    try:
        from fgeh_linked_cas_bindings import ensure_managed_action, iter_managed_actions
        ok = bool(ensure_managed_action(pack_id, pose_name))
    except Exception:
        _h49_trace("REGISTER_ENSURE_EXCEPTION pack={!r} pose={!r}".format(pack_id, pose_name), exc=True)
        ok = False
        iter_managed_actions = None
    persisted = False
    if ok:
        try:
            if iter_managed_actions is not None:
                persisted = any(
                    str(action.get("pack_id", "") or "") == str(pack_id or "")
                    and str(action.get("pose_name", "") or "") == str(pose_name or "")
                    for action in iter_managed_actions()
                    if isinstance(action, dict)
                )
        except Exception:
            _h49_trace("REGISTER_VERIFY_EXCEPTION", exc=True)
            persisted = False
        # Re-adding a pose is an explicit request to make it visible again.
        _v89_unhide_linked_ref(manager, pack_id, pose_name)
        _caslib_refresh_requirement_cache()
        visible_now = False
        try:
            visible_now = any(
                str(ref.get("pack_id", "") or "") == str(pack_id or "")
                and str(ref.get("pose_name", "") or "") == str(pose_name or "")
                for ref in _v89_all_linked_pose_refs(manager)
                if isinstance(ref, dict)
            )
        except Exception:
            _h49_trace("REGISTER_VISIBLE_EXCEPTION", exc=True)
            visible_now = False
        _h49_trace(
            "REGISTER_RESULT pack={!r} pose={!r} ok={} persisted={} visible_now={}".format(
                pack_id, pose_name, ok, persisted, visible_now
            )
        )
        try:
            manager.fgeh_pose_manager_debug_log(
                "[H50_LINK_REGISTER] pack={} pose={} persisted={} visible_now={}".format(
                    pack_id, pose_name, persisted, visible_now
                )
            )
        except Exception:
            pass
    else:
        _h49_trace("REGISTER_RESULT pack={!r} pose={!r} ok=False".format(pack_id, pose_name))
    return bool(ok and persisted)


def _real_pose_names_for_pack(manager, pack_id, pack=None):
    """Return only real Pose names owned by this pack; no UI pseudo rows."""
    result = []
    seen = set()
    if pack is None:
        try:
            pack = (getattr(manager.state, "all_packs_cache", {}) or {}).get(str(pack_id or ""))
        except Exception:
            pack = None
    for pose_item in getattr(pack, "pose_list", ()) or ():
        pose_name = str(getattr(pose_item, "pose_name", "") or "").strip()
        if pose_name and pose_name not in seen:
            seen.add(pose_name)
            result.append(pose_name)
    return result


def _register_managed_linked_pack(manager, pack_id, pack=None, source="pack-detail"):
    pack_id = str(pack_id or "")
    pose_names = _real_pose_names_for_pack(manager, pack_id, pack=pack)
    _h49_trace(
        "PACK_REGISTER_BEGIN source={} pack={!r} pose_count={}".format(
            source, pack_id, len(pose_names)
        )
    )
    if not pack_id or not pose_names:
        _h49_trace(
            "PACK_REGISTER_RESULT source={} pack={!r} ok=False reason=no-real-poses".format(
                source, pack_id
            )
        )
        return False, 0
    try:
        from fgeh_linked_cas_bindings import ensure_managed_actions, iter_managed_actions
        ok = bool(ensure_managed_actions(pack_id, pose_names))
    except Exception:
        _h49_trace(
            "PACK_REGISTER_ENSURE_EXCEPTION source={} pack={!r}".format(source, pack_id),
            exc=True,
        )
        return False, 0

    wanted = set(pose_names)
    if ok:
        # An explicit pack-level add also restores anything the user previously
        # hid from the linked library.
        for pose_name in pose_names:
            _v89_unhide_linked_ref(manager, pack_id, pose_name)
        _caslib_refresh_requirement_cache()

    persisted = set()
    try:
        persisted = {
            str(action.get("pose_name", "") or "")
            for action in iter_managed_actions()
            if isinstance(action, dict)
            and str(action.get("pack_id", "") or "") == pack_id
            and str(action.get("pose_name", "") or "") in wanted
        }
    except Exception:
        _h49_trace("PACK_REGISTER_VERIFY_EXCEPTION", exc=True)

    success = bool(ok and wanted.issubset(persisted))
    _h49_trace(
        "PACK_REGISTER_RESULT source={} pack={!r} ok={} persisted={}/{} success={}".format(
            source, pack_id, ok, len(persisted), len(wanted), success
        )
    )
    try:
        manager.fgeh_pose_manager_debug_log(
            "[H50_PACK_REGISTER_ALL] source={} pack={} persisted={}/{} success={}".format(
                source, pack_id, len(persisted), len(wanted), success
            )
        )
    except Exception:
        pass
    return success, len(wanted)

def _v8918_linked_outer_groups(manager):
    groups = getattr(manager.state, "user_grouped_packs_groups", {}) or {}
    return groups if isinstance(groups, dict) else {}


def _v8918_selected_linked_outer_group(manager):
    selected = str(
        getattr(
            manager.state,
            "selected_linked_grouped_outer_name",
            "",
        ) or ""
    )
    groups = _v8918_linked_outer_groups(manager)

    if selected and selected in groups:
        return selected

    try:
        manager.state.selected_linked_grouped_outer_name = None
    except Exception:
        pass
    return None


def _v8918_linked_pack_ids(manager):
    result = set()
    for ref in _v89_all_linked_pose_refs(manager):
        pack_id = str(ref.get("pack_id", "") or "")
        if pack_id:
            result.add(pack_id)
    return result


def _v8918_linked_outer_group_cards(manager):
    """
    "分组联动" folders are NOT independently authored linked groups.

    They are derived automatically from:
        ACTION outer-group membership ∩ Packs that have linked requirements.

    Folder names therefore always mirror user_grouped_packs_groups.
    """
    linked_pack_ids = _v8918_linked_pack_ids(manager)
    outer_groups = _v8918_linked_outer_groups(manager)

    rows = []
    icons = []
    packs = []
    for group_name, members in outer_groups.items():
        member_list = [
            str(value)
            for value in (members or ())
            if value
        ]
        member_ids = set(member_list)
        intersection = [
            pack_id for pack_id in member_list
            if pack_id in linked_pack_ids
        ]

        # Empty intersections are not useful in the linked library.
        if not intersection:
            continue

        # Linked group folders mirror ACTION groups.  Reuse a manually chosen
        # outer-group cover when present; otherwise use the first linked Pack
        # thumbnail in the group's stored order.  If no Pack exposes a real
        # thumbnail, leave the icon blank so AS keeps the built-in llama.
        default_linked_icon = _v8960_first_group_pack_icon(
            manager,
            intersection,
        )
        linked_group_icon = _v8946_group_cover_icon(
            manager,
            "outer",
            group_name,
            member_ids,
            fallback=default_linked_icon,
        )

        rows.append({
            "pack_id": "linked_group:{}".format(group_name),
            "name": str(group_name),
            "creator": "动作分组 ∩ 联动动作",
            "pose_count": len(intersection),
            "favorite": False,
            "icon_index": len(icons),
            "kind": "linked_macro_group",
            "value": str(group_name),
        })
        icons.append(linked_group_icon)
        packs.append(None)

    return rows, icons, packs


def _v89_linked_pose_names_for_pack(manager, pack_id, grouped_only=None):
    pack_id = str(pack_id or "")
    if not pack_id:
        return set()

    names = set()
    for ref in _v89_all_linked_pose_refs(manager):
        if str(ref.get("pack_id", "") or "") != pack_id:
            continue
        pose_name = str(ref.get("pose_name", "") or "")
        if pose_name:
            names.add(pose_name)

    if grouped_only is None:
        grouped_only = (_v89_linked_view_mode(manager) == 1)

    if grouped_only:
        selected_group = _v8918_selected_linked_outer_group(manager)
        if selected_group:
            allowed = set(
                str(value)
                for value in (
                    _v8918_linked_outer_groups(manager).get(
                        selected_group,
                        (),
                    ) or ()
                )
                if value
            )
            if pack_id not in allowed:
                return set()

    # IMPORTANT:
    # Outer linked grouping filters PACK membership only.
    # It must never require or modify the Pack's inner Pose groups.
    return names


def _v89_linked_group_names_for_pack(
    manager,
    pack_id,
    group_dict,
    group_names,
):
    linked_names = _v89_linked_pose_names_for_pack(
        manager,
        pack_id,
        grouped_only=False,
    )
    if not linked_names:
        return []

    result = []
    for group_name in group_names or ():
        members = set(
            str(value)
            for value in (group_dict.get(group_name, ()) or ())
            if value
        )
        if members.intersection(linked_names):
            result.append(str(group_name))
    return result


# ------------------------------------------------------------------
# H32 CAS 收藏配件库 — JSON-backed browse / group / swatch / try-on
# ------------------------------------------------------------------
# The collection JSON is CAS-authoritative.  Life-mode browsing is read-only:
# group assignment / deletion still belongs to the CAS widget and arrives on
# the next CAS -> PLAY export.  This avoids two writers fighting over the same
# favorite set while still giving Pose Manager a real accessory library.
_CASLIB_ALL = "__FGEH_CASLIB_ALL__"
_CASLIB_UNGROUPED = "__FGEH_CASLIB_UNGROUPED__"

# H34: the standalone library reuses the exact linked-settings CAS product UI.
_CASLIB_VIRTUAL_PACK_ID = "__FGEH_CAS_LIBRARY__"
_CASLIB_VIRTUAL_POSE = "__FGEH_CAS_LIBRARY_BROWSE__"
_CASLIB_SOURCE_LOCAL = "local"
_CASLIB_SOURCE_EXTERNAL = "external"
_CASLIB_EXTERNAL_TAB = "游戏外绑定"
_CASLIB_LOCAL_TAB = "游戏内配件"
_CASLIB_EXTERNAL_CACHE = None
_CASLIB_EXTERNAL_BY_VARIANT = None


def _caslib_source(manager):
    value = str(getattr(manager.state, "custom_pose_ui_cas_library_source", "local") or "local").strip().lower()
    return _CASLIB_SOURCE_EXTERNAL if value == _CASLIB_SOURCE_EXTERNAL else _CASLIB_SOURCE_LOCAL


def _caslib_set_source(manager, source):
    source = _CASLIB_SOURCE_EXTERNAL if str(source or "").strip().lower() == _CASLIB_SOURCE_EXTERNAL else _CASLIB_SOURCE_LOCAL
    manager.state.custom_pose_ui_cas_library_source = source
    manager.state.custom_pose_ui_cas_library_group = None
    manager.state.custom_pose_ui_cas_library_base = None
    return source


def _caslib_active(manager):
    return _v7_active_nav(manager) == NAV_ACCESSORY_LIBRARY


def _caslib_group(manager):
    value = getattr(manager.state, "custom_pose_ui_cas_library_group", None)
    return None if value in (None, "") else str(value)


def _caslib_base(manager):
    value = getattr(manager.state, "custom_pose_ui_cas_library_base", None)
    return None if value in (None, "") else str(value)


def _caslib_reset(manager, leave_library=False):
    manager.state.custom_pose_ui_cas_library_group = None
    manager.state.custom_pose_ui_cas_library_base = None
    if leave_library:
        manager.state.custom_pose_ui_cas_library_source = _CASLIB_SOURCE_LOCAL


def _caslib_load():
    try:
        from fgeh_cas_collection_library import load_collection
        data = load_collection()
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _caslib_items_in_order(data):
    items = data.get("items", ()) or () if isinstance(data, dict) else ()
    by_base = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        base_id = str(item.get("base_id") or "")
        if base_id:
            by_base[base_id] = item
    result = []
    seen = set()
    for raw in (data.get("order", ()) or ()) if isinstance(data, dict) else ():
        base_id = str(raw or "")
        item = by_base.get(base_id)
        if item is not None and base_id not in seen:
            result.append(item)
            seen.add(base_id)
    for base_id, item in by_base.items():
        if base_id not in seen:
            result.append(item)
    return result


def _caslib_group_items(data, group_name):
    items = _caslib_items_in_order(data)
    if group_name in (None, _CASLIB_ALL):
        return items
    groups = data.get("groups", {}) or {} if isinstance(data, dict) else {}
    if group_name == _CASLIB_UNGROUPED:
        grouped = set()
        if isinstance(groups, dict):
            for values in groups.values():
                grouped.update(str(v) for v in (values or ()) if v)
        return [item for item in items if str(item.get("base_id") or "") not in grouped]
    allowed = set(str(v) for v in (groups.get(str(group_name), ()) or ())) if isinstance(groups, dict) else set()
    return [item for item in items if str(item.get("base_id") or "") in allowed]


def _caslib_thumbnail_resource(raw_value):
    """Rebuild the real 00B2D882 thumbnail ResourceKey captured in CAS.

    CC rows can legitimately carry ICON=0; those use Pose Manager's existing
    project fallback icon in H32.  Generating a live mannequin preview for
    icon-less CC is deliberately kept for the next visual pass and does not
    block the library/data workflow.
    """
    try:
        instance_id = int(str(raw_value or "0"), 10)
    except Exception:
        instance_id = 0
    if instance_id <= 0:
        return None
    try:
        import sims4.resources as _resources
        resource_key_cls = getattr(_resources, "ResourceKey", None)
        if resource_key_cls is not None:
            return resource_key_cls(0x00B2D882, 0, instance_id)
        return _resources.get_resource_key(instance_id, 0x00B2D882)
    except Exception:
        return None


def _caslib_variant_icon(variant):
    if not isinstance(variant, dict):
        return None
    return _caslib_thumbnail_resource(variant.get("icon_key_raw"))


def _caslib_product_icon(item):
    variants = list(item.get("variants", ()) or ()) if isinstance(item, dict) else []
    for variant in variants:
        if bool(variant.get("is_selected")):
            icon = _caslib_variant_icon(variant)
            if icon is not None:
                return icon
    for variant in variants:
        icon = _caslib_variant_icon(variant)
        if icon is not None:
            return icon
    return None


def _caslib_fallback_icon(manager):
    try:
        return _v8964_group_placeholder_icon(manager)
    except Exception:
        return None


def _caslib_add_row(rows, icons, packs, row, icon, manager):
    if icon is None:
        icon = _caslib_fallback_icon(manager)
    row = dict(row)
    row["icon_index"] = len(icons) if icon is not None else -1
    rows.append(row)
    icons.append(icon)
    packs.append(None)


def _caslib_source_label(item):
    source = str((item or {}).get("source_type") or "").strip().lower()
    return "CC" if source == "cc" else "EA"


def _caslib_color_label(variant):
    colors = list((variant or {}).get("colors", ()) or ())
    values = []
    for raw in colors[:3]:
        try:
            value = int(raw or 0) & 0xFFFFFFFF
        except Exception:
            value = 0
        if value:
            values.append("#{:06X}".format(value & 0xFFFFFF))
    return " / ".join(values)


def _caslib_group_names(data):
    groups = data.get("groups", {}) or {} if isinstance(data, dict) else {}
    return [str(name) for name in groups.keys()] if isinstance(groups, dict) else []


def _caslib_group_tab_window(manager, names):
    """Five visible native tabs; page large collections without truncating names."""
    names = list(names)
    if len(names) <= 5:
        manager.state.custom_pose_ui_cas_library_group_page = 0
        return names, [('group', name) for name in names]
    pages = (len(names) + 2) // 3
    try:
        page = int(getattr(manager.state, 'custom_pose_ui_cas_library_group_page', 0) or 0)
    except Exception:
        page = 0
    page = max(0, min(page, pages - 1))
    manager.state.custom_pose_ui_cas_library_group_page = page
    current = names[page * 3:page * 3 + 3]
    labels = ['‹ 分类'] + current + ['分类 ›']
    entries = [('page', max(0, page - 1))] + [('group', name) for name in current] + [('page', min(pages - 1, page + 1))]
    return labels, entries


def _caslib_select_group_tab(manager, entries, action_index):
    if int(action_index) == 0:
        manager.state.custom_pose_ui_cas_library_group = None
        return True
    index = int(action_index) - 1
    if not 0 <= index < len(entries):
        return False
    kind, value = entries[index]
    if kind == 'page':
        if value == getattr(manager.state, 'custom_pose_ui_cas_library_group_page', 0):
            return False
        manager.state.custom_pose_ui_cas_library_group_page = value
    else:
        if value == getattr(manager.state, 'custom_pose_ui_cas_library_group', None):
            return False
        manager.state.custom_pose_ui_cas_library_group = value
    return True


def _caslib_swatch_hex(variant):
    colors = list((variant or {}).get("colors", ()) or ())
    for raw in colors:
        try:
            value = int(raw or 0) & 0xFFFFFFFF
        except Exception:
            value = 0
        if value:
            return "#{:06X}".format(value & 0xFFFFFF)
    return ""


def _caslib_find_variant_any(data, cas_part_id):
    try:
        wanted = int(cas_part_id or 0)
    except Exception:
        wanted = 0
    if not wanted:
        return None, None
    for item in _caslib_items_in_order(data):
        for variant in item.get("variants", ()) or ():
            try:
                candidate = int(variant.get("cas_part_id") or 0)
            except Exception:
                candidate = 0
            if candidate == wanted:
                return item, variant
    return None, None


def _caslib_linked_products(data, selected_group=None):
    """Adapt CAS collection JSON into the proven LINKED_PRODUCTS_V2 schema."""
    products = []
    for item in _caslib_group_items(data, selected_group):
        base_id = str(item.get("base_id") or "")
        if not base_id:
            continue
        label = str(item.get("display_name") or "配件 {}".format(base_id))
        variants = []
        for local_index, variant in enumerate(item.get("variants", ()) or ()):
            try:
                item_id = int(variant.get("cas_part_id") or 0)
            except Exception:
                item_id = 0
            if not item_id:
                continue
            try:
                swatch_index = int(variant.get("style_index", local_index) or local_index)
            except Exception:
                swatch_index = local_index
            variants.append({
                "item_id": item_id,
                "variant_label": "样式 {}".format(swatch_index + 1),
                "swatch_index": swatch_index + 1,
                "swatch_color": _caslib_swatch_hex(variant),
                "origin": "local",
            })
        if not variants:
            continue
        products.append({
            "product_key": "cas_collection|{}".format(base_id),
            "product_label": label,
            "key_source": "cas_collection",
            "variants": variants,
        })
    return products


def _caslib_attach_linked_product_payload(header, manager, data):
    """Feed the standalone accessory library into the old linked CAS renderer.

    One synthetic linked row is enough: the V2 shared catalog carries all
    product + swatch metadata.  In bind mode we use the real pack/pose identity;
    in browse mode a reserved pseudo identity lets the command handler route a
    click to live try-on instead of saving a binding.
    """
    selected_group = _caslib_group(manager)
    products = _caslib_linked_products(data, selected_group)
    bind_pack, bind_pose = _caslib_binding_context(manager)
    binding = bool(bind_pack and bind_pose)
    # H58 component boundary: the GFX identity of AccessoryLibraryView is
    # ALWAYS synthetic.  The real target pack/pose belongs only to Python
    # binding context; never overload linked_pack_id with the business target.
    # H52's independent AccessoryLibraryView branch keys off this identity.
    linked_pack = _CASLIB_VIRTUAL_PACK_ID
    linked_pose = _CASLIB_VIRTUAL_POSE

    if binding:
        selected_ids = sorted(_caslib_bound_ids(manager))
    else:
        selected_ids = []
        # Preserve the CAS snapshot's currently-selected swatch as a visual
        # starting point without mutating anything in PLAY.
        for item in _caslib_group_items(data, selected_group):
            for variant in item.get("variants", ()) or ():
                if not bool(variant.get("is_selected")):
                    continue
                try:
                    value = int(variant.get("cas_part_id") or 0)
                except Exception:
                    value = 0
                if value:
                    selected_ids.append(value)
                    break

    header["view_kind"] = "pack_detail_linked"
    header["linked_detail"] = True
    header["linked_pack_id"] = linked_pack
    header["linked_detail_rows"] = ({
        "pose_name": linked_pose,
        "cas_auto": True,
        "object_auto": False,
        "resources": (),
        "object_products": (),
    },)
    header["linked_cas_catalogs"] = (tuple(products),)
    header["linked_cas_pose_states"] = ({
        "pose_name": linked_pose,
        "catalog_index": 0,
        "cas_auto": True,
        "selected_ids": tuple(selected_ids),
    },)
    return len(products)


def _caslib_binding_context(manager):
    pack_id = str(getattr(manager.state, "custom_pose_ui_bind_pack_id", "") or "")
    pose_name = str(getattr(manager.state, "custom_pose_ui_bind_pose_name", "") or "")
    return (pack_id, pose_name) if pack_id and pose_name else ("", "")


def _caslib_binding_scope(manager):
    value = str(getattr(manager.state, "custom_pose_ui_bind_scope", "") or "").strip().lower()
    return "pack" if value == "pack" else "pose"


def _caslib_binding_pose_names(manager, pack_id, anchor_pose_name):
    """Resolve the business target independently from AccessoryLibraryView identity.

    H59: the linked-library picker edits a whole Pose Pack.  The anchor Pose is
    retained only so Done can reopen the same LinkedActionEditor row.
    """
    pack_id = str(pack_id or "").strip()
    anchor_pose_name = str(anchor_pose_name or "").strip()
    if not pack_id:
        return []
    if _caslib_binding_scope(manager) != "pack":
        return [anchor_pose_name] if anchor_pose_name else []
    names = list(_real_pose_names_for_pack(manager, pack_id) or ())
    if anchor_pose_name and anchor_pose_name not in names:
        names.append(anchor_pose_name)
    return [str(name) for name in names if str(name or "").strip()]


def _caslib_binding_mode(manager):
    pack_id, pose_name = _caslib_binding_context(manager)
    return bool(pack_id and pose_name)


def _bind_select_mode_kind(manager):
    value = getattr(manager.state, "custom_pose_ui_bind_select_mode", False)
    if value in ("register", "cas"):
        return value
    return "cas" if bool(value) else ""


def _bind_select_mode(manager):
    return bool(_bind_select_mode_kind(manager))


def _clear_binding_context(manager, clear_select=True):
    if clear_select:
        manager.state.custom_pose_ui_bind_select_mode = False
    manager.state.custom_pose_ui_bind_pack_id = ""
    manager.state.custom_pose_ui_bind_pose_name = ""
    manager.state.custom_pose_ui_bind_scope = ""
    manager.state.custom_pose_ui_bind_return_nav = NAV_ALL_PACKS


def _caslib_bound_ids(manager):
    pack_id, pose_name = _caslib_binding_context(manager)
    if not pack_id or not pose_name:
        return set()
    try:
        from fgeh_linked_cas_bindings import get_saved_cas_part_ids_for_pose
        targets = _caslib_binding_pose_names(manager, pack_id, pose_name)
        if not targets:
            return set()
        shared = None
        for target_pose in targets:
            _asset_ids, binding_ids = get_saved_cas_part_ids_for_pose(pack_id, target_pose)
            current = set(int(value) for value in (binding_ids or ()) if int(value or 0))
            shared = current if shared is None else shared.intersection(current)
        return shared or set()
    except Exception:
        return set()


def _caslib_find_item_variant(data, base_id, cas_part_id):
    base_id = str(base_id or "")
    try:
        cas_part_id = int(cas_part_id or 0)
    except Exception:
        cas_part_id = 0
    for item in _caslib_items_in_order(data):
        if str(item.get("base_id") or "") != base_id:
            continue
        for variant in item.get("variants", ()) or ():
            try:
                candidate = int(variant.get("cas_part_id") or 0)
            except Exception:
                candidate = 0
            if candidate == cas_part_id:
                return item, variant
    return None, None


def _caslib_refresh_requirement_cache():
    try:
        from fgeh_pose_requirement_registry import clear_requirement_cache
        clear_requirement_cache()
    except Exception:
        pass


def _caslib_sync_pose_enabled_choices(manager, pack_id, pose_name):
    try:
        from fgeh_linked_cas_bindings import get_saved_cas_part_ids_for_pose
        _asset_ids, binding_ids = get_saved_cas_part_ids_for_pose(pack_id, pose_name)
        ids = sorted(set(int(v) for v in (binding_ids or ()) if int(v or 0)))
    except Exception:
        ids = []
    try:
        manager.set_enabled_linked_cas_part_ids(pack_id, pose_name, ids)
        manager.set_linked_cas_apply_enabled(pack_id, pose_name, bool(ids))
    except Exception:
        pass
    return ids


def _caslib_toggle_binding(manager, base_id, cas_part_id):
    """Toggle one collection product for the binding target scope.

    H59: LinkedActionEditor -> AccessoryLibraryView uses PACK scope. One click
    therefore normalizes that product across every real Pose in the Pack.
    Different products still coexist; sibling swatches of one product remain
    mutually exclusive.
    """
    pack_id, pose_name = _caslib_binding_context(manager)
    if not pack_id or not pose_name:
        return False
    target_poses = _caslib_binding_pose_names(manager, pack_id, pose_name)
    if not target_poses:
        return False
    data = _caslib_load()
    item, variant = _caslib_find_item_variant(data, base_id, cas_part_id)
    if item is None or variant is None:
        return False
    try:
        cas_part_id = int(cas_part_id or 0)
    except Exception:
        return False

    sibling_ids = []
    for sibling in item.get("variants", ()) or ():
        try:
            value = int(sibling.get("cas_part_id") or 0)
        except Exception:
            value = 0
        if value and value not in sibling_ids:
            sibling_ids.append(value)

    # In pack scope a product is visually selected only when every target Pose
    # owns it.  Old partial per-Pose states therefore converge on the next click.
    shared_bound = _caslib_bound_ids(manager)
    remove_product = cas_part_id in shared_bound
    display_name = str(
        item.get("display_name")
        or item.get("catalog_name")
        or "配件 {}".format(item.get("base_id") or "")
    )
    try:
        from fgeh_linked_cas_bindings import set_cas_collection_product_for_poses
        changed = bool(set_cas_collection_product_for_poses(
            pack_id,
            target_poses,
            sibling_ids,
            0 if remove_product else cas_part_id,
            body_type=int(item.get("body_type") or 0),
            display_name=display_name,
            source_type=str(item.get("source_type") or "unknown"),
            body_group="body_type_{}".format(int(item.get("body_type") or 0)),
        ))
    except Exception:
        changed = False

    if changed:
        _caslib_refresh_requirement_cache()
        synced = {}
        for target_pose in target_poses:
            synced[target_pose] = _caslib_sync_pose_enabled_choices(
                manager, pack_id, target_pose
            )
        try:
            manager.fgeh_pose_manager_debug_log(
                "[H59_PACK_CAS_BIND] pack={} anchor={} targets={} product={} toggled={} remove={} synced={}".format(
                    pack_id, pose_name, len(target_poses), base_id, cas_part_id,
                    remove_product, synced
                )
            )
        except Exception:
            pass
    return changed

def _h70w7_arm_linked_reenter(manager, pack_id, pose_name):
    """One-shot semantic return target for a fresh Linked Settings payload."""
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    if not pack_id or not pose_name:
        return False
    try:
        manager.state.custom_pose_ui_linked_reenter_pack_id = pack_id
        manager.state.custom_pose_ui_linked_reenter_pose_name = pose_name
        return True
    except Exception:
        return False


def _caslib_find_item_by_variant(data, cas_part_id):
    try:
        cas_part_id = int(cas_part_id or 0)
    except Exception:
        return None, None
    for item in _caslib_items_in_order(data):
        for variant in item.get("variants", ()) or ():
            try:
                candidate = int(variant.get("cas_part_id") or 0)
            except Exception:
                candidate = 0
            if candidate == cas_part_id:
                return item, variant
    return None, None

def _caslib_return_to_bound_pose(manager, owner):
    global _ACTIVE_PLAY_CONTEXT
    context = _ACTIVE_PLAY_CONTEXT if isinstance(_ACTIVE_PLAY_CONTEXT, dict) else None
    if not context:
        _clear_binding_context(manager)
        manager.state.custom_pose_ui_active_nav = NAV_ALL_PACKS
        _caslib_reset(manager)
        return False

    pack = context.get("pack")
    if pack is None:
        return False
    try:
        return_nav = int(getattr(manager.state, "custom_pose_ui_bind_return_nav", NAV_ALL_PACKS))
    except Exception:
        return_nav = NAV_ALL_PACKS

    _clear_binding_context(manager)
    _caslib_reset(manager)
    manager.state.custom_pose_ui_active_nav = return_nav
    manager.state.custom_pose_ui_scroll_row = 0
    _v7_reset_subview(manager)
    _nav_switch_root(manager, save=False)
    _nav_enter_pack(manager, pack, save=False)

    import alarms
    from date_and_time import TimeSpan
    holder = {}
    def _reopen(_handle):
        h = holder.get("handle")
        if h is not None:
            _PENDING_REOPEN_ALARMS.pop(id(h), None)
        show_pose_manager_pack_detail(
            owner,
            pack,
            on_item_selected=context.get("on_item_selected"),
            on_back=context.get("on_back"),
        )
    try:
        handle = alarms.add_alarm_real_time(owner, TimeSpan.ZERO, _reopen, use_sleep_time=False)
    except Exception:
        handle = alarms.add_alarm(owner, TimeSpan.ZERO, _reopen, repeating=False)
    holder["handle"] = handle
    _PENDING_REOPEN_ALARMS[id(handle)] = handle
    return True


def _caslib_build_rows(manager):
    data = _caslib_load()
    rows, icons, packs = [], [], []
    selected_base = _caslib_base(manager)
    selected_group = _caslib_group(manager)
    binding_mode = _caslib_binding_mode(manager)
    bound_ids = _caslib_bound_ids(manager) if binding_mode else set()

    if selected_base:
        item = None
        for candidate in _caslib_items_in_order(data):
            if str(candidate.get("base_id") or "") == selected_base:
                item = candidate
                break
        if item is None:
            manager.state.custom_pose_ui_cas_library_base = None
            return _caslib_build_rows(manager)

        if binding_mode:
            _caslib_add_row(rows, icons, packs, {
                "pack_id": "caslib:binding_done",
                "name": "完成绑定",
                "creator": "保存当前选择并返回动作",
                "pose_count": len(bound_ids),
                "favorite": False,
                "kind": "cas_binding_done",
                "value": "done",
            }, None, manager)
        else:
            _caslib_add_row(rows, icons, packs, {
                "pack_id": "caslib:restore",
                "name": "恢复原装",
                "creator": "恢复进入配件试穿前的穿搭",
                "pose_count": 0,
                "favorite": False,
                "kind": "cas_library_restore",
                "value": "restore",
            }, None, manager)

        source = _caslib_source_label(item)
        for index, variant in enumerate(item.get("variants", ()) or ()):
            cas_part_id = str(variant.get("cas_part_id") or "")
            if not cas_part_id:
                continue
            try:
                cas_int = int(cas_part_id)
            except Exception:
                cas_int = 0
            color_text = _caslib_color_label(variant)
            subtitle = "CASPart {} · {}".format(cas_part_id, source)
            if color_text:
                subtitle += " · {}".format(color_text)
            is_bound = cas_int in bound_ids
            if binding_mode:
                subtitle = ("已绑定 · " if is_bound else "未绑定 · ") + subtitle
            _caslib_add_row(rows, icons, packs, {
                "pack_id": "caslib:variant:{}".format(cas_part_id),
                "name": "样式 {}{}".format(
                    int(variant.get("style_index", index) or index) + 1,
                    " · 已绑定" if binding_mode and is_bound else (" · 当前" if bool(variant.get("is_selected")) else ""),
                ),
                "creator": subtitle,
                "pose_count": int(variant.get("style_index", index) or index) + 1,
                "favorite": bool(is_bound),
                "kind": "cas_library_variant",
                "value": cas_part_id,
                "base_id": selected_base,
            }, _caslib_variant_icon(variant), manager)
        return rows, icons, packs

    # H33: group selection lives in the top horizontal tabs.  The content area
    # always contains products directly; no fake group/folder cards.
    items = _caslib_group_items(data, selected_group)
    if binding_mode:
        _caslib_add_row(rows, icons, packs, {
            "pack_id": "caslib:binding_done",
            "name": "完成绑定",
            "creator": "已选择 {} 个配件样式 · 返回动作".format(len(bound_ids)),
            "pose_count": len(bound_ids),
            "favorite": False,
            "kind": "cas_binding_done",
            "value": "done",
        }, None, manager)

    for item in items:
        base_id = str(item.get("base_id") or "")
        if not base_id:
            continue
        variants = list(item.get("variants", ()) or ())
        variant_ids = set()
        for variant in variants:
            try:
                variant_ids.add(int(variant.get("cas_part_id") or 0))
            except Exception:
                pass
        bound_here = len(bound_ids.intersection(variant_ids)) if binding_mode else 0
        variant_count = len(variants)
        body_type = int(item.get("body_type") or 0)
        display_name = str(item.get("display_name") or "配件 {}".format(base_id))
        subtitle = "{} · {} 个样式 · BodyType {}".format(
            _caslib_source_label(item), variant_count, body_type
        )
        if binding_mode and bound_here:
            subtitle = "已绑定 {} 个样式 · ".format(bound_here) + subtitle
        _caslib_add_row(rows, icons, packs, {
            "pack_id": "caslib:product:{}".format(base_id),
            "name": display_name,
            "creator": subtitle,
            "pose_count": variant_count,
            "favorite": bool(bound_here),
            "kind": "cas_library_product",
            "value": base_id,
            "sort_key": display_name,
        }, _caslib_product_icon(item), manager)
    return rows, icons, packs


def _caslib_apply_variant(manager, target, cas_part_id):
    try:
        from fgeh_cas_collection_library import apply_variant_to_target
        result = bool(apply_variant_to_target(target, cas_part_id))
        manager.fgeh_pose_manager_debug_log(
            "[CAS_LIBRARY] apply cas_part_id={} result={}".format(cas_part_id, result)
        )
        return result
    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "[CAS_LIBRARY] apply failed cas_part_id={}".format(cas_part_id),
            exc=True,
        )
        return False


def _caslib_restore(manager, target):
    try:
        from fgeh_cas_collection_library import restore_target_outfit
        result = bool(restore_target_outfit(target))
        manager.fgeh_pose_manager_debug_log(
            "[CAS_LIBRARY] restore result={}".format(result)
        )
        return result
    except Exception:
        manager.fgeh_pose_manager_debug_log("[CAS_LIBRARY] restore failed", exc=True)
        return False


def _v75_build_linked_root_cards(
    manager,
    base_rows,
    base_icons,
    base_packs,
):
    """
    Unified Linked library.

    ALL:
      every real Pack with at least one linked Pose.

    GROUPED:
      overview = inherited ACTION outer-group folder cards
      folder open = only Packs in (outer group ∩ linked Packs)

    No separate linked folder creation is required.
    """
    grouped_view = (_v89_linked_view_mode(manager) == 1)
    selected_outer = _v8918_selected_linked_outer_group(manager)

    if grouped_view and not selected_outer:
        return _v8918_linked_outer_group_cards(manager)

    refs = _v89_all_linked_pose_refs(manager)
    allowed_pack_ids = None

    if grouped_view and selected_outer:
        allowed_pack_ids = set(
            str(value)
            for value in (
                _v8918_linked_outer_groups(manager).get(
                    selected_outer,
                    (),
                ) or ()
            )
            if value
        )

    pose_names_by_pack = {}
    for ref in refs:
        pack_id = str(ref.get("pack_id", "") or "")
        pose_name = str(ref.get("pose_name", "") or "")
        if not pack_id or not pose_name:
            continue
        if (
            allowed_pack_ids is not None
            and pack_id not in allowed_pack_ids
        ):
            continue
        pose_names_by_pack.setdefault(pack_id, set()).add(pose_name)

    base_index = {}
    for index, row in enumerate(base_rows):
        pack_id = str(row.get("pack_id", "") or "")
        if pack_id:
            base_index[pack_id] = index

    rows, icons, packs = [], [], []

    for pack_id, pose_names in pose_names_by_pack.items():
        index = base_index.get(pack_id)

        if index is not None:
            copied = dict(base_rows[index])
            pack = (
                base_packs[index]
                if index < len(base_packs)
                else None
            )
            icon = (
                base_icons[index]
                if index < len(base_icons)
                else None
            )
        else:
            pack = (
                getattr(manager.state, "all_packs_cache", {}) or {}
            ).get(pack_id)
            if pack is None:
                continue
            try:
                name = manager.get_visible_pack_name(pack)
            except Exception:
                name = pack_id
            copied = {
                "pack_id": pack_id,
                "name": str(name or pack_id),
                "creator": "联动动作",
                "favorite": pack_id in set(
                    str(v)
                    for v in (
                        getattr(
                            manager.state,
                            "favorite_packs",
                            (),
                        ) or ()
                    )
                    if v
                ),
            }
            icon = getattr(pack, "icon", None)

        copied["pose_count"] = len(pose_names)
        copied["icon_index"] = len(icons)
        copied["kind"] = "linked_pack"
        copied["value"] = pack_id

        rows.append(copied)
        icons.append(icon)
        packs.append(pack)

    manager.fgeh_pose_manager_debug_log(
        "[LINKED_GROUP_VIEW] build={} mode={} selected_outer={!r} rows={}".format(
            UI_BUILD_TAG,
            "grouped" if grouped_view else "all",
            selected_outer,
            len(rows),
        )
    )

    return rows, icons, packs



def _build_blank_pack_rows(manager):
    """Dedicated Root V3 subview for unnamed/hash-zero pose packs.

    Blank packs are deliberately excluded from normal ALL Packs, but remain
    discoverable here.  Their card title stays visually blank; pack_id and
    creator remain available for identity/search/debugging.
    """
    if not getattr(manager.state, "cache_built", False):
        manager.build_cache_safe()
    creator_by_pack = _creator_map(manager)
    favorites = set(str(v) for v in (getattr(manager.state, "favorite_packs", ()) or ()))
    items = []
    for pack_id, pack in (getattr(manager.state, "all_packs_cache", {}) or {}).items():
        if manager.get_pack_display_name(pack, allow_placeholder=False) is not None:
            continue
        pack_id = str(pack_id)
        creator = str(creator_by_pack.get(pack_id, "") or "")
        items.append((creator.casefold(), pack_id.casefold(), pack_id, pack))
    items.sort(key=lambda item: (item[0], item[1]))

    rows, icons, packs = [], [], []
    for _creator_key, _id_key, pack_id, pack in items:
        note = _v88_custom_note(manager, "pack_{}".format(pack_id))
        creator_text = str(creator_by_pack.get(pack_id, "") or "")
        if note:
            creator_text = "{} · {}".format(creator_text, note) if creator_text else note
        rows.append({
            "pack_id": pack_id,
            "name": _v88_custom_name(manager, "pack_{}".format(pack_id), " "),
            "sort_key": pack_id,
            "creator": creator_text,
            "pose_count": len(getattr(pack, "pose_list", ()) or ()),
            "favorite": pack_id in favorites,
            "icon_index": len(icons),
            "kind": "pack",
            "value": pack_id,
        })
        icons.append(getattr(pack, "icon", None))
        packs.append(pack)
    return rows, icons, packs



def _v8936_apply_root_search(manager, rows, icons, packs):
    """Filter root pack rows by visible name / creator / note without touching old data."""
    query = str(getattr(manager.state, "custom_pose_ui_query", "") or "").strip()
    if not query or _v7_active_nav(manager) != NAV_ALL_PACKS:
        return rows, icons, packs

    tokens = [token.casefold() for token in query.split() if token.strip()]
    if not tokens:
        return rows, icons, packs

    out_rows = []
    out_icons = []
    out_packs = []
    for index, row in enumerate(rows or ()):
        haystack = " ".join((
            str(row.get("name", "") or ""),
            str(row.get("creator", "") or ""),
            str(row.get("pack_id", "") or ""),
            str(row.get("value", "") or ""),
            str(row.get("sort_key", "") or ""),
        )).casefold()
        if not all(token in haystack for token in tokens):
            continue
        out_rows.append(row)
        out_icons.append(icons[index] if index < len(icons) else None)
        out_packs.append(packs[index] if index < len(packs) else None)

    return out_rows, out_icons, out_packs


_ROOT_FINAL_CACHE = None

def _root_final_key(manager):
    # Existing base metadata key plus actual catalog object identities.  Do not
    # include navigation history or the current text query: search is local.
    state = manager.state
    packs = getattr(state, 'all_packs_cache', {}) or {}
    return (id(state), _root_base_rows_cache_key(manager),
            tuple((str(k), id(v)) for k, v in packs.items()),
            _v87_sort_mode(manager))


def _build_rows_v7(manager):
    global _ROOT_FINAL_CACHE
    nav = _v7_active_nav(manager)
    cacheable = (nav == NAV_ALL_PACKS and
                 not bool(getattr(manager.state, 'custom_pose_ui_blank_pack_view', False)))
    if cacheable and bool(getattr(manager.state, 'cache_built', False)):
        cache_key = _root_final_key(manager)
        cached = _ROOT_FINAL_CACHE
        if cached is not None and cached[0] == cache_key:
            rows, icons, packs = cached[1]
            # The caller normalizes icons and edits card dictionaries.
            return [dict(row) for row in rows], list(icons), list(packs)

    # H70W7D2R5: Accessory Library and Settings are independent datasets.
    # The old function built all 800+ pose-pack rows first and then threw them
    # away for these two views.  Skip that dead O(pack_count) work entirely.
    if nav == NAV_ACCESSORY_LIBRARY:
        result = _caslib_build_rows(manager)
    elif nav == NAV_SETTINGS:
        result = _v8918_settings_rows(manager)
    elif nav == NAV_OUTFIT_MANAGER:
        result = _outfit_ui_rows(manager)
    else:
        base_rows, base_icons, base_packs = _build_rows(manager)

        for row in base_rows:
            row["kind"] = "pack"

        if nav == NAV_ALL_PACKS:
            if bool(getattr(manager.state, "custom_pose_ui_blank_pack_view", False)):
                result = _build_blank_pack_rows(manager)
            else:
                result = (base_rows, base_icons, base_packs)

        elif nav == NAV_FAVORITE_PACKS:
            result = _v87_build_favorite_pack_view(
                manager,
                base_rows,
                base_icons,
                base_packs,
            )

        elif nav == NAV_FAVORITE_CREATORS:
            result = _v7_build_creator_cards(
                manager,
                base_rows,
                base_icons,
                base_packs,
            )

        elif nav == NAV_GROUPED_PACKS:
            result = _v7_build_macro_group_cards(
                manager,
                base_rows,
                base_icons,
                base_packs,
            )

        elif nav == NAV_FAVORITE_POSES:
            result = _v88_build_favorite_pose_view(
                manager,
                base_rows,
                base_icons,
                base_packs,
            )

        elif nav == NAV_LINKED_ACTIONS:
            result = _v75_build_linked_root_cards(
                manager,
                base_rows,
                base_icons,
                base_packs,
            )

        else:
            result = (base_rows, base_icons, base_packs)

    sorted_result = _v87_apply_root_sort(
        manager,
        result[0],
        result[1],
        result[2],
    )
    if cacheable:
        # Snapshot before Show's icon normalization; never retain live dialog,
        # owner, callback, protobuf or a mutable row handed to the caller.
        _ROOT_FINAL_CACHE = (
            _root_final_key(manager),
            (tuple(dict(row) for row in sorted_result[0]),
             tuple(sorted_result[1]), tuple(sorted_result[2])))
    # V8.9.37: send the COMPLETE sorted row set. The GFX performs live
    # filtering locally on Event.CHANGE, so typing does not close/reopen the
    # dialog. custom_pose_ui_query is still carried in the header only to
    # restore the search after returning from a pack/detail view.
    return sorted_result



def _v7_root_title(manager):
    nav = _v7_active_nav(manager)

    if nav == NAV_ALL_PACKS and bool(getattr(manager.state, "custom_pose_ui_blank_pack_view", False)):
        return "空白动作包"

    if nav == NAV_FAVORITE_PACKS:
        selected_creator = getattr(
            manager.state,
            "custom_pose_ui_selected_creator",
            None,
        )
        if selected_creator:
            try:
                return str(
                    manager.get_display_name(
                        selected_creator,
                        "creator_",
                    )
                    or selected_creator
                )
            except Exception:
                return str(selected_creator)

        edit_group = getattr(
            manager.state,
            "custom_pose_ui_edit_fav_pack_group",
            None,
        )
        if edit_group:
            return "编辑收藏动作包分组 · {}".format(edit_group)

        selected_group = getattr(
            manager.state,
            "custom_pose_ui_selected_fav_pack_group",
            None,
        )
        if selected_group:
            return str(selected_group)

        return "收藏动作包"

    if nav == NAV_FAVORITE_CREATORS:
        selected = getattr(
            manager.state,
            "custom_pose_ui_selected_creator",
            None,
        )
        if selected:
            try:
                return str(manager.get_display_name(selected, "creator_") or selected)
            except Exception:
                return str(selected)
        return _v899_creator_view_label(manager)

    if nav == NAV_GROUPED_PACKS:
        edit_group = getattr(
            manager.state,
            "custom_pose_ui_edit_outer_group",
            None,
        )
        if edit_group:
            return "编辑动作分组 · {}".format(edit_group)

        selected = getattr(
            manager.state,
            "custom_pose_ui_selected_macro_group",
            None,
        )
        return str(selected) if selected else "动作分组"

    if nav == NAV_FAVORITE_POSES:
        edit_group = getattr(manager.state, "custom_pose_ui_edit_fav_pose_group", None)
        if edit_group:
            return "编辑收藏动作分组 · {}".format(edit_group)
        selected_group = getattr(manager.state, "custom_pose_ui_selected_fav_pose_group", None)
        if selected_group:
            return str(selected_group)
        selected_author = getattr(manager.state, "custom_pose_ui_selected_fav_pose_author", None)
        if selected_author:
            try:
                return str(manager.get_display_name(selected_author, "creator_") or selected_author)
            except Exception:
                return str(selected_author)
        return "收藏动作"

    if nav == NAV_LINKED_ACTIONS:
        selected_linked_outer = _v8918_selected_linked_outer_group(manager)
        if selected_linked_outer:
            return "联动动作 · {}".format(selected_linked_outer)
        return "联动动作"

    if nav == NAV_ACCESSORY_LIBRARY:
        selected_base = _caslib_base(manager)
        selected_group = _caslib_group(manager)
        pack_id, pose_name = _caslib_binding_context(manager)
        prefix = "配件库 · 绑定：{}".format(pose_name) if pack_id and pose_name else "配件库"
        if selected_base:
            return "{} · 样式".format(prefix)
        if selected_group:
            return "{} · {}".format(prefix, selected_group)
        return prefix

    if nav == NAV_SETTINGS:
        return "设置"

    if nav == NAV_OUTFIT_MANAGER:
        mode = _outfit_ui_mode(manager)
        if mode == "parts":
            key = _outfit_ui_current_key(manager)
            if key is not None:
                return "管理当前服装 · {} {}".format(
                    _outfit_ui_category_label(key[0]), key[1] + 1
                )
        selected_category = _outfit_ui_browse_category(manager)
        if selected_category is not None:
            return "管理当前服装 · {}".format(_outfit_ui_category_label(selected_category))
        return "管理当前服装"

    return "动作库"


def _v7_root_library_label(manager):
    if getattr(manager.state, "custom_pose_ui_selected_creator", None):
        if _v7_active_nav(manager) == NAV_FAVORITE_PACKS:
            return "返回收藏动作包"
        return "返回作者"

    if getattr(
        manager.state,
        "custom_pose_ui_selected_fav_pack_group",
        None,
    ):
        return "返回收藏动作包"

    if getattr(
        manager.state,
        "custom_pose_ui_selected_fav_pose_group",
        None,
    ) or getattr(
        manager.state,
        "custom_pose_ui_selected_fav_pose_author",
        None,
    ):
        return "返回收藏动作"

    if getattr(manager.state, "custom_pose_ui_selected_macro_group", None):
        return "返回动作分组"

    if _v7_active_nav(manager) == NAV_ACCESSORY_LIBRARY:
        if _caslib_base(manager):
            return "返回配件库"
        if _caslib_binding_mode(manager):
            return "返回动作"
        return "返回动作库"

    if (
        _v7_active_nav(manager) == NAV_LINKED_ACTIONS
        and _v8918_selected_linked_outer_group(manager)
    ):
        return "返回分组联动"

    if _v7_active_nav(manager) == NAV_SETTINGS:
        if _outfit_ui_has_subview(manager):
            return "返回服装"
        return "返回动作库"

    return "全部动作包"


def _schedule_root_reopen(manager, owner, on_pack_selected, reason):
    """Reopen after the old dialog's close request has been distributed."""
    # Keep the current ROOT node fresh. This mutates only the in-memory stack;
    # explicit Close/Back persists it through the legacy save path.
    _nav_sync_root(manager, save=False)
    import alarms
    from date_and_time import TimeSpan

    holder = {}

    def _reopen(_alarm_handle):
        alarm_handle = holder.get("handle")
        if alarm_handle is not None:
            _PENDING_REOPEN_ALARMS.pop(id(alarm_handle), None)
        manager.fgeh_pose_manager_debug_log(
            "custom UI deferred reopen begin reason={}".format(reason)
        )
        opened = show_pose_manager_root(
            owner,
            on_pack_selected=on_pack_selected,
        )
        manager.fgeh_pose_manager_debug_log(
            "custom UI deferred reopen result={} reason={} last_error={!r}".format(
                opened,
                reason,
                LAST_ERROR,
            )
        )

    try:
        alarm_handle = alarms.add_alarm_real_time(
            owner,
            TimeSpan.ZERO,
            _reopen,
            use_sleep_time=False,
        )
    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "custom UI real-time reopen alarm failed; using simulation alarm",
            exc=True,
        )
        alarm_handle = alarms.add_alarm(owner, TimeSpan.ZERO, _reopen)
    holder["handle"] = alarm_handle
    _PENDING_REOPEN_ALARMS[id(alarm_handle)] = alarm_handle
    manager.fgeh_pose_manager_debug_log(
        "custom UI deferred reopen scheduled reason={} handle={}".format(
            reason,
            id(alarm_handle),
        )
    )


def _schedule_pack_selection(manager, owner, pack, on_pack_selected):
    """Enter a pack after the root EpicCard has finished hiding."""
    import alarms
    from date_and_time import TimeSpan

    holder = {}

    def _select(_alarm_handle):
        alarm_handle = holder.get("handle")
        if alarm_handle is not None:
            _PENDING_REOPEN_ALARMS.pop(id(alarm_handle), None)
        manager.fgeh_pose_manager_debug_log(
            "custom UI deferred pack selection begin pack={!r}".format(pack)
        )
        on_pack_selected(pack)

    try:
        alarm_handle = alarms.add_alarm_real_time(
            owner,
            TimeSpan.ZERO,
            _select,
            use_sleep_time=False,
        )
    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "custom UI pack selection real-time alarm failed; using simulation alarm",
            exc=True,
        )
        alarm_handle = alarms.add_alarm(owner, TimeSpan.ZERO, _select)
    holder["handle"] = alarm_handle
    _PENDING_REOPEN_ALARMS[id(alarm_handle)] = alarm_handle
    manager.fgeh_pose_manager_debug_log(
        "custom UI deferred pack selection scheduled handle={}".format(
            id(alarm_handle)
        )
    )



def _v75_pack_group_names(manager, pack):
    pack_id = str(
        manager.get_pack_id(pack)
        or getattr(pack, "__name__", "")
        or ""
    )
    grouped = getattr(manager.state, "grouped_packs", {}) or {}
    groups = grouped.get(pack_id, {}) if isinstance(grouped, dict) else {}
    if not isinstance(groups, dict):
        groups = {}
    return pack_id, groups, [str(name) for name in groups.keys()]


def _v75_active_inner_group(manager, group_names):
    selected = getattr(
        manager.state,
        "custom_pose_ui_active_inner_group",
        None,
    )
    if selected and str(selected) in group_names:
        return str(selected)
    manager.state.custom_pose_ui_active_inner_group = None
    return None


def _v75_inner_group_index(group_names, selected):
    if not selected:
        return -1
    try:
        return group_names.index(str(selected))
    except ValueError:
        return -1


def _v8_edit_inner_group(manager, group_names):
    selected = getattr(
        manager.state,
        "custom_pose_ui_edit_inner_group",
        None,
    )
    if selected and str(selected) in group_names:
        return str(selected)

    manager.state.custom_pose_ui_edit_inner_group = None
    return None


def _v8_next_inner_group_name(group_dict):
    n = len(group_dict) + 1
    name = "Group {}".format(n)

    while name in group_dict:
        n += 1
        name = "Group {}".format(n)

    return name


def _detail_shared_indexes(manager):
    """Runtime-only revision cache; saving/loading state invalidates it."""
    state = manager.state
    favorites = getattr(state, 'favorite_poses', ())
    groups = getattr(state, 'user_grouped_packs_groups', {})
    if not isinstance(groups, dict):
        groups = {}
    revision = getattr(state, '_fgeh_detail_index_revision', 0)
    cached = getattr(state, '_fgeh_detail_shared_indexes', None)
    if (cached is not None and cached['revision'] == revision
            and cached['favorites_source'] is favorites
            and cached['groups_source'] is groups):
        return cached
    favorite_set = frozenset(str(value) for value in (favorites or ()) if value)
    names = tuple(str(name) for name in groups)
    memberships = {}
    for raw_name, values in groups.items():
        name = str(raw_name)
        for value in (values or ()):
            memberships.setdefault(str(value), set()).add(name)
    cached = {'revision': revision, 'favorites_source': favorites,
              'groups_source': groups, 'favorites': favorite_set,
              'names': names, 'memberships': memberships}
    state._fgeh_detail_shared_indexes = cached
    return cached


def _v8_outer_group_state(manager, pack_id):
    cached = _detail_shared_indexes(manager)
    names = list(cached['names'])
    membership = cached['memberships'].get(str(pack_id), ())
    return names, [name in membership for name in names]



def _build_pack_detail_rows(manager, pack):
    rows = []
    icons = []
    item_tags = []

    pack_id, group_dict, group_names = _v75_pack_group_names(
        manager,
        pack,
    )

    linked_detail = (_v7_active_nav(manager) == NAV_LINKED_ACTIONS)
    linked_pose_names = None

    if linked_detail:
        linked_pose_names = _v89_linked_pose_names_for_pack(
            manager,
            pack_id,
        )
        group_names = _v89_linked_group_names_for_pack(
            manager,
            pack_id,
            group_dict,
            group_names,
        )
        # 联动库 only mirrors existing action groups; it never edits them.
        manager.state.custom_pose_ui_edit_inner_group = None

    active_inner_group = _v75_active_inner_group(
        manager,
        group_names,
    )
    edit_inner_group = (
        None
        if linked_detail
        else _v8_edit_inner_group(
            manager,
            group_names,
        )
    )

    # Editing a group's members always shows the whole visible pose list.
    allowed_pose_names = None
    if active_inner_group and not edit_inner_group:
        allowed_pose_names = set(
            str(value)
            for value in (group_dict.get(active_inner_group, ()) or ())
            if value
        )

    if linked_pose_names is not None:
        if allowed_pose_names is None:
            allowed_pose_names = set(linked_pose_names)
        else:
            allowed_pose_names.intersection_update(linked_pose_names)

    favorite_poses = _detail_shared_indexes(manager)['favorites']
    favorite_only = bool(
        getattr(manager.state, "custom_pose_ui_favorite_only", False)
    )
    edit_members = set(
        str(value)
        for value in (group_dict.get(edit_inner_group, ()) or ())
    ) if edit_inner_group else set()

    favorite_subset = _v88_favorite_pose_subset(manager) if favorite_only else None
    _blank_pose_label_count = 0
    _raw_pose_count = len(getattr(pack, "pose_list", ()) or ())
    for pose_index, pose_item in enumerate(
        getattr(pack, "pose_list", ()) or ()
    ):
        # R9 invariant: blank DISPLAY LABELS are still valid poses.
        # Filtering is reserved for blank PACK names only.
        try:
            if manager.get_pose_display_name_safe(pose_item, allow_placeholder=False) is None:
                _blank_pose_label_count += 1
        except Exception:
            pass

        pose_name = str(
            getattr(pose_item, "pose_name", "") or ""
        )
        if not pose_name:
            continue

        if (
            allowed_pose_names is not None
            and pose_name not in allowed_pose_names
        ):
            continue

        if favorite_only and pose_name not in favorite_poses:
            continue

        if favorite_only and pose_name not in favorite_subset:
            continue

        display_name = _v88_custom_name(
            manager,
            "pose_{}".format(pose_name),
            manager.get_visible_pose_name(pose_item),
        )

        note = _v88_custom_note(manager, "pose_{}".format(pose_name))
        rows.append({
            "pack_id": "pose:{}".format(pose_index),
            "name": display_name,
            "creator": note if note else pose_name,
            "pose_count": pose_index + 1,
            "favorite": pose_name in favorite_poses,
            "icon_index": len(icons),
            "member_selected": pose_name in edit_members,
            "kind": "pose",
        })
        icons.append(getattr(pose_item, "icon", None))
        item_tags.append(pose_item)

    try:
        if _blank_pose_label_count:
            manager.fgeh_pose_manager_debug_log(
                "[POSE_BLANK_LABELS] pack={} raw={} blank_labels={} visible_rows={}".format(
                    str(getattr(pack, "__name__", "") or ""),
                    _raw_pose_count,
                    _blank_pose_label_count,
                    len(rows),
                )
            )
    except Exception:
        pass
    return rows, icons, item_tags



def _v89_option_value(option, *names):
    if isinstance(option, dict):
        for name in names:
            value = option.get(name)
            if value not in (None, ""):
                return value
    else:
        for name in names:
            try:
                value = getattr(option, name, None)
            except Exception:
                value = None
            if value not in (None, ""):
                return value
    return None


# V8.9.42 release gate.  The old development branch can save an entire
# outfit as many singleton CAS rows ("整套服装 - ATHLETIC 1", etc.).  That
# experiment is intentionally hidden for the release build: the underlying
# saved data is NOT deleted, so the feature can be revived later.
RELEASE_HIDE_EXPERIMENTAL_OUTFIT_BINDINGS = True


def _v8942_is_experimental_outfit_option(option):
    def _text(*names):
        try:
            return str(_v89_option_value(option, *names) or "").strip()
        except Exception:
            return ""

    asset_kind = _text("asset_kind", "kind").lower()
    source_type = _text("source_type", "binding_type", "link_type").lower()
    source_origin = _text("source_origin", "origin").lower()
    outfit_binding_id = _text("outfit_binding_id", "outfit_id")
    entry_label = _text("entry_label", "display_name", "label", "name")

    if entry_label.startswith("整套服装 -"):
        return True
    if outfit_binding_id:
        return True
    if asset_kind in ("outfit", "full_outfit", "saved_outfit"):
        return True
    if source_type in (
        "outfit", "outfit_binding", "full_outfit", "saved_outfit",
        "outfit_part", "outfit_cas_part",
    ):
        return True
    if source_origin in ("outfit", "outfit_binding", "saved_outfit"):
        return True
    return False


def _v8942_release_cas_options(manager, pack_id, pose_name, log_hidden=False):
    try:
        raw = list(manager.get_linked_cas_variant_options(pack_id, pose_name) or ())
    except Exception:
        raw = []

    if not RELEASE_HIDE_EXPERIMENTAL_OUTFIT_BINDINGS:
        return raw

    visible = []
    hidden = 0
    for option in raw:
        if _v8942_is_experimental_outfit_option(option):
            hidden += 1
        else:
            visible.append(option)

    if log_hidden and hidden:
        try:
            manager.fgeh_pose_manager_debug_log(
                "[OUTFIT_BINDING_RELEASE_HIDE] build={} pack={} pose={} hidden={} visible={}".format(
                    UI_BUILD_TAG, pack_id, pose_name, hidden, len(visible)
                )
            )
        except Exception:
            pass
    return visible


def _v89692_install_release_linked_gate(manager):
    """Hide experimental whole-outfit rows from *legacy* linked viewers too.

    The custom linked drawer already uses ``_v8942_release_cas_options``.
    Older/native menu paths call ``manager.get_linked_cas_variant_options``
    directly, which allowed saved ``full_outfit`` development rows to leak
    back into release UI.  Wrap that shared getter once instead of deleting
    any data or removing the normal accessory/object binding interactions.
    """
    if manager is None or not RELEASE_HIDE_EXPERIMENTAL_OUTFIT_BINDINGS:
        return

    try:
        current = getattr(manager, "get_linked_cas_variant_options", None)
    except Exception:
        current = None
    if current is None:
        return

    try:
        if getattr(current, "_fgeh_release_outfit_filter", False):
            return
    except Exception:
        pass

    # Preserve the unfiltered callable for development builds / future revival.
    try:
        original = getattr(
            manager,
            "_fgeh_unfiltered_get_linked_cas_variant_options",
            None,
        )
    except Exception:
        original = None
    if original is None:
        original = current
        try:
            manager._fgeh_unfiltered_get_linked_cas_variant_options = original
        except Exception:
            pass

    def _release_filtered_get_linked_cas_variant_options(pack_id, pose_name):
        try:
            raw = list(original(pack_id, pose_name) or ())
        except Exception:
            return []
        return [
            option for option in raw
            if not _v8942_is_experimental_outfit_option(option)
        ]

    try:
        _release_filtered_get_linked_cas_variant_options._fgeh_release_outfit_filter = True
    except Exception:
        pass
    try:
        manager.get_linked_cas_variant_options = (
            _release_filtered_get_linked_cas_variant_options
        )
    except Exception:
        pass


# Install the release gate as early as this UI bridge is imported.  The two
# show_* entry points repeat the call defensively in case import order changes.
try:
    import couplepose1 as _release_linked_manager
    _v89692_install_release_linked_gate(_release_linked_manager)
except Exception:
    pass


_V8919_LINKED_ICON_LOGGED = set()


def _v8919_parse_resource_key_text(value):
    """
    Restore the legacy linked thumbnail conversion.

    Accept:
      TYPE:GROUP:INSTANCE
      GROUP!INSTANCE_HIGH'INSTANCE_LOW.TYPE

    The important part for Object previews is preserving GROUP.  Object
    preview_thumbnail keys are frequently non-zero-group resources.
    """
    if value is None:
        return None

    if not isinstance(value, str):
        return value

    text = value.strip().strip('"').strip("'")
    if not text:
        return None

    type_id = group_id = instance_id = None

    match = re.match(
        r"^\s*(?:0x)?([0-9A-Fa-f]{1,8})"
        r"\s*:\s*(?:0x)?([0-9A-Fa-f]{1,8})"
        r"\s*:\s*(?:0x)?([0-9A-Fa-f]{1,16})\s*$",
        text,
    )
    if match:
        type_id = int(match.group(1), 16)
        group_id = int(match.group(2), 16)
        instance_id = int(match.group(3), 16)
    else:
        match = re.match(
            r"^\s*(?:0x)?([0-9A-Fa-f]{1,8})!"
            r"(?:0x)?([0-9A-Fa-f]{1,8})'"
            r"([0-9A-Fa-f]{1,8})\."
            r"(?:0x)?([0-9A-Fa-f]{1,8})\s*$",
            text,
        )
        if match:
            group_id = int(match.group(1), 16)
            instance_id = (
                (int(match.group(2), 16) << 32)
                | int(match.group(3), 16)
            )
            type_id = int(match.group(4), 16)

    if type_id is None or group_id is None or instance_id is None:
        return None

    try:
        import sims4.resources as _resources

        resource_key_cls = getattr(_resources, "ResourceKey", None)
        if resource_key_cls is not None:
            return resource_key_cls(
                int(type_id),
                int(group_id),
                int(instance_id),
            )

        # Compatibility fallback only when no group information is lost.
        if int(group_id) == 0:
            return _resources.get_resource_key(
                int(instance_id),
                int(type_id),
            )
    except Exception:
        return None

    return None


def _v8919_resolve_linked_icon(option, fallback=None):
    """
    Prefer real ResourceKeys, then parse legacy thumbnail text into one.
    """
    resolved_fields = (
        "icon_resource",
        "first_variant_icon",
        "resource_key",
        "thumbnail_resource",
        "icon_key",
        "icon",
    )
    thumbnail_fields = (
        "entry_thumbnail",
        "first_variant_thumbnail",
        "preview_thumbnail",
        "catalog_thumbnail",
        "thumbnail",
        "thumbnail_key",
    )

    for field_name in resolved_fields:
        candidate = _v89_option_value(option, field_name)
        if candidate in (None, ""):
            continue
        parsed = _v8919_parse_resource_key_text(candidate)
        if parsed is not None:
            return parsed, field_name, candidate
        if not isinstance(candidate, str):
            return candidate, field_name, candidate

    for field_name in thumbnail_fields:
        candidate = _v89_option_value(option, field_name)
        if candidate in (None, ""):
            continue
        parsed = _v8919_parse_resource_key_text(candidate)
        if parsed is not None:
            return parsed, field_name, candidate

    fallback_parsed = _v8919_parse_resource_key_text(fallback)
    if fallback_parsed is not None:
        return fallback_parsed, "fallback", fallback

    return fallback, "fallback", fallback


def _v8919_log_linked_icon(
    manager,
    link_type,
    item_id,
    option,
    source_field,
    raw_candidate,
    resolved_icon,
):
    """Log each distinct resource once instead of flooding the debug file."""
    key = "{}:{}".format(link_type, item_id)
    if key in _V8919_LINKED_ICON_LOGGED:
        return
    _V8919_LINKED_ICON_LOGGED.add(key)

    try:
        option_keys = (
            sorted(str(k) for k in option.keys())
            if isinstance(option, dict)
            else []
        )
    except Exception:
        option_keys = []

    manager.fgeh_pose_manager_debug_log(
        "[LINKED_ICON] build={} type={} item={} source={} "
        "raw={!r} resolved={!r} option_keys={}".format(
            UI_BUILD_TAG,
            link_type,
            item_id,
            source_field,
            raw_candidate,
            resolved_icon,
            option_keys,
        )
    )


def _v89_option_icon(option, fallback=None):
    """Compatibility wrapper for callers outside the linked inspector."""
    return _v8919_resolve_linked_icon(option, fallback)[0]


def _v8920_object_definition_icon(definition_id):
    """Deferred IconInfoData descriptor for Build/Buy catalog thumbnails."""
    try:
        definition_id = int(definition_id or 0)
    except Exception:
        definition_id = 0
    if not definition_id:
        return None
    return {
        "_fgeh_icon_kind": "object_definition",
        "definition_id": definition_id,
    }


def _v8920_is_object_definition_icon(value):
    return (
        isinstance(value, dict)
        and value.get("_fgeh_icon_kind") == "object_definition"
        and int(value.get("definition_id", 0) or 0) > 0
    )


def _v8930_linked_icon_dedupe_key(value):
    """Stable key for sharing the same linked object thumbnail across poses."""
    if _v8920_is_object_definition_icon(value):
        return ("obj_def", int(value.get("definition_id", 0) or 0))
    try:
        return (
            "resource",
            int(getattr(value, "type", 0) or 0),
            int(getattr(value, "group", 0) or 0),
            int(getattr(value, "instance", 0) or 0),
        )
    except Exception:
        return ("text", str(value))


def _v8920_create_icon_info(IconInfoData, icon_value):
    """Build either a normal resource icon or a catalog object preview."""
    if _v8920_is_object_definition_icon(icon_value):
        return IconInfoData(
            obj_def_id=int(icon_value.get("definition_id") or 0)
        )
    if icon_value is None:
        return IconInfoData()
    return IconInfoData(icon_resource=icon_value)




# ------------------------------------------------------------------
# V8.9.26 CAS product grouping core + lazy hover product-card UI data
# ------------------------------------------------------------------
# The linked registry exposes one concrete CASPart per row/swatches.  For the
# future CAS-style UI we need a stable PRODUCT layer above those rows:
#
#   product -> [swatch CASPart A, swatch CASPart B, ...]
#
# Prefer the metadata that already exists in the old registry (entry_label /
# variant_label / entry_icon).  Only fall back to display-name parsing when an
# old/local record does not carry those fields.
_V8924_SWATCH_SUFFIX_RE = re.compile(
    r"\s*[-–—:]?\s*(?:swatch|colour|color|variant|style)"
    r"\s*#?\s*(\d+)\s*$",
    re.IGNORECASE,
)
_V8924_TRAILING_NUMBER_RE = re.compile(r"(?:^|\s)(\d+)\s*$")


def _v8924_text(value):
    return str(value or "").strip()


def _v8924_normalize_key_text(value):
    text = _v8924_text(value).lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _v8924_variant_number(value):
    text = _v8924_text(value)
    if not text:
        return 0
    match = _V8924_SWATCH_SUFFIX_RE.search(text)
    if match:
        try:
            return int(match.group(1))
        except Exception:
            return 0
    match = _V8924_TRAILING_NUMBER_RE.search(text)
    if match:
        try:
            return int(match.group(1))
        except Exception:
            return 0
    return 0


def _v8924_strip_variant_suffix(label, variant_label=""):
    """Return a human-facing base product label without the swatch suffix."""
    text = _v8924_text(label)
    variant = _v8924_text(variant_label)
    if not text:
        return ""

    # Strongest form: the registry explicitly tells us the variant label.
    # Remove it only when it is a suffix, preserving product names containing
    # words such as "Color" in the middle.
    if variant:
        lower_text = text.lower()
        lower_variant = variant.lower()
        if lower_text.endswith(lower_variant):
            prefix = text[: len(text) - len(variant)]
            prefix = re.sub(r"\s*[-–—:]\s*$", "", prefix).strip()
            if prefix:
                text = prefix

    # Compatibility fallback for legacy labels like "Phone - Swatch 4".
    text = _V8924_SWATCH_SUFFIX_RE.sub("", text).strip()
    return text


def _v8938_linked_product_edit_key(kind, product_key):
    """Stable custom-name / note key for linked CAS and object products.

    It deliberately does not include the current Pose: the same linked product
    can appear in many Poses, so a player rename should follow the product.
    Existing custom_names storage is reused for backwards-compatible JSON.
    """
    return "linked_{}_product::{}".format(
        str(kind or "resource").strip().lower(),
        str(product_key or "").strip(),
    )


def _v8938_apply_linked_product_edit(manager, product, kind):
    if not isinstance(product, dict):
        return product
    product_key = str(product.get("product_key", "") or "")
    # Keep EA LocalizedString values intact.  Turning them into str here would
    # produce literal ``hash: 123...`` text and throw away the client-side
    # Build/Buy localization token.
    original_label = product.get("product_label", "") or ""
    edit_key = _v8938_linked_product_edit_key(kind, product_key)
    custom_names = getattr(getattr(manager, "state", None), "custom_names", {}) or {}
    custom_name = str(custom_names.get(edit_key, "") or "").strip()
    note = _v88_custom_note(manager, edit_key) if manager is not None else ""
    product["edit_key"] = edit_key
    product["original_product_label"] = original_label
    product["custom_name"] = custom_name
    product["note"] = note
    if custom_name:
        product["product_label"] = custom_name
    return product


def _v8931_normalize_swatch_color(value):
    """Return #RRGGBB when optional v2 metadata supplies a swatch color."""
    if value in (None, ""):
        return ""
    if isinstance(value, (list, tuple)):
        # CAS can expose multiple chip colors.  The first chip is enough for
        # the compact selector today; keep the parser permissive for generators.
        value = value[0] if value else ""
    text = str(value or "").strip()
    if not text:
        return ""
    # Accept common generator forms: #RRGGBB, RRGGBB, 0xRRGGBB, decimal int.
    try:
        if text.lower().startswith("0x"):
            return "#{:06X}".format(int(text, 16) & 0xFFFFFF)
        if text.startswith("#"):
            raw = text[1:]
            if len(raw) >= 6:
                return "#" + raw[:6].upper()
        compact = re.sub(r"[^0-9a-fA-F]", "", text)
        if len(compact) == 6:
            return "#" + compact.upper()
        if text.isdigit():
            return "#{:06X}".format(int(text) & 0xFFFFFF)
    except Exception:
        pass
    return ""


def _v8924_cas_product_identity(option, item_id=0):
    """
    Resolve one concrete CAS swatch to a stable product identity.

    V8.9.31 schema preference (all OPTIONAL, old snippets remain valid):
      product_key / product_id / catalog_product_key
      product_label / product_name
      swatch_index / swatch_order / variant_index
      swatch_color / color_hex / swatch_colour

    Legacy fallback remains exactly the old entry_label + variant_label path.
    """
    label = _v8924_text(
        _v89_option_value(option, "label", "display_name", "name")
    )
    entry_label = _v8924_text(_v89_option_value(option, "entry_label"))
    variant_label = _v8924_text(
        _v89_option_value(option, "variant_label", "swatch_label")
    )
    entry_icon = _v8924_text(
        _v89_option_value(option, "entry_icon", "first_variant_icon")
    )
    body_group = _v8924_text(_v89_option_value(option, "body_group"))
    body_type = _v8924_text(_v89_option_value(option, "body_type"))

    explicit_key = _v8924_text(_v89_option_value(
        option,
        "product_key", "product_id", "catalog_product_key", "base_product_key",
    ))
    explicit_label = _v8924_text(_v89_option_value(
        option,
        "product_label", "product_name", "catalog_product_name",
    ))

    if explicit_label:
        product_label = explicit_label
        key_source = "product_key" if explicit_key else "product_label"
    elif entry_label:
        product_label = _v8924_strip_variant_suffix(entry_label, variant_label)
        key_source = "entry_label"
    else:
        product_label = _v8924_strip_variant_suffix(label, variant_label)
        key_source = "label_fallback"

    if not product_label:
        product_label = label or "CAS {}".format(int(item_id or 0))
        key_source = "item_fallback"

    if explicit_key:
        product_key = "cas|explicit|" + _v8924_normalize_key_text(explicit_key)
    else:
        key_parts = [
            _v8924_normalize_key_text(product_label),
            _v8924_normalize_key_text(body_group),
            _v8924_normalize_key_text(body_type),
            _v8924_normalize_key_text(entry_icon),
        ]
        product_key = "cas|" + "|".join(key_parts)

    explicit_index = _v89_option_value(
        option,
        "swatch_index", "swatch_order", "variant_index", "variant_order",
    )
    try:
        swatch_index = int(explicit_index) if explicit_index not in (None, "") else 0
    except Exception:
        swatch_index = 0
    if swatch_index <= 0:
        swatch_index = _v8924_variant_number(variant_label or label)

    if not variant_label:
        suffix_match = _V8924_SWATCH_SUFFIX_RE.search(label)
        if suffix_match:
            variant_label = "Swatch {}".format(suffix_match.group(1))

    swatch_color = _v8931_normalize_swatch_color(_v89_option_value(
        option,
        "swatch_color", "color_hex", "swatch_colour", "variant_color", "colour_hex",
    ))

    return {
        "product_key": product_key,
        "product_label": product_label,
        "key_source": key_source,
        "variant_label": variant_label,
        "swatch_index": int(swatch_index or 0),
        "swatch_color": swatch_color,
    }


def _v8931_cas_catalog_signature(cas_options):
    """Static signature: equal option sets share one serialized catalog."""
    signature = []
    for option in cas_options or ():
        try:
            item_id = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            item_id = 0
        if not item_id:
            continue
        identity = _v8924_cas_product_identity(option, item_id)
        signature.append((
            item_id,
            identity.get("product_key", ""),
            identity.get("product_label", ""),
            identity.get("variant_label", ""),
            int(identity.get("swatch_index", 0) or 0),
            identity.get("swatch_color", ""),
            _v895_link_origin(option),
        ))
    return tuple(signature)


def _v8931_build_shared_cas_catalog(cas_options, manager=None):
    """
    Build one STATIC CAS catalog for one unique option signature.

    No Pose-specific enabled state lives here.  That is the important V8.9.31
    split: static product/variant metadata is serialized once; each Pose only
    carries a compact selected-id list + catalog index.
    """
    groups = {}
    order = []
    original_order = 0
    for option in cas_options or ():
        try:
            item_id = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            item_id = 0
        if not item_id:
            continue
        identity = _v8924_cas_product_identity(option, item_id)
        key = identity.get("product_key") or "cas|{}".format(item_id)
        product = groups.get(key)
        if product is None:
            product = {
                "product_key": key,
                "product_label": identity.get("product_label", "") or "CAS {}".format(item_id),
                "key_source": identity.get("key_source", ""),
                "variants": [],
            }
            groups[key] = product
            order.append(key)

        product["variants"].append({
            "item_id": item_id,
            "variant_label": identity.get("variant_label", ""),
            "swatch_index": int(identity.get("swatch_index", 0) or 0),
            "swatch_color": identity.get("swatch_color", ""),
            "origin": _v895_link_origin(option),
            "original_order": original_order,
        })
        original_order += 1

    result = []
    for key in order:
        product = groups[key]
        product["variants"].sort(key=lambda value: (
            0 if int(value.get("swatch_index", 0) or 0) > 0 else 1,
            int(value.get("swatch_index", 0) or 0)
            if int(value.get("swatch_index", 0) or 0) > 0
            else int(value.get("original_order", 0)),
            int(value.get("original_order", 0)),
        ))
        for value in product["variants"]:
            value.pop("original_order", None)
        product["variant_count"] = len(product["variants"])
        if manager is not None:
            _v8938_apply_linked_product_edit(manager, product, "cas")
        result.append(product)
    return result



def _v89692_object_catalog_localization(definition_id):
    """Return EA-native localized Build/Buy name + stable catalog name key.

    ``LocalizationHelperTuning.get_object_name(definition)`` is the same path
    EA definition pickers use.  It carries an OBJECT localization token, so
    the client resolves the catalog name in the player's current language.
    ``build_buy.get_object_catalog_name`` supplies the stable catalog-name key
    used to group swatch/style definitions without stringifying localization.
    """
    try:
        definition_id = int(definition_id or 0)
    except Exception:
        definition_id = 0
    if not definition_id:
        return None, 0

    catalog_name_key = 0
    try:
        import build_buy
        catalog_name_key = int(
            build_buy.get_object_catalog_name(definition_id) or 0
        )
    except Exception:
        catalog_name_key = 0

    localized_name = None
    try:
        import services
        from sims4.localization import LocalizationHelperTuning

        obj_def = services.definition_manager().get(definition_id)
        if obj_def is not None:
            localized_name = LocalizationHelperTuning.get_object_name(obj_def)
    except Exception:
        localized_name = None

    return localized_name, catalog_name_key


def _v8934_object_product_identity(option, item_id=0):
    """Resolve Build/Buy object style variants into one product identity.

    Release behavior deliberately separates the *display* name from the
    grouping key: display uses EA's OBJECT localization token; grouping uses
    the catalog-name hash (or explicit/base metadata).  This avoids the old
    ``str(LocalizedString) -> 'hash: ...'`` regression.
    """
    try:
        item_id = int(item_id or 0)
    except Exception:
        item_id = 0

    localized_catalog_name, catalog_name_key = (
        _v89692_object_catalog_localization(item_id)
    )

    label = _v8924_text(
        _v89_option_value(option, "label", "display_name", "name")
    )
    # Legacy runtime metadata may carry either text or a catalog-name hash.
    # Keep it only as a fallback; the EA Definition path above is authoritative
    # for display and language selection.
    legacy_catalog_name = _v8924_text(
        _v89_option_value(option, "catalog_name")
    )
    entry_label = _v8924_text(_v89_option_value(option, "entry_label"))
    variant_label = _v8924_text(_v89_option_value(
        option,
        "variant_label", "style_label", "swatch_label",
        "material_label", "style_name", "variant_name",
    ))

    explicit_key = _v8924_text(_v89_option_value(
        option,
        "object_product_key", "product_key", "product_id",
        "catalog_product_key", "catalog_object_id", "base_product_key",
    ))
    explicit_label = _v89_option_value(
        option,
        "object_product_label", "product_label", "product_name",
        "catalog_product_name",
    )
    explicit_label_text = _v8924_text(explicit_label)

    base_definition = _v89_option_value(
        option,
        "base_definition_id", "base_object_definition_id",
        "master_definition_id", "catalog_base_definition_id",
    )
    try:
        base_definition = int(base_definition or 0)
    except Exception:
        base_definition = 0

    # Display priority: an explicitly authored product label may intentionally
    # override the catalog; otherwise prefer the real localized Build/Buy name.
    if explicit_label not in (None, ""):
        product_label = explicit_label
        key_source = "product_key" if explicit_key else "product_label"
    elif localized_catalog_name is not None:
        product_label = localized_catalog_name
        key_source = "catalog_name_key"
    elif legacy_catalog_name:
        product_label = _v8924_strip_variant_suffix(
            legacy_catalog_name, variant_label
        )
        key_source = "catalog_name"
    elif entry_label and (
        variant_label or _V8924_SWATCH_SUFFIX_RE.search(entry_label)
    ):
        product_label = _v8924_strip_variant_suffix(
            entry_label, variant_label
        )
        key_source = "entry_label"
    else:
        product_label = _v8924_strip_variant_suffix(label, variant_label)
        key_source = "singleton"

    if product_label in (None, ""):
        product_label = (
            legacy_catalog_name
            or entry_label
            or label
            or "Object {}".format(item_id)
        )

    origin = _v895_link_origin(option)
    if explicit_key:
        product_key = "object|explicit|" + _v8924_normalize_key_text(
            explicit_key
        )
    elif base_definition:
        product_key = "object|base|{}".format(base_definition)
        key_source = "base_definition"
    elif catalog_name_key:
        product_key = "object|catalogkey|{}|{}".format(
            int(catalog_name_key),
            _v8924_normalize_key_text(origin),
        )
        key_source = "catalog_name_key"
    elif legacy_catalog_name:
        # Legacy fallback only. Do not use LocalizedString display text here.
        fallback_group_text = (
            explicit_label_text
            or _v8924_strip_variant_suffix(legacy_catalog_name, variant_label)
        )
        product_key = "object|catalog|{}|{}".format(
            _v8924_normalize_key_text(fallback_group_text),
            _v8924_normalize_key_text(origin),
        )
    elif key_source == "entry_label":
        product_key = "object|entry|{}|{}".format(
            _v8924_normalize_key_text(
                _v8924_strip_variant_suffix(entry_label, variant_label)
            ),
            _v8924_normalize_key_text(origin),
        )
    else:
        product_key = "object|id|{}".format(item_id)

    explicit_index = _v89_option_value(
        option,
        "swatch_index", "style_index", "variant_index",
        "variant_order", "style_order",
    )
    try:
        swatch_index = (
            int(explicit_index)
            if explicit_index not in (None, "")
            else 0
        )
    except Exception:
        swatch_index = 0
    if swatch_index <= 0:
        swatch_index = _v8924_variant_number(
            variant_label or entry_label or label
        )

    if not variant_label:
        source = entry_label or label
        suffix_match = _V8924_SWATCH_SUFFIX_RE.search(source or "")
        if suffix_match:
            variant_label = "Style {}".format(suffix_match.group(1))

    return {
        "product_key": product_key,
        "product_label": product_label,
        "key_source": key_source,
        "variant_label": variant_label,
        "swatch_index": int(swatch_index or 0),
        "origin": origin,
    }

def _v8934_build_object_products(object_entries, manager=None):
    """Build one product -> style-variant model from legacy object rows."""
    groups = {}
    order = []

    for original_order, entry in enumerate(object_entries or ()):
        try:
            resource_index, option, resource = entry
        except Exception:
            continue

        item_id = int((resource or {}).get("item_id", 0) or 0)
        identity = _v8934_object_product_identity(option, item_id)
        key = identity.get("product_key") or "object|id|{}".format(item_id)

        product = groups.get(key)
        if product is None:
            product = {
                "product_key": key,
                "product_label": identity.get("product_label", "")
                or "Object {}".format(item_id),
                "key_source": identity.get("key_source", ""),
                "variants": [],
            }
            groups[key] = product
            order.append(key)

        product["variants"].append({
            "resource_index": int(resource_index),
            "item_id": int(item_id),
            "variant_label": identity.get("variant_label", ""),
            "swatch_index": int(identity.get("swatch_index", 0) or 0),
            "origin": identity.get("origin", "external"),
            "original_order": int(original_order),
        })

    result = []
    for key in order:
        product = groups[key]
        variants = product["variants"]
        variants.sort(key=lambda value: (
            0 if int(value.get("swatch_index", 0) or 0) > 0 else 1,
            int(value.get("swatch_index", 0) or 0)
            if int(value.get("swatch_index", 0) or 0) > 0
            else int(value.get("original_order", 0)),
            int(value.get("original_order", 0)),
        ))
        for value in variants:
            value.pop("original_order", None)
        product["variant_count"] = len(variants)
        if manager is not None:
            _v8938_apply_linked_product_edit(manager, product, "object")
        result.append(product)
    return result


def _v8934_choose_one_object_variant_per_product(
    options, current_selected=None
):
    """Return at most one object definition per grouped Build/Buy product."""
    current = set(
        int(value or 0)
        for value in (current_selected or ())
        if int(value or 0)
    )
    groups = []
    by_key = {}

    for option in options or ():
        try:
            item_id = int(_v89_option_value(
                option, "definition_id", "object_definition_id"
            ) or 0)
        except Exception:
            item_id = 0
        if not item_id:
            continue
        identity = _v8934_object_product_identity(option, item_id)
        key = identity.get("product_key") or "object|id|{}".format(item_id)
        group = by_key.get(key)
        if group is None:
            group = []
            by_key[key] = group
            groups.append(group)
        if item_id not in group:
            group.append(item_id)

    result = []
    for group in groups:
        chosen = next((value for value in group if value in current), None)
        if chosen is None and group:
            chosen = group[0]
        if chosen:
            result.append(chosen)
    return result


def _v8924_build_cas_products(cas_entries):
    """
    Build ordered product groups from [(resource_index, option, resource), ...].

    The original resource rows remain untouched.  This is a parallel model used
    by the new UI, so old toggle/apply/playback code continues to address the
    same concrete CASPart ids.
    """
    groups = {}
    order = []

    for original_order, entry in enumerate(cas_entries or ()):
        try:
            resource_index, option, resource = entry
        except Exception:
            continue

        item_id = int((resource or {}).get("item_id", 0) or 0)
        identity = _v8924_cas_product_identity(option, item_id)
        key = identity["product_key"]
        if key not in groups:
            groups[key] = {
                "product_key": key,
                "product_label": identity["product_label"],
                "key_source": identity["key_source"],
                "variants": [],
            }
            order.append(key)

        groups[key]["variants"].append({
            "resource_index": int(resource_index),
            "item_id": item_id,
            "variant_label": identity["variant_label"],
            "swatch_index": int(identity["swatch_index"] or 0),
            "original_order": int(original_order),
        })

    result = []
    for key in order:
        product = groups[key]
        variants = product["variants"]
        # Numeric Swatch N metadata wins when present. Unknown variants keep
        # their original order after numbered swatches.
        variants.sort(
            key=lambda value: (
                0 if int(value.get("swatch_index", 0) or 0) > 0 else 1,
                int(value.get("swatch_index", 0) or 0)
                if int(value.get("swatch_index", 0) or 0) > 0
                else int(value.get("original_order", 0)),
                int(value.get("original_order", 0)),
            )
        )
        for value in variants:
            value.pop("original_order", None)
        product["variant_count"] = len(variants)
        result.append(product)

    return result




def _v8928_enforce_single_selected_variant(
    manager,
    pack_id,
    pose_name,
    cas_options,
    available_ids,
    selected_ids,
):
    """
    Hard invariant for the product-card UI:

        one CAS product -> zero OR one enabled swatch.

    Older builds allowed several sibling CASPart ids from the same entry to be
    persisted at once.  They cannot be worn simultaneously and they make the
    product-card state ambiguous, so normalize legacy state as soon as a linked
    pose is read.  Different products remain independently selectable.

    Selection precedence is deterministic: preserve the first enabled swatch in
    the registry/product order and drop later siblings from that same product.
    """
    available = [int(value or 0) for value in (available_ids or ()) if int(value or 0)]
    selected = set(int(value or 0) for value in (selected_ids or ()) if int(value or 0))
    selected.intersection_update(available)

    kept = []
    kept_set = set()
    first_for_product = {}
    removed = []

    for option in cas_options or ():
        try:
            item_id = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            item_id = 0
        if not item_id or item_id not in selected:
            continue

        identity = _v8924_cas_product_identity(option, item_id)
        product_key = identity.get("product_key") or "cas|{}".format(item_id)
        if product_key in first_for_product:
            removed.append(item_id)
            continue

        first_for_product[product_key] = item_id
        kept.append(item_id)
        kept_set.add(item_id)

    # Preserve any selected id that was available but not represented by the
    # option scan as its own singleton.  This is defensive for legacy data.
    scanned_ids = set()
    for option in cas_options or ():
        try:
            candidate = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            candidate = 0
        if candidate:
            scanned_ids.add(candidate)
    for item_id in available:
        if item_id in selected and item_id not in scanned_ids and item_id not in kept_set:
            kept.append(item_id)
            kept_set.add(item_id)

    if kept_set != selected:
        try:
            manager.set_enabled_linked_cas_part_ids(
                pack_id,
                pose_name,
                [item_id for item_id in available if item_id in kept_set],
            )
            manager.fgeh_pose_manager_debug_log(
                "[CAS_PRODUCT_NORMALIZE] build={} pack={} pose={} "
                "before={} kept={} removed={}".format(
                    UI_BUILD_TAG,
                    pack_id,
                    pose_name,
                    [item_id for item_id in available if item_id in selected],
                    [item_id for item_id in available if item_id in kept_set],
                    removed,
                )
            )
        except Exception as exc:
            try:
                manager.fgeh_pose_manager_debug_log(
                    "[CAS_PRODUCT_NORMALIZE] build={} FAILED pack={} pose={} error={!r}".format(
                        UI_BUILD_TAG, pack_id, pose_name, exc
                    )
                )
            except Exception:
                pass

    return kept_set


def _v895_link_origin(option):
    # W7D2: authoritative game-created ownership markers win before heuristics.
    created_in_game = _v89_option_value(option, "created_in_game", "game_created")
    if created_in_game is True or str(created_in_game or "").strip().lower() in ("1", "true", "yes"):
        return "local"
    user_group = str(_v89_option_value(option, "user_group", "binding_group") or "").strip().lower()
    if user_group in ("in_game_binding", "ingame_binding", "local_binding"):
        return "local"

    raw = _v89_option_value(
        option,
        "source_origin",
        "origin",
        "link_origin",
        "binding_origin",
        "entry_origin",
        "library_origin",
    )
    raw_text = str(raw or "").strip().lower()

    identity = _v89_option_value(
        option,
        "link_id",
        "binding_id",
        "asset_id",
        "source_id",
        "source_key",
    )
    identity_text = str(identity or "").strip().lower()

    local_markers = (
        "local",
        "in_game",
        "ingame",
        "game_bind",
        "runtime",
        "user.object",
        "saved_binding",
        "binding",
    )
    external_markers = (
        "external",
        "xml",
        "snippet",
        "metadata",
        "package",
        "outside",
    )

    if any(marker in raw_text for marker in local_markers):
        return "local"
    if any(marker in raw_text for marker in external_markers):
        return "external"
    if any(marker in identity_text for marker in local_markers):
        return "local"
    if any(marker in identity_text for marker in external_markers):
        return "external"

    source_type = str(
        _v89_option_value(option, "source_type") or ""
    ).strip().lower()
    if source_type in ("local", "in_game", "ingame"):
        return "local"
    if source_type in ("external", "xml", "metadata"):
        return "external"

    # Legacy XML-created links usually do not carry an explicit origin.
    # Game-created bindings normally carry a local/binding marker.
    return "external"


def _h63_expand_collection_variants_for_linked_display(cas_options):
    """Display-only expansion for game-created CAS collection bindings.

    The binding store intentionally keeps ONE selected CASPart per product/Pose.
    LinkedActionEditor, however, should render the full product palette so the
    player can see/switch every swatch while the saved CASPart remains the
    selected one. External XML/snippet rows are left untouched.
    """
    raw = list(cas_options or ())
    if not raw:
        return raw
    try:
        data = _caslib_load()
        collection_options = list(_caslib_catalog_options(data, None) or ())
    except Exception:
        return raw

    by_variant = {}
    by_base = {}
    for option in collection_options:
        try:
            item_id = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            item_id = 0
        base_id = str(_v89_option_value(option, "base_id") or "")
        if not item_id or not base_id:
            continue
        by_variant[item_id] = base_id
        by_base.setdefault(base_id, []).append(option)

    result = []
    expanded_bases = set()
    for option in raw:
        try:
            item_id = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            item_id = 0
        base_id = by_variant.get(item_id)
        try:
            origin = _v895_link_origin(option)
        except Exception:
            origin = "external"
        category = str(_v89_option_value(option, "category") or "").strip().lower()

        # H59/H60 game-created collection bindings are local. Category is the
        # strongest discriminator when the manager exposes it; local+known-ID
        # is the backwards-compatible fallback for older saved rows.
        is_collection_local = bool(
            base_id
            and (category == "cas_collection" or origin == "local")
        )
        if not is_collection_local:
            result.append(option)
            continue
        if base_id in expanded_bases:
            continue
        expanded_bases.add(base_id)
        result.extend(by_base.get(base_id, ()) or (option,))
    return result


def _h63_switch_collection_variant_from_linked_editor(manager, pack_id, pose_name, item_id):
    """Switch a displayed collection swatch from LinkedActionEditor.

    Returns None when this is not a local collection product, otherwise a bool
    result. The UI catalog may contain sibling swatches that are not binding
    rows; this function maps that display choice back to the existing per-Pose
    local binding backend without creating a second storage model.
    """
    try:
        pack_id = str(pack_id or "").strip()
        pose_name = str(pose_name or "").strip()
        item_id = int(item_id or 0)
    except Exception:
        return None
    if not pack_id or not pose_name or not item_id:
        return None
    try:
        data = _caslib_load()
        item, variant = _caslib_find_item_by_variant(data, item_id)
    except Exception:
        item = variant = None
    if item is None or variant is None:
        return None

    sibling_ids = []
    for sibling in item.get("variants", ()) or ():
        try:
            value = int(sibling.get("cas_part_id") or 0)
        except Exception:
            value = 0
        if value and value not in sibling_ids:
            sibling_ids.append(value)
    if not sibling_ids:
        return None

    # Only intercept when this product is already a game-created local binding
    # for the linked Pose. External/package requirements keep their old path.
    try:
        from fgeh_linked_cas_bindings import get_saved_cas_part_ids_for_pose
        _asset_ids, local_ids = get_saved_cas_part_ids_for_pose(pack_id, pose_name)
        local_ids = set(int(value) for value in (local_ids or ()) if int(value or 0))
    except Exception:
        local_ids = set()
    if not local_ids.intersection(sibling_ids):
        return None

    # R24: this is a per-pose edit. Pack-wide changes are explicit Apply Pack.
    target_poses = [pose_name]

    # H65: selection state and binding state are deliberately separate.
    # Left-clicking the CURRENTLY SELECTED swatch again only deselects this
    # product for the current Pose.  The local binding row stays intact, so the
    # product remains visible in LinkedActionEditor and can be re-selected.
    # Actual binding deletion remains an explicit right-click/long-press action
    # handled by H61's local-unbind backend.
    try:
        option_ids = []
        for option in _v8942_release_cas_options(manager, pack_id, pose_name):
            try:
                value = int(_v89_option_value(option, "cas_part_id") or 0)
            except Exception:
                value = 0
            if value and value not in option_ids:
                option_ids.append(value)
        for value in sibling_ids:
            if value and value not in option_ids:
                option_ids.append(value)
        current_enabled = set(
            manager.get_enabled_linked_cas_part_ids(
                pack_id, pose_name, option_ids
            ) or ()
        )
    except Exception:
        option_ids = list(sibling_ids)
        current_enabled = set()

    if item_id in current_enabled:
        current_enabled.difference_update(sibling_ids)
        try:
            manager.set_enabled_linked_cas_part_ids(
                pack_id,
                pose_name,
                [value for value in option_ids if value in current_enabled],
            )
            manager.fgeh_pose_manager_debug_log(
                "[H65_LINKED_SWATCH_DESELECT] pack={} pose={} base={} item={} remaining={}".format(
                    pack_id, pose_name, item.get("base_id"), item_id,
                    [value for value in option_ids if value in current_enabled],
                )
            )
            return True
        except Exception:
            return False

    display_name = str(
        item.get("display_name")
        or item.get("catalog_name")
        or "配件 {}".format(item.get("base_id") or "")
    )
    try:
        from fgeh_linked_cas_bindings import set_cas_collection_product_for_poses
        changed = bool(set_cas_collection_product_for_poses(
            pack_id,
            target_poses,
            sibling_ids,
            item_id,
            body_type=int(item.get("body_type") or 0),
            display_name=display_name,
            source_type=str(item.get("source_type") or "unknown"),
            body_group="body_type_{}".format(int(item.get("body_type") or 0)),
        ))
    except Exception:
        changed = False
    if changed:
        _caslib_refresh_requirement_cache()
        for target_pose in target_poses:
            # Update only the clicked product. Binding catalog is not an enabled snapshot.
            desired = current_enabled.difference(sibling_ids)
            desired.add(item_id)
            manager.set_enabled_linked_cas_part_ids(
                pack_id, target_pose, sorted(desired)
            )
            manager.set_linked_cas_apply_enabled(pack_id, target_pose, True)
        try:
            manager.fgeh_pose_manager_debug_log(
                "[H65_LINKED_SWATCH_SWITCH] pack={} anchor={} poses={} base={} item={}".format(
                    pack_id, pose_name, len(target_poses), item.get("base_id"), item_id
                )
            )
        except Exception:
            pass
    return changed



def _v89_linked_detail_payload(
    manager,
    pack,
    item_tags,
    rows,
    first_resource_icon_index,
):
    """
    V8.9.31 payload architecture.

    OLD: every Pose serialized the same 50+ CAS variant rows + product groups.
    NEW: unique static CAS catalogs are serialized once.  A Pose row stores only
         catalog_index + selected CAS ids + auto flag.  Object resources remain
         per-Pose because their availability can legitimately differ.

    Old XML/snippet metadata is still accepted by _v8924_cas_product_identity.
    """
    pack_id = str(manager.get_pack_id(pack) or getattr(pack, "__name__", "") or "")
    import time
    started_at = time.perf_counter()
    result = []
    extra_icons = []
    extra_icon_offsets = {}

    shared_catalogs = []
    catalog_index_by_signature = {}
    pose_states = []

    for row_index, pose_item in enumerate(item_tags or ()):
        pose_name = str(getattr(pose_item, "pose_name", "") or "")
        cas_options = _v8942_release_cas_options(
            manager, pack_id, pose_name, log_hidden=True
        )
        # H63: binding rows stay one selected CASPart per product; the editor
        # receives a richer display catalog containing every collection swatch.
        display_cas_options = _h63_expand_collection_variants_for_linked_display(
            cas_options
        )
        try:
            object_options = list(manager.get_linked_object_variant_options(pack_id, pose_name) or ())
        except Exception:
            object_options = []

        cas_ids = []
        for option in cas_options:
            try:
                item_id = int(_v89_option_value(option, "cas_part_id") or 0)
            except Exception:
                item_id = 0
            if item_id:
                cas_ids.append(item_id)

        object_ids = []
        for option in object_options:
            try:
                item_id = int(_v89_option_value(option, "definition_id", "object_definition_id") or 0)
            except Exception:
                item_id = 0
            if item_id:
                object_ids.append(item_id)

        try:
            cas_auto = bool(manager.is_linked_cas_apply_enabled(pack_id, pose_name))
        except Exception:
            cas_auto = True
        try:
            object_auto = bool(manager.is_linked_object_spawn_enabled(pack_id, pose_name))
        except Exception:
            object_auto = True

        try:
            cas_enabled = set(manager.get_enabled_linked_cas_part_ids(pack_id, pose_name, cas_ids) or ())
        except Exception:
            cas_enabled = set(cas_ids if cas_auto else ())

        cas_enabled = _v8928_enforce_single_selected_variant(
            manager, pack_id, pose_name, cas_options, cas_ids, cas_enabled,
        )

        try:
            object_enabled_raw = manager.get_enabled_linked_object_definition_ids(
                pack_id, pose_name, object_ids
            )
            object_enabled = set(
                object_ids
                if object_enabled_raw is None
                else (object_enabled_raw or ())
            )
        except Exception:
            object_enabled = set(object_ids if object_auto else ())

        # V8.9.34 normalizes legacy multi-style object choices for display and
        # copy/apply semantics. It does not force a save merely by opening UI.
        object_enabled = set(
            _v8934_choose_one_object_variant_per_product(
                object_options, object_enabled
            )
        )

        signature = _v8931_cas_catalog_signature(display_cas_options)
        catalog_index = catalog_index_by_signature.get(signature)
        if catalog_index is None:
            catalog_index = len(shared_catalogs)
            catalog_index_by_signature[signature] = catalog_index
            shared_catalogs.append(_v8931_build_shared_cas_catalog(display_cas_options, manager))

        pose_states.append({
            "pose_name": pose_name,
            "catalog_index": int(catalog_index),
            "cas_auto": bool(cas_auto),
            "selected_ids": [value for value in cas_ids if value in cas_enabled],
        })

        # V8.9.31: linked-detail resources now contain OBJECTS ONLY.  CAS static
        # metadata lives in shared_catalogs; enabled state lives in pose_states.
        resources = []
        object_entries = []
        for option in object_options:
            try:
                item_id = int(_v89_option_value(option, "definition_id", "object_definition_id") or 0)
            except Exception:
                item_id = 0
            if not item_id:
                continue
            localized_object_name, _catalog_name_key = (
                _v89692_object_catalog_localization(item_id)
            )
            label = localized_object_name or _v89_option_value(
                option,
                "display_name", "entry_label", "label", "name", "catalog_name"
            ) or "Object {}".format(item_id)
            description = _v89_option_value(
                option, "description", "row_description", "source_type"
            ) or "Object Definition ID: {}".format(item_id)
            icon, icon_source, icon_raw = _v8919_resolve_linked_icon(option, None)
            if icon is not None:
                icon = _valid_icon_resource(manager, icon, "linked-object:{}:{}".format(pose_name, item_id))
            if icon is None:
                icon = _v8920_object_definition_icon(item_id)
                icon_source = "object_definition"
                icon_raw = item_id
            dedupe_key = _v8930_linked_icon_dedupe_key(icon)
            icon_offset = extra_icon_offsets.get(dedupe_key)
            if icon_offset is None:
                icon_offset = len(extra_icons)
                extra_icon_offsets[dedupe_key] = icon_offset
                extra_icons.append(icon)
                _v8919_log_linked_icon(manager, "object", item_id, option, icon_source, icon_raw, icon)

            resource = {
                "type": "object",
                "item_id": item_id,
                # Do NOT stringify EA LocalizedString object names here.
                "label": label,
                "description": description,
                "enabled": object_auto and item_id in object_enabled,
                "icon_index": first_resource_icon_index + icon_offset,
                "origin": _v895_link_origin(option),
            }
            resources.append(resource)
            object_entries.append((len(resources) - 1, option, resource))

        object_products = _v8934_build_object_products(object_entries, manager)

        if row_index < len(rows):
            summary = []
            # Product-level summary is more meaningful after exclusive swatches.
            product_count = len(shared_catalogs[catalog_index]) if catalog_index < len(shared_catalogs) else 0
            if cas_ids:
                summary.append("配饰 {}/{}".format(
                    len(cas_enabled) if cas_auto else 0,
                    product_count or len(cas_ids),
                ))
            if object_ids:
                object_selected_products = 0
                if object_auto:
                    for product in object_products:
                        if any(
                            int(variant.get("item_id", 0) or 0) in object_enabled
                            for variant in product.get("variants", ()) or ()
                        ):
                            object_selected_products += 1
                summary.append("物体 {}/{}".format(
                    object_selected_products,
                    len(object_products) or len(object_ids),
                ))
            if summary:
                rows[row_index]["creator"] = " · ".join(summary)

        result.append({
            "pose_name": pose_name,
            "cas_auto": cas_auto,
            "object_auto": object_auto,
            "resources": resources,
            "object_products": object_products,
            # Empty on purpose: V2 shared catalog is in header.  Adapter keeps
            # V1 support when shared catalogs are absent.
            "cas_products": (),
        })

    try:
        total_variants = sum(
            len(product.get("variants", ()))
            for catalog in shared_catalogs
            for product in catalog
        )
        manager.fgeh_pose_manager_debug_log(
            "[LINKED_CATALOG_V2] build={} pack={} poses={} catalogs={} variants={} unique_object_icons={} elapsed_ms={:.1f}".format(
                UI_BUILD_TAG, pack_id, len(result), len(shared_catalogs), total_variants,
                len(extra_icons), (time.perf_counter() - started_at) * 1000.0,
            )
        )
    except Exception:
        pass

    # V8.9.38: one lightweight edit-metadata table lets GFX middle-click
    # any linked CAS/object product and reuse the existing edit-info modal.
    # The static product protocols themselves stay byte-for-byte compatible.
    linked_edit_items = []
    seen_edit_keys = set()
    for catalog in shared_catalogs:
        for product in catalog or ():
            key = str(product.get("edit_key", "") or "")
            if key and key not in seen_edit_keys:
                seen_edit_keys.add(key)
                linked_edit_items.append({
                    "key": key,
                    "name": str(product.get("custom_name", "") or ""),
                    "note": str(product.get("note", "") or ""),
                    "original": product.get("original_product_label", "") or "",
                })
    for row in result:
        for product in row.get("object_products", ()) or ():
            key = str(product.get("edit_key", "") or "")
            if key and key not in seen_edit_keys:
                seen_edit_keys.add(key)
                linked_edit_items.append({
                    "key": key,
                    "name": str(product.get("custom_name", "") or ""),
                    "note": str(product.get("note", "") or ""),
                    "original": product.get("original_product_label", "") or "",
                })

    return result, extra_icons, shared_catalogs, pose_states, linked_edit_items


def _schedule_pack_reopen(
    manager,
    owner,
    pack,
    on_item_selected,
    on_back,
    reason,
):
    # Repaint/refresh is NOT navigation. Update the existing pack leaf instead
    # of pushing another history entry.
    _nav_sync_pack(manager, pack, page=None, save=False)
    import alarms
    from date_and_time import TimeSpan

    holder = {}

    def _reopen(_alarm_handle):
        alarm_handle = holder.get("handle")
        if alarm_handle is not None:
            _PENDING_REOPEN_ALARMS.pop(id(alarm_handle), None)
        manager.fgeh_pose_manager_debug_log(
            "custom UI pack deferred reopen begin reason={}".format(reason)
        )
        _h49_trace(
            "REOPEN_BEGIN reason={} mode={!r} feedback={!r}".format(
                reason, _bind_select_mode_kind(manager),
                getattr(manager.state, "custom_pose_ui_link_register_feedback", ""),
            )
        )
        opened = show_pose_manager_pack_detail(
            owner,
            pack,
            on_item_selected=on_item_selected,
            on_back=on_back,
        )
        manager.fgeh_pose_manager_debug_log(
            "custom UI pack deferred reopen result={} reason={} last_error={!r}".format(
                opened,
                reason,
                LAST_ERROR,
            )
        )
        _h49_trace(
            "REOPEN_RESULT opened={} reason={} mode={!r} feedback={!r} last_error={!r}".format(
                opened, reason, _bind_select_mode_kind(manager),
                getattr(manager.state, "custom_pose_ui_link_register_feedback", ""), LAST_ERROR
            )
        )

    try:
        alarm_handle = alarms.add_alarm_real_time(
            owner,
            TimeSpan.ZERO,
            _reopen,
            use_sleep_time=False,
        )
    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "custom UI pack real-time reopen alarm failed; using simulation alarm",
            exc=True,
        )
        alarm_handle = alarms.add_alarm(owner, TimeSpan.ZERO, _reopen)
    holder["handle"] = alarm_handle
    _PENDING_REOPEN_ALARMS[id(alarm_handle)] = alarm_handle
    manager.fgeh_pose_manager_debug_log(
        "custom UI pack deferred reopen scheduled reason={} handle={}".format(
            reason,
            id(alarm_handle),
        )
    )


def _show_custom_inner_group_rename_dialog(
    manager,
    owner,
    pack,
    old_name,
    on_item_selected,
    on_back,
):
    """
    Reuse the mod's existing rename_dialog tuning, but return to the
    custom EpicCard UI instead of reopening the old Picker.
    """
    import services
    import sims4.resources
    from event_testing.resolver import SingleSimResolver
    from sims4.localization import LocalizationHelperTuning

    sim_info = getattr(owner, "sim_info", owner)
    live_owner = getattr(
        sim_info,
        "get_sim_instance",
        lambda: owner,
    )()
    if live_owner is None:
        return False

    interaction_tuning = services.get_instance_manager(
        sims4.resources.Types.INTERACTION
    ).get(5376477438524819063)

    if interaction_tuning is None:
        manager.fgeh_pose_manager_debug_log(
            "V8 rename dialog tuning missing"
        )
        return False

    dialog = interaction_tuning.rename_dialog(
        live_owner,
        SingleSimResolver(sim_info),
    )

    pack_id = str(
        manager.get_pack_id(pack)
        or getattr(pack, "__name__", "")
        or ""
    )

    def _finish():
        _schedule_pack_reopen(
            manager,
            live_owner,
            pack,
            on_item_selected,
            on_back,
            "rename-inner-group",
        )

    def _on_rename_response(response_dialog):
        try:
            if response_dialog.accepted:
                new_name = response_dialog.text_input_responses.get(
                    interaction_tuning.TEXT_INPUT_NEW_NAME
                )
                if new_name is not None:
                    new_name = str(new_name).strip()

                    groups = getattr(
                        manager.state,
                        "grouped_packs",
                        {},
                    ) or {}
                    pack_groups = groups.get(pack_id, {}) or {}

                    if (
                        new_name
                        and new_name != old_name
                        and old_name in pack_groups
                        and new_name not in pack_groups
                    ):
                        pack_groups[new_name] = pack_groups.pop(
                            old_name
                        )

                        if getattr(
                            manager.state,
                            "custom_pose_ui_active_inner_group",
                            None,
                        ) == old_name:
                            manager.state.custom_pose_ui_active_inner_group = new_name

                        if getattr(
                            manager.state,
                            "custom_pose_ui_edit_inner_group",
                            None,
                        ) == old_name:
                            manager.state.custom_pose_ui_edit_inner_group = new_name

                        groups[pack_id] = pack_groups
                        manager.state.grouped_packs = groups
                        manager.save_favorites()
        finally:
            _finish()

    localized_old_name_factory = (
        lambda *args, **kwargs:
        LocalizationHelperTuning.get_raw_text(old_name)
    )
    overrides = {
        interaction_tuning.TEXT_INPUT_NEW_NAME:
            localized_old_name_factory
    }

    dialog.add_listener(_on_rename_response)
    dialog.show_dialog(text_input_overrides=overrides)
    return True



def _v86_resolve_interaction_from_callback(callback):
    """
    Recover the live PoseByPack interaction captured by the custom UI callback.

    The custom panel is intentionally decoupled from couplepose1.py, so the
    interaction is not passed as a formal parameter.  In current integration
    builds it is either the bound-method owner or a closure/partial capture.
    """
    seen = set()
    queue = [callback]

    while queue:
        obj = queue.pop(0)
        if obj is None:
            continue

        obj_id = id(obj)
        if obj_id in seen:
            continue
        seen.add(obj_id)

        try:
            if (
                hasattr(obj, "sim")
                and hasattr(obj, "target")
                and hasattr(obj, "_show_picker_dialog")
            ):
                return obj
        except Exception:
            pass

        try:
            bound_self = getattr(obj, "__self__", None)
            if bound_self is not None:
                queue.append(bound_self)
        except Exception:
            pass

        try:
            closure = getattr(obj, "__closure__", None)
            if closure:
                for cell in closure:
                    try:
                        queue.append(cell.cell_contents)
                    except Exception:
                        pass
        except Exception:
            pass

        # functools.partial compatibility.
        try:
            func = getattr(obj, "func", None)
            if func is not None:
                queue.append(func)
            for value in (getattr(obj, "args", ()) or ()):
                queue.append(value)
            for value in (getattr(obj, "keywords", {}) or {}).values():
                queue.append(value)
        except Exception:
            pass

    return None



def _v8966_restore_original_outfit(sim_info):
    """Call the existing linked-CAS restore routine without touching its Interaction tuning."""
    candidates = (
        ("fgeh_cas_accessory_outfit_utils", "restore_original_outfit"),
        ("fgeh_cas_accessory_picker", "restore_original_outfit"),
    )
    last_error = None
    for module_name, function_name in candidates:
        try:
            module = __import__(module_name, fromlist=(function_name,))
            function = getattr(module, function_name)
        except Exception as exc:
            last_error = exc
            continue

        targets = [sim_info]
        try:
            sim = sim_info.get_sim_instance() if sim_info is not None else None
        except Exception:
            sim = None
        if sim is not None and sim is not sim_info:
            targets.append(sim)

        for target in targets:
            try:
                return function(target)
            except TypeError as exc:
                last_error = exc
                continue
            except Exception as exc:
                last_error = exc
                continue

    if last_error is not None:
        raise last_error
    return False


def _v8966_clear_linked_objects(sim_info):
    """Force-clear linked objects using the existing runtime cleanup APIs.

    Prefer the current-lot cleanup because this button is the recovery path for
    stuck generated objects. Fall back to the current Sim registry if the older
    runtime does not expose the lot-wide helper.
    """
    last_error = None
    try:
        from fgeh_linked_object_runtime import destroy_all_linked_objects
        try:
            return destroy_all_linked_objects()
        except TypeError:
            # Some historical builds accepted an optional target.
            try:
                return destroy_all_linked_objects(sim_info)
            except Exception as exc:
                last_error = exc
        except Exception as exc:
            last_error = exc
    except Exception as exc:
        last_error = exc

    try:
        from fgeh_linked_object_runtime import destroy_linked_objects_for_sim
        targets = [sim_info]
        try:
            sim = sim_info.get_sim_instance() if sim_info is not None else None
        except Exception:
            sim = None
        if sim is not None and sim is not sim_info:
            targets.append(sim)
        for target in targets:
            try:
                return destroy_linked_objects_for_sim(target)
            except Exception as exc:
                last_error = exc
    except Exception as exc:
        last_error = exc

    if last_error is not None:
        raise last_error
    return 0


def _v882_play_all_visible(
    manager,
    owner,
    pack,
    item_tags,
    on_item_selected,
    on_back,
    selected_pose_names=None,
    reopen=True,
):
    """
    Queue every real Pose represented by the CURRENT pack-detail view.

    This deliberately mirrors the old G_PLAY_ALL_IN_GROUP implementation,
    but it is no longer limited to grouped-pack mode.

    - normal pack detail -> whole pack
    - selected inner group -> that group only
    - 收藏动作 / 收藏动作分组 -> only the filtered favorite poses
    """
    import services
    from interactions.context import QueueInsertStrategy
    from interactions.priority import Priority

    interaction = _v86_resolve_interaction_from_callback(on_item_selected)

    if interaction is None:
        manager.fgeh_pose_manager_debug_log(
            "V8.8.2 play-all could not resolve interaction; reopening detail"
        )
        _schedule_pack_reopen(
            manager,
            owner,
            pack,
            on_item_selected,
            on_back,
            "play-all-no-interaction",
        )
        return False

    actual_target = getattr(interaction, "target", None)

    try:
        custom_target_id = getattr(
            interaction,
            "fgeh_custom_target_id",
            None,
        )
        if custom_target_id:
            found_sim = services.object_manager().get(custom_target_id)
            if found_sim is not None:
                actual_target = found_sim
    except Exception:
        pass

    if actual_target is None:
        manager.fgeh_pose_manager_debug_log(
            "V8.8.2 play-all missing target; reopening detail"
        )
        _schedule_pack_reopen(
            manager,
            owner,
            pack,
            on_item_selected,
            on_back,
            "play-all-no-target",
        )
        return False

    pose_items = [
        tag
        for tag in (item_tags or ())
        if hasattr(tag, "pose_name")
        and getattr(tag, "pose_name", None)
    ]

    if selected_pose_names is not None:
        selected_pose_names = set(
            str(value)
            for value in (selected_pose_names or ())
            if value
        )
        pose_items = [
            pose_item
            for pose_item in pose_items
            if str(getattr(pose_item, "pose_name", "") or "")
            in selected_pose_names
        ]

    queued = 0

    try:
        for pose_item in pose_items:
            pose_name = getattr(pose_item, "pose_name", None)
            if not pose_name:
                continue

            try:
                interaction.interaction_parameters["pose_name"] = pose_name
            except Exception:
                pass

            try:
                _cas_result = manager.try_apply_linked_accessory_before_pose(
                    actual_target,
                    pose_name,
                    pack,
                )
                manager.fgeh_pose_manager_debug_log(
                    "[LINKED_APPLY] build={} pose={} type=cas global_auto={} result={!r}".format(
                        UI_BUILD_TAG,
                        pose_name,
                        bool(
                            getattr(
                                manager.state,
                                "auto_apply_linked_requirements",
                                True,
                            )
                        ),
                        _cas_result,
                    )
                )
            except Exception:
                manager.fgeh_pose_manager_debug_log(
                    "[LINKED_APPLY] CAS exception pose={}".format(
                        pose_name
                    ),
                    exc=True,
                )

            try:
                _object_result = manager.try_spawn_linked_objects_before_pose(
                    actual_target,
                    pose_name,
                    pack,
                )
                manager.fgeh_pose_manager_debug_log(
                    "[LINKED_APPLY] build={} pose={} type=object global_auto={} spawned={}".format(
                        UI_BUILD_TAG,
                        pose_name,
                        bool(
                            getattr(
                                manager.state,
                                "auto_apply_linked_requirements",
                                True,
                            )
                        ),
                        len(_object_result or ()),
                    )
                )
            except Exception:
                manager.fgeh_pose_manager_debug_log(
                    "[LINKED_APPLY] OBJECT exception pose={}".format(
                        pose_name
                    ),
                    exc=True,
                )

            interaction.push_tunable_continuation(
                interaction.continuation,
                pose_name=pose_name,
                insert_strategy=QueueInsertStrategy.LAST,
                priority=Priority.High,
                actor=actual_target,
            )
            queued += 1

        manager.fgeh_pose_manager_debug_log(
            "V8.9.6 pose-sequence queued pack_id={} count={} selected_mode={} active_group={!r} favorite_only={}".format(
                str(manager.get_pack_id(pack) or getattr(pack, "__name__", "Unknown")),
                queued,
                selected_pose_names is not None,
                getattr(
                    manager.state,
                    "custom_pose_ui_active_inner_group",
                    None,
                ),
                bool(
                    getattr(
                        manager.state,
                        "custom_pose_ui_favorite_only",
                        False,
                    )
                ),
            )
        )

    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "V8.8.2 play-all queue failed after count={}".format(queued),
            exc=True,
        )

    # Response-based Play All closes the UiDialog and still reopens.
    # Selected playback is a server command and keeps the current dialog open.
    if reopen:
        _schedule_pack_reopen(
            manager,
            owner,
            pack,
            on_item_selected,
            on_back,
            "play-visible:{}".format(queued),
        )
    return queued > 0


def _v86_show_custom_target_sim_picker(
    manager,
    owner,
    pack,
    on_item_selected,
    on_back,
):
    """
    V8.6 target picker.

    IMPORTANT:
    Do NOT call couplepose1.show_fgeh_sim_picker() or forward
    BTN_SELECT_OTHER_SIM into the old choice handler here.

    The legacy helper always returns by calling interaction._show_picker_dialog(),
    which is the old POSE BY PACK picker.  That is exactly what caused the
    native pink picker to take over and repeatedly reopen after V8.5.
    """
    import services
    from sims4.localization import LocalizationHelperTuning
    from ui.ui_dialog_picker import UiSimPicker, SimPickerRow

    interaction = _v86_resolve_interaction_from_callback(on_item_selected)

    manager.fgeh_pose_manager_debug_log(
        "V8.6 target picker resolve callback_type={} interaction_type={}".format(
            type(on_item_selected).__name__ if on_item_selected is not None else "None",
            type(interaction).__name__ if interaction is not None else "None",
        )
    )

    if interaction is None:
        manager.fgeh_pose_manager_debug_log(
            "V8.6 target picker could not resolve interaction; safely reopening custom detail"
        )
        _schedule_pack_reopen(
            manager,
            owner,
            pack,
            on_item_selected,
            on_back,
            "target-picker-no-interaction",
        )
        return False

    sim_info = getattr(owner, "sim_info", owner)
    live_owner = getattr(
        sim_info,
        "get_sim_instance",
        lambda: owner,
    )()
    if live_owner is None:
        live_owner = getattr(interaction, "sim", None)

    if live_owner is None:
        manager.fgeh_pose_manager_debug_log(
            "V8.6 target picker missing live owner; safely reopening custom detail"
        )
        _schedule_pack_reopen(
            manager,
            owner,
            pack,
            on_item_selected,
            on_back,
            "target-picker-no-owner",
        )
        return False

    try:
        title_text = _loc("target_picker_title", fallback="选择目标小人")
        body_text = _loc("target_picker_desc", fallback="选择接下来播放动作的小人")

        dialog = UiSimPicker.TunableFactory().default(
            live_owner,
            title=lambda **_: title_text,
            text=lambda **_: body_text,
            min_selectable=1,
            max_selectable=1,
            column_count=3,
            should_show_names=True,
        )

        row_count = 0
        for candidate in services.sim_info_manager().instanced_sims_gen():
            if candidate is None:
                continue

            sim_id = getattr(
                candidate,
                "id",
                getattr(candidate, "sim_id", 0),
            )
            first_name = getattr(candidate, "first_name", None)

            if sim_id and first_name:
                dialog.add_row(
                    SimPickerRow(
                        sim_id=sim_id,
                        select_default=False,
                        tag=sim_id,
                    )
                )
                row_count += 1

        manager.fgeh_pose_manager_debug_log(
            "V8.6 custom target picker show rows={}".format(row_count)
        )

        def _on_target_response(response_dialog):
            try:
                selected_id = None

                if response_dialog.accepted:
                    try:
                        result_tags = response_dialog.get_result_tags() or ()
                    except Exception:
                        result_tags = ()

                    if result_tags:
                        selected_id = result_tags[0]

                if selected_id:
                    try:
                        interaction.fgeh_custom_target_id = selected_id
                        manager.fgeh_pose_manager_debug_log(
                            "V8.6 target selected sim_id={}".format(selected_id)
                        )
                    except Exception:
                        manager.fgeh_pose_manager_debug_log(
                            "V8.6 failed to store target sim_id={}".format(selected_id),
                            exc=True,
                        )
                else:
                    manager.fgeh_pose_manager_debug_log(
                        "V8.6 target picker cancelled"
                    )
            finally:
                # Always return to the CUSTOM detail UI.
                # Never call interaction._show_picker_dialog() here.
                _schedule_pack_reopen(
                    manager,
                    owner,
                    pack,
                    on_item_selected,
                    on_back,
                    "target-picker-return",
                )

        dialog.add_listener(_on_target_response)
        dialog.show_dialog()
        return True

    except Exception:
        manager.fgeh_pose_manager_debug_log(
            "V8.6 custom target picker failed; safely reopening custom detail",
            exc=True,
        )
        _schedule_pack_reopen(
            manager,
            owner,
            pack,
            on_item_selected,
            on_back,
            "target-picker-exception",
        )
        return False


def _v8944_dialog_portrait_sim_info(owner, callback=None):
    """Resolve the Sim whose portrait the custom GFX should show.

    Dialog ownership/resolver stays on the original owner. This helper only
    chooses icon_override: custom target Sim first, then interaction target,
    finally the original owner.
    """
    base_info = getattr(owner, "sim_info", owner)
    try:
        import services

        interaction = _v86_resolve_interaction_from_callback(callback)
        if interaction is None:
            return base_info

        target = None
        custom_target_id = getattr(interaction, "fgeh_custom_target_id", None)
        if custom_target_id:
            try:
                target = services.object_manager().get(custom_target_id)
            except Exception:
                target = None
            if target is None:
                try:
                    target_info = services.sim_info_manager().get(custom_target_id)
                    if target_info is not None:
                        return target_info
                except Exception:
                    pass

        if target is None:
            target = getattr(interaction, "target", None)

        target_info = getattr(target, "sim_info", None)
        if target_info is not None:
            return target_info
    except Exception:
        pass

    return base_info


def show_pose_manager_pack_detail(
    owner,
    pack,
    on_item_selected=None,
    on_back=None,
):
    """Open one pose pack in the same wide UI used by the root library."""
    global LAST_ERROR
    LAST_ERROR = ""
    try:
        import couplepose1 as manager
        _release_disable_debug_log(manager)
        _v89692_install_release_linked_gate(manager)
        if _nav_bridge is not None:
            try:
                _nav_bridge.ensure_installed()
            except Exception:
                pass
        _v88_ensure_metadata_state(manager)
        if not manager.is_custom_pose_manager_ui_enabled():
            LAST_ERROR = "custom_pose_manager_ui is disabled"
            return False
        if USE_NATIVE_DETAIL_FALLBACK:
            return _show_native_pack_detail(
                manager,
                owner,
                pack,
                on_item_selected,
                on_back,
            )

        from distributor.shared_messages import IconInfoData, create_icon_info_msg
        from event_testing.resolver import SingleSimResolver
        from sims4.localization import LocalizationHelperTuning
        from ui.ui_dialog import UiDialogResponse
        from ui.ui_dialog_labeled_icons import UiDialogIcons

        sim_info = getattr(owner, "sim_info", owner)
        live_owner = getattr(sim_info, "get_sim_instance", lambda: owner)()
        if live_owner is None:
            LAST_ERROR = "active Sim instance is unavailable"
            return False

        rows, icon_keys, item_tags = _build_pack_detail_rows(manager, pack)
        pack_id = str(manager.get_pack_id(pack) or getattr(pack, "__name__", "Unknown"))
        _h49_trace(
            "OPEN pack={!r} nav={} mode={!r} feedback_pack={!r} feedback_pose={!r}".format(
                pack_id,
                _v7_active_nav(manager),
                _bind_select_mode_kind(manager),
                getattr(manager.state, "custom_pose_ui_link_register_feedback_pack_id", ""),
                getattr(manager.state, "custom_pose_ui_link_register_feedback", ""),
            )
        )

        global _ACTIVE_PLAY_CONTEXT
        _ACTIVE_PLAY_CONTEXT = {
            "owner": live_owner,
            "pack": pack,
            "item_tags": tuple(item_tags or ()),
            "on_item_selected": on_item_selected,
            "on_back": on_back,
        }
        pack_pages = getattr(manager.state, "custom_pose_ui_pack_pages", None)
        if not isinstance(pack_pages, dict):
            pack_pages = {}
            manager.state.custom_pose_ui_pack_pages = pack_pages
        page = clamp_page(pack_pages.get(pack_id, 0), len(rows))
        page_count = max(1, (len(rows) + PAGE_SIZE - 1) // PAGE_SIZE)
        pose_count = sum(1 for tag in item_tags if hasattr(tag, "pose_name"))
        pack_name = manager.get_pack_display_name(pack, allow_placeholder=True) or pack_id
        # V8: the custom library is scroll-only.  Internally the scrollbar
        # still jumps between 12-item windows, but there is no page-mode UI.
        navigation_mode = "scroll"
        manager.state.custom_pose_ui_navigation_mode = "scroll"

        # H48: this value is consumed while the header is being built below.
        # H47 accidentally assigned it later, which raised UnboundLocalError
        # for every normal pack and forced the legacy POSE BY PACK fallback.
        _linked_detail = (_v7_active_nav(manager) == NAV_LINKED_ACTIONS)

        header = {
            "page": page,
            "page_count": page_count,
            "page_label": _loc("tpl_page", page + 1, page_count, fallback="第 {} / {} 页"),
            "filter": "pack",
            "query": "",
            "navigation_mode": navigation_mode,
            "navigation_label": (
                "__FGEH_LINK_REGISTER_ARMED__"
                if (not _linked_detail and _bind_select_mode_kind(manager) == "register")
                else (
                    "__FGEH_LINK_REGISTERED__"
                    if (
                        not _linked_detail
                        and str(getattr(manager.state, "custom_pose_ui_link_register_feedback_pack_id", "") or "") == str(pack_id or "")
                        and bool(getattr(manager.state, "custom_pose_ui_link_register_feedback", "") or "")
                    )
                    else (
                        "浏览方式：滑动" if navigation_mode == "scroll" else "浏览方式：翻页"
                    )
                )
            ),
            "item_count": pose_count,
            "view_title": pack_name,
            "library_label": (
                "返回联动库"
                if _v7_active_nav(manager) == NAV_LINKED_ACTIONS
                else "返回动作库"
            ),
        }

        # W7D2: after a successful local linked delete, reopen exactly the
        # same Pose's Linked Settings after the fresh payload has been rebuilt.
        try:
            _reenter_pack = str(getattr(manager.state, "custom_pose_ui_linked_reenter_pack_id", "") or "")
            _reenter_pose = str(getattr(manager.state, "custom_pose_ui_linked_reenter_pose_name", "") or "")
        except Exception:
            _reenter_pack, _reenter_pose = "", ""
        _reenter_marker_written = False
        if _linked_detail and _reenter_pack == pack_id and _reenter_pose:
            for _ri, _rtag in enumerate(item_tags or ()):
                if str(getattr(_rtag, "pose_name", "") or "") == _reenter_pose:
                    header["navigation_label"] = "__FGEH_LINKED_REENTER_INDEX__:{}".format(int(_ri))
                    _reenter_marker_written = True
                    break

        _v8951_attach_global_widget_state(header, manager)

        header["favorite_pack_group_names"] = list(
            (getattr(manager.state, "user_fav_groups", {}) or {}).keys()
        )
        header["favorite_pose_group_names"] = list(
            (getattr(manager.state, "user_fav_pose_groups", {}) or {}).keys()
        )
        header["outer_action_group_names"] = list(
            (getattr(manager.state, "user_grouped_packs_groups", {}) or {}).keys()
        )

        _group_pack_id, _group_dict, _group_names = _v75_pack_group_names(
            manager,
            pack,
        )
        if _linked_detail:
            _group_names = _v89_linked_group_names_for_pack(
                manager,
                _group_pack_id,
                _group_dict,
                _group_names,
            )

        _selected_group = _v75_active_inner_group(
            manager,
            _group_names,
        )

        _edit_group = (
            None
            if _linked_detail
            else _v8_edit_inner_group(
                manager,
                _group_names,
            )
        )

        # Detail always uses the V8 extension.
        header["enable_v7"] = True
        header["view_kind"] = (
            "pack_detail_linked"
            if _linked_detail
            else (
                "pack_detail_group_edit"
                if _edit_group
                else "pack_detail_groups"
            )
        )
        header["active_nav"] = _v7_active_nav(manager)
        header["group_names"] = _group_names
        header["active_group_index"] = _v75_inner_group_index(
            _group_names,
            _selected_group,
        )

        if _edit_group:
            edit_index = _v75_inner_group_index(
                _group_names,
                _edit_group,
            )
            header["member_edit_mode"] = True
            header["member_edit_group_index"] = edit_index
            header["member_selected_flags"] = "".join(
                "1" if row.get("member_selected") else "0"
                for row in rows
            )

        outer_names, outer_selected = _v8_outer_group_state(
            manager,
            pack_id,
        )
        header["outer_group_names"] = outer_names
        header["outer_group_selected"] = outer_selected

        header["edit_keys"] = [
            "pose_{}".format(str(getattr(tag, "pose_name", "") or ""))
            if hasattr(tag, "pose_name") else ""
            for tag in item_tags
        ]
        header["edit_names"] = [
            str((getattr(manager.state, "custom_names", {}) or {}).get(key, "") or "")
            if key else "" for key in header["edit_keys"]
        ]
        header["edit_notes"] = [
            _v88_custom_note(manager, key) if key else ""
            for key in header["edit_keys"]
        ]

        if _linked_detail:
            linked_detail_rows, linked_extra_icons, linked_cas_catalogs, linked_cas_pose_states, linked_edit_items = _v89_linked_detail_payload(
                manager,
                pack,
                item_tags,
                rows,
                len(icon_keys),
            )
            header["linked_detail"] = True
            header["linked_pack_id"] = pack_id
            header["linked_detail_rows"] = linked_detail_rows
            header["linked_cas_catalogs"] = linked_cas_catalogs
            header["linked_cas_pose_states"] = linked_cas_pose_states
            header["linked_edit_items"] = linked_edit_items
            icon_keys.extend(linked_extra_icons)

            manager.fgeh_pose_manager_debug_log(
                "V8.9 linked detail payload pack_id={} poses={} unique_resource_icons={}".format(
                    pack_id,
                    len(linked_detail_rows),
                    len(linked_extra_icons),
                )
            )

        _attach_ui_localization(header)
        _h49_trace(
            "PAYLOAD pack={!r} linked_detail={} marker={!r} mode={!r} feedback={!r}".format(
                pack_id, _linked_detail, header.get("navigation_label", ""),
                _bind_select_mode_kind(manager),
                getattr(manager.state, "custom_pose_ui_link_register_feedback", ""),
            )
        )
        raw_payload = pack_payload(header, rows)
        if _linked_detail and _reenter_pack == pack_id and _reenter_pose:
            try:
                manager.state.custom_pose_ui_linked_reenter_pack_id = ""
                manager.state.custom_pose_ui_linked_reenter_pose_name = ""
            except Exception:
                pass
        # H49: successful registration feedback is intentionally persistent
        # for this pack. It is cleared only by an explicit next action, Back,
        # Close, or arming another registration. This prevents a rapid extra
        # reopen/refresh from erasing “已加入联动” before the user can see it.
        _target_rail = None
        try:
            import fgeh_target_rail as _target_rail
            raw_payload = _target_rail.prepare_safe(__import__(__name__), manager, live_owner, on_item_selected, raw_payload,
                (header.get("view_kind") == "pack_detail_groups" or (header.get("view_kind") == "pack_detail_linked" and header.get("active_nav") == NAV_LINKED_ACTIONS)) and _bind_select_mode_kind(manager) != "register", len(icon_keys))
        except Exception as _rail_error:
            manager.fgeh_pose_manager_debug_log("T03 optional rail import failed: {}".format(_rail_error))
        localized_payload = _localized_payload_cached(
            "detail", raw_payload, manager
        )
        additional_icon_messages = []
        for icon_index, icon_key in enumerate(icon_keys):
            try:
                icon_info = _v8920_create_icon_info(IconInfoData, icon_key)
                additional_icon_messages.append(
                    create_icon_info_msg(icon_info)
                )
                if _v8920_is_object_definition_icon(icon_key):
                    manager.fgeh_pose_manager_debug_log(
                        "[LINKED_ICON_MSG] build={} index={} mode=obj_def definition_id={}".format(
                            UI_BUILD_TAG,
                            icon_index,
                            int(icon_key.get("definition_id") or 0),
                        )
                    )
            except Exception:
                manager.fgeh_pose_manager_debug_log(
                    "custom UI pack replaced invalid icon value={!r}".format(icon_key),
                    exc=True,
                )
                additional_icon_messages.append(create_icon_info_msg(IconInfoData()))

        if _target_rail is not None:
            additional_icon_messages.extend(_target_rail.icons())
        blank = LocalizationHelperTuning.get_raw_text("")
        dialog = UiDialogIcons.TunableFactory().default(
            live_owner,
            resolver=SingleSimResolver(sim_info),
            title=_constant_localized_string(blank),
            text=_constant_localized_string(blank),
            additional_texts=localized_payload,
            show_dialog_message_override=SHOW_MESSAGE,
        )
        if _target_rail is not None:
            try:
                _target_rail.bind(dialog)
            except Exception as _rail_error:
                _target_rail.diagnostic("bind_failed", _rail_error)
        dialog.set_responses((
            UiDialogResponse(dialog_response_id=RESPONSE_BACK),
        ))
        manager.fgeh_pose_manager_debug_log(
            "custom UI pack dialog prepared id={} pack_id={} rows={} page={}".format(
                dialog.dialog_id,
                pack_id,
                len(rows),
                page,
            )
        )

        def _on_response(response_dialog):
            try:
                response = getattr(response_dialog, "response", None)
                try:
                    response_value = int(response)
                except Exception:
                    response_value = response
                manager.fgeh_pose_manager_debug_log(
                    "custom UI pack response raw={!r} value={!r} pack_id={}".format(
                        response,
                        response_value,
                        pack_id,
                    )
                )
                _h49_trace(
                    "RESPONSE pack={!r} raw={!r} value={!r} mode={!r} feedback={!r}".format(
                        pack_id, response, response_value, _bind_select_mode_kind(manager),
                        getattr(manager.state, "custom_pose_ui_link_register_feedback", ""),
                    )
                )

                # ------------------------------------------------
                # V8.5 dedicated target switch.
                # ------------------------------------------------
                # The fixed left-side button used to emit 100000. That only
                # worked when legacy control rows occupied row 0. In V8,
                # detail rows are real poses only; an empty group has zero
                # rows, so consuming 100000 killed the UiDialog lifecycle.
                if response_value == RESPONSE_SWITCH_TARGET:
                    manager.fgeh_pose_manager_debug_log(
                        "V8.6 dedicated switch-target response pack_id={} active_group={!r}".format(
                            pack_id,
                            getattr(
                                manager.state,
                                "custom_pose_ui_active_inner_group",
                                None,
                            ),
                        )
                    )

                    _v86_show_custom_target_sim_picker(
                        manager,
                        live_owner,
                        pack,
                        on_item_selected,
                        on_back,
                    )
                    return

                if response_value == RESPONSE_PLAY_ALL_VISIBLE:
                    _v882_play_all_visible(
                        manager,
                        live_owner,
                        pack,
                        item_tags,
                        on_item_selected,
                        on_back,
                    )
                    return

                if _linked_detail and isinstance(response_value, int) and 710000 <= response_value < 711000:
                    index = response_value - 710000
                    ok = False
                    if 0 <= index < len(item_tags):
                        name = str(getattr(item_tags[index], 'pose_name', '') or '')
                        ok, message = _r74_remove_linked_action(manager, pack_id, name)
                        _r74_linked_message(live_owner, message)
                    if ok:
                        if _nav_can_back(manager):
                            _nav_back(manager, save=False)
                        _schedule_root_reopen(manager, live_owner, _ACTIVE_ROOT_PACK_CALLBACK, 'remove-linked-action')
                    else:
                        _schedule_pack_reopen(manager, live_owner, pack, on_item_selected, on_back, 'remove-linked-blocked')
                    return

                # H55 low-coupling bridge: LinkedActionEditor asks the existing
                # AccessoryLibraryView to edit CAS bindings for exactly one Pose.
                # The library owns browsing/preview/swatches; the linked editor
                # owns the Pose context. No UI container is shared.
                if (
                    _linked_detail
                    and isinstance(response_value, int)
                    and RESPONSE_LINKED_ADD_LIBRARY_BASE <= response_value < RESPONSE_LINKED_ADD_LIBRARY_BASE + 1000
                ):
                    linked_index = int(response_value - RESPONSE_LINKED_ADD_LIBRARY_BASE)
                    if 0 <= linked_index < len(item_tags):
                        tag = item_tags[linked_index]
                        pose_name = str(getattr(tag, "pose_name", "") or "")
                        if pose_name:
                            manager.state.custom_pose_ui_bind_select_mode = "cas"
                            manager.state.custom_pose_ui_bind_pack_id = pack_id
                            manager.state.custom_pose_ui_bind_pose_name = pose_name
                            manager.state.custom_pose_ui_bind_scope = "pack"
                            manager.state.custom_pose_ui_bind_return_nav = NAV_LINKED_ACTIONS
                            manager.state.custom_pose_ui_active_nav = NAV_ACCESSORY_LIBRARY
                            manager.state.custom_pose_ui_scroll_row = 0
                            _caslib_reset(manager)
                            _v7_reset_subview(manager)
                            # H57: this is a modal editor bridge, not a second LinkedDrawer.
                            # Open the full AccessoryLibraryView directly so the user gets
                            # its real category tabs / 3x3 catalog / preview / swatches.
                            # Do NOT rebuild the ordinary root here and do NOT embed the
                            # catalog inside LinkedActionEditor.
                            try:
                                manager.fgeh_pose_manager_debug_log(
                                    "[H57_LINKED_LIBRARY] OPEN pack={} pose={}".format(pack_id, pose_name)
                                )
                            except Exception:
                                pass
                            _schedule_caslib_product_panel(
                                manager, live_owner, _ACTIVE_ROOT_PACK_CALLBACK,
                                "linked-library-open:{}".format(pose_name),
                            )
                            return
                    _schedule_pack_reopen(
                        manager, live_owner, pack, on_item_selected, on_back,
                        "linked-add-from-library-invalid",
                    )
                    return

                if response_value == RESPONSE_LINKED_RESTORE_OUTFIT:
                    try:
                        _v8966_restore_original_outfit(sim_info)
                    except Exception:
                        pass
                    _schedule_pack_reopen(
                        manager, live_owner, pack, on_item_selected, on_back,
                        "linked-restore-original-outfit",
                    )
                    return

                if response_value == RESPONSE_LINKED_CLEAR_OBJECTS:
                    try:
                        _v8966_clear_linked_objects(sim_info)
                    except Exception:
                        pass
                    _schedule_pack_reopen(
                        manager, live_owner, pack, on_item_selected, on_back,
                        "linked-clear-generated-objects",
                    )
                    return

                if response_value == RESPONSE_EDIT_INFO_REFRESH:
                    _schedule_pack_reopen(
                        manager, live_owner, pack, on_item_selected, on_back, "edit-info-refresh"
                    )
                    return

                group_action = decode_group_response(
                    response_value
                )
                if group_action is not None:
                    action, action_index = group_action

                    _pid, _groups, _names = _v75_pack_group_names(
                        manager,
                        pack,
                    )
                    if _linked_detail:
                        _names = _v89_linked_group_names_for_pack(
                            manager,
                            _pid,
                            _groups,
                            _names,
                        )
                    _edit_group = (
                        None
                        if _linked_detail
                        else _v8_edit_inner_group(
                            manager,
                            _names,
                        )
                    )

                    if action == "tab":
                        manager.state.custom_pose_ui_edit_inner_group = None

                        if action_index == 0:
                            manager.state.custom_pose_ui_active_inner_group = None
                        else:
                            group_index = action_index - 1
                            if 0 <= group_index < len(_names):
                                manager.state.custom_pose_ui_active_inner_group = _names[group_index]

                        pack_pages[pack_id] = 0
                        _schedule_pack_reopen(
                            manager,
                            live_owner,
                            pack,
                            on_item_selected,
                            on_back,
                            "inner-group-tab:{}".format(action_index),
                        )
                        return

                    if action == "create":
                        groups = getattr(
                            manager.state,
                            "grouped_packs",
                            {},
                        ) or {}
                        pack_groups = groups.get(pack_id, {}) or {}

                        new_name = _v8_next_inner_group_name(
                            pack_groups
                        )
                        pack_groups[new_name] = []
                        groups[pack_id] = pack_groups
                        manager.state.grouped_packs = groups
                        manager.state.custom_pose_ui_active_inner_group = None
                        manager.save_favorites()

                        _schedule_pack_reopen(
                            manager,
                            live_owner,
                            pack,
                            on_item_selected,
                            on_back,
                            "create-inner-group:{}".format(new_name),
                        )
                        return

                    if action == "smart_two":
                        try:
                            sorted_groups = manager.auto_sort_couple_pack(
                                pack
                            )
                        except Exception:
                            sorted_groups = {"组 1": [], "组 2": []}
                            for pose_index, pose_item in enumerate(
                                getattr(pack, "pose_list", ()) or ()
                            ):
                                pose_name = getattr(
                                    pose_item,
                                    "pose_name",
                                    None,
                                )
                                if pose_name:
                                    key = "组 1" if pose_index % 2 == 0 else "组 2"
                                    sorted_groups[key].append(pose_name)

                        manager.state.grouped_packs[pack_id] = sorted_groups
                        manager.state.custom_pose_ui_active_inner_group = None
                        manager.state.custom_pose_ui_edit_inner_group = None
                        manager.save_favorites()

                        _schedule_pack_reopen(
                            manager,
                            live_owner,
                            pack,
                            on_item_selected,
                            on_back,
                            "smart-two",
                        )
                        return

                    if action == "edit":
                        if (
                            action_index is not None
                            and 0 <= action_index < len(_names)
                        ):
                            group_name = _names[action_index]
                            manager.state.custom_pose_ui_active_inner_group = None
                            manager.state.custom_pose_ui_edit_inner_group = group_name
                            pack_pages[pack_id] = 0

                            _schedule_pack_reopen(
                                manager,
                                live_owner,
                                pack,
                                on_item_selected,
                                on_back,
                                "edit-inner-group:{}".format(group_name),
                            )
                        return

                    if action == "delete":
                        if (
                            action_index is not None
                            and 0 <= action_index < len(_names)
                        ):
                            group_name = _names[action_index]
                            groups = getattr(
                                manager.state,
                                "grouped_packs",
                                {},
                            ) or {}
                            pack_groups = groups.get(pack_id, {}) or {}

                            if group_name in pack_groups:
                                del pack_groups[group_name]
                                groups[pack_id] = pack_groups
                                manager.state.grouped_packs = groups

                                if getattr(
                                    manager.state,
                                    "custom_pose_ui_active_inner_group",
                                    None,
                                ) == group_name:
                                    manager.state.custom_pose_ui_active_inner_group = None

                                if getattr(
                                    manager.state,
                                    "custom_pose_ui_edit_inner_group",
                                    None,
                                ) == group_name:
                                    manager.state.custom_pose_ui_edit_inner_group = None

                                manager.save_favorites()

                            _schedule_pack_reopen(
                                manager,
                                live_owner,
                                pack,
                                on_item_selected,
                                on_back,
                                "delete-inner-group:{}".format(group_name),
                            )
                        return

                    if action == "rename":
                        if (
                            action_index is not None
                            and 0 <= action_index < len(_names)
                        ):
                            _show_custom_inner_group_rename_dialog(
                                manager,
                                live_owner,
                                pack,
                                _names[action_index],
                                on_item_selected,
                                on_back,
                            )
                        return

                    if action == "member_toggle":
                        if (
                            _edit_group
                            and action_index is not None
                            and 0 <= action_index < len(item_tags)
                        ):
                            pose_item = item_tags[action_index]
                            pose_name = str(
                                getattr(
                                    pose_item,
                                    "pose_name",
                                    "",
                                ) or ""
                            )

                            if pose_name:
                                groups = getattr(
                                    manager.state,
                                    "grouped_packs",
                                    {},
                                ) or {}
                                pack_groups = groups.get(
                                    pack_id,
                                    {},
                                ) or {}
                                members = list(
                                    pack_groups.get(
                                        _edit_group,
                                        (),
                                    ) or ()
                                )

                                if pose_name in members:
                                    members.remove(pose_name)
                                else:
                                    members.append(pose_name)

                                pack_groups[_edit_group] = members
                                groups[pack_id] = pack_groups
                                manager.state.grouped_packs = groups
                                manager.save_favorites()

                            _schedule_pack_reopen(
                                manager,
                                live_owner,
                                pack,
                                on_item_selected,
                                on_back,
                                "toggle-inner-member",
                            )
                        return

                    if action == "smart_pattern":
                        if _edit_group:
                            pose_list = list(
                                getattr(pack, "pose_list", ()) or ()
                            )
                            groups = getattr(
                                manager.state,
                                "grouped_packs",
                                {},
                            ) or {}
                            pack_groups = groups.get(
                                pack_id,
                                {},
                            ) or {}
                            current_members = set(
                                str(value)
                                for value in (
                                    pack_groups.get(
                                        _edit_group,
                                        (),
                                    ) or ()
                                )
                            )

                            selected_indices = []
                            for index, pose_item in enumerate(
                                pose_list
                            ):
                                pose_name = str(
                                    getattr(
                                        pose_item,
                                        "pose_name",
                                        "",
                                    ) or ""
                                )
                                if pose_name in current_members:
                                    selected_indices.append(index)

                            if len(selected_indices) >= 2:
                                start_index = selected_indices[0]
                                interval = (
                                    selected_indices[1]
                                    - selected_indices[0]
                                )

                                if interval > 0:
                                    generated = []
                                    for index in range(
                                        start_index,
                                        len(pose_list),
                                        interval,
                                    ):
                                        pose_name = str(
                                            getattr(
                                                pose_list[index],
                                                "pose_name",
                                                "",
                                            ) or ""
                                        )
                                        if pose_name:
                                            generated.append(
                                                pose_name
                                            )

                                    pack_groups[_edit_group] = generated
                                    groups[pack_id] = pack_groups
                                    manager.state.grouped_packs = groups
                                    manager.save_favorites()

                            _schedule_pack_reopen(
                                manager,
                                live_owner,
                                pack,
                                on_item_selected,
                                on_back,
                                "smart-pattern",
                            )
                        return

                    if action == "edit_done":
                        if _edit_group:
                            manager.state.custom_pose_ui_edit_inner_group = None
                            manager.state.custom_pose_ui_active_inner_group = _edit_group

                        pack_pages[pack_id] = 0
                        _schedule_pack_reopen(
                            manager,
                            live_owner,
                            pack,
                            on_item_selected,
                            on_back,
                            "edit-inner-done",
                        )
                        return

                    if action == "outer_toggle":
                        outer_names, _outer_selected = _v8_outer_group_state(
                            manager,
                            pack_id,
                        )

                        if (
                            action_index is not None
                            and 0 <= action_index < len(outer_names)
                        ):
                            group_name = outer_names[action_index]
                            outer_groups = getattr(
                                manager.state,
                                "user_grouped_packs_groups",
                                {},
                            ) or {}
                            members = list(
                                outer_groups.get(
                                    group_name,
                                    (),
                                ) or ()
                            )

                            if pack_id in members:
                                members.remove(pack_id)
                            else:
                                members.append(pack_id)

                            outer_groups[group_name] = members
                            manager.state.user_grouped_packs_groups = outer_groups
                            manager.save_favorites()

                        _schedule_pack_reopen(
                            manager,
                            live_owner,
                            pack,
                            on_item_selected,
                            on_back,
                            "toggle-outer-group",
                        )
                        return

                    # "manage" is local AS-only; smart_three is intentionally retired.
                    return

                if response_value == RESPONSE_ROOT_SEARCH_APPLY:
                    # H50: “加入绑定动作” is PACK-level. One click registers
                    # every real Pose in this pack; no second Pose-selection step.
                    manager.state.custom_pose_ui_bind_select_mode = False
                    manager.state.custom_pose_ui_link_register_feedback = ""
                    manager.state.custom_pose_ui_link_register_feedback_pack_id = ""
                    registered, pose_count = _register_managed_linked_pack(
                        manager, pack_id, pack=pack, source="pack-detail"
                    )
                    if registered:
                        manager.state.custom_pose_ui_link_register_feedback = "ALL:{}".format(pose_count)
                        manager.state.custom_pose_ui_link_register_feedback_pack_id = pack_id
                    _h49_trace(
                        "PACK_BUTTON pack={!r} registered={} pose_count={}".format(
                            pack_id, registered, pose_count
                        )
                    )
                    pack_pages[pack_id] = page
                    manager.save_favorites()
                    _schedule_pack_reopen(
                        manager, live_owner, pack, on_item_selected, on_back,
                        "link-register-pack-all",
                    )
                    return

                if response_value == RESPONSE_BACK:
                    _h49_trace("BACK pack={!r} mode={!r}".format(pack_id, _bind_select_mode_kind(manager)))
                    if _bind_select_mode_kind(manager) == "register":
                        manager.state.custom_pose_ui_bind_select_mode = False
                    manager.state.custom_pose_ui_link_register_feedback = ""
                    manager.state.custom_pose_ui_link_register_feedback_pack_id = ""
                    # Pack -> parent root/group.  Pop exactly one leaf; the
                    # legacy on_back callback is retained only as the actual
                    # UI reopen mechanism.
                    if _nav_can_back(manager):
                        _nav_back(manager, save=True)
                    if on_back is not None:
                        on_back()
                    return
                requested_page = decode_page_response(response_value)
                if requested_page is not None:
                    next_page = clamp_page(requested_page, len(rows))
                    pack_pages[pack_id] = next_page
                    manager.save_favorites()
                    _schedule_pack_reopen(
                        manager,
                        live_owner,
                        pack,
                        on_item_selected,
                        on_back,
                        "page:{}".format(next_page),
                    )
                    return
                favorite_index = decode_pack_favorite_response(response_value)
                if favorite_index is not None:
                    pack_pages[pack_id] = page

                    if getattr(
                        manager.state,
                        "custom_pose_ui_edit_inner_group",
                        None,
                    ):
                        _schedule_pack_reopen(
                            manager,
                            live_owner,
                            pack,
                            on_item_selected,
                            on_back,
                            "ignore-favorite-during-member-edit",
                        )
                        return
                    if 0 <= favorite_index < len(item_tags):
                        tag = item_tags[favorite_index]
                        pose_name = str(getattr(tag, "pose_name", "") or "")
                        if pose_name:
                            if pose_name in manager.state.favorite_poses:
                                manager.state.favorite_poses.remove(pose_name)
                                enabled = False
                            else:
                                manager.state.favorite_poses.append(pose_name)
                                enabled = True
                            manager.save_favorites()
                            manager.fgeh_pose_manager_debug_log(
                                "custom UI pose favorite toggled pose={} enabled={}".format(
                                    pose_name,
                                    enabled,
                                )
                            )
                    _schedule_pack_reopen(
                        manager,
                        live_owner,
                        pack,
                        on_item_selected,
                        on_back,
                        "favorite:{}".format(favorite_index),
                    )
                    return
                item_index = decode_pack_response(response_value)
                if item_index is None:
                    _h49_trace(
                        "CLOSE_OR_CANCEL pack={!r} value={!r} mode={!r}".format(
                            pack_id, response_value, _bind_select_mode_kind(manager)
                        )
                    )
                    if _bind_select_mode_kind(manager) == "register":
                        manager.state.custom_pose_ui_bind_select_mode = False
                    manager.state.custom_pose_ui_link_register_feedback = ""
                    manager.state.custom_pose_ui_link_register_feedback_pack_id = ""
                    # Close keeps the pack leaf.  Save its current page/group
                    # so reopening resumes the same detail screen.
                    _nav_sync_pack(manager, pack, page=page, save=False)
                    _nav_persist(manager)
                    manager.fgeh_pose_manager_debug_log(
                        "custom UI pack response treated as close/cancel value={!r}".format(
                            response_value
                        )
                    )
                    return

                pack_pages[pack_id] = page
                manager.save_favorites()

                if 0 <= item_index < len(item_tags):
                    row = rows[item_index] if item_index < len(rows) else {}
                    row_kind = str(row.get("kind", "") or "") if isinstance(row, dict) else ""
                    _h49_trace(
                        "ITEM_CLICK pack={!r} index={} row_kind={!r} mode={!r}".format(
                            pack_id, item_index, row_kind, _bind_select_mode_kind(manager)
                        )
                    )

                    if (
                        _bind_select_mode_kind(manager) == "register"
                        and row_kind == "pose"
                    ):
                        tag = item_tags[item_index]
                        pose_name = str(getattr(tag, "pose_name", "") or "")
                        if pose_name:
                            manager.state.custom_pose_ui_bind_select_mode = False
                            registered = _register_managed_linked_action(
                                manager, pack_id, pose_name
                            )
                            manager.state.custom_pose_ui_link_register_feedback = (
                                pose_name if registered else ""
                            )
                            manager.state.custom_pose_ui_link_register_feedback_pack_id = (
                                pack_id if registered else ""
                            )
                            _h49_trace(
                                "REGISTER_FEEDBACK pack={!r} pose={!r} registered={} feedback={!r}".format(
                                    pack_id, pose_name, registered,
                                    manager.state.custom_pose_ui_link_register_feedback,
                                )
                            )
                            pack_pages[pack_id] = page
                            manager.save_favorites()
                            _schedule_pack_reopen(
                                manager, live_owner, pack, on_item_selected, on_back,
                                "link-register:{}".format(pose_name),
                            )
                            return

                    if on_item_selected is not None:
                        manager.fgeh_pose_manager_debug_log(
                            "custom UI pack item selected index={} tag_type={}".format(
                                item_index,
                                type(item_tags[item_index]).__name__,
                            )
                        )
                        on_item_selected(item_tags[item_index])
                        return

                # V8.5 safety net:
                # UiDialog responses are one-shot. If a stale hit area sends
                # an out-of-range item response, reopen the current detail
                # instead of leaving a visible but server-dead GFX shell.
                manager.fgeh_pose_manager_debug_log(
                    "V8.5 stale pack item response recovered index={} rows={} pack_id={}".format(
                        item_index,
                        len(item_tags),
                        pack_id,
                    )
                )
                _schedule_pack_reopen(
                    manager,
                    live_owner,
                    pack,
                    on_item_selected,
                    on_back,
                    "recover-stale-item-response:{}".format(item_index),
                )
                return
            except Exception as exc:
                manager.fgeh_pose_manager_debug_log(
                    "custom UI pack response callback failed: {}: {}".format(
                        type(exc).__name__,
                        exc,
                    ),
                    exc=True,
                )

        dialog.show_dialog(
            on_response=_on_response,
            # V8.9.54: deliberately blank. The header now belongs to the
            # global Plumbob widget; never ask UiDialog for a Sim portrait.
            icon_override=IconInfoData(),
            additional_icons=tuple(additional_icon_messages),
        )
        return True
    except Exception as exc:
        LAST_ERROR = "{}: {}".format(type(exc).__name__, exc)
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "custom pose manager pack UI failed: {}".format(LAST_ERROR),
                exc=True,
            )
        except Exception:
            pass
        return False




def _v88_show_root_group_rename_dialog(manager, owner, context, old_name, on_pack_selected):
    import services
    import sims4.resources
    from event_testing.resolver import SingleSimResolver
    from sims4.localization import LocalizationHelperTuning

    sim_info = getattr(owner, "sim_info", owner)
    live_owner = getattr(sim_info, "get_sim_instance", lambda: owner)()
    if live_owner is None:
        return False

    tuning = services.get_instance_manager(sims4.resources.Types.INTERACTION).get(5376477438524819063)
    if tuning is None:
        return False

    dialog = tuning.rename_dialog(live_owner, SingleSimResolver(sim_info))

    def _finish():
        _schedule_root_reopen(manager, live_owner, on_pack_selected, "root-group-rename")

    def _on_response(response_dialog):
        try:
            if response_dialog.accepted:
                new_name = response_dialog.text_input_responses.get(tuning.TEXT_INPUT_NEW_NAME)
                if new_name is not None:
                    new_name = str(new_name).strip()
                    groups = _v88_context_groups(manager, context)
                    if new_name and new_name != old_name and old_name in groups and new_name not in groups:
                        groups[new_name] = groups.pop(old_name)
                        setattr(manager.state, context["groups_attr"], groups)
                        for attr in (context["selected_attr"], context["edit_attr"]):
                            if getattr(manager.state, attr, None) == old_name:
                                setattr(manager.state, attr, new_name)
                        manager.save_favorites()
        finally:
            _finish()

    overrides = {
        tuning.TEXT_INPUT_NEW_NAME:
            (lambda *args, **kwargs: LocalizationHelperTuning.get_raw_text(old_name))
    }
    dialog.add_listener(_on_response)
    dialog.show_dialog(text_input_overrides=overrides)
    return True


def _v8951_global_plumbob_enabled(manager):
    """Read the existing persistent headline/plumbob setting safely."""
    try:
        return bool(getattr(manager.state, "headline_effects_enabled", True))
    except Exception:
        return True


def _v8951_attach_global_widget_state(header, manager):
    # One source of truth for all Pose Manager screens.  The theme id is
    # intentionally data-driven so a future pink/brown skin only swaps the
    # palette instead of duplicating interaction code.
    header["global_plumbob_enabled"] = _v8951_global_plumbob_enabled(manager)
    header["global_widget_theme"] = GLOBAL_WIDGET_THEME_ID



# ------------------------------------------------------------------
# H34 — standalone CAS favorites library rendered by the EXISTING linked-
# settings product-card/swatches/hover UI.  No generic action-pack cards.
# ------------------------------------------------------------------

def _caslib_external_value(obj, *names):
    for name in names:
        try:
            if isinstance(obj, dict) and name in obj:
                value = obj.get(name)
            else:
                value = getattr(obj, name, None)
        except Exception:
            value = None
        if value not in (None, ""):
            return value
    return None


def _caslib_external_snapshot(manager=None):
    """Build a process-local catalog from existing game-external CAS metadata.

    This is deliberately independent from the CAS AccountSettings collection.
    It scans the already-supported external/tuning accessory definitions and
    exposes only their CASPart variants for quick reuse in the Accessory Library.
    """
    global _CASLIB_EXTERNAL_CACHE, _CASLIB_EXTERNAL_BY_VARIANT
    if _CASLIB_EXTERNAL_CACHE is not None and _CASLIB_EXTERNAL_BY_VARIANT is not None:
        return _CASLIB_EXTERNAL_CACHE, _CASLIB_EXTERNAL_BY_VARIANT

    try:
        from fgeh_cas_accessory_picker import get_all_accessory_entries
        entries = list(get_all_accessory_entries() or ())
    except Exception:
        entries = []

    options = []
    by_variant = {}
    seen = set()
    for entry_index, entry_info in enumerate(entries):
        if not isinstance(entry_info, dict):
            continue
        label = str(entry_info.get("label") or "").strip() or "游戏外配件 {}".format(entry_index + 1)
        category = str(entry_info.get("category") or "cas").strip() or "cas"
        snippet = entry_info.get("snippet")
        snippet_id = ""
        for attr in ("guid64", "guid", "instance_id", "tuning_id", "__name__"):
            try:
                raw = getattr(snippet, attr, None)
            except Exception:
                raw = None
            if raw not in (None, ""):
                snippet_id = str(raw)
                break
        product_key = "external:{}:{}:{}".format(snippet_id, category, entry_index)
        variants = list(entry_info.get("variants", ()) or ())
        sibling_ids = []
        variant_rows = []
        for variant_index, variant in enumerate(variants):
            try:
                cas_part_id = int(_caslib_external_value(variant, "cas_part_id", "id", "value") or 0)
            except Exception:
                cas_part_id = 0
            if not cas_part_id or cas_part_id in seen:
                continue
            seen.add(cas_part_id)
            sibling_ids.append(cas_part_id)
            try:
                body_type = int(_caslib_external_value(variant, "body_type") or 0)
            except Exception:
                body_type = 0
            body_group = str(_caslib_external_value(variant, "body_group") or "body_type_{}".format(body_type))
            source_type = str(_caslib_external_value(variant, "source_type") or "unknown").strip().lower() or "unknown"
            variant_label = str(_caslib_external_value(variant, "variant_label", "display_name", "label") or "样式 {}".format(variant_index + 1))
            try:
                swatch_index = int(_caslib_external_value(variant, "style_index", "swatch_index", "variant_index") or 0)
            except Exception:
                swatch_index = 0
            if swatch_index <= 0:
                swatch_index = variant_index + 1
            row = {
                "cas_part_id": cas_part_id,
                "product_key": product_key,
                "product_label": label,
                "entry_label": label,
                "label": label,
                "variant_label": variant_label,
                "swatch_index": swatch_index,
                "source_origin": "external",
                "source_type": source_type,
                "body_type": body_type,
                "body_group": body_group,
                "category": category,
            }
            options.append(row)
            variant_rows.append(row)
        for row in variant_rows:
            by_variant[int(row["cas_part_id"])] = {
                "product_key": product_key,
                "product_label": label,
                "sibling_ids": tuple(sibling_ids),
                "body_type": int(row.get("body_type", 0) or 0),
                "body_group": str(row.get("body_group") or "other"),
                "source_type": str(row.get("source_type") or "unknown"),
                "category": category,
            }

    catalog = tuple(_v8931_build_shared_cas_catalog(options, manager))
    _CASLIB_EXTERNAL_CACHE = catalog
    _CASLIB_EXTERNAL_BY_VARIANT = by_variant
    try:
        if manager is not None:
            manager.fgeh_pose_manager_debug_log(
                "[CASLIB_EXTERNAL] scanned entries={} products={} variants={}".format(
                    len(entries), len(catalog), len(by_variant)
                )
            )
    except Exception:
        pass
    return catalog, by_variant


def _caslib_external_product_for_variant(manager, cas_part_id):
    try:
        cas_part_id = int(cas_part_id or 0)
    except Exception:
        cas_part_id = 0
    _catalog, by_variant = _caslib_external_snapshot(manager)
    return by_variant.get(cas_part_id)


def _caslib_toggle_external_binding(manager, cas_part_id):
    pack_id, pose_name = _caslib_binding_context(manager)
    if not pack_id or not pose_name:
        return False
    product = _caslib_external_product_for_variant(manager, cas_part_id)
    if not product:
        return False
    target_poses = _caslib_binding_pose_names(manager, pack_id, pose_name)
    if not target_poses:
        return False
    shared_bound = _caslib_bound_ids(manager)
    remove_product = int(cas_part_id) in shared_bound
    try:
        from fgeh_linked_cas_bindings import set_external_cas_product_for_poses
        changed = bool(set_external_cas_product_for_poses(
            pack_id,
            target_poses,
            product.get("sibling_ids", ()),
            0 if remove_product else int(cas_part_id),
            body_type=int(product.get("body_type", 0) or 0),
            display_name=str(product.get("product_label") or "CAS {}".format(cas_part_id)),
            source_type=str(product.get("source_type") or "unknown"),
            body_group=str(product.get("body_group") or "other"),
            external_product_key=str(product.get("product_key") or ""),
        ))
    except Exception:
        changed = False
    if changed:
        _caslib_refresh_requirement_cache()
        for target_pose in target_poses:
            _caslib_sync_pose_enabled_choices(manager, pack_id, target_pose)
        try:
            manager.fgeh_pose_manager_debug_log(
                "[CASLIB_EXTERNAL_BIND] pack={} anchor={} targets={} item={} remove={} product={!r}".format(
                    pack_id, pose_name, len(target_poses), cas_part_id,
                    remove_product, product.get("product_key")
                )
            )
        except Exception:
            pass
    return changed


def _caslib_first_swatch_color(variant):
    for raw in (variant.get("colors", ()) or ()) if isinstance(variant, dict) else ():
        try:
            value = int(raw or 0) & 0xFFFFFFFF
        except Exception:
            value = 0
        if value:
            return value
    return ""


def _caslib_catalog_options(data, group_name=None):
    options = []
    for item in _caslib_group_items(data, group_name):
        base_id = str(item.get("base_id") or "")
        if not base_id:
            continue
        label = (
            item.get("display_name")
            or item.get("catalog_name")
            or "配件 {}".format(base_id)
        )
        try:
            body_type = int(item.get("body_type") or 0)
        except Exception:
            body_type = 0
        variants = list(item.get("variants", ()) or ())
        for fallback_index, variant in enumerate(variants):
            try:
                cas_part_id = int(variant.get("cas_part_id") or 0)
            except Exception:
                cas_part_id = 0
            if not cas_part_id:
                continue
            try:
                style_index = int(variant.get("style_index", fallback_index) or 0)
            except Exception:
                style_index = fallback_index
            options.append({
                "cas_part_id": cas_part_id,
                "product_key": "cas_collection:{}".format(base_id),
                "product_label": label,
                "entry_label": label,
                "label": label,
                "variant_label": "样式 {}".format(style_index + 1),
                "swatch_index": style_index + 1,
                "swatch_color": _caslib_first_swatch_color(variant),
                "source_origin": "local",
                "source_type": str(item.get("source_type") or "unknown"),
                "body_type": body_type,
                "body_group": "body_type_{}".format(body_type),
                "base_id": base_id,
                "icon_key_raw": str(variant.get("icon_key_raw") or "0"),
                "modded": bool(variant.get("modded")),
            })
    return options


def _caslib_build_shared_catalog_direct(data, group_name):
    """Build the local CAS JSON catalog directly, without 1185 intermediate option dicts."""
    result = []
    for item in _caslib_group_items(data, group_name):
        base_id = str(item.get("base_id") or "")
        if not base_id:
            continue

        label = (
            item.get("display_name")
            or item.get("catalog_name")
            or "配件 {}".format(base_id)
        )
        product_label = _v8924_text(label)
        if not product_label:
            product_label = "配件 {}".format(base_id)
        explicit_key = "cas_collection:{}".format(base_id)
        product_key = "cas|explicit|" + _v8924_normalize_key_text(explicit_key)

        variants_out = []
        for fallback_index, variant in enumerate(item.get("variants", ()) or ()):
            try:
                item_id = int(variant.get("cas_part_id") or 0)
            except Exception:
                item_id = 0
            if not item_id:
                continue
            try:
                style_index = int(variant.get("style_index", fallback_index) or 0)
            except Exception:
                style_index = fallback_index
            swatch_index = style_index + 1
            variants_out.append({
                "item_id": item_id,
                "variant_label": "样式 {}".format(swatch_index),
                "swatch_index": swatch_index,
                "swatch_color": _v8931_normalize_swatch_color(
                    _caslib_first_swatch_color(variant)
                ),
                "origin": "local",
                "original_order": fallback_index,
            })

        variants_out.sort(key=lambda value: (
            0 if int(value.get("swatch_index", 0) or 0) > 0 else 1,
            int(value.get("swatch_index", 0) or 0)
            if int(value.get("swatch_index", 0) or 0) > 0
            else int(value.get("original_order", 0)),
            int(value.get("original_order", 0)),
        ))
        for value in variants_out:
            value.pop("original_order", None)

        if not variants_out:
            continue

        result.append({
            "product_key": product_key,
            "product_label": product_label,
            "key_source": "product_key",
            "variants": variants_out,
            "variant_count": len(variants_out),
        })
    return result


def _caslib_shared_catalog_cached(data, group_name, manager):
    """Cache static/effective CAS catalogs while source/edit state is unchanged."""
    global _CASLIB_CATALOG_CACHE_DATA_ID, _CASLIB_CATALOG_CACHE
    global _CASLIB_EFFECTIVE_CATALOG_CACHE

    if not isinstance(data, dict):
        data = {}
    items = data.get("items", ()) or ()
    groups = data.get("groups", {}) or {}
    data_id = id(data)

    # fgeh_cas_collection_library.load_collection() returns the same dict while
    # its on-disk file signature is unchanged.  A new dict therefore gives us
    # a cheap, exact process-local generation boundary.
    if _CASLIB_CATALOG_CACHE_DATA_ID != data_id:
        _CASLIB_CATALOG_CACHE_DATA_ID = data_id
        _CASLIB_CATALOG_CACHE = {}
        _CASLIB_EFFECTIVE_CATALOG_CACHE = {}

    group_key = "" if group_name in (None, "") else str(group_name)
    cache_key = (
        str(data.get("exported_at", "") or ""),
        len(items),
        len(groups) if isinstance(groups, dict) else 0,
        group_key,
    )

    raw_catalog = _CASLIB_CATALOG_CACHE.get(cache_key)
    if raw_catalog is None:
        started = _perf_now()
        raw_catalog = _caslib_build_shared_catalog_direct(data, group_name)
        # Keep a small bounded set so switching among the user's few accessory
        # groups does not rebuild 1185 variant records every time.
        if len(_CASLIB_CATALOG_CACHE) >= 16:
            _CASLIB_CATALOG_CACHE.pop(next(iter(_CASLIB_CATALOG_CACHE)), None)
        _CASLIB_CATALOG_CACHE[cache_key] = raw_catalog
        _perf_log(
            manager,
            "PERF CASLIB_CATALOG_BUILD ms={:.3f} products={} variants={}".format(
                _perf_ms(started),
                len(raw_catalog),
                sum(len(product.get("variants", ()) or ()) for product in raw_catalog),
            ),
        )
    else:
        _perf_log(
            manager,
            "PERF CASLIB_CATALOG_HIT products={}".format(len(raw_catalog)),
        )

    # Product rename/note state belongs to Pose Manager.  Only product-level
    # fields are edited; variant dicts are read-only in pack_payload.  Avoid the
    # old ~N_variants dict copies on every Accessory Library open.
    custom_names = getattr(getattr(manager, "state", None), "custom_names", {}) or {}
    edit_signature = []
    for cached_product in raw_catalog or ():
        product_key = str(cached_product.get("product_key", "") or "")
        edit_key = _v8938_linked_product_edit_key("cas", product_key)
        edit_signature.append((
            edit_key,
            str(custom_names.get(edit_key, "") or ""),
            _v88_custom_note(manager, edit_key) if manager is not None else "",
        ))
    effective_key = (cache_key, tuple(edit_signature))
    cached_effective = _CASLIB_EFFECTIVE_CATALOG_CACHE.get(effective_key)
    if cached_effective is not None:
        _perf_log(
            manager,
            "PERF CASLIB_EFFECTIVE_CATALOG_HIT products={}".format(
                len(cached_effective)
            ),
        )
        return cached_effective

    started_effective = _perf_now()
    result = []
    for cached_product in raw_catalog or ():
        product = dict(cached_product)
        product["variants"] = cached_product.get("variants", ()) or ()
        if manager is not None:
            _v8938_apply_linked_product_edit(manager, product, "cas")
        result.append(product)
    result = tuple(result)
    if len(_CASLIB_EFFECTIVE_CATALOG_CACHE) >= 16:
        _CASLIB_EFFECTIVE_CATALOG_CACHE.pop(next(iter(_CASLIB_EFFECTIVE_CATALOG_CACHE)), None)
    _CASLIB_EFFECTIVE_CATALOG_CACHE[effective_key] = result
    _perf_log(
        manager,
        "PERF CASLIB_EFFECTIVE_CATALOG_BUILD ms={:.3f} products={}".format(
            _perf_ms(started_effective), len(result)
        ),
    )
    return result


def _caslib_pose_display_name(manager, pack_id, pose_name):
    pack_id = str(pack_id or "")
    pose_name = str(pose_name or "")
    try:
        pack = (getattr(manager.state, "all_packs_cache", {}) or {}).get(pack_id)
        if pack is not None:
            for pose_item in getattr(pack, "pose_list", ()) or ():
                if str(getattr(pose_item, "pose_name", "") or "") != pose_name:
                    continue
                return _v88_custom_name(
                    manager,
                    "pose_{}".format(pose_name),
                    manager.get_visible_pose_name(pose_item),
                )
    except Exception:
        pass
    return pose_name or "配件库"


def _caslib_target_from_state(manager):
    try:
        sim_id = int(getattr(manager.state, "custom_pose_ui_cas_library_target_sim_id", 0) or 0)
    except Exception:
        sim_id = 0
    if not sim_id:
        return None
    try:
        import services
        info_manager = services.sim_info_manager()
        if info_manager is not None:
            sim_info = info_manager.get(sim_id)
            if sim_info is not None:
                return sim_info
    except Exception:
        pass
    try:
        import services
        obj = services.object_manager().get(sim_id)
        if obj is not None:
            return obj
    except Exception:
        pass
    return None


def _schedule_caslib_product_panel(manager, owner, on_pack_selected, reason):
    import alarms
    from date_and_time import TimeSpan
    holder = {}

    def _reopen(_handle):
        handle = holder.get("handle")
        if handle is not None:
            _PENDING_REOPEN_ALARMS.pop(id(handle), None)
        _show_cas_library_product_panel(owner, on_pack_selected=on_pack_selected)

    try:
        handle = alarms.add_alarm_real_time(
            owner, TimeSpan.ZERO, _reopen, use_sleep_time=False
        )
    except Exception:
        handle = alarms.add_alarm(owner, TimeSpan.ZERO, _reopen)
    holder["handle"] = handle
    _PENDING_REOPEN_ALARMS[id(handle)] = handle
    try:
        manager.fgeh_pose_manager_debug_log(
            "[H34_CASLIB] reopen scheduled reason={} handle={}".format(
                reason, id(handle)
            )
        )
    except Exception:
        pass


# Published catalog tuples are immutable within a collection generation.
# Keep references, rather than IDs alone, so Python ID reuse cannot hit stale data.
_CASLIB_PREPARED_PAYLOAD_CACHE = []


def _caslib_prepared_payload(header, rows, catalog, manager):
    from copy import deepcopy
    source = _caslib_source(manager)
    small_header = {key: value for key, value in header.items() if key != 'linked_cas_catalogs'}
    # Only local catalogs have a documented immutable publication contract.
    cacheable = source == _CASLIB_SOURCE_LOCAL and isinstance(catalog, tuple)
    if cacheable:
        for index, entry in enumerate(_CASLIB_PREPARED_PAYLOAD_CACHE):
            old_catalog, old_header, old_rows, raw, localized = entry
            if old_catalog is catalog and old_header == small_header and old_rows == rows:
                _CASLIB_PREPARED_PAYLOAD_CACHE.append(_CASLIB_PREPARED_PAYLOAD_CACHE.pop(index))
                return raw, localized
    raw = tuple(pack_payload(header, rows))
    localized = _localized_payload_cached('caslib', raw, manager)
    if cacheable:
        _CASLIB_PREPARED_PAYLOAD_CACHE.append((catalog, deepcopy(small_header), deepcopy(rows), raw, localized))
        if len(_CASLIB_PREPARED_PAYLOAD_CACHE) > 4:
            del _CASLIB_PREPARED_PAYLOAD_CACHE[0]
    return raw, localized


_CASLIB_ACTIVE_CONTEXT = None

def _show_cas_library_product_panel(owner, on_pack_selected=None):
    """Show CAS JSON products through the proven linked-settings card renderer."""
    global LAST_ERROR
    LAST_ERROR = ""
    try:
        import couplepose1 as manager
        _cas_perf_total = _perf_now()
        from distributor.shared_messages import IconInfoData
        from event_testing.resolver import SingleSimResolver
        from sims4.localization import LocalizationHelperTuning
        from ui.ui_dialog import UiDialogResponse
        from ui.ui_dialog_labeled_icons import UiDialogIcons

        sim_info = _caslib_target_from_state(manager) or _v8944_dialog_portrait_sim_info(owner, on_pack_selected)
        live_owner = getattr(sim_info, "get_sim_instance", lambda: owner)()
        if live_owner is None:
            LAST_ERROR = "active Sim instance is unavailable"
            return False
        try:
            manager.state.custom_pose_ui_cas_library_target_sim_id = int(
                getattr(sim_info, "sim_id", 0) or 0
            )
        except Exception:
            pass

        _cas_load_t = _perf_now()
        data = _caslib_load()
        _perf_log(manager, "PERF CASLIB_LOAD ms={:.3f}".format(_perf_ms(_cas_load_t)))
        source_mode = _caslib_source(manager)
        local_group_names = _caslib_group_names(data)
        selected_group = _caslib_group(manager) if source_mode == _CASLIB_SOURCE_LOCAL else None
        if selected_group not in local_group_names:
            selected_group = None
            manager.state.custom_pose_ui_cas_library_group = None

        _cas_catalog_t = _perf_now()
        if source_mode == _CASLIB_SOURCE_EXTERNAL:
            catalog, _external_index = _caslib_external_snapshot(manager)
            group_names = []
        else:
            catalog = _caslib_shared_catalog_cached(data, selected_group, manager)
            group_names, group_tab_entries = _caslib_group_tab_window(manager, local_group_names)
        _perf_log(manager, "PERF CASLIB_CATALOG_READY ms={:.3f} source={} products={}".format(
            _perf_ms(_cas_catalog_t), source_mode, len(catalog)
        ))
        binding = _caslib_binding_mode(manager)
        if binding:
            pack_id, pose_name = _caslib_binding_context(manager)
            row_name = _caslib_pose_display_name(manager, pack_id, pose_name)
            selected_ids = [
                int(value) for value in _caslib_bound_ids(manager) if int(value or 0)
            ]
            view_title = "从联动库选择 · {}".format("游戏外" if source_mode == _CASLIB_SOURCE_EXTERNAL else "游戏内")
            library_label = "完成选择"
            creator_text = "已选择 {} 件 · 当前来源：{}".format(
                len(selected_ids), "游戏外绑定" if source_mode == _CASLIB_SOURCE_EXTERNAL else "游戏内配件"
            )
        else:
            pack_id = _CASLIB_VIRTUAL_PACK_ID
            pose_name = _CASLIB_VIRTUAL_POSE
            row_name = "游戏外绑定" if source_mode == _CASLIB_SOURCE_EXTERNAL else "配件库"
            selected_ids = []
            view_title = row_name
            library_label = "返回动作库"
            creator_text = (
                "{} 件可复用配件 · 来自已有游戏外绑定".format(len(catalog))
                if source_mode == _CASLIB_SOURCE_EXTERNAL
                else "{} 件商品".format(len(catalog))
            )

        rows = [{
            "pack_id": "caslib:product-ui",
            "name": row_name,
            "creator": creator_text,
            "pose_count": len(catalog),
            "favorite": False,
            "icon_index": -1,
            "kind": "pose",
        }]
        header = {
            "page": 0,
            "page_count": 1,
            "page_label": "",
            "filter": "cas_library",
            "query": "",
            "navigation_mode": "scroll",
            "navigation_label": "",
            "item_count": 1,
            "view_title": view_title,
            "library_label": library_label,
            "enable_v7": True,
            "view_kind": "pack_detail_linked",
            "active_nav": NAV_ACCESSORY_LIBRARY,
            "group_names": group_names,
            "active_group_index": (
                group_tab_entries.index(('group', selected_group))
                if source_mode == _CASLIB_SOURCE_LOCAL and ('group', selected_group) in group_tab_entries
                else (999 if source_mode == _CASLIB_SOURCE_LOCAL and selected_group is not None else -1)
            ),
            "outer_group_names": [],
            "outer_group_selected": [],
            "edit_keys": [""],
            "edit_names": [""],
            "edit_notes": [""],
            "linked_detail": True,
            # H58: View identity is synthetic even in binding mode.
            # Real pack/pose stay in custom_pose_ui_bind_* Python state.
            "linked_pack_id": _CASLIB_VIRTUAL_PACK_ID,
            "linked_detail_rows": [{
                "pose_name": _CASLIB_VIRTUAL_POSE,
                "cas_auto": True,
                "object_auto": False,
                "resources": [],
                "object_products": (),
                "cas_products": (),
            }],
            "linked_cas_catalogs": [catalog],
            "linked_cas_pose_states": [{
                "pose_name": _CASLIB_VIRTUAL_POSE,
                "catalog_index": 0,
                "cas_auto": True,
                "selected_ids": selected_ids,
            }],
            "linked_edit_items": [],
        }
        _v8951_attach_global_widget_state(header, manager)
        _attach_ui_localization(header)
        _cas_payload_t = _perf_now()
        raw_payload, localized_payload = _caslib_prepared_payload(
            header, rows, catalog, manager
        )
        _perf_log(manager, "PERF CASLIB_PAYLOAD ms={:.3f} payload_items={}".format(
            _perf_ms(_cas_payload_t), len(raw_payload)
        ))
        blank = LocalizationHelperTuning.get_raw_text("")
        dialog = UiDialogIcons.TunableFactory().default(
            live_owner,
            resolver=SingleSimResolver(sim_info),
            title=_constant_localized_string(blank),
            text=_constant_localized_string(blank),
            additional_texts=localized_payload,
            show_dialog_message_override=SHOW_MESSAGE,
        )
        dialog.set_responses(tuple(UiDialogResponse(dialog_response_id=value) for value in (RESPONSE_BACK, 700034, 700035, RESPONSE_LINKED_RESTORE_OUTFIT)))
        global _CASLIB_ACTIVE_CONTEXT
        _CASLIB_ACTIVE_CONTEXT = (manager, live_owner, on_pack_selected, dialog)

        def _on_response(response_dialog):
            try:
                response = getattr(response_dialog, "response", None)
                try:
                    response_value = int(response)
                except Exception:
                    response_value = response

                # R10: index 8 is a visual child under ALL Packs, not a new
                # top-level nav id. Keep protocol 0..7 stable and switch the
                # ALL root into its dedicated blank-pack subview.
                if response_value == RESPONSE_NAV_BLANK_PACKS:
                    if binding:
                        _clear_binding_context(manager)
                    _caslib_reset(manager, leave_library=True)
                    manager.state.custom_pose_ui_active_nav = NAV_ALL_PACKS
                    manager.state.custom_pose_ui_query = ""
                    manager.state.custom_pose_ui_scroll_row = 0
                    _v7_reset_subview(manager)
                    manager.state.custom_pose_ui_blank_pack_view = True
                    _nav_switch_root(manager, save=False)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "caslib-nav:blank-packs"
                    )
                    return

                nav_index = decode_nav_response(response_value)
                if nav_index is not None:
                    if nav_index == NAV_ACCESSORY_LIBRARY:
                        _schedule_caslib_product_panel(
                            manager, live_owner, on_pack_selected, "nav-accessory"
                        )
                        return
                    if binding:
                        _clear_binding_context(manager)
                    _caslib_reset(manager, leave_library=True)
                    manager.state.custom_pose_ui_active_nav = nav_index
                    manager.state.custom_pose_ui_blank_pack_view = False
                    manager.state.custom_pose_ui_scroll_row = 0
                    _v7_reset_subview(manager)
                    _nav_switch_root(manager, save=False)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "caslib-nav:{}".format(nav_index)
                    )
                    return

                group_action = decode_group_response(response_value)
                if group_action is not None:
                    action, action_index = group_action
                    if action == "tab":
                        if source_mode == _CASLIB_SOURCE_EXTERNAL:
                            # External page has implicit “全部” plus one return tab.
                            if int(action_index) == 1:
                                _caslib_set_source(manager, _CASLIB_SOURCE_LOCAL)
                                reason = "caslib-source:local"
                            else:
                                manager.state.custom_pose_ui_cas_library_group = None
                                reason = "caslib-source:external-all"
                        else:
                            # ui.dialog.respond consumes the current dialog even for
                            # an unchanged tab/page. Always reopen to renew its id.
                            _caslib_select_group_tab(manager, group_tab_entries, action_index)
                            reason = "caslib-group:{}".format(action_index)
                        _schedule_caslib_product_panel(
                            manager, live_owner, on_pack_selected, reason,
                        )
                    return

                if response_value in (700034, 700035):
                    _caslib_set_source(manager, _CASLIB_SOURCE_EXTERNAL if response_value == 700035 else _CASLIB_SOURCE_LOCAL)
                    _schedule_caslib_product_panel(manager, live_owner, on_pack_selected, "caslib-source-button")
                    return

                if response_value == RESPONSE_LINKED_RESTORE_OUTFIT:
                    target = _caslib_target_from_state(manager) or live_owner
                    try:
                        result = _v8966_restore_original_outfit(target)
                    except Exception:
                        result = False
                    try:
                        manager.fgeh_pose_manager_debug_log(
                            "[CAS_LIBRARY_RESTORE] target={!r} result={!r}".format(target, result)
                        )
                    except Exception:
                        pass
                    _schedule_caslib_product_panel(
                        manager, live_owner, on_pack_selected, "restore-outfit"
                    )
                    return

                if response_value == RESPONSE_BACK:
                    if binding:
                        _caslib_return_to_bound_pose(manager, live_owner)
                        return
                    _caslib_reset(manager, leave_library=True)
                    if _nav_can_back(manager):
                        result = _nav_back(manager, save=True)
                        if result is not None:
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected, "caslib-nav-v2-back"
                            )
                            return
                    # H44 fail-closed: never fabricate an All Packs destination.
                    # A missing history frame is a navigation failure, not a
                    # reason to destroy the current context. Reopen the current
                    # Accessory Library root so the bug remains visible/safe.
                    try:
                        manager.fgeh_pose_manager_debug_log(
                            "[H44_NAV] accessory Back blocked: NAV V2 has no parent"
                        )
                    except Exception:
                        pass
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected,
                        "caslib-back-no-nav-parent",
                    )
                    return

                _nav_persist(manager)
            except Exception:
                try:
                    manager.fgeh_pose_manager_debug_log(
                        "[H34_CASLIB] response failed", exc=True
                    )
                except Exception:
                    pass

        _cas_show_t = _perf_now()
        _fgeh_trace_begin(dialog, "caslib", _cas_perf_total, len(raw_payload))
        dialog.show_dialog(
            on_response=_on_response,
            icon_override=IconInfoData(),
            additional_icons=(),
        )
        _perf_log(manager, "PERF CASLIB_DIALOG_SHOW_CALL ms={:.3f}".format(_perf_ms(_cas_show_t)))
        _perf_log(manager, "PERF CASLIB_TOTAL ms={:.3f}".format(_perf_ms(_cas_perf_total)))
        try:
            manager.fgeh_pose_manager_debug_log(
                "[H34_CASLIB] shown binding={} group={!r} products={} variants={}".format(
                    binding,
                    selected_group,
                    len(catalog),
                    sum(len(p.get("variants", ()) or ()) for p in catalog),
                )
            )
        except Exception:
            pass
        return True
    except Exception as exc:
        LAST_ERROR = "{}: {}".format(type(exc).__name__, exc)
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "[H34_CASLIB] show failed: {}".format(LAST_ERROR), exc=True
            )
        except Exception:
            pass
        return False


_R76_ROOT_CONTEXT = None

def show_pose_manager_root(owner, on_pack_selected=None):
    """Open the large root library and return selection through the dialog."""
    global LAST_ERROR, _ACTIVE_ROOT_PACK_CALLBACK
    _ACTIVE_ROOT_PACK_CALLBACK = on_pack_selected
    LAST_ERROR = ""
    try:
        import couplepose1 as manager
        _root_perf_total = _perf_now()
        target_info = _v8944_dialog_portrait_sim_info(owner, on_pack_selected)
        manager.state.custom_pose_ui_cas_library_target_sim_id = int(getattr(target_info, "sim_id", 0) or 0)
        _release_disable_debug_log(manager)
        _v89692_install_release_linked_gate(manager)
        if _nav_bridge is not None:
            try:
                _nav_bridge.ensure_installed()
            except Exception:
                pass
        _v88_ensure_metadata_state(manager)
        if not manager.is_custom_pose_manager_ui_enabled():
            LAST_ERROR = "custom_pose_manager_ui is disabled"
            return False
        if USE_NATIVE_ROOT_FALLBACK:
            return _show_native_root(manager, owner, on_pack_selected)

        from distributor.shared_messages import IconInfoData, create_icon_info_msg
        from event_testing.resolver import SingleSimResolver
        from sims4.localization import LocalizationHelperTuning
        from ui.ui_dialog import UiDialogResponse
        from ui.ui_dialog_labeled_icons import UiDialogIcons

        sim_info = getattr(owner, "sim_info", owner)
        live_owner = getattr(sim_info, "get_sim_instance", lambda: owner)()
        if live_owner is None:
            LAST_ERROR = "active Sim instance is unavailable"
            return False

        if _v7_active_nav(manager) == NAV_ACCESSORY_LIBRARY:
            return _show_cas_library_product_panel(
                live_owner, on_pack_selected=on_pack_selected
            )

        _nav_v3_trace(
            "ROOT_OPEN_BEGIN",
            "nav={} query={!r} state_page={}".format(
                _v7_active_nav(manager),
                getattr(manager.state, "custom_pose_ui_query", ""),
                int(getattr(manager.state, "custom_pose_ui_scroll_row", 0) or 0),
            ),
        )
        _v75_debug_loaded_legacy_data(manager)
        _root_rows_t = _perf_now()
        rows, icon_keys, packs = _build_rows_v7(manager)
        _perf_log(manager, "PERF ROOT_BUILD_ROWS_V7 ms={:.3f} rows={} icons={}".format(
            _perf_ms(_root_rows_t), len(rows), len(icon_keys)
        ))
        _v8964_apply_real_group_placeholders(manager, rows, icon_keys)
        _v8960_normalize_missing_icon_indexes(rows, icon_keys)
        root_page_size=9 if _v7_active_nav(manager)==NAV_OUTFIT_MANAGER and _outfit_ui_mode(manager)=="outfits" else PAGE_SIZE
        page = clamp_page(
            getattr(manager.state, "custom_pose_ui_scroll_row", 0),
            len(rows),root_page_size,
        )
        page_count = max(1, (len(rows) + root_page_size - 1) // root_page_size)
        _nav_v3_trace(
            "ROOT_OPEN_RESOLVED",
            "rows={} nav={} query={!r} state_page={} clamped_page={} page_count={}".format(
                len(rows),
                _v7_active_nav(manager),
                getattr(manager.state, "custom_pose_ui_query", ""),
                int(getattr(manager.state, "custom_pose_ui_scroll_row", 0) or 0),
                page,
                page_count,
            ),
        )
        header = {
            "page": page,
            "page_count": page_count,
            "page_label": _loc("tpl_page", page + 1, page_count, fallback="第 {} / {} 页"),
            "filter": getattr(manager.state, "custom_pose_ui_filter", "all"),
            "query": getattr(manager.state, "custom_pose_ui_query", ""),
            "navigation_mode": "scroll",
            "item_count": len(rows),
            "view_title": _v7_root_title(manager),
            "library_label": _v7_root_library_label(manager),

            # V7 extension activates the new ROOT sidebar in AS.
            # Pack detail deliberately remains on the stable V2 payload for now.
            "enable_v7": True,
            "view_kind": "root",
            "active_nav": _v7_active_nav(manager),
        }
        header["navigation_label"] = "滑动"
        manager.state.custom_pose_ui_navigation_mode = "scroll"
        _v8951_attach_global_widget_state(header, manager)

        header["favorite_pack_group_names"] = list(
            (getattr(manager.state, "user_fav_groups", {}) or {}).keys()
        )
        header["favorite_pose_group_names"] = list(
            (getattr(manager.state, "user_fav_pose_groups", {}) or {}).keys()
        )
        header["outer_action_group_names"] = list(
            (getattr(manager.state, "user_grouped_packs_groups", {}) or {}).keys()
        )

        # V8.9.18:
        # Settings cards are controls, not sortable/favoritable assets.
        header["root_tools"] = (
            _v7_active_nav(manager) not in (NAV_SETTINGS, NAV_ACCESSORY_LIBRARY)
        )
        header["root_sort_enabled"] = (
            False
            if _v7_active_nav(manager) in (NAV_SETTINGS, NAV_ACCESSORY_LIBRARY)
            else _v898_rows_support_sort(rows)
        )
        header["root_sort_label"] = _v87_sort_label(manager)
        nav = _v7_active_nav(manager)
        header["root_view_enabled"] = nav in (
            NAV_FAVORITE_PACKS,
            NAV_FAVORITE_CREATORS,
            NAV_FAVORITE_POSES,
            NAV_LINKED_ACTIONS,
        )
        if nav == NAV_FAVORITE_PACKS:
            header["root_view_label"] = _v87_fav_pack_view_label(manager)
        elif nav == NAV_FAVORITE_CREATORS:
            header["root_view_label"] = _v899_creator_view_label(manager)
            if getattr(
                manager.state,
                "custom_pose_ui_selected_creator",
                None,
            ):
                header["root_view_enabled"] = False
        elif nav == NAV_FAVORITE_POSES:
            header["root_view_label"] = _v88_fav_pose_view_label(manager)
        elif nav == NAV_LINKED_ACTIONS:
            header["root_view_label"] = _v89_linked_view_label(manager)
            if _v89_linked_view_mode(manager) == 1:
                header["view_kind"] = (
                    "root_linked_group_packs"
                    if _v8918_selected_linked_outer_group(manager)
                    else "root_linked_groups"
                )
            else:
                header["view_kind"] = "root_linked"
        elif nav == NAV_ACCESSORY_LIBRARY:
            global _CAS_LIBRARY_TARGET
            _CAS_LIBRARY_TARGET = live_owner
            header["root_view_enabled"] = False
            header["root_view_label"] = ""
            header["root_sort_enabled"] = False
            header["root_tools"] = False
            data = _caslib_load()
            names = _caslib_group_names(data)
            selected_group = _caslib_group(manager)
            header["group_names"] = names
            header["active_group_index"] = (names.index(selected_group) if selected_group in names else -1)
            # H36: do not invent a second accessory renderer.  Present the CAS
            # JSON as the mature pack_detail_linked / LINKED_PRODUCTS_V2 model.
            _caslib_attach_linked_product_payload(header, manager, data)
        elif nav == NAV_SETTINGS:
            header["root_view_enabled"] = False
            header["root_view_label"] = ""
            header["root_sort_enabled"] = False
            header["root_tools"] = False
            header["view_kind"] = "root_settings"
            header["group_names"] = []
            header["active_group_index"] = -1
        elif nav == NAV_OUTFIT_MANAGER:
            header["root_view_enabled"] = False
            header["root_view_label"] = ""
            header["root_sort_enabled"] = False
            outfit_mode = _outfit_ui_mode(manager)
            if outfit_mode == "outfits":
                header["root_tools"] = True
                header["view_kind"] = "root_outfits"
                outfit_tab_names, _outfit_tab_categories, outfit_active_index = _outfit_ui_category_tabs(manager)
                header["group_names"] = outfit_tab_names
                header["active_group_index"] = outfit_active_index
            else:
                header["root_tools"] = False
                header["view_kind"] = "root_outfit_parts"
                header["group_names"] = []
                header["active_group_index"] = -1
        else:
            header["root_view_label"] = ""

        context = _v88_group_context(manager)
        if context is not None:
            names = _v88_context_group_names(manager, context)
            edit_group = getattr(manager.state, context["edit_attr"], None)
            selected_group = getattr(manager.state, context["selected_attr"], None)
            if edit_group:
                header["view_kind"] = context["edit_kind"]
            elif selected_group and context["kind"] != "outer":
                header["view_kind"] = context["play_kind"]
            else:
                # Preserve V8.7 action-group behavior: the outer action-group
                # toolbar remains available even while one macro group is open.
                header["view_kind"] = context["browse_kind"]
            header["group_names"] = names
            active_group_name = edit_group or selected_group
            header["active_group_index"] = _v88_context_group_index(
                manager,
                context,
                active_group_name,
            )

            # V8.8.3: reuse the existing MEMBER_EDIT payload for every
            # root-level group editor, not just inner pack groups.
            # This lets AS draw the same green selection frame everywhere.
            if edit_group:
                header["member_edit_mode"] = True
                header["member_edit_group_index"] = _v88_context_group_index(
                    manager,
                    context,
                    edit_group,
                )
                header["member_selected_flags"] = "".join(
                    "1" if row.get("member_selected") else "0"
                    for row in rows
                )

            manager.fgeh_pose_manager_debug_log(
                "V8.9.18 root group context kind={} view={} groups={} selected={!r} edit={!r} active_index={}".format(
                    context["kind"],
                    header["view_kind"],
                    len(names),
                    selected_group,
                    edit_group,
                    header["active_group_index"],
                )
            )

        edit_keys, edit_names, edit_notes = _v88_build_edit_metadata(manager, rows)
        header["edit_keys"] = edit_keys
        header["edit_names"] = edit_names
        header["edit_notes"] = edit_notes

        _attach_ui_localization(header)
        _root_payload_t = _perf_now()
        raw_payload = pack_payload(header, rows)
        localized_payload = _localized_payload_cached(
            "root", raw_payload, manager
        )
        _perf_log(manager, "PERF ROOT_PAYLOAD ms={:.3f} payload_items={}".format(
            _perf_ms(_root_payload_t), len(raw_payload)
        ))
        _root_icons_t = _perf_now()
        additional_icons = _root_icon_messages_cached(
            icon_keys, create_icon_info_msg, IconInfoData, manager
        )
        _perf_log(manager, "PERF ROOT_ICON_MESSAGES ms={:.3f} count={}".format(
            _perf_ms(_root_icons_t), len(additional_icons)
        ))
        blank = LocalizationHelperTuning.get_raw_text("")
        dialog = UiDialogIcons.TunableFactory().default(
            live_owner,
            resolver=SingleSimResolver(sim_info),
            title=_constant_localized_string(blank),
            text=_constant_localized_string(blank),
            additional_texts=localized_payload,
            show_dialog_message_override=SHOW_MESSAGE,
        )
        # UiDialogIcons has no built-in responses. Without at least one
        # response, UiDialogService displays it but does not register its
        # dialog_id, so every ui.dialog.respond command is silently ignored.
        # The custom GFX owns the visible controls; this response only keeps
        # the dialog registered on the server.
        dialog.set_responses((
            UiDialogResponse(dialog_response_id=RESPONSE_BACK),
        ))
        manager.fgeh_pose_manager_debug_log(
            "custom UI dialog prepared id={} has_responses={}".format(
                dialog.dialog_id,
                bool(dialog.has_responses()),
            )
        )

        def _on_response(response_dialog):
            try:
                response = getattr(response_dialog, "response", None)
                try:
                    response_value = int(response)
                except Exception:
                    response_value = response

                manager.fgeh_pose_manager_debug_log(
                    "custom UI response raw={!r} value={!r} type={}".format(
                        response,
                        response_value,
                        type(response).__name__,
                    )
                )

                # ------------------------------------------------
                # V7 root navigation MUST be decoded first.
                # ------------------------------------------------
                # R10 nested child: GFX item index 8 sits visually under ALL
                # Packs but is deliberately NOT a ninth top-level nav id.
                if response_value == RESPONSE_NAV_BLANK_PACKS:
                    manager.state.custom_pose_ui_active_nav = NAV_ALL_PACKS
                    manager.state.custom_pose_ui_query = ""
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _v7_reset_subview(manager)
                    _caslib_reset(manager)
                    manager.state.custom_pose_ui_blank_pack_view = True
                    _nav_switch_root(manager, save=False)
                    try:
                        manager.fgeh_pose_manager_debug_log(
                            "[BLANK_PACK_SUBMENU] open response={} page=0".format(response_value)
                        )
                    except Exception:
                        pass
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "nav-blank-packs"
                    )
                    return

                nav_index = decode_nav_response(response_value)
                if nav_index is not None:
                    manager.fgeh_pose_manager_debug_log(
                        "[NAV] build={} selected_index={}".format(
                            UI_BUILD_TAG,
                            nav_index,
                        )
                    )
                    previous_nav = _v7_active_nav(manager)
                    entering_accessory = (
                        nav_index == NAV_ACCESSORY_LIBRARY
                        and previous_nav != NAV_ACCESSORY_LIBRARY
                    )

                    # H70W7D3 NAV PRESERVE: receiving the already-active
                    # top-level tab is a redraw/refresh, not a new navigation
                    # path.  Replacing the stack here used to erase the only
                    # ALL_PACKS parent frame after first forcing scroll_row=0.
                    # Preserve a true top-level root exactly as-is; section
                    # subviews (creator/group/etc.) keep the old behavior where
                    # clicking their sidebar tab returns to that section root.
                    same_nav = (nav_index == previous_nav)
                    has_section_subview = bool(any((
                        getattr(manager.state, "custom_pose_ui_selected_creator", None),
                        getattr(manager.state, "custom_pose_ui_selected_macro_group", None),
                        getattr(manager.state, "custom_pose_ui_selected_fav_pack_group", None),
                        getattr(manager.state, "custom_pose_ui_selected_fav_pose_group", None),
                        getattr(manager.state, "custom_pose_ui_selected_fav_pose_author", None),
                        getattr(manager.state, "custom_pose_ui_edit_outer_group", None),
                        getattr(manager.state, "custom_pose_ui_edit_fav_pack_group", None),
                        getattr(manager.state, "custom_pose_ui_edit_fav_pose_group", None),
                        _v8918_selected_linked_outer_group(manager),
                        _caslib_base(manager),
                        _caslib_group(manager),
                        bool(getattr(manager.state, "custom_pose_ui_blank_pack_view", False)),
                        (_v7_active_nav(manager) == NAV_OUTFIT_MANAGER and _outfit_ui_has_subview(manager)),
                    )))
                    if same_nav and not has_section_subview:
                        before_scroll = getattr(
                            manager.state, "custom_pose_ui_scroll_row", 0
                        )
                        try:
                            manager.fgeh_pose_manager_debug_log(
                                "[NAV_PRESERVE] same-nav={} scroll={} kept".format(
                                    nav_index, before_scroll
                                )
                            )
                        except Exception:
                            pass
                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "nav-preserve:{}".format(nav_index),
                        )
                        return

                    if entering_accessory:
                        # H44: Accessory Library is a CHILD surface, never a
                        # sidebar root replacement. Snapshot the exact parent
                        # before mutating any root state. If NAV V2 is missing
                        # or sync fails, do not enter the library and silently
                        # destroy the user's browser history.
                        parent_node = _nav_sync_root(manager, save=False)
                        if parent_node is None:
                            try:
                                manager.fgeh_pose_manager_debug_log(
                                    "[H44_NAV] accessory entry aborted: parent sync failed"
                                )
                            except Exception:
                                pass
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected,
                                "accessory-entry-nav-sync-failed",
                            )
                            return

                    manager.state.custom_pose_ui_active_nav = nav_index
                    manager.state.custom_pose_ui_blank_pack_view = False
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    manager.state.custom_pose_ui_query = ""
                    _v7_reset_subview(manager)
                    _caslib_reset(manager)
                    if nav_index != NAV_ACCESSORY_LIBRARY and _caslib_binding_mode(manager):
                        _clear_binding_context(manager)

                    if nav_index == NAV_FAVORITE_CREATORS:
                        # "作者" always opens on 收藏作者 first.
                        manager.state.custom_pose_ui_creator_view_mode = 0

                    if nav_index == NAV_OUTFIT_MANAGER:
                        _outfit_ui_reset(manager)

                    if entering_accessory:
                        pushed = _nav_push_root(manager, save=False)
                        if pushed is None:
                            # Parent frame was already synced. Restore it rather
                            # than falling through to a fake All Packs root.
                            _nav_apply_current(manager)
                            try:
                                manager.fgeh_pose_manager_debug_log(
                                    "[H44_NAV] accessory entry rolled back: push failed"
                                )
                            except Exception:
                                pass
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected,
                                "accessory-entry-nav-push-failed",
                            )
                            return
                    else:
                        # Ordinary sidebar sections keep their established
                        # top-level switch semantics.
                        _nav_switch_root(manager, save=False)

                    manager.fgeh_pose_manager_debug_log(
                        "custom UI V7 nav selected index={}".format(nav_index)
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "nav:{}".format(nav_index),
                    )
                    return


                # ------------------------------------------------
                # V8.7 root toolbar.
                # ------------------------------------------------
                if response_value == RESPONSE_BLANK_PACK_VIEW_TOGGLE:
                    if _v7_active_nav(manager) != NAV_ALL_PACKS:
                        return
                    manager.state.custom_pose_ui_blank_pack_view = not bool(
                        getattr(manager.state, "custom_pose_ui_blank_pack_view", False)
                    )
                    manager.state.custom_pose_ui_query = ""
                    manager.state.custom_pose_ui_scroll_row = 0
                    _nav_sync_root(manager, save=False)
                    try:
                        manager.fgeh_pose_manager_debug_log(
                            "[BLANK_PACK_SUBVIEW] enabled={}".format(
                                bool(manager.state.custom_pose_ui_blank_pack_view)
                            )
                        )
                    except Exception:
                        pass
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "blank-pack-subview-toggle"
                    )
                    return

                if response_value == RESPONSE_ROOT_SORT_TOGGLE:
                    current_sort = _v87_sort_mode(manager)
                    manager.state.pack_sort_mode = 0 if current_sort == 1 else 1
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.save_favorites()

                    manager.fgeh_pose_manager_debug_log(
                        "V8.7 root sort toggled {} -> {}".format(
                            current_sort,
                            manager.state.pack_sort_mode,
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "root-sort-toggle",
                    )
                    return

                if response_value == RESPONSE_FAV_PACK_VIEW_TOGGLE:
                    if _v7_active_nav(manager) != NAV_FAVORITE_PACKS:
                        manager.fgeh_pose_manager_debug_log(
                            "V8.7 fav-pack view toggle ignored outside favorite packs"
                        )
                        return

                    current_view = _v87_fav_pack_view_mode(manager)
                    manager.state.fav_packs_view_toggle = (current_view + 1) % 3
                    manager.state.custom_pose_ui_selected_creator = None
                    manager.state.custom_pose_ui_selected_fav_pack_group = None
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.save_favorites()

                    manager.fgeh_pose_manager_debug_log(
                        "V8.7 fav-pack view toggled {} -> {}".format(
                            current_view,
                            manager.state.fav_packs_view_toggle,
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "fav-pack-view-toggle",
                    )
                    return

                if response_value == RESPONSE_FAV_POSE_VIEW_TOGGLE:
                    if _v7_active_nav(manager) != NAV_FAVORITE_POSES:
                        return
                    current_view = _v88_fav_pose_view_mode(manager)
                    manager.state.fav_poses_view_toggle = (current_view + 1) % 3
                    manager.state.custom_pose_ui_selected_fav_pose_group = None
                    manager.state.custom_pose_ui_selected_fav_pose_author = None
                    manager.state.custom_pose_ui_edit_fav_pose_group = None
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.save_favorites()
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "fav-pose-view-toggle"
                    )
                    return




                if response_value == RESPONSE_CREATOR_VIEW_TOGGLE:
                    if _v7_active_nav(manager) != NAV_FAVORITE_CREATORS:
                        return

                    current_view = _v899_creator_view_mode(manager)
                    manager.state.custom_pose_ui_creator_view_mode = (
                        0 if current_view == 1 else 1
                    )
                    manager.state.custom_pose_ui_selected_creator = None
                    manager.state.custom_pose_ui_scroll_row = 0

                    manager.fgeh_pose_manager_debug_log(
                        "V8.9.9 creator view toggled {} -> {}".format(
                            current_view,
                            manager.state.custom_pose_ui_creator_view_mode,
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "creator-view-toggle",
                    )
                    return


                if response_value == RESPONSE_LINKED_VIEW_TOGGLE:
                    if _v7_active_nav(manager) != NAV_LINKED_ACTIONS:
                        return

                    current_view = _v89_linked_view_mode(manager)
                    new_view = 0 if current_view == 1 else 1
                    _v8934_persist_linked_view_mode(manager, new_view)
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_active_inner_group = None
                    manager.state.custom_pose_ui_edit_inner_group = None
                    try:
                        manager.state.selected_linked_grouped_outer_name = None
                    except Exception:
                        pass

                    manager.fgeh_pose_manager_debug_log(
                        "V8.9 linked view toggled {} -> {}".format(
                            current_view,
                            _v89_linked_view_mode(manager),
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "linked-view-toggle",
                    )
                    return


                # R16 Outfit Manager: reuse the already-stable horizontal group-tab
                # component for EA OutfitCategory.  Tab 0 is the implicit “全部”;
                # subsequent tabs map only to categories that really exist on the Sim.
                if (
                    _v7_active_nav(manager) == NAV_OUTFIT_MANAGER
                    and _outfit_ui_mode(manager) == "outfits"
                ):
                    outfit_group_action = decode_group_response(response_value)
                    if outfit_group_action is not None:
                        action, action_index = outfit_group_action
                        if action == "tab":
                            _names, categories, _active = _outfit_ui_category_tabs(manager)
                            if action_index == 0:
                                _outfit_ui_set_browse_category(manager, None)
                            else:
                                category_index = int(action_index or 0) - 1
                                if 0 <= category_index < len(categories):
                                    _outfit_ui_set_browse_category(
                                        manager, categories[category_index]
                                    )
                            manager.state.custom_pose_ui_scroll_row = 0
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected,
                                "outfit-category-tab:{}".format(action_index),
                            )
                            return

                # H33 accessory-library group tabs are read-only mirrors of
                # fgeh_cas_collection.json.  Tab 0 is “全部”; tab N maps to
                # JSON group_names[N-1].  Group creation/deletion stays in CAS.
                if _v7_active_nav(manager) == NAV_ACCESSORY_LIBRARY and not _caslib_base(manager):
                    cas_group_action = decode_group_response(response_value)
                    if cas_group_action is not None:
                        action, action_index = cas_group_action
                        if action == "tab":
                            data = _caslib_load()
                            names = _caslib_group_names(data)
                            if action_index == 0:
                                manager.state.custom_pose_ui_cas_library_group = None
                            else:
                                index = int(action_index or 0) - 1
                                if 0 <= index < len(names):
                                    manager.state.custom_pose_ui_cas_library_group = names[index]
                            manager.state.custom_pose_ui_cas_library_base = None
                            manager.state.custom_pose_ui_scroll_row = 0
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected,
                                "cas-library-tab:{}".format(action_index),
                            )
                            return

                # ------------------------------------------------
                # V8.8 shared root group manager.
                # ------------------------------------------------
                outer_group_action = decode_outer_group_response(response_value)
                if outer_group_action is not None:
                    action, action_index = outer_group_action
                    context = _v88_group_context(manager)
                    if context is None:
                        return
                    groups = _v88_context_groups(manager, context)
                    names = _v88_context_group_names(manager, context)

                    if action == "create":
                        group_name = _v88_next_context_group_name(manager, context)
                        groups[group_name] = []
                        setattr(manager.state, context["groups_attr"], groups)
                        setattr(manager.state, context["selected_attr"], None)
                        setattr(manager.state, context["edit_attr"], group_name)
                        manager.state.custom_pose_ui_scroll_row = 0
                        manager.save_favorites()
                        _schedule_root_reopen(manager, live_owner, on_pack_selected, "root-group-create")
                        return

                    if action == "done":
                        setattr(manager.state, context["edit_attr"], None)
                        setattr(manager.state, context["selected_attr"], None)
                        manager.state.custom_pose_ui_scroll_row = 0
                        _schedule_root_reopen(manager, live_owner, on_pack_selected, "root-group-done")
                        return

                    if action in ("select_all", "clear"):
                        group_name = getattr(manager.state, context["edit_attr"], None)
                        if not group_name:
                            return
                        if action == "clear":
                            groups[group_name] = []
                        else:
                            members = []
                            for row in rows:
                                kind = str(row.get("kind", "") or "")
                                if context["kind"] == "fav_pose":
                                    if kind != "fav_pose_group_member":
                                        continue
                                    member_id = str(row.get("value", "") or "")
                                else:
                                    expected = "outer_group_member" if context["kind"] == "outer" else "fav_pack_group_member"
                                    if kind != expected:
                                        continue
                                    member_id = str(row.get("value", row.get("pack_id", "")) or "")
                                if member_id and member_id not in members:
                                    members.append(member_id)
                            groups[group_name] = members
                        setattr(manager.state, context["groups_attr"], groups)
                        manager.state.custom_pose_ui_scroll_row = 0
                        manager.save_favorites()
                        _schedule_root_reopen(manager, live_owner, on_pack_selected, "root-group-bulk")
                        return

                    if action == "edit":
                        if action_index is not None and 0 <= action_index < len(names):
                            group_name = names[action_index]
                            setattr(manager.state, context["selected_attr"], None)
                            setattr(manager.state, context["edit_attr"], group_name)
                            manager.state.custom_pose_ui_scroll_row = 0
                            _schedule_root_reopen(manager, live_owner, on_pack_selected, "root-group-edit")
                        return

                    if action == "rename":
                        if action_index is not None and 0 <= action_index < len(names):
                            _v88_show_root_group_rename_dialog(
                                manager, live_owner, context, names[action_index], on_pack_selected
                            )
                        return

                    if action == "delete":
                        if action_index is not None and 0 <= action_index < len(names):
                            group_name = names[action_index]
                            if group_name in groups:
                                del groups[group_name]
                                setattr(manager.state, context["groups_attr"], groups)
                                if getattr(manager.state, context["selected_attr"], None) == group_name:
                                    setattr(manager.state, context["selected_attr"], None)
                                if getattr(manager.state, context["edit_attr"], None) == group_name:
                                    setattr(manager.state, context["edit_attr"], None)
                                manager.save_favorites()
                            manager.state.custom_pose_ui_scroll_row = 0
                            _schedule_root_reopen(manager, live_owner, on_pack_selected, "root-group-delete")
                        return

                # ------------------------------------------------
                # Back: first leave a creator/group subview,
                # then leave the current V7 section, then use the
                # normal root behavior.
                # ------------------------------------------------
                if response_value == RESPONSE_BACK:
                    for edit_attr in (
                        "custom_pose_ui_edit_outer_group",
                        "custom_pose_ui_edit_fav_pack_group",
                        "custom_pose_ui_edit_fav_pose_group",
                    ):
                        if getattr(manager.state, edit_attr, None):
                            setattr(manager.state, edit_attr, None)
                            manager.state.custom_pose_ui_scroll_row = 0
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected, "root-group-edit-back"
                            )
                            return

                    if (
                        _v7_active_nav(manager) == NAV_OUTFIT_MANAGER
                        and _outfit_ui_has_subview(manager)
                    ):
                        _outfit_ui_reset(manager)
                        manager.state.custom_pose_ui_scroll_row = 0
                        _schedule_root_reopen(
                            manager, live_owner, on_pack_selected, "outfit-manager-back"
                        )
                        return

                    accessory_root_back = (
                        _v7_active_nav(manager) == NAV_ACCESSORY_LIBRARY
                    )
                    if accessory_root_back:
                        if _caslib_base(manager):
                            manager.state.custom_pose_ui_cas_library_base = None
                            manager.state.custom_pose_ui_scroll_row = 0
                            _schedule_root_reopen(
                                manager, live_owner, on_pack_selected, "cas-library-back-product"
                            )
                            return
                        if _caslib_binding_mode(manager):
                            _caslib_return_to_bound_pose(manager, live_owner)
                            return

                    # V8.9.58 NAV V2: a real browser-like Back.  If a
                    # path exists, pop exactly one root/group/author level and
                    # let the restored parent state redraw.  The old flag-based
                    # branch below remains as migration fallback only.
                    if _nav_can_back(manager):
                        result = _nav_back(manager, save=True)
                        if result is not None:
                            _schedule_root_reopen(
                                manager,
                                live_owner,
                                on_pack_selected,
                                "nav-v2-back",
                            )
                            return

                    if accessory_root_back:
                        # H44: do not let Accessory Library fall through into
                        # the legacy `active_nav != NAV_ALL_PACKS` hard jump.
                        try:
                            manager.fgeh_pose_manager_debug_log(
                                "[H44_NAV] root accessory Back blocked: no NAV V2 parent"
                            )
                        except Exception:
                            pass
                        _schedule_root_reopen(
                            manager, live_owner, on_pack_selected,
                            "accessory-root-back-no-nav-parent",
                        )
                        return

                    if getattr(
                        manager.state,
                        "custom_pose_ui_selected_creator",
                        None,
                    ):
                        manager.state.custom_pose_ui_selected_creator = None
                        manager.state.custom_pose_ui_scroll_row = 0

                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "creator-back",
                        )
                        return

                    if getattr(
                        manager.state,
                        "custom_pose_ui_selected_fav_pack_group",
                        None,
                    ):
                        manager.state.custom_pose_ui_selected_fav_pack_group = None
                        manager.state.custom_pose_ui_scroll_row = 0

                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "fav-pack-group-back",
                        )
                        return

                    if getattr(
                        manager.state,
                        "custom_pose_ui_selected_fav_pose_group",
                        None,
                    ):
                        manager.state.custom_pose_ui_selected_fav_pose_group = None
                        manager.state.custom_pose_ui_scroll_row = 0
                        _schedule_root_reopen(
                            manager, live_owner, on_pack_selected, "fav-pose-group-back"
                        )
                        return

                    if getattr(
                        manager.state,
                        "custom_pose_ui_selected_fav_pose_author",
                        None,
                    ):
                        manager.state.custom_pose_ui_selected_fav_pose_author = None
                        manager.state.custom_pose_ui_scroll_row = 0
                        _schedule_root_reopen(
                            manager, live_owner, on_pack_selected, "fav-pose-author-back"
                        )
                        return

                    if getattr(
                        manager.state,
                        "custom_pose_ui_selected_macro_group",
                        None,
                    ):
                        manager.state.custom_pose_ui_selected_macro_group = None
                        manager.state.custom_pose_ui_scroll_row = 0

                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "group-back",
                        )
                        return

                    if (
                        _v7_active_nav(manager) == NAV_LINKED_ACTIONS
                        and _v8918_selected_linked_outer_group(manager)
                    ):
                        manager.state.selected_linked_grouped_outer_name = None
                        manager.state.custom_pose_ui_scroll_row = 0
                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "linked-outer-group-back",
                        )
                        return

                    if _v7_active_nav(manager) != NAV_ALL_PACKS:
                        manager.state.custom_pose_ui_active_nav = NAV_ALL_PACKS
                        manager.state.custom_pose_ui_scroll_row = 0
                        manager.state.custom_pose_ui_favorite_only = False

                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "nav-back-all",
                        )
                        return

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "library-root",
                    )
                    return


                if response_value == RESPONSE_ROOT_SEARCH_APPLY:
                    manager.state.custom_pose_ui_scroll_row = 0
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "root-search"
                    )
                    return

                if response_value == RESPONSE_EDIT_INFO_REFRESH:
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "edit-info-refresh"
                    )
                    return

                requested_page = decode_page_response(response_value)
                if requested_page is not None:
                    next_page = clamp_page(requested_page, len(rows), root_page_size)
                    manager.state.custom_pose_ui_scroll_row = next_page

                    # H70W7D3R2: persist the ROOT navigation node *after*
                    # updating its scroll/page state.  The previous ordering
                    # saved favorites first, then _schedule_root_reopen() only
                    # refreshed NAV_V2 in memory.  If the player closed the
                    # GFX with X afterwards, the on-disk NAV_V2 stack could
                    # still contain page 0, so the next manual open jumped to
                    # the beginning even though the live dialog had reached a
                    # later page.
                    synced = _nav_sync_root_view(
                        manager,
                        query=getattr(manager.state, "custom_pose_ui_query", ""),
                        page=next_page,
                        save=True,
                    )
                    if synced is None:
                        # Keep the legacy fallback working when navigation is
                        # unavailable for any reason.
                        manager.save_favorites()

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "page:{}".format(next_page),
                    )
                    return

                # ------------------------------------------------
                # Right click favorite.
                # Creator/group pseudo cards are navigation nodes,
                # not real pose packs, so never write their fake
                # pack_id into favorite_packs.
                # ------------------------------------------------
                favorite_decoded = decode_pack_favorite_response(response_value)
                if favorite_decoded is not None:
                    pack_index = favorite_decoded
                    # R24: local GFX paging already flushes through PostResponse.
                    # Do not overwrite it with the dialog-open closure page.

                    if any((
                        getattr(manager.state, "custom_pose_ui_edit_outer_group", None),
                        getattr(manager.state, "custom_pose_ui_edit_fav_pack_group", None),
                        getattr(manager.state, "custom_pose_ui_edit_fav_pose_group", None),
                    )):
                        _schedule_root_reopen(
                            manager, live_owner, on_pack_selected, "root-group-edit-ignore-right-click"
                        )
                        return

                    if 0 <= pack_index < len(rows):
                        row = rows[pack_index]
                        row_kind = str(row.get("kind", "pack"))

                        # R20 Outfit Manager interaction contract:
                        #   left click  = wear/switch to this saved EA outfit
                        #   right click = open this outfit for inspection/editing
                        # The native cell already maps right click onto the existing
                        # favorite-response channel, so reuse that proven input path
                        # instead of adding another GFX event surface.
                        if row_kind == "outfit_manager_outfit":
                            try:
                                manager.state.custom_pose_ui_outfit_manager_category = int(row.get("outfit_category"))
                                manager.state.custom_pose_ui_outfit_manager_index = int(row.get("outfit_index"))
                                # R26: detail is a dedicated dialog that reuses the
                                # proven CAS product/swatch renderer.  Keep the
                                # root mode as outfits so Back has one clear owner.
                                manager.state.custom_pose_ui_outfit_manager_mode = "outfits"
                                manager.state.custom_pose_ui_scroll_row = 0
                            except Exception:
                                manager.fgeh_pose_manager_debug_log(
                                    "[OUTFIT_MANAGER] right-click edit open failed", exc=True
                                )
                            _schedule_outfit_detail_panel(
                                manager, live_owner, on_pack_selected, "outfit-manager-right-edit-r26"
                            )
                            return

                        if row_kind in ("pack", "favorite_pose_pack", "linked_pack"):
                            pack_id = str(row.get("pack_id", "") or "")
                            if pack_id:
                                if pack_id in manager.state.favorite_packs:
                                    manager.state.favorite_packs.remove(pack_id)
                                    favorite_enabled = False
                                else:
                                    manager.state.favorite_packs.append(pack_id)
                                    favorite_enabled = True
                                manager.save_favorites()
                                manager.fgeh_pose_manager_debug_log(
                                    "custom UI pack favorite toggled pack_id={} enabled={}".format(
                                        pack_id,
                                        favorite_enabled,
                                    )
                                )
                        else:
                            manager.fgeh_pose_manager_debug_log(
                                "custom UI pseudo row ignored right-click kind={} index={}".format(
                                    row_kind,
                                    pack_index,
                                )
                            )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "favorite:{}".format(pack_index),
                    )
                    return

                decoded = decode_pack_response(response_value)
                if decoded is None:
                    # Close is NOT Back. Persist the exact current node so the
                    # next manual open can resume here.
                    _nav_sync_root(manager, save=False)
                    _nav_persist(manager)
                    manager.fgeh_pose_manager_debug_log(
                        "custom UI response treated as close/cancel value={!r}".format(
                            response_value
                        )
                    )
                    return

                pack_index = decoded
                # R24: retain the live root cursor synchronized before response.

                if not (0 <= pack_index < len(rows)):
                    manager.fgeh_pose_manager_debug_log(
                        "custom UI selected invalid index={} rows={}".format(
                            pack_index,
                            len(rows),
                        )
                    )
                    return

                row = rows[pack_index]
                row_kind = str(row.get("kind", "pack"))

                if row_kind == "outfit_manager_outfit":
                    try:
                        category = int(row.get("outfit_category"))
                        outfit_index = int(row.get("outfit_index"))
                        _outfit_ui_switch_saved_outfit(manager, category, outfit_index)
                    except Exception:
                        manager.fgeh_pose_manager_debug_log(
                            "[OUTFIT_MANAGER] left-click switch dispatch failed", exc=True
                        )
                    # Stay on the same Outfit category page so the interaction feels
                    # like EA's picker rather than navigation into a detail page.
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "outfit-manager-left-switch"
                    )
                    return

                if row_kind == "outfit_manager_settings":
                    manager.state.custom_pose_ui_outfit_manager_mode = "settings"
                    manager.state.custom_pose_ui_scroll_row = 0
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "outfit-manager-settings"
                    )
                    return

                if row_kind == "outfit_manager_native_preview":
                    try:
                        if _outfit_phase1 is not None:
                            _outfit_phase1.show_native_picker_read_only()
                    except Exception:
                        manager.fgeh_pose_manager_debug_log("[OUTFIT_MANAGER] native preview failed", exc=True)
                    return

                if row_kind in ("outfit_manager_part", "outfit_manager_info"):
                    manager.fgeh_pose_manager_debug_log(
                        "[OUTFIT_MANAGER] read-only row kind={} value={!r}".format(
                            row_kind, row.get("value")
                        )
                    )
                    return

                if row_kind == "setting":
                    setting_key = str(row.get("value", "") or "")

                    # V8.9.69.6 SAFE SETTINGS UTILITIES:
                    # These are one-shot recovery actions, not persistent bool settings.
                    # Keep them entirely inside the existing settings-cell response path;
                    # do NOT touch couplepose1 / the root UI bridge / Interaction tuning.
                    if setting_key == "utility_restore_original_outfit":
                        try:
                            result = _v8966_restore_original_outfit(sim_info)
                            manager.fgeh_pose_manager_debug_log(
                                "[SETTINGS_UTIL_V1] restore_original_outfit result={!r} sim_id={}".format(
                                    result,
                                    getattr(sim_info, "sim_id", None),
                                )
                            )
                        except Exception:
                            manager.fgeh_pose_manager_debug_log(
                                "[SETTINGS_UTIL_V1] restore_original_outfit failed",
                                exc=True,
                            )
                    elif setting_key == "utility_clear_linked_objects":
                        try:
                            result = _v8966_clear_linked_objects(sim_info)
                            manager.fgeh_pose_manager_debug_log(
                                "[SETTINGS_UTIL_V1] clear_linked_objects result={!r} sim_id={}".format(
                                    result,
                                    getattr(sim_info, "sim_id", None),
                                )
                            )
                        except Exception:
                            manager.fgeh_pose_manager_debug_log(
                                "[SETTINGS_UTIL_V1] clear_linked_objects failed",
                                exc=True,
                            )
                    elif setting_key != "cache_info":
                        _v8918_toggle_setting(manager, setting_key)
                    else:
                        manager.fgeh_pose_manager_debug_log(
                            "[SETTINGS] build={} cache-info clicked".format(
                                UI_BUILD_TAG
                            )
                        )

                    manager.state.custom_pose_ui_scroll_row = 0
                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "settings:{}".format(setting_key),
                    )
                    return

                if row_kind == "cas_library_product":
                    manager.state.custom_pose_ui_cas_library_base = str(row.get("value") or "")
                    manager.state.custom_pose_ui_scroll_row = 0
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "cas-library-product"
                    )
                    return

                if row_kind == "cas_library_variant":
                    try:
                        if _caslib_binding_mode(manager):
                            _caslib_toggle_binding(
                                manager,
                                row.get("base_id") or _caslib_base(manager),
                                int(row.get("value") or 0),
                            )
                        else:
                            _caslib_apply_variant(manager, live_owner, int(row.get("value") or 0))
                    except Exception:
                        manager.fgeh_pose_manager_debug_log("[CAS_LIBRARY] variant action failed", exc=True)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected,
                        "cas-library-variant-toggle" if _caslib_binding_mode(manager) else "cas-library-variant-apply"
                    )
                    return

                if row_kind == "cas_binding_done":
                    _caslib_return_to_bound_pose(manager, live_owner)
                    return

                if row_kind == "cas_library_restore":
                    _caslib_restore(manager, live_owner)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "cas-library-restore"
                    )
                    return

                if row_kind == "linked_macro_group":
                    group_name = str(row.get("value", "") or "")
                    if group_name:
                        _nav_sync_root(manager, save=False)
                        manager.state.selected_linked_grouped_outer_name = group_name
                        manager.state.custom_pose_ui_scroll_row = 0
                        _nav_push_root(manager, save=False)
                        manager.fgeh_pose_manager_debug_log(
                            "[LINKED_GROUP_VIEW] selected outer group={!r}".format(
                                group_name
                            )
                        )
                        _schedule_root_reopen(
                            manager,
                            live_owner,
                            on_pack_selected,
                            "linked-outer-group:{}".format(group_name),
                        )
                    return

                if row_kind in (
                    "outer_group_member",
                    "fav_pack_group_member",
                    "fav_pose_group_member",
                ):
                    context = _v88_group_context(manager)
                    if context is not None:
                        group_name = getattr(manager.state, context["edit_attr"], None)
                        member_id = str(row.get("value", row.get("pack_id", "")) or "")
                        if group_name and member_id:
                            groups = _v88_context_groups(manager, context)
                            members = list(groups.get(group_name, ()) or ())
                            if member_id in members:
                                members.remove(member_id)
                            else:
                                members.append(member_id)
                            groups[group_name] = members
                            setattr(manager.state, context["groups_attr"], groups)
                            manager.save_favorites()
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "root-group-member-toggle"
                    )
                    return

                # 收藏动作包 / 按作者 -> 作者的收藏动作包。
                if row_kind == "fav_pack_author":
                    creator = row.get("value")
                    _nav_sync_root(manager, save=False)
                    manager.state.custom_pose_ui_selected_creator = creator
                    manager.state.custom_pose_ui_selected_fav_pack_group = None
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _nav_push_root(manager, save=False)

                    manager.fgeh_pose_manager_debug_log(
                        "V8.7 favorite-pack author selected creator={!r}".format(
                            creator
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "fav-pack-author:{}".format(creator),
                    )
                    return

                # 收藏动作包 / 我的分组 -> 组里的收藏动作包。
                if row_kind == "fav_pack_group":
                    group_name = row.get("value")
                    _nav_sync_root(manager, save=False)
                    manager.state.custom_pose_ui_selected_creator = None
                    manager.state.custom_pose_ui_selected_fav_pack_group = group_name
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _nav_push_root(manager, save=False)

                    manager.fgeh_pose_manager_debug_log(
                        "V8.7 favorite-pack group selected group={!r}".format(
                            group_name
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "fav-pack-group:{}".format(group_name),
                    )
                    return

                if row_kind == "fav_pose_group":
                    group_name = row.get("value")
                    _nav_sync_root(manager, save=False)
                    manager.state.custom_pose_ui_selected_fav_pose_group = group_name
                    manager.state.custom_pose_ui_selected_fav_pose_author = None
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _nav_push_root(manager, save=False)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "fav-pose-group:{}".format(group_name)
                    )
                    return

                if row_kind == "fav_pose_author":
                    author = row.get("value")
                    _nav_sync_root(manager, save=False)
                    manager.state.custom_pose_ui_selected_fav_pose_author = author
                    manager.state.custom_pose_ui_selected_fav_pose_group = None
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _nav_push_root(manager, save=False)
                    _schedule_root_reopen(
                        manager, live_owner, on_pack_selected, "fav-pose-author:{}".format(author)
                    )
                    return

                # Favorite creator card -> creator's real packs.
                if row_kind == "creator":
                    creator = row.get("value")
                    _nav_sync_root(manager, save=False)
                    manager.state.custom_pose_ui_selected_creator = creator
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _nav_push_root(manager, save=False)

                    manager.fgeh_pose_manager_debug_log(
                        "custom UI creator selected creator={!r}".format(creator)
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "creator:{}".format(creator),
                    )
                    return

                # Outer custom pose-pack group -> group's real packs.
                if row_kind == "macro_group":
                    group_name = row.get("value")
                    _nav_sync_root(manager, save=False)
                    manager.state.custom_pose_ui_selected_macro_group = group_name
                    manager.state.custom_pose_ui_scroll_row = 0
                    manager.state.custom_pose_ui_favorite_only = False
                    _nav_push_root(manager, save=False)

                    manager.fgeh_pose_manager_debug_log(
                        "custom UI macro group selected group={!r}".format(
                            group_name
                        )
                    )

                    _schedule_root_reopen(
                        manager,
                        live_owner,
                        on_pack_selected,
                        "macro-group:{}".format(group_name),
                    )
                    return

                # In 收藏动作, the card still represents a real pack,
                # but the detail builder filters it down to favorite poses.
                if row_kind == "favorite_pose_pack":
                    manager.state.custom_pose_ui_favorite_only = True
                else:
                    manager.state.custom_pose_ui_favorite_only = False

                manager.fgeh_pose_manager_debug_log(
                    "custom UI pack selected index={} remembered_page={} kind={}".format(
                        pack_index,
                        page,
                        row_kind,
                    )
                )

                if (
                    0 <= pack_index < len(packs)
                    and packs[pack_index] is not None
                    and on_pack_selected is not None
                ):
                    # Root -> pack is a real navigation edge. Keep the exact
                    # parent root/group/author node below the pack leaf.
                    _nav_enter_pack(manager, packs[pack_index], save=False)
                    _schedule_pack_selection(
                        manager,
                        live_owner,
                        packs[pack_index],
                        on_pack_selected,
                    )

            except Exception as exc:
                manager.fgeh_pose_manager_debug_log(
                    "custom UI response callback failed: {}: {}".format(
                        type(exc).__name__,
                        exc,
                    ),
                    exc=True,
                )


        _root_show_t = _perf_now()
        _fgeh_trace_begin(dialog, "root", _root_perf_total, len(raw_payload))
        global _R76_ROOT_CONTEXT
        _R76_ROOT_CONTEXT = (manager, live_owner, on_pack_selected, dialog)
        dialog.show_dialog(
            on_response=_on_response,
            # V8.9.54: deliberately blank. The header now belongs to the
            # global Plumbob widget; never ask UiDialog for a Sim portrait.
            icon_override=IconInfoData(),
            additional_icons=additional_icons,
        )
        _perf_log(manager, "PERF ROOT_DIALOG_SHOW_CALL ms={:.3f}".format(_perf_ms(_root_show_t)))
        _perf_log(manager, "PERF ROOT_TOTAL_PY ms={:.3f}".format(_perf_ms(_root_perf_total)))
        return True
    except Exception as exc:
        LAST_ERROR = "{}: {}".format(type(exc).__name__, exc)
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "custom pose manager UI failed: {}".format(LAST_ERROR),
                exc=True,
            )
        except Exception:
            pass
        return False



def _v89_decode_command_text(value):
    try:
        from urllib.parse import unquote
        return unquote(str(value or ""))
    except Exception:
        return str(value or "")


_V810_FAVORITE_ITEM_SEPARATOR = "<<<FGEH_FAV_ITEM>>>"


def _v810_decode_favorite_items(value):
    raw = _v89_decode_command_text(value)

    if _V810_FAVORITE_ITEM_SEPARATOR in raw:
        pieces = raw.split(_V810_FAVORITE_ITEM_SEPARATOR)
    else:
        # Backward compatibility with V8.9.9 / older AS.
        pieces = raw.splitlines()

    result = []
    seen = set()
    for piece in pieces:
        piece = str(piece or "").strip()
        if not piece or piece in seen:
            continue
        seen.add(piece)
        result.append(piece)

    return result





@sims4.commands.Command(
    "fgeh.favorite_add_group",
    command_type=sims4.commands.CommandType.Live,
)
def _v816_command_favorite_add_group(
    scope="",
    group_name="",
    item_values="",
    _connection=None,
):
    """
    One-step filing action used by batch selection.

    scope=pack:
      ensure items are in favorite_packs
      add items to user_fav_groups[group_name]

    scope=pose:
      ensure items are in favorite_poses
      add items to user_fav_pose_groups[group_name]

    This is deliberately idempotent and is NOT a favorite toggle.
    "加入收藏分组" must never accidentally un-favorite an already-favorite item.
    A previously unknown group_name creates that favorite group on demand.
    """
    del _connection

    try:
        import couplepose1 as manager

        scope = _v89_decode_command_text(scope).strip()
        group_name = _v89_decode_command_text(group_name).strip()
        values = _v810_decode_favorite_items(item_values)

        if not group_name or not values:
            return False

        if scope == "pack":
            favorites = manager.state.favorite_packs
            groups_attr = "user_fav_groups"
        elif scope == "pose":
            favorites = manager.state.favorite_poses
            groups_attr = "user_fav_pose_groups"
        else:
            manager.fgeh_pose_manager_debug_log(
                "V8.9.16 favorite-add-group ignored unsupported scope={!r}".format(
                    scope
                )
            )
            return False

        favorite_added = 0
        for value in values:
            if value not in favorites:
                favorites.append(value)
                favorite_added += 1

        groups = getattr(manager.state, groups_attr, {}) or {}
        if not isinstance(groups, dict):
            groups = {}

        members = list(groups.get(group_name, ()) or ())
        member_added = 0

        for value in values:
            if value not in members:
                members.append(value)
                member_added += 1

        groups[group_name] = members
        setattr(manager.state, groups_attr, groups)

        manager.save_favorites()

        manager.fgeh_pose_manager_debug_log(
            "V8.9.16 favorite-add-group scope={} group={!r} requested={} favorite_added={} member_added={}".format(
                scope,
                group_name,
                len(values),
                favorite_added,
                member_added,
            )
        )
        return True

    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.16 favorite-add-group failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.root_search_query",
    command_type=sims4.commands.CommandType.Live,
)
def _v8936_root_search_query(encoded_query="", encoded_page="", _connection=None):
    """V3 lightweight live-search / local-page state sync.

    GFX remains responsible for immediate Draw().  This command updates only
    Python memory + the current navigation node; it does not reopen the dialog
    and does not write the user JSON on every debounce tick.
    """
    del _connection
    try:
        import couplepose1 as manager

        # H70W7D3R7 package bridge keeps the proven one-business-argument
        # PostServerCommand shape and sends:
        #     encodeURIComponent(query) + "|" + current_page
        # Split BEFORE URL-decoding: a literal pipe inside the user's query is
        # encoded as %7C, so the final raw pipe is an unambiguous separator.
        raw_query_arg = str(encoded_query or "")
        raw_page_arg = str(encoded_page or "")
        combined_page = ""
        combined_query = raw_query_arg
        if not raw_page_arg and "|" in raw_query_arg:
            left, separator, right = raw_query_arg.rpartition("|")
            if separator and right.strip():
                try:
                    int(right.strip())
                    combined_query = left
                    combined_page = right.strip()
                except Exception:
                    pass

        query = _v89_decode_command_text(combined_query).strip()
        page_text = _v89_decode_command_text(
            raw_page_arg if raw_page_arg else combined_page
        ).strip()
        page = None
        if page_text:
            try:
                page = max(0, int(page_text))
            except Exception:
                page = None

        before_query = str(getattr(manager.state, "custom_pose_ui_query", "") or "")
        before_page = int(getattr(manager.state, "custom_pose_ui_scroll_row", 0) or 0)
        _nav_v3_trace(
            "SYNC_RX",
            "raw_query={!r} raw_page={!r} parsed_query={!r} parsed_page={} before_query={!r} before_page={}".format(
                raw_query_arg, raw_page_arg, query, page, before_query, before_page
            ),
        )

        node = _nav_sync_root_view(
            manager,
            query=query,
            page=page,
            save=False,
        )
        if node is None:
            # Compatibility fallback if the navigation helper cannot load.
            manager.state.custom_pose_ui_query = query
            if page is not None:
                manager.state.custom_pose_ui_scroll_row = page

        _nav_v3_trace(
            "SYNC_APPLIED",
            "query={!r} parsed_page={} state_query={!r} state_page={} {}".format(
                query,
                page,
                getattr(manager.state, "custom_pose_ui_query", ""),
                int(getattr(manager.state, "custom_pose_ui_scroll_row", 0) or 0),
                _nav_v3_node_brief(node),
            ),
        )

        manager.fgeh_pose_manager_debug_log(
            "[ROOT_STATE_V3] build={} query={!r} page={} effective={}".format(
                UI_BUILD_TAG,
                query,
                page,
                int(getattr(manager.state, "custom_pose_ui_scroll_row", 0) or 0),
            )
        )
        return True
    except Exception:
        _nav_v3_trace("SYNC_ERROR", "root_search_query failed", exc=True)
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "[ROOT_STATE_V3] failed", exc=True
            )
        except Exception:
            pass
        return False


PROJECTION_TRACE_ENABLED = True


def _projection_write_trace(event, detail):
    # Independent of the release build's disabled Pose Manager logger.
    return  # R26: release diagnostic/file output disabled.


@sims4.commands.Command('fgeh.projection_trace', command_type=sims4.commands.CommandType.Live)
def _projection_trace_command(event='manual_ping', detail='PROJECTION_LOG2', _connection=None):
    return  # Release: diagnostic capture/output disabled.


@sims4.commands.Command(
    "fgeh.ui_build_ping",
    command_type=sims4.commands.CommandType.Live,
)
def _v89172_command_ui_build_ping(
    as_build="",
    view_kind="",
    active_group="-1",
    _connection=None,
):
    return  # Release: diagnostic capture/output disabled.


@sims4.commands.Command(
    "fgeh.membership_add_many",
    command_type=sims4.commands.CommandType.Live,
)
def _v89173_command_membership_add_many(
    mode="",
    group_name="",
    pack_id="",
    item_values="",
    _connection=None,
):
    """
    Idempotent membership ADD.

    Current V8.9.17.3 UI uses:
      outer -> user_grouped_packs_groups[group_name]

    This is deliberately NOT a toggle:
    clicking "加入动作分组" must never remove a Pack that was already there.
    """
    del _connection

    try:
        import couplepose1 as manager

        mode = _v89_decode_command_text(mode).strip()
        group_name = _v89_decode_command_text(group_name).strip()
        pack_id = _v89_decode_command_text(pack_id).strip()
        values = _v810_decode_favorite_items(item_values)

        if not group_name or not values:
            return False

        added = 0

        if mode == "inner":
            if not pack_id:
                return False
            grouped = getattr(manager.state, "grouped_packs", {}) or {}
            if not isinstance(grouped, dict):
                grouped = {}
            pack_groups = grouped.get(pack_id, {}) or {}
            if not isinstance(pack_groups, dict):
                pack_groups = {}
            members = list(pack_groups.get(group_name, ()) or ())
            for value in values:
                if value not in members:
                    members.append(value)
                    added += 1
            pack_groups[group_name] = members
            grouped[pack_id] = pack_groups
            manager.state.grouped_packs = grouped
        else:
            if mode == "outer":
                attr_name = "user_grouped_packs_groups"
            elif mode == "fav_pack":
                attr_name = "user_fav_groups"
            elif mode == "fav_pose":
                attr_name = "user_fav_pose_groups"
            else:
                return False

            groups = getattr(manager.state, attr_name, {}) or {}
            if not isinstance(groups, dict):
                groups = {}
            members = list(groups.get(group_name, ()) or ())
            for value in values:
                if value not in members:
                    members.append(value)
                    added += 1
            groups[group_name] = members
            setattr(manager.state, attr_name, groups)

        manager.save_favorites()
        manager.fgeh_pose_manager_debug_log(
            "V8.9.17.3 membership-add mode={} group={!r} pack={} requested={} added={}".format(
                mode,
                group_name,
                pack_id,
                len(values),
                added,
            )
        )
        return True

    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.17.3 membership-add failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.ui_trace",
    command_type=sims4.commands.CommandType.Live,
)
def _v89173_command_ui_trace(
    as_build="",
    event_name="",
    detail="",
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        manager.fgeh_pose_manager_debug_log(
            "[UI_TRACE] panel={} as={} event={} detail={}".format(
                UI_BUILD_TAG,
                _v89_decode_command_text(as_build).strip() or "?",
                _v89_decode_command_text(event_name).strip() or "?",
                _v89_decode_command_text(detail).strip(),
            )
        )
        return True
    except Exception:
        return False


@sims4.commands.Command(
    "fgeh.membership_remove_many",
    command_type=sims4.commands.CommandType.Live,
)
def _v8917_command_membership_remove_many(
    mode="",
    group_name="",
    pack_id="",
    item_values="",
    _connection=None,
):
    """
    Unified membership removal foundation.

    Removes relationships only; never deletes Package/Pose resources.

    mode:
      outer    -> user_grouped_packs_groups[group_name]
      fav_pack -> user_fav_groups[group_name]
      fav_pose -> user_fav_pose_groups[group_name]
      inner    -> grouped_packs[pack_id][group_name]

    STEP 1 UI uses outer only. Other modes are prepared for later reuse.
    """
    del _connection

    try:
        import couplepose1 as manager

        mode = _v89_decode_command_text(mode).strip()
        group_name = _v89_decode_command_text(group_name).strip()
        pack_id = _v89_decode_command_text(pack_id).strip()
        values = _v810_decode_favorite_items(item_values)

        if not group_name or not values:
            return False

        removed = 0

        if mode == "inner":
            if not pack_id:
                return False

            grouped = getattr(manager.state, "grouped_packs", {}) or {}
            if not isinstance(grouped, dict):
                grouped = {}

            pack_groups = grouped.get(pack_id, {}) or {}
            if not isinstance(pack_groups, dict):
                pack_groups = {}

            members = list(pack_groups.get(group_name, ()) or ())
            for value in values:
                while value in members:
                    members.remove(value)
                    removed += 1

            pack_groups[group_name] = members
            grouped[pack_id] = pack_groups
            manager.state.grouped_packs = grouped

        else:
            if mode == "outer":
                attr_name = "user_grouped_packs_groups"
            elif mode == "fav_pack":
                attr_name = "user_fav_groups"
            elif mode == "fav_pose":
                attr_name = "user_fav_pose_groups"
            else:
                return False

            groups = getattr(manager.state, attr_name, {}) or {}
            if not isinstance(groups, dict):
                groups = {}

            members = list(groups.get(group_name, ()) or ())
            for value in values:
                while value in members:
                    members.remove(value)
                    removed += 1

            groups[group_name] = members
            setattr(manager.state, attr_name, groups)

        manager.save_favorites()
        manager.fgeh_pose_manager_debug_log(
            "V8.9.17 membership-remove mode={} group={!r} pack={} requested={} removed={}".format(
                mode, group_name, pack_id, len(values), removed
            )
        )
        return True

    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.17 membership-remove failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.group_set_thumbnail",
    command_type=sims4.commands.CommandType.Live,
)
def _v8946_command_group_set_thumbnail(
    mode="",
    group_name="",
    pack_id="",
    _connection=None,
):
    """Persist one child Pack as the cover thumbnail of its current group."""
    del _connection
    try:
        import couplepose1 as manager

        mode = _v89_decode_command_text(mode).strip()
        group_name = _v89_decode_command_text(group_name).strip()
        pack_id = _v89_decode_command_text(pack_id).strip()

        if mode == "outer":
            groups_attr = "user_grouped_packs_groups"
        elif mode == "fav_pack":
            groups_attr = "user_fav_groups"
        else:
            return False

        if not group_name or not pack_id:
            return False

        groups = getattr(manager.state, groups_attr, {}) or {}
        if not isinstance(groups, dict) or group_name not in groups:
            return False

        members = set(str(v) for v in (groups.get(group_name, ()) or ()) if v)
        if pack_id not in members:
            manager.fgeh_pose_manager_debug_log(
                "[GROUP_THUMBNAIL] rejected mode={} group={!r} pack={} reason=not-member".format(
                    mode, group_name, pack_id,
                )
            )
            return False

        custom_names = getattr(manager.state, "custom_names", {}) or {}
        if not isinstance(custom_names, dict):
            custom_names = {}
        custom_names[_v8946_group_thumb_key(mode, group_name)] = pack_id
        manager.state.custom_names = custom_names
        manager.save_favorites()

        manager.fgeh_pose_manager_debug_log(
            "[GROUP_THUMBNAIL] build={} mode={} group={!r} pack={}".format(
                UI_BUILD_TAG, mode, group_name, pack_id,
            )
        )
        return True
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.46 group thumbnail save failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.group_toggle_many",
    command_type=sims4.commands.CommandType.Live,
)
def _v898_command_group_toggle_many(
    mode="",
    group_name="",
    pack_id="",
    item_values="",
    _connection=None,
):
    """
    Toggle many existing group members in one save.

    mode:
      inner    -> grouped_packs[pack_id][group_name]  (Pose names)
      outer    -> user_grouped_packs_groups[group_name] (Pack IDs)
      fav_pack -> user_fav_groups[group_name]         (Pack IDs)
      fav_pose -> user_fav_pose_groups[group_name]    (Pose names)
    """
    del _connection
    try:
        import couplepose1 as manager

        mode = _v89_decode_command_text(mode)
        group_name = _v89_decode_command_text(group_name)
        pack_id = _v89_decode_command_text(pack_id)
        raw_values = _v89_decode_command_text(item_values)
        values = [
            value.strip()
            for value in raw_values.splitlines()
            if value.strip()
        ]

        if not group_name or not values:
            return False

        if mode == "inner":
            if not pack_id:
                try:
                    context = _ACTIVE_PLAY_CONTEXT
                    context_pack = (
                        context.get("pack")
                        if isinstance(context, dict)
                        else None
                    )
                    pack_id = str(
                        manager.get_pack_id(context_pack) or ""
                    )
                except Exception:
                    pack_id = ""
            if not pack_id:
                return False
            grouped = getattr(manager.state, "grouped_packs", {}) or {}
            if not isinstance(grouped, dict):
                grouped = {}
            pack_groups = grouped.get(pack_id, {}) or {}
            if not isinstance(pack_groups, dict):
                pack_groups = {}
            members = list(pack_groups.get(group_name, ()) or ())

            for value in values:
                if value in members:
                    members.remove(value)
                else:
                    members.append(value)

            pack_groups[group_name] = members
            grouped[pack_id] = pack_groups
            manager.state.grouped_packs = grouped

        else:
            if mode == "outer":
                attr_name = "user_grouped_packs_groups"
            elif mode == "fav_pack":
                attr_name = "user_fav_groups"
            elif mode == "fav_pose":
                attr_name = "user_fav_pose_groups"
            else:
                return False

            groups = getattr(manager.state, attr_name, {}) or {}
            if not isinstance(groups, dict):
                groups = {}
            members = list(groups.get(group_name, ()) or ())

            for value in values:
                if value in members:
                    members.remove(value)
                else:
                    members.append(value)

            groups[group_name] = members
            setattr(manager.state, attr_name, groups)

        manager.save_favorites()
        manager.fgeh_pose_manager_debug_log(
            "V8.9.8 group toggle many mode={} group={!r} pack={} count={}".format(
                mode,
                group_name,
                pack_id,
                len(values),
            )
        )
        return True

    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.8 group toggle many failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.link_pack_all",
    command_type=sims4.commands.CommandType.Live,
)
def _h50_command_link_pack_all(pack_id="", _connection=None):
    """Long-right organizer entry: register every real Pose in one pack."""
    del _connection
    try:
        import couplepose1 as manager
        pack_id = _v89_decode_command_text(pack_id).strip()
        if not pack_id:
            return False
        pack = (getattr(manager.state, "all_packs_cache", {}) or {}).get(pack_id)
        if _v7_active_nav(manager) == NAV_LINKED_ACTIONS:
            names = list(_real_pose_names_for_pack(manager, pack_id) or ())
            results = [_r74_remove_linked_action(manager, pack_id, name) for name in names]
            ok = bool(results) and all(result[0] for result in results)
            context = _R76_ROOT_CONTEXT
            if context is not None and context[0] is manager:
                _, owner, callback, dialog = context
                external = any('XML' in result[1] for result in results)
                message = ('已取消本动作包的游戏内联动；仍有游戏外绑定的动作保留。' if external else '已取消本动作包的游戏内联动和手动登记。') if ok else '取消未全部完成，请检查绑定。'
                _r74_linked_message(owner, message)
                import services
                services.ui_dialog_service().dialog_cancel(dialog.dialog_id)
                _schedule_root_reopen(manager, owner, callback, 'cancel-linked-pack')
            return ok
        ok, pose_count = _register_managed_linked_pack(
            manager, pack_id, pack=pack, source="pack-organizer"
        )
        _h49_trace(
            "PACK_ORGANIZER_COMMAND pack={!r} ok={} pose_count={}".format(
                pack_id, ok, pose_count
            )
        )
        return bool(ok)
    except Exception:
        _h49_trace("PACK_ORGANIZER_COMMAND_EXCEPTION", exc=True)
        return False


@sims4.commands.Command(
    "fgeh.batch_favorite",
    command_type=sims4.commands.CommandType.Live,
)
def _v897_command_batch_favorite(
    scope="",
    item_values="",
    enabled=1,
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager

        scope = _v89_decode_command_text(scope)
        values = _v810_decode_favorite_items(item_values)
        enabled = bool(int(enabled or 0))

        if not values:
            return False

        # In the 收藏动作 root view, every card is a *container of favorite
        # poses*, not a favorite pack.  The current GFX still emits
        # scope=pack for that card's star because the visual cell is shared
        # with normal pack cards.  Reinterpret that one case here.
        if (
            scope == "pack"
            and _v7_active_nav(manager) == NAV_FAVORITE_POSES
            and not bool(getattr(manager.state, "custom_pose_ui_favorite_only", False))
        ):
            wanted_pack_ids = set(str(v) for v in values if v)
            pose_values = []
            cache = getattr(manager.state, "all_poses_cache", {}) or {}
            for pose_name in list(getattr(manager.state, "favorite_poses", ()) or ()): 
                info = cache.get(pose_name)
                if not isinstance(info, dict):
                    continue
                pack = info.get("pack_ref")
                if pack is None:
                    continue
                try:
                    pose_pack_id = str(manager.get_pack_id(pack) or "")
                except Exception:
                    pose_pack_id = str(getattr(pack, "__name__", "") or "")
                if pose_pack_id in wanted_pack_ids:
                    pose_values.append(str(pose_name))

            manager.fgeh_pose_manager_debug_log(
                "[FAV_POSE_FIX_V4] reinterpret root pack favorite as pose favorite "
                "enabled={} packs={} poses={}".format(
                    enabled, len(wanted_pack_ids), len(pose_values)
                )
            )
            scope = "pose"
            values = pose_values

        if scope == "pose":
            target = manager.state.favorite_poses
        elif scope == "pack":
            target = manager.state.favorite_packs
        elif scope == "creator":
            target = manager.state.favorite_creators
        else:
            manager.fgeh_pose_manager_debug_log(
                "V8.9.9 batch favorite ignored unsupported scope={!r}".format(
                    scope
                )
            )
            return False

        changed = 0
        for value in values:
            if enabled:
                if value not in target:
                    target.append(value)
                    changed += 1
            elif value in target:
                target.remove(value)
                changed += 1

        if changed:
            manager.save_favorites()

        manager.fgeh_pose_manager_debug_log(
            "V8.9.10 batch favorite scope={} enabled={} requested={} changed={} total_now={} first={!r} last={!r}".format(
                scope,
                enabled,
                len(values),
                changed,
                len(target),
                values[0] if values else "",
                values[-1] if values else "",
            )
        )
        return True
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.10 batch favorite failed",
                exc=True,
            )
        except Exception:
            pass
        return False



def _v8963_saved_binding_is_local(binding):
    """Recognize rows owned by the in-game binding store, never XML metadata."""
    if not isinstance(binding, dict):
        return False
    if binding.get("created_in_game") is True:
        return True
    user_group = str(binding.get("user_group") or "").strip().lower()
    if user_group in ("in_game_binding", "ingame_binding", "local_binding"):
        return True
    origin = str(
        binding.get("source_origin")
        or binding.get("binding_origin")
        or binding.get("origin")
        or ""
    ).strip().lower()
    if origin in ("local", "in_game", "ingame", "game_bind", "runtime"):
        return True

    # fgeh_linked_object_bindings.json is itself the project-owned in-game
    # store.  Old schemas may predate created_in_game/user_group markers, so a
    # structurally valid row from this module is still local.  We intentionally
    # do NOT inspect or mutate snippet/XML/package metadata here.
    try:
        definition_id = int(binding.get("definition_id") or 0)
    except Exception:
        definition_id = 0
    return bool(
        str(binding.get("pack_id") or "").strip()
        and str(binding.get("pose_name") or "").strip()
        and definition_id
    )


def _v8963_remove_local_object_binding_rows(pack_id, pose_name, definition_ids):
    """Delete matching rows only from the dedicated in-game binding store.

    Prefer a future public API when the runtime module provides one.  Current
    shipped/legacy modules expose _load_data/_save_data, so the fallback edits
    that exact store atomically and cleans orphan local object_assets.
    """
    import fgeh_linked_object_bindings as bindings

    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    ids = set()
    for value in definition_ids or ():
        try:
            parsed = int(value or 0)
        except Exception:
            parsed = 0
        if parsed:
            ids.add(parsed)
    if not pack_id or not pose_name or not ids:
        return 0

    # Forward-compatible public APIs, if a newer binding module already ships
    # one.  Signatures are attempted conservatively and fall back to the proven
    # local JSON store when unavailable.
    for api_name in (
        "remove_saved_object_bindings",
        "remove_object_bindings",
        "delete_saved_object_bindings",
    ):
        api = getattr(bindings, api_name, None)
        if not callable(api):
            continue
        try:
            result = api(pack_id, pose_name, list(ids))
            if isinstance(result, bool):
                return len(ids) if result else 0
            return int(result or 0)
        except TypeError:
            pass
        except Exception:
            break

    load_data = getattr(bindings, "_load_data", None)
    save_data = getattr(bindings, "_save_data", None)
    if not callable(load_data) or not callable(save_data):
        return 0

    data = load_data()
    if not isinstance(data, dict):
        return 0
    raw_bindings = data.get("object_bindings", []) or []
    kept = []
    removed = 0
    for row in raw_bindings:
        if not isinstance(row, dict):
            kept.append(row)
            continue
        try:
            definition_id = int(row.get("definition_id") or 0)
        except Exception:
            definition_id = 0
        matches = (
            str(row.get("pack_id") or "").strip() == pack_id
            and str(row.get("pose_name") or "").strip() == pose_name
            and definition_id in ids
            and _v8963_saved_binding_is_local(row)
        )
        if matches:
            removed += 1
        else:
            kept.append(row)

    if not removed:
        return 0

    data["object_bindings"] = kept

    # Remove a local asset row only when no remaining local binding in this
    # Pack references the same definition.  This is hygiene; the requirement
    # registry itself is driven by object_bindings.
    still_used = set()
    for row in kept:
        if not isinstance(row, dict):
            continue
        if str(row.get("pack_id") or "").strip() != pack_id:
            continue
        try:
            definition_id = int(row.get("definition_id") or 0)
        except Exception:
            definition_id = 0
        if definition_id and _v8963_saved_binding_is_local(row):
            still_used.add(definition_id)

    assets = []
    for asset in data.get("object_assets", []) or []:
        if not isinstance(asset, dict):
            assets.append(asset)
            continue
        try:
            asset_id = int(asset.get("definition_id") or 0)
        except Exception:
            asset_id = 0
        if (
            str(asset.get("pack_id") or "").strip() == pack_id
            and asset_id in ids
            and asset_id not in still_used
            and (
                asset.get("created_in_game") is True
                or str(asset.get("user_group") or "").strip().lower()
                   in ("in_game_binding", "ingame_binding", "local_binding")
            )
        ):
            continue
        assets.append(asset)
    data["object_assets"] = assets

    return removed if save_data(data) else 0


def _v8963_prune_removed_object_choice_state(manager, pack_id, pose_name):
    """Prune only IDs that vanished from BOTH local and external sources."""
    try:
        remaining_options = list(
            manager.get_linked_object_variant_options(pack_id, pose_name) or ()
        )
    except Exception:
        remaining_options = []
    remaining_ids = set()
    for option in remaining_options:
        try:
            value = _v89_option_value(option, "definition_id", "object_definition_id")
            value = int(value or 0)
        except Exception:
            value = 0
        if value:
            remaining_ids.add(value)

    try:
        key = manager.linked_object_choice_key(pack_id, pose_name)
    except Exception:
        key = str(pack_id or "") + "::" + str(pose_name or "")

    changed = False
    enabled = getattr(manager.state, "linked_object_enabled_choices", {}) or {}
    if isinstance(enabled, dict) and key in enabled:
        cleaned = []
        for value in enabled.get(key, ()) or ():
            try:
                value = int(value or 0)
            except Exception:
                value = 0
            if value and value in remaining_ids and value not in cleaned:
                cleaned.append(value)
        if cleaned != list(enabled.get(key, ()) or ()):
            enabled[key] = cleaned
            manager.state.linked_object_enabled_choices = enabled
            changed = True

    legacy = getattr(manager.state, "linked_object_variant_choices", {}) or {}
    if isinstance(legacy, dict) and key in legacy:
        try:
            legacy_id = int(legacy.get(key) or 0)
        except Exception:
            legacy_id = 0
        if legacy_id and legacy_id not in remaining_ids:
            legacy.pop(key, None)
            manager.state.linked_object_variant_choices = legacy
            changed = True

    if changed:
        manager.save_favorites()
    return remaining_ids




@sims4.commands.Command(
    "fgeh.linked_remove_local_cas",
    command_type=sims4.commands.CommandType.Live,
)
def _h61_command_linked_remove_local_cas(
    pack_id="",
    pose_name="",
    cas_part_ids="",
    _connection=None,
):
    """Remove only game-created CAS bindings, Pack-scoped, in one store write."""
    del _connection
    try:
        import couplepose1 as manager
        pack_id = _v89_decode_command_text(pack_id).strip()
        pose_name = _v89_decode_command_text(pose_name).strip()
        raw_ids = _v89_decode_command_text(cas_part_ids).strip()
        ids = []
        for token in raw_ids.replace(";", ",").split(","):
            try:
                value = int(token.strip() or 0)
            except Exception:
                value = 0
            if value and value not in ids:
                ids.append(value)

        # AccessoryLibraryView uses a synthetic UI identity. If this command is
        # ever invoked there, resolve the real Pack context separately.
        if pack_id == _CASLIB_VIRTUAL_PACK_ID:
            real_pack, real_pose = _caslib_binding_context(manager)
            if real_pack:
                pack_id = real_pack
                pose_name = real_pose or pose_name

        if not pack_id or not pose_name or not ids:
            return False
        pose_names = list(_real_pose_names_for_pack(manager, pack_id) or ())
        if pose_name and pose_name not in pose_names:
            pose_names.append(pose_name)
        from fgeh_linked_cas_bindings import remove_cas_bindings_for_poses
        removed = int(remove_cas_bindings_for_poses(pack_id, pose_names, ids) or 0)

        # Remove stale enabled-choice ids for the same Pack rows. Persist once.
        state = manager.state
        choices = getattr(state, "linked_cas_enabled_choices", {}) or {}
        if not isinstance(choices, dict):
            choices = {}
        changed_state = False
        remove_ids = set(ids)
        for target_pose in pose_names:
            key = manager.linked_object_choice_key(pack_id, target_pose)
            if key not in choices:
                continue
            old = list(choices.get(key, ()) or ())
            new = [int(value) for value in old if int(value or 0) not in remove_ids]
            if new != old:
                choices[key] = new
                changed_state = True
        if changed_state:
            state.linked_cas_enabled_choices = choices
            manager.save_favorites()
        try:
            from fgeh_pose_requirement_registry import clear_requirement_cache
            clear_requirement_cache()
        except Exception:
            pass
        reenter_armed = False
        if removed > 0:
            reenter_armed = _h70w7_arm_linked_reenter(manager, pack_id, pose_name)
        manager.fgeh_pose_manager_debug_log(
            "[H70W7D2_PACK_CAS_REMOVE] build={} pack={} anchor={} poses={} ids={} removed={} reenter_armed={}".format(
                UI_BUILD_TAG, pack_id, pose_name, len(pose_names), ids, removed, reenter_armed
            )
        )
        return removed > 0
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log("[H61_PACK_CAS_REMOVE] FAILED", exc=True)
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.linked_remove_local_object",
    command_type=sims4.commands.CommandType.Live,
)
def _v8963_command_linked_remove_local_object(
    pack_id="",
    pose_name="",
    definition_ids="",
    _connection=None,
):
    """Remove ONLY game-created object bindings for one Pose.

    External XML/snippet/package requirements are never written by this code.
    The linked requirement registry is rebuilt afterwards, so a Pose remains in
    the linked library whenever any external or other local requirement remains.
    """
    del _connection
    try:
        import couplepose1 as manager

        pack_id = _v89_decode_command_text(pack_id).strip()
        pose_name = _v89_decode_command_text(pose_name).strip()
        raw_ids = _v89_decode_command_text(definition_ids).strip()
        ids = []
        for token in raw_ids.replace(";", ",").split(","):
            try:
                value = int(token.strip() or 0)
            except Exception:
                value = 0
            if value and value not in ids:
                ids.append(value)
        if not pack_id or not pose_name or not ids:
            return False

        # H60: local object bindings use the same Pack-scope semantics as CAS.
        # The anchor Pose identifies the Pack/editor row only; removal fans out
        # through the existing per-Pose JSON schema with ONE store write.
        pose_names = list(_real_pose_names_for_pack(manager, pack_id) or ())
        if pose_name and pose_name not in pose_names:
            pose_names.append(pose_name)
        try:
            from fgeh_linked_object_bindings import remove_object_bindings_for_poses
            removed = int(remove_object_bindings_for_poses(pack_id, pose_names, ids) or 0)
        except Exception:
            # Compatibility fallback for an older object-binding module.
            removed = 0
            for target_pose_name in pose_names:
                removed += int(_v8963_remove_local_object_binding_rows(
                    pack_id, target_pose_name, ids
                ) or 0)

        try:
            from fgeh_pose_requirement_registry import clear_requirement_cache
            clear_requirement_cache()
        except Exception:
            pass

        remaining_by_pose = {}
        for target_pose_name in pose_names:
            remaining_by_pose[target_pose_name] = sorted(
                _v8963_prune_removed_object_choice_state(
                    manager, pack_id, target_pose_name
                )
            )

        reenter_armed = False
        if removed > 0:
            reenter_armed = _h70w7_arm_linked_reenter(manager, pack_id, pose_name)
        manager.fgeh_pose_manager_debug_log(
            "[H70W7D2_PACK_OBJECT_REMOVE] build={} pack={} anchor={} poses={} requested={} removed={} remaining={} reenter_armed={}".format(
                UI_BUILD_TAG,
                pack_id,
                pose_name,
                len(pose_names),
                ids,
                removed,
                remaining_by_pose,
                reenter_armed,
            )
        )
        return removed > 0
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "[LINKED_LOCAL_REMOVE] build={} FAILED".format(UI_BUILD_TAG),
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.linked_toggle_item",
    command_type=sims4.commands.CommandType.Live,
)
def _v89_command_linked_toggle_item(
    pack_id="",
    pose_name="",
    link_type="",
    item_id=0,
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        pack_id = _v89_decode_command_text(pack_id)
        pose_name = _v89_decode_command_text(pose_name)
        link_type = str(link_type or "").strip().lower()
        item_id = int(item_id or 0)

        # H34 standalone library: the existing GFX product/swatches UI sends
        # the same command as linked settings.  Route it to try-on or to the
        # game-owned local binding store depending on context.
        if link_type == "cas" and pack_id == _CASLIB_VIRTUAL_PACK_ID:
            # H58: the reusable AccessoryLibraryView always speaks with its
            # synthetic UI identity.  In binding mode, route the click through
            # the separately stored real target context; otherwise it is normal
            # browse/try-on.  This keeps View identity and business identity
            # fully decoupled.
            bind_pack_id, bind_pose_name = _caslib_binding_context(manager)
            if bind_pack_id and bind_pose_name:
                data = _caslib_load()
                item, _variant = _caslib_find_item_by_variant(data, item_id)
                if item is None:
                    return False
                return _caslib_toggle_binding(
                    manager, str(item.get("base_id") or ""), item_id
                )
            target = _caslib_target_from_state(manager)
            return bool(target is not None and _caslib_apply_variant(manager, target, item_id))

        bind_pack_id, bind_pose_name = _caslib_binding_context(manager)
        if (
            link_type == "cas"
            and bind_pack_id
            and pack_id == bind_pack_id
            and pose_name == bind_pose_name
        ):
            data = _caslib_load()
            item, _variant = _caslib_find_item_by_variant(data, item_id)
            if item is None:
                return False
            return _caslib_toggle_binding(
                manager, str(item.get("base_id") or ""), item_id
            )

        if link_type == "cas":
            if _v7_active_nav(manager) == NAV_ACCESSORY_LIBRARY:
                if _caslib_source(manager) == _CASLIB_SOURCE_EXTERNAL:
                    external_product = _caslib_external_product_for_variant(manager, item_id)
                    if external_product is not None:
                        if _caslib_binding_mode(manager):
                            return _caslib_toggle_external_binding(manager, item_id)
                        if pack_id == _CAS_LIBRARY_LINKED_PACK_ID:
                            target = _caslib_target_from_state(manager) or _CAS_LIBRARY_TARGET
                            result = _caslib_apply_variant(manager, target, item_id)
                            try:
                                manager.fgeh_pose_manager_debug_log(
                                    "[CASLIB_EXTERNAL_CLICK] browse item={} result={}".format(
                                        item_id, result
                                    )
                                )
                            except Exception:
                                pass
                            return result
                else:
                    data = _caslib_load()
                    item, variant = _caslib_find_variant_any(data, item_id)
                    if item is not None and variant is not None:
                        if _caslib_binding_mode(manager):
                            return _caslib_toggle_binding(
                                manager,
                                str(item.get("base_id") or ""),
                                item_id,
                            )
                        if pack_id == _CAS_LIBRARY_LINKED_PACK_ID:
                            target = _caslib_target_from_state(manager) or _CAS_LIBRARY_TARGET
                            result = _caslib_apply_variant(manager, target, item_id)
                            try:
                                manager.fgeh_pose_manager_debug_log(
                                    "[H36_CAS_LIBRARY_CLICK] browse item={} result={}".format(
                                        item_id, result
                                    )
                                )
                            except Exception:
                                pass
                            return result

            h63_collection_result = _h63_switch_collection_variant_from_linked_editor(
                manager, pack_id, pose_name, item_id
            )
            if h63_collection_result is not None:
                return bool(h63_collection_result)

            options = _v8942_release_cas_options(
                manager, pack_id, pose_name
            )
            available_ids = [
                int(_v89_option_value(option, "cas_part_id") or 0)
                for option in options
                if int(_v89_option_value(option, "cas_part_id") or 0)
            ]

            # V8.9.26: one product may expose many concrete CASPart swatches.
            # Those sibling swatches are mutually exclusive. Different
            # products remain independently selectable.
            clicked_key = None
            sibling_ids = set()
            for option in options:
                try:
                    candidate_id = int(
                        _v89_option_value(option, "cas_part_id") or 0
                    )
                except Exception:
                    candidate_id = 0
                if not candidate_id:
                    continue
                identity = _v8924_cas_product_identity(option, candidate_id)
                if candidate_id == item_id:
                    clicked_key = identity.get("product_key")
                    break

            if clicked_key:
                for option in options:
                    try:
                        candidate_id = int(
                            _v89_option_value(option, "cas_part_id") or 0
                        )
                    except Exception:
                        candidate_id = 0
                    if not candidate_id:
                        continue
                    identity = _v8924_cas_product_identity(option, candidate_id)
                    if identity.get("product_key") == clicked_key:
                        sibling_ids.add(candidate_id)

            try:
                current = set(
                    manager.get_enabled_linked_cas_part_ids(
                        pack_id, pose_name, available_ids
                    ) or ()
                )
            except Exception:
                current = set()

            was_enabled = item_id in current
            if sibling_ids:
                current.difference_update(sibling_ids)
            else:
                current.discard(item_id)

            if not was_enabled:
                current.add(item_id)
                try:
                    manager.set_linked_cas_apply_enabled(
                        pack_id, pose_name, True
                    )
                except Exception:
                    pass

            manager.set_enabled_linked_cas_part_ids(
                pack_id,
                pose_name,
                [value for value in available_ids if value in current],
            )
            manager.fgeh_pose_manager_debug_log(
                "[CAS_PRODUCT_SELECT] build={} pack={} pose={} item={} "
                "was_enabled={} siblings={} selected={}".format(
                    UI_BUILD_TAG,
                    pack_id,
                    pose_name,
                    item_id,
                    was_enabled,
                    sorted(sibling_ids),
                    [value for value in available_ids if value in current],
                )
            )
        elif link_type == "object":
            options = list(
                manager.get_linked_object_variant_options(
                    pack_id, pose_name
                ) or ()
            )
            available_ids = [
                int(
                    _v89_option_value(
                        option,
                        "definition_id",
                        "object_definition_id",
                    ) or 0
                )
                for option in options
                if int(
                    _v89_option_value(
                        option,
                        "definition_id",
                        "object_definition_id",
                    ) or 0
                )
            ]

            clicked_key = None
            sibling_ids = set()
            for option in options:
                try:
                    candidate_id = int(_v89_option_value(
                        option, "definition_id", "object_definition_id"
                    ) or 0)
                except Exception:
                    candidate_id = 0
                if not candidate_id:
                    continue
                identity = _v8934_object_product_identity(
                    option, candidate_id
                )
                if candidate_id == item_id:
                    clicked_key = identity.get("product_key")
                    break

            if clicked_key:
                for option in options:
                    try:
                        candidate_id = int(_v89_option_value(
                            option, "definition_id", "object_definition_id"
                        ) or 0)
                    except Exception:
                        candidate_id = 0
                    if not candidate_id:
                        continue
                    identity = _v8934_object_product_identity(
                        option, candidate_id
                    )
                    if identity.get("product_key") == clicked_key:
                        sibling_ids.add(candidate_id)

            try:
                current = set(
                    manager.get_enabled_linked_object_definition_ids(
                        pack_id, pose_name, available_ids
                    ) or ()
                )
            except Exception:
                current = set()

            was_enabled = item_id in current
            if sibling_ids:
                current.difference_update(sibling_ids)
            else:
                current.discard(item_id)
            if not was_enabled:
                current.add(item_id)

            key = manager.linked_object_choice_key(pack_id, pose_name)
            choices = getattr(
                manager.state, "linked_object_enabled_choices", {}
            ) or {}
            if not isinstance(choices, dict):
                choices = {}
            choices[key] = [
                value for value in available_ids if value in current
            ]
            manager.state.linked_object_enabled_choices = choices

            if not was_enabled:
                disabled = getattr(
                    manager.state, "linked_object_spawn_disabled", {}
                ) or {}
                if not isinstance(disabled, dict):
                    disabled = {}
                disabled.pop(key, None)
                manager.state.linked_object_spawn_disabled = disabled

            try:
                variants = getattr(
                    manager.state, "linked_object_variant_choices", {}
                ) or {}
                if isinstance(variants, dict):
                    variants.pop(key, None)
                    manager.state.linked_object_variant_choices = variants
            except Exception:
                pass

            manager.save_favorites()
            manager.fgeh_pose_manager_debug_log(
                "[OBJECT_PRODUCT_SELECT] build={} pack={} pose={} item={} "
                "was_enabled={} siblings={} selected={}".format(
                    UI_BUILD_TAG,
                    pack_id,
                    pose_name,
                    item_id,
                    was_enabled,
                    sorted(sibling_ids),
                    [value for value in available_ids if value in current],
                )
            )
        else:
            return False

        manager.fgeh_pose_manager_debug_log(
            "V8.9 linked item toggled type={} pack={} pose={} item={}".format(
                link_type, pack_id, pose_name, item_id
            )
        )
        return True
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9 linked item toggle failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.linked_toggle_auto",
    command_type=sims4.commands.CommandType.Live,
)
def _v89_command_linked_toggle_auto(
    pack_id="",
    pose_name="",
    link_type="",
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        pack_id = _v89_decode_command_text(pack_id)
        pose_name = _v89_decode_command_text(pose_name)
        link_type = str(link_type or "").strip().lower()

        if pack_id == _CASLIB_VIRTUAL_PACK_ID:
            return True

        if link_type == "cas":
            current = manager.is_linked_cas_apply_enabled(pack_id, pose_name)
            manager.set_linked_cas_apply_enabled(
                pack_id, pose_name, not current
            )
        elif link_type == "object":
            current = manager.is_linked_object_spawn_enabled(pack_id, pose_name)
            manager.set_linked_object_spawn_enabled(
                pack_id, pose_name, not current
            )
        else:
            return False
        return True
    except Exception:
        return False


def _v8929_choose_one_cas_swatch_per_product(options, current_selected=None):
    """Return one CASPart id per grouped product, preserving a current choice."""
    current = set(int(value or 0) for value in (current_selected or ()) if int(value or 0))
    groups = []
    by_key = {}

    for option in options or ():
        try:
            item_id = int(_v89_option_value(option, "cas_part_id") or 0)
        except Exception:
            item_id = 0
        if not item_id:
            continue
        identity = _v8924_cas_product_identity(option, item_id)
        key = identity.get("product_key") or "cas|{}".format(item_id)
        group = by_key.get(key)
        if group is None:
            group = []
            by_key[key] = group
            groups.append(group)
        if item_id not in group:
            group.append(item_id)

    result = []
    for group in groups:
        chosen = next((value for value in group if value in current), None)
        if chosen is None and group:
            chosen = group[0]
        if chosen:
            result.append(chosen)
    return result


def _v8929_all_pose_names_for_pack(manager, pack_id):
    result = []
    seen = set()

    def add(value):
        value = str(value or "").strip()
        if value and value not in seen:
            seen.add(value)
            result.append(value)

    try:
        for value in _v89_linked_pose_names_for_pack(
            manager, pack_id, grouped_only=False
        ) or ():
            add(value)
    except Exception:
        pass

    try:
        pack = (getattr(manager.state, "all_packs_cache", {}) or {}).get(pack_id)
        for pose_item in getattr(pack, "pose_list", ()) or ():
            add(getattr(pose_item, "pose_name", ""))
    except Exception:
        pass

    return result


def _v8929_write_linked_snapshot_state(
    manager, pack_id, pose_names, cas_auto, object_auto, cas_ids, object_ids
):
    """Write a linked snapshot for one/many poses and persist exactly once."""
    state = manager.state

    cas_choices = getattr(state, "linked_cas_enabled_choices", {}) or {}
    cas_disabled = getattr(state, "linked_cas_apply_disabled", {}) or {}
    object_choices = getattr(state, "linked_object_enabled_choices", {}) or {}
    object_disabled = getattr(state, "linked_object_spawn_disabled", {}) or {}
    object_variants = getattr(state, "linked_object_variant_choices", {}) or {}

    if not isinstance(cas_choices, dict):
        cas_choices = {}
    if not isinstance(cas_disabled, dict):
        cas_disabled = {}
    if not isinstance(object_choices, dict):
        object_choices = {}
    if not isinstance(object_disabled, dict):
        object_disabled = {}
    if not isinstance(object_variants, dict):
        object_variants = {}

    cas_ids = [int(value) for value in cas_ids or () if int(value or 0)]
    object_ids = [int(value) for value in object_ids or () if int(value or 0)]

    changed = 0
    seen = set()
    for pose_name in pose_names or ():
        pose_name = str(pose_name or "").strip()
        if not pose_name or pose_name in seen:
            continue
        seen.add(pose_name)
        key = manager.linked_object_choice_key(pack_id, pose_name)

        # Explicit lists are stored even when empty; absence has legacy/default
        # semantics, while [] means the user deliberately selected none.
        cas_choices[key] = list(cas_ids)
        object_choices[key] = list(object_ids)
        object_variants.pop(key, None)

        if cas_auto:
            cas_disabled.pop(key, None)
        else:
            cas_disabled[key] = True

        if object_auto:
            object_disabled.pop(key, None)
        else:
            object_disabled[key] = True

        changed += 1

    state.linked_cas_enabled_choices = cas_choices
    state.linked_cas_apply_disabled = cas_disabled
    state.linked_object_enabled_choices = object_choices
    state.linked_object_spawn_disabled = object_disabled
    state.linked_object_variant_choices = object_variants

    if changed:
        manager.save_favorites()
    return changed


@sims4.commands.Command(
    "fgeh.linked_set_all",
    command_type=sims4.commands.CommandType.Live,
)
def _v89_command_linked_set_all(
    pack_id="",
    pose_name="",
    enabled=1,
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        pack_id = _v89_decode_command_text(pack_id)
        pose_name = _v89_decode_command_text(pose_name)
        enabled = bool(int(enabled or 0))
        if pack_id == _CASLIB_VIRTUAL_PACK_ID:
            return True

        cas_options = _v8942_release_cas_options(
            manager, pack_id, pose_name
        )
        all_cas_ids = [
            int(_v89_option_value(option, "cas_part_id") or 0)
            for option in cas_options
            if int(_v89_option_value(option, "cas_part_id") or 0)
        ]
        try:
            current_cas = set(
                manager.get_enabled_linked_cas_part_ids(
                    pack_id, pose_name, all_cas_ids
                ) or ()
            )
        except Exception:
            current_cas = set()

        if enabled:
            cas_ids = _v8929_choose_one_cas_swatch_per_product(
                cas_options, current_cas
            )
            cas_auto = True
        else:
            cas_ids = []
            try:
                cas_auto = bool(
                    manager.is_linked_cas_apply_enabled(pack_id, pose_name)
                )
            except Exception:
                cas_auto = True

        object_options = list(
            manager.get_linked_object_variant_options(pack_id, pose_name) or ()
        )
        all_object_ids = [
            int(
                _v89_option_value(
                    option, "definition_id", "object_definition_id"
                ) or 0
            )
            for option in object_options
            if int(
                _v89_option_value(
                    option, "definition_id", "object_definition_id"
                ) or 0
            )
        ]
        if enabled:
            try:
                current_object = set(
                    manager.get_enabled_linked_object_definition_ids(
                        pack_id, pose_name, all_object_ids
                    ) or ()
                )
            except Exception:
                current_object = set()
            object_ids = _v8934_choose_one_object_variant_per_product(
                object_options, current_object
            )
            object_auto = True
        else:
            object_ids = []
            try:
                object_auto = bool(
                    manager.is_linked_object_spawn_enabled(pack_id, pose_name)
                )
            except Exception:
                object_auto = True

        _v8929_write_linked_snapshot_state(
            manager,
            pack_id,
            [pose_name],
            cas_auto,
            object_auto,
            cas_ids,
            object_ids,
        )
        manager.fgeh_pose_manager_debug_log(
            "[LINKED_SET_ALL_FAST] build={} pack={} pose={} enabled={} "
            "cas_products={} cas_selected={} objects={}".format(
                UI_BUILD_TAG, pack_id, pose_name, enabled,
                len(_v8929_choose_one_cas_swatch_per_product(cas_options, current_cas)),
                len(cas_ids), len(object_ids),
            )
        )
        return True
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "[LINKED_SET_ALL_FAST] build={} FAILED".format(UI_BUILD_TAG),
                exc=True,
            )
        except Exception:
            pass
        return False



def _v892_apply_linked_selection_to_poses(
    manager,
    pack_id,
    source_pose_name,
    target_pose_names,
):
    """
    Copy the source Pose's existing linked-selection state only to selected
    target Poses.

    This intentionally mirrors the semantics of the old
    apply_linked_*_selection_to_pack helpers, but it does NOT create a new
    persistence schema and does NOT touch unselected Poses.
    """
    pack_id = str(pack_id or "")
    source_pose_name = str(source_pose_name or "")
    if not pack_id or not source_pose_name:
        return 0

    allowed = set(
        _v89_linked_pose_names_for_pack(
            manager,
            pack_id,
            grouped_only=False,
        )
        or ()
    )

    try:
        pack = (
            getattr(manager.state, "all_packs_cache", {}) or {}
        ).get(pack_id)
        for pose_item in getattr(pack, "pose_list", ()) or ():
            pose_name = str(
                getattr(pose_item, "pose_name", "") or ""
            )
            if pose_name:
                allowed.add(pose_name)
    except Exception:
        pass

    from fgeh_linked_scope_n2 import scope
    group_members = scope(manager, _ACTIVE_PLAY_CONTEXT, pack_id, source_pose_name)
    if group_members is not None:
        target_pose_names = [v for v in target_pose_names or () if str(v).strip() in group_members]
    targets = []
    seen = set()
    for pose_name in target_pose_names or ():
        pose_name = str(pose_name or "").strip()
        if not pose_name or pose_name in seen:
            continue
        if allowed and pose_name not in allowed:
            continue
        seen.add(pose_name)
        targets.append(pose_name)

    if not targets:
        return 0

    state = manager.state

    # ----- CAS -----
    source_key = manager.linked_object_choice_key(
        pack_id,
        source_pose_name,
    )
    source_cas_enabled = manager.is_linked_cas_apply_enabled(
        pack_id,
        source_pose_name,
    )
    cas_choices = getattr(
        state,
        "linked_cas_enabled_choices",
        {},
    ) or {}
    cas_disabled = getattr(
        state,
        "linked_cas_apply_disabled",
        {},
    ) or {}

    if not isinstance(cas_choices, dict):
        cas_choices = {}
    if not isinstance(cas_disabled, dict):
        cas_disabled = {}

    source_has_cas_list = source_key in cas_choices
    source_cas_list = list(
        cas_choices.get(source_key, ()) or ()
    )

    # Release builds deliberately ignore old experimental full-outfit ids when
    # copying a Pose.  Keep the saved source data intact; only the copy result
    # is filtered to CAS products that are currently exposed by the release UI.
    try:
        release_cas_ids = {
            int(_v89_option_value(option, "cas_part_id") or 0)
            for option in _v8942_release_cas_options(
                manager, pack_id, source_pose_name
            )
            if int(_v89_option_value(option, "cas_part_id") or 0)
        }
        source_cas_list = [
            int(value) for value in source_cas_list
            if int(value or 0) in release_cas_ids
        ]
    except Exception:
        pass

    # ----- OBJECT -----
    source_object_enabled = manager.is_linked_object_spawn_enabled(
        pack_id,
        source_pose_name,
    )
    object_choices = getattr(
        state,
        "linked_object_enabled_choices",
        {},
    ) or {}
    object_disabled = getattr(
        state,
        "linked_object_spawn_disabled",
        {},
    ) or {}
    object_variants = getattr(
        state,
        "linked_object_variant_choices",
        {},
    ) or {}

    if not isinstance(object_choices, dict):
        object_choices = {}
    if not isinstance(object_disabled, dict):
        object_disabled = {}
    if not isinstance(object_variants, dict):
        object_variants = {}

    source_has_object_list = source_key in object_choices
    source_object_list = list(
        object_choices.get(source_key, ()) or ()
    )
    try:
        source_legacy_definition_id = int(
            manager.get_selected_linked_object_definition_id(
                pack_id,
                source_pose_name,
            )
            or 0
        )
    except Exception:
        source_legacy_definition_id = 0

    changed = 0

    for pose_name in targets:
        key = manager.linked_object_choice_key(
            pack_id,
            pose_name,
        )

        # CAS auto + selected list.
        if source_cas_enabled:
            cas_disabled.pop(key, None)
        else:
            cas_disabled[key] = True

        if source_has_cas_list:
            cas_choices[key] = list(source_cas_list)
        else:
            cas_choices.pop(key, None)

        # Object auto + selected list / legacy single choice.
        if source_object_enabled:
            object_disabled.pop(key, None)
        else:
            object_disabled[key] = True

        if source_has_object_list:
            object_choices[key] = list(source_object_list)
            object_variants.pop(key, None)
        elif source_legacy_definition_id:
            object_variants[key] = source_legacy_definition_id
            object_choices.pop(key, None)
        else:
            object_choices.pop(key, None)
            object_variants.pop(key, None)

        changed += 1

    state.linked_cas_enabled_choices = cas_choices
    state.linked_cas_apply_disabled = cas_disabled
    state.linked_object_enabled_choices = object_choices
    state.linked_object_spawn_disabled = object_disabled
    state.linked_object_variant_choices = object_variants

    if changed:
        manager.save_favorites()

    return changed



@sims4.commands.Command(
    "fgeh.linked_apply_selected",
    command_type=sims4.commands.CommandType.Live,
)
def _v892_command_linked_apply_selected(
    pack_id="",
    source_pose_name="",
    target_pose_names="",
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager

        pack_id = _v89_decode_command_text(pack_id)
        source_pose_name = _v89_decode_command_text(
            source_pose_name
        )
        raw_targets = _v89_decode_command_text(
            target_pose_names
        )
        if pack_id == _CASLIB_VIRTUAL_PACK_ID:
            return True

        targets = [
            value.strip()
            for value in raw_targets.splitlines()
            if value.strip()
        ]

        changed = _v892_apply_linked_selection_to_poses(
            manager,
            pack_id,
            source_pose_name,
            targets,
        )

        manager.fgeh_pose_manager_debug_log(
            "V8.9.2 linked multi apply pack={} source={} targets={} changed={}".format(
                pack_id,
                source_pose_name,
                len(targets),
                changed,
            )
        )
        return True
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.2 linked multi apply failed",
                exc=True,
            )
        except Exception:
            pass
        return False



def _v893_parse_id_list(raw_value):
    raw_value = _v89_decode_command_text(raw_value)
    result = []
    seen = set()
    for piece in str(raw_value or "").split(","):
        piece = piece.strip()
        if not piece:
            continue
        try:
            value = int(piece)
        except Exception:
            continue
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


@sims4.commands.Command(
    "fgeh.linked_apply_snapshot",
    command_type=sims4.commands.CommandType.Live,
)
def _v893_command_linked_apply_snapshot(
    pack_id="",
    source_pose_name="",
    cas_auto=1,
    object_auto=1,
    cas_ids="",
    object_ids="",
    target_pose_names="",
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        import time
        started_at = time.perf_counter()

        pack_id = _v89_decode_command_text(pack_id)
        source_pose_name = _v89_decode_command_text(source_pose_name)
        cas_auto = bool(int(cas_auto or 0))
        object_auto = bool(int(object_auto or 0))
        cas_ids = _v893_parse_id_list(cas_ids)
        object_ids = _v893_parse_id_list(object_ids)
        if pack_id == _CASLIB_VIRTUAL_PACK_ID:
            return True

        raw_targets = _v89_decode_command_text(target_pose_names)
        requested_targets = [
            value.strip()
            for value in raw_targets.splitlines()
            if value.strip()
        ]

        all_pose_names = _v8929_all_pose_names_for_pack(manager, pack_id)
        from fgeh_linked_scope_n2 import scope
        group_members = scope(manager, _ACTIVE_PLAY_CONTEXT, pack_id, source_pose_name)
        if group_members is not None:
            all_pose_names = [v for v in all_pose_names if v in group_members]
            requested_targets = [v for v in requested_targets if v in group_members]

        allowed = set(all_pose_names)
        if source_pose_name:
            allowed.add(source_pose_name)

        if raw_targets.strip() and not requested_targets:
            return False

        if requested_targets:
            targets = []
            seen = set()
            for value in requested_targets:
                if value in seen:
                    continue
                if allowed and value not in allowed:
                    continue
                seen.add(value)
                targets.append(value)
            mode = "selected"
            pose_names = [source_pose_name] + targets
        else:
            mode = "pack"
            pose_names = list(all_pose_names)
            if source_pose_name and source_pose_name not in pose_names:
                pose_names.insert(0, source_pose_name)
            targets = [
                value for value in pose_names if value != source_pose_name
            ]

        # One in-memory state update + ONE save_favorites() replaces the old
        # source setters plus separate CAS/object pack apply passes.
        written = _v8929_write_linked_snapshot_state(
            manager,
            pack_id,
            pose_names,
            cas_auto,
            object_auto,
            cas_ids,
            object_ids,
        )

        manager.fgeh_pose_manager_debug_log(
            "[LINKED_APPLY_FAST] build={} mode={} pack={} source={} "
            "cas_ids={} object_ids={} targets={} written={} elapsed_ms={:.1f}".format(
                UI_BUILD_TAG, mode, pack_id, source_pose_name,
                len(cas_ids), len(object_ids), len(targets), written,
                (time.perf_counter() - started_at) * 1000.0,
            )
        )
        return True
    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "[LINKED_APPLY_FAST] build={} FAILED".format(UI_BUILD_TAG),
                exc=True,
            )
        except Exception:
            pass
        return False




@sims4.commands.Command(
    "fgeh.linked_ui_perf",
    command_type=sims4.commands.CommandType.Live,
)
def _v8932_command_linked_ui_perf(
    phase="",
    server_return_ms=0,
    total_ui_ms=0,
    mirrored_rows=0,
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        manager.fgeh_pose_manager_debug_log(
            "[LINKED_UI_PERF] build={} phase={} server_return_ms={} "
            "total_ui_ms={} mirrored_rows={}".format(
                UI_BUILD_TAG,
                str(phase or ""),
                int(server_return_ms or 0),
                int(total_ui_ms or 0),
                int(mirrored_rows or 0),
            )
        )
        return True
    except Exception:
        return False


@sims4.commands.Command(
    "fgeh.linked_apply_pack",
    command_type=sims4.commands.CommandType.Live,
)
def _v89_command_linked_apply_pack(
    pack_id="",
    pose_name="",
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager
        pack_id = _v89_decode_command_text(pack_id)
        pose_name = _v89_decode_command_text(pose_name)
        if pack_id == _CASLIB_VIRTUAL_PACK_ID:
            return True
        from fgeh_linked_scope_n2 import scope
        group_members = scope(manager, _ACTIVE_PLAY_CONTEXT, pack_id, pose_name)
        if group_members is not None:
            _v892_apply_linked_selection_to_poses(manager, pack_id, pose_name, sorted(group_members))
            return True
        manager.apply_linked_cas_selection_to_pack(pack_id, pose_name)
        manager.apply_linked_object_selection_to_pack(pack_id, pose_name)
        manager.fgeh_pose_manager_debug_log(
            "V8.9 linked selection applied to pack={} source_pose={}".format(
                pack_id, pose_name
            )
        )
        return True
    except Exception:
        return False





def _v814_resolve_current_target():
    import services
    import couplepose1 as manager

    context = _ACTIVE_PLAY_CONTEXT
    if not isinstance(context, dict):
        return manager, None, None

    interaction = _v86_resolve_interaction_from_callback(
        context.get("on_item_selected")
    )
    if interaction is None:
        return manager, None, None

    target = getattr(interaction, "target", None)

    try:
        custom_target_id = getattr(
            interaction,
            "fgeh_custom_target_id",
            None,
        )
        if custom_target_id:
            found = services.object_manager().get(custom_target_id)
            if found is not None:
                target = found
    except Exception:
        pass

    return manager, interaction, target


def _v814_iter_target_interactions(sim):
    if sim is None:
        return

    seen = set()

    getter = getattr(
        sim,
        "get_all_running_and_queued_interactions",
        None,
    )
    if callable(getter):
        try:
            for interaction in getter():
                if interaction is None:
                    continue
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                yield interaction
        except Exception:
            pass

    try:
        queue = getattr(sim, "queue", None)
        if queue is not None:
            for interaction in queue:
                if interaction is None:
                    continue
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                yield interaction
    except Exception:
        pass

    try:
        si_state = getattr(sim, "si_state", None)
        if si_state is not None:
            for interaction in si_state:
                if interaction is None:
                    continue
                key = id(interaction)
                if key in seen:
                    continue
                seen.add(key)
                yield interaction
    except Exception:
        pass


def _v814_is_pose_interaction(
    manager,
    interaction,
    manager_interaction,
):
    if interaction is None or interaction is manager_interaction:
        return False

    try:
        checker = getattr(
            manager,
            "_is_live_pose_interaction",
            None,
        )
        if callable(checker):
            return bool(
                checker(
                    interaction,
                    exclude_interaction=manager_interaction,
                )
            )
    except Exception:
        pass

    try:
        return bool(getattr(interaction, "pose_name", None))
    except Exception:
        return False


def _v814_cancel_one_pose(interaction):
    try:
        from interactions.interaction_finisher import FinishingType

        cancel = getattr(interaction, "cancel", None)
        if callable(cancel):
            try:
                cancel(
                    FinishingType.USER_CANCEL,
                    cancel_reason_msg=(
                        "FGEH Pose Manager clear Pose queue"
                    ),
                )
            except TypeError:
                cancel(FinishingType.USER_CANCEL)
            return True
    except Exception:
        pass

    try:
        cancel_user = getattr(interaction, "cancel_user", None)
        if callable(cancel_user):
            try:
                cancel_user(
                    cancel_reason_msg=(
                        "FGEH Pose Manager clear Pose queue"
                    )
                )
            except TypeError:
                cancel_user()
            return True
    except Exception:
        pass

    return False


@sims4.commands.Command(
    "fgeh.clear_pose_queue",
    command_type=sims4.commands.CommandType.Live,
)
def _v814_command_clear_pose_queue(_connection=None):
    del _connection

    manager = None

    try:
        manager, manager_interaction, target = (
            _v814_resolve_current_target()
        )

        if target is None:
            manager.fgeh_pose_manager_debug_log(
                "V8.9.14 clear pose queue ignored: no current target"
            )
            return False

        all_interactions = list(
            _v814_iter_target_interactions(target) or ()
        )

        pose_interactions = [
            interaction
            for interaction in all_interactions
            if _v814_is_pose_interaction(
                manager,
                interaction,
                manager_interaction,
            )
        ]

        cancelled = 0
        for interaction in pose_interactions:
            if _v814_cancel_one_pose(interaction):
                cancelled += 1

        # Positioning belongs to the same Pose chain.
        try:
            manager.cancel_positioning_sessions_for_sim(
                target,
                reason="ui-clear-pose-queue",
            )
        except Exception:
            pass

        # R25: cancelling the queue must also schedule CAS restoration;
        # child cancellation/liability callbacks are not a guaranteed entry.
        try:
            manager.schedule_pose_chain_cleanup_check(target, reason="ui-clear-pose-queue")
        except Exception:
            pass

        # Destroy linked world objects spawned for cancelled Poses.
        try:
            manager.cleanup_linked_objects_after_pose(target)
        except Exception:
            pass

        manager.fgeh_pose_manager_debug_log(
            "V8.9.14 clear pose queue target={} all_interactions={} pose_interactions={} cancelled={}".format(
                getattr(
                    target,
                    "sim_id",
                    getattr(target, "id", None),
                ),
                len(all_interactions),
                len(pose_interactions),
                cancelled,
            )
        )
        return True

    except Exception:
        try:
            if manager is None:
                import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.14 clear pose queue failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.play_selected_poses",
    command_type=sims4.commands.CommandType.Live,
)
def _v896_command_play_selected_poses(
    selected_pose_names="",
    _connection=None,
):
    del _connection
    try:
        import couplepose1 as manager

        raw_names = _v89_decode_command_text(selected_pose_names)
        names = [
            value.strip()
            for value in raw_names.splitlines()
            if value.strip()
        ]

        context = _ACTIVE_PLAY_CONTEXT
        if not isinstance(context, dict):
            manager.fgeh_pose_manager_debug_log(
                "V8.9.6 selected play ignored: no active detail context"
            )
            return False

        if not names:
            manager.fgeh_pose_manager_debug_log(
                "V8.9.6 selected play ignored: empty selection"
            )
            return False

        return _v882_play_all_visible(
            manager,
            context.get("owner"),
            context.get("pack"),
            context.get("item_tags"),
            context.get("on_item_selected"),
            context.get("on_back"),
            selected_pose_names=names,
            reopen=False,
        )

    except Exception:
        try:
            import couplepose1 as manager
            manager.fgeh_pose_manager_debug_log(
                "V8.9.6 selected play failed",
                exc=True,
            )
        except Exception:
            pass
        return False


@sims4.commands.Command(
    "fgeh.headline_widget_toggle",
    command_type=sims4.commands.CommandType.Live,
)
def _fgeh_headline_widget_toggle(_connection=None):
    """Toggle the existing global headline/plumbob setting from the 2D widget."""
    output = sims4.commands.CheatOutput(_connection)
    try:
        import couplepose1 as manager

        current = _v8951_global_plumbob_enabled(manager)
        enabled = not current

        # Reuse the original mod's own runtime setter whenever possible.
        # Different development builds used slightly different signatures,
        # so keep a conservative fallback to the vanilla client cheat.
        applied = False
        setter = getattr(manager, "set_headline_effects_enabled", None)
        if callable(setter):
            try:
                setter(enabled, _connection)
                applied = True
            except TypeError:
                try:
                    setter(enabled)
                    applied = True
                except Exception:
                    pass
            except Exception:
                pass

        if not applied:
            command = "headlineeffects on" if enabled else "headlineeffects off"
            sims4.commands.client_cheat(command, _connection)

        # Persist through the SAME field / save path the old settings page
        # already uses, so the next game session restores the chosen state.
        try:
            manager.state.headline_effects_enabled = bool(enabled)
        except Exception:
            pass
        try:
            manager.save_favorites()
        except Exception:
            pass

        try:
            manager.fgeh_pose_manager_debug_log(
                "[GLOBAL_PLUMBOB_WIDGET] enabled={}".format(bool(enabled))
            )
        except Exception:
            pass

        output("FGEH plumbob/headline effects: {}".format("ON" if enabled else "OFF"))
    except Exception as exc:
        output("FGEH plumbob widget failed: {}".format(exc))


@sims4.commands.Command("fgeh.pose_ui", command_type=sims4.commands.CommandType.Live)
def open_pose_manager_ui(_connection=None):
    output = sims4.commands.CheatOutput(_connection)
    manager = None
    try:
        import services
        import couplepose1 as manager
        _release_disable_debug_log(manager)
        if not manager.is_custom_pose_manager_ui_enabled():
            output("Pose Manager custom UI is disabled in this release profile.")
            return False
        owner = services.get_active_sim()
        if owner is None:
            output("No active Sim.")
            return False
        result = show_pose_manager_root(owner)
        output("Pose Manager custom UI opened." if result else "Pose Manager custom UI failed.")
        return result
    except Exception as exc:
        if manager is not None:
            manager.fgeh_pose_manager_debug_log(
                "fgeh.pose_ui command failed: {}: {}".format(
                    type(exc).__name__, exc
                ),
                exc=True,
            )
        output("Pose Manager custom UI failed: {}: {}".format(type(exc).__name__, exc))
        return False

# R30 wraps the editor bridge after all functions are defined.
import sys as _r30_sys
_r30_editor.install(_r30_sys.modules[__name__])


@sims4.commands.Command("fgeh.perf_ui", command_type=sims4.commands.CommandType.Live)
def _fgeh_perf_ui(duration='0', dialog_id='0', _connection=None):
    return  # R26: release diagnostic/file output disabled.


_FGEH_TRACE_REQUESTS = {}
_FGEH_TRACE_EVENTS = ('SHOW_ENTER', 'BASE_SHOW_DONE', 'SEARCH_READY', 'BEFORE_DRAW', 'DRAW_DONE', 'NATIVE_CELLS_DONE', 'FIXED_TOOLS_DONE', 'EXPORT_BEGIN', 'EXPORT_DONE', 'SHOW_DONE')
_FGEH_TRACE_REPORT_AT = 0.0

def _fgeh_trace_begin(dialog, kind, started, payload_items):
    return  # R26: release diagnostic/file output disabled.

def _fgeh_trace_error(where, exc):
    try:
        import couplepose1
        couplepose1.fgeh_pose_manager_perf_log('TRACE R72 FAILURE where={} error={}:{}'.format(where, type(exc).__name__, exc))
    except Exception:
        pass

def _fgeh_trace_finish(key):
    return  # R26: release diagnostic/file output disabled.

def _fgeh_trace_write_reports(force=False):
    return  # R26: release diagnostic/file output disabled.

@sims4.commands.Command("fgeh.perf_trace", command_type=sims4.commands.CommandType.Live)
def _fgeh_perf_trace(value='', dialog_id='0', _connection=None):
    return  # R26: release diagnostic/file output disabled.



_FGEH_AUTO_PERF_REPORT_AT = 0.0

@sims4.commands.Command("fgeh.perf_phase", command_type=sims4.commands.CommandType.Live)
def _fgeh_perf_phase(value='', dialog_id='0', _connection=None):
    return  # R26: release diagnostic/file output disabled.


@sims4.commands.Command("fgeh.perf_report", command_type=sims4.commands.CommandType.Live)
def _fgeh_perf_report(_connection=None, _silent=False):
    return  # R26: release diagnostic/file output disabled.


@sims4.commands.Command("fgeh.caslib_source", command_type=sims4.commands.CommandType.Live)
def _fgeh_caslib_source(source='external', dialog_id='0', _connection=None):
    context = _CASLIB_ACTIVE_CONTEXT
    if context is None:
        return
    manager, owner, callback, dialog = context
    try:
        active_id = int(getattr(dialog, 'dialog_id', 0))
        if int(dialog_id) != active_id:
            _perf_log(manager, 'CASLIB_SOURCE_CLICK stale_dialog={}'.format(dialog_id))
            return
        if source == 'back':
            _perf_log(manager, 'CASLIB_BACK_CLICK dialog={}'.format(active_id))
            import services
            services.ui_dialog_service().dialog_cancel(active_id)
            if _caslib_binding_mode(manager):
                _caslib_return_to_bound_pose(manager, owner)
                return
            _caslib_reset(manager, leave_library=True)
            if _nav_can_back(manager):
                _nav_back(manager, save=True)
            else:
                manager.state.custom_pose_ui_active_nav = NAV_ALL_PACKS
                _v7_reset_subview(manager)
                _nav_switch_root(manager, save=False)
            _schedule_root_reopen(manager, owner, callback, 'caslib-back-command')
            return
        previous = _caslib_source(manager)
        _perf_log(manager, 'CASLIB_SOURCE_CLICK from={} to={} dialog={}'.format(previous, source, active_id))
        if source != 'restore' and source == previous:
            return
        if source == 'restore':
            result = _v8966_restore_original_outfit(owner)
            _perf_log(manager, 'CASLIB_RESTORE_COMMAND result={}'.format(result))
        else:
            _caslib_set_source(manager, source)
        try:
            import services
            service = services.ui_dialog_service()
            cancel = getattr(service, 'dialog_cancel', None)
            if cancel is not None:
                cancel(active_id)
        except Exception:
            pass
        _schedule_caslib_product_panel(manager, owner, callback, 'caslib-source-command')
        _perf_log(manager, 'CASLIB_SOURCE_SWITCH from={} to={}'.format(previous, _caslib_source(manager)))
    except Exception as exc:
        _perf_log(manager, 'CASLIB_SOURCE_FAILURE error={}'.format(exc))


def _r74_remove_linked_action(manager, pack_id, pose_name):
    """Remove local bindings/markers, preserving external XML requirements."""
    import json
    from pathlib import Path
    import fgeh_pose_requirement_registry as registry
    import fgeh_linked_cas_bindings as cas
    import fgeh_linked_object_bindings as objects
    pack_id, pose_name = str(pack_id or ''), str(pose_name or '')
    if not pack_id or not pose_name:
        return False, '未选中动作'
    registry.clear_requirement_cache()
    has_external = False
    for source in registry.iter_requirement_sources_for_pack(manager.state.all_packs_cache, pack_id):
        info = source.get('entry_info') or {}
        if info.get('snippet') is not None:
            if any(str(getattr(item, 'pose_name', '') or '') == pose_name for item in registry._iter_pose_items_for_entry(source.get('pack'), info)):
                has_external = True
    plans = []
    seen = set()
    for module, filename in ((cas, cas.CAS_BINDINGS_FILENAME), (objects, objects.OBJECT_BINDINGS_FILENAME)):
        for folder in module._candidate_dirs():
            path = Path(module._path_in(folder, filename))
            if str(path.resolve()) in seen or not path.exists():
                continue
            seen.add(str(path.resolve()))
            old = json.loads(path.read_text(encoding='utf-8'))
            data = json.loads(json.dumps(old))
            data, changed = module._clean_pose_refs_from_data(data, [(pack_id, pose_name)])
            if module is cas:
                # A reused outfit identifier must not delete another pose's row.
                data['outfit_bindings'] = [row for row in (old.get('outfit_bindings', []) or []) if not (isinstance(row, dict) and str(row.get('pack_id') or '') == pack_id and str(row.get('pose_name') or '') == pose_name)]
                markers = data.get('managed_actions', []) or []
                kept = [row for row in markers if not (isinstance(row, dict) and str(row.get('pack_id') or '') == pack_id and str(row.get('pose_name') or '') == pose_name)]
                changed = changed or len(kept) != len(markers)
                data['managed_actions'] = kept
            if changed:
                plans.append((module, folder, old, data))
    attempted = []
    try:
        for module, folder, old, data in plans:
            attempted.append((module, folder, old))
            if not module._save_data_to_folder(folder, data):
                raise RuntimeError('保存失败')
    except Exception:
        rollback_ok = True
        for module, folder, old in reversed(attempted):
            rollback_ok = bool(module._save_data_to_folder(folder, old)) and rollback_ok
        registry.clear_requirement_cache()
        return False, '移除未完成，已恢复原绑定。' if rollback_ok else '移除未完成，部分绑定恢复失败；请保留个人数据备份。'
    registry.clear_requirement_cache()
    # The list derives from bindings/markers, rather than a cosmetic hide flag.
    key = manager.linked_object_choice_key(pack_id, pose_name)
    for attr in ('linked_cas_enabled_choices', 'linked_object_enabled_choices'):
        choices = dict(getattr(manager.state, attr, {}) or {})
        choices.pop(key, None)
        setattr(manager.state, attr, choices)
    manager.save_favorites()
    if has_external:
        return True, '已解除游戏内绑定和手动登记；仍有游戏外 XML 绑定，因此保留在联动列表。'
    return True, '已移除这个动作的全部游戏内联动和手动登记；动作本身保留。'


def _r74_linked_message(owner, message):
    from ui.ui_dialog_notification import UiDialogNotification
    from sims4.localization import LocalizationHelperTuning
    dialog = UiDialogNotification.TunableFactory().default(
        owner,
        title=lambda **kwargs: _fgeh_hash_ui_text('移除联动'),
        text=lambda **kwargs: _fgeh_hash_ui_text(message),
    )
    dialog.show_dialog()


# Read-only diagnosis. Automatic snapshots stay in memory; no file logger.
_FGEH_HASH_PROBE_MEMORY = []

@sims4.commands.Command("fgeh.hash_probe.capture", command_type=sims4.commands.CommandType.Live)
def _fgeh_hash_probe_capture(value='', _connection=None):
    return  # R26: release diagnostic/file output disabled.

@sims4.commands.Command("fgeh.hash_probe", command_type=sims4.commands.CommandType.Live)
def _fgeh_hash_probe_dump(_connection=None):
    return  # R26: release diagnostic/file output disabled.


@sims4.commands.Command('fgeh.perf_on', command_type=sims4.commands.CommandType.Live)
def _fgeh_perf_enable(_connection=None):
    return  # R26: release diagnostic/file output disabled.

@sims4.commands.Command('fgeh.perf_off', command_type=sims4.commands.CommandType.Live)
def _fgeh_perf_disable(_connection=None):
    return  # R26: release diagnostic/file output disabled.
