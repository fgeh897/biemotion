# coding: utf-8
"""PLAY-side Python receiver for FgEH CAS Collection.

Compile with the user's Sims 4 Python 3.7 workflow. Do NOT bundle a precompiled
.ts4script here. Data is expected from a PLAY GFX PostServerCommand bridge.

Protocol:
  fgeh.cas.collection.begin <token> <expected_count>
  fgeh.cas.collection.chunk <token> <kind> <key> <part> <total> <urlencoded_chunk>
  fgeh.cas.collection.commit <token>
  fgeh.cas.collection.abort <token>

kind: m = manifest, i = item record (key=base id), g = groups
Chunks are URL-encoded by AS3 encodeURIComponent() and unquoted here.
"""
import json
import os
import time
import traceback
try:
    from urllib.parse import unquote
except Exception:
    from urllib import unquote

import sims4.commands

try:
    from fgeh_cas_collection_codec import build_collection, build_collection_v2
except Exception:
    from .fgeh_cas_collection_codec import build_collection, build_collection_v2

JSON_FILENAME = "fgeh_cas_collection.json"
TMP_FILENAME = "fgeh_cas_collection_tmp"
TMP_LEGACY_FILENAME = "fgeh_cas_collection.json.tmp"
BACKUP_FILENAME = "fgeh_cas_collection_backup"
BACKUP_LEGACY_FILENAME = "fgeh_cas_collection.bak"
LOG_FILENAME = "fgeh_cas_collection_bridge.log"
MAX_SESSIONS = 4
MAX_STREAM_CHARS = 262144
_SESSIONS = {}


def _module_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return ""


def _mod_directory():
    # Same directory convention used by the user's stable action-manager helpers.
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        return _module_dir()


def _primary_dir():
    folder = _mod_directory()
    return folder if folder and os.path.isdir(folder) else _module_dir()


def _path(name):
    return os.path.join(_primary_dir(), name)


def _log(message):
    return  # R26: release diagnostic/file output disabled.


def _load_json_dict(path):
    try:
        if not path or not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _write_json_stable(data):
    """Mirror Pose Manager save order: tmp -> backup old -> rename tmp to target."""
    target = _path(JSON_FILENAME)
    tmp = _path(TMP_FILENAME)
    backup = _path(BACKUP_FILENAME)
    backup_legacy = _path(BACKUP_LEGACY_FILENAME)
    try:
        with open(tmp, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2)
        # Never replace a good file with an unreadable temp.
        check = _load_json_dict(tmp)
        if check is None or check.get("schema") != "fgeh.cas.collection.v1":
            _log("JSON_COMMIT temp validation failed")
            return False
        if os.path.exists(target):
            try:
                if os.path.exists(backup):
                    os.remove(backup)
                elif os.path.exists(backup_legacy):
                    os.remove(backup_legacy)
            except Exception:
                pass
            os.rename(target, backup)
        os.rename(tmp, target)
        final = _load_json_dict(target)
        if final is None or final.get("schema") != "fgeh.cas.collection.v1":
            _log("JSON_COMMIT final validation failed")
            return False
        return True
    except Exception as exc:
        _log("JSON_COMMIT exception={!r}\n{}".format(exc, traceback.format_exc()))
        return False


def _clean_sessions():
    if len(_SESSIONS) <= MAX_SESSIONS:
        return
    ordered = sorted(_SESSIONS.items(), key=lambda pair: pair[1].get("created", 0))
    for token, _ in ordered[:-MAX_SESSIONS]:
        _SESSIONS.pop(token, None)


def _session(token):
    return _SESSIONS.get(str(token or ""))


def _put_chunk(session, kind, key, part_index, part_count, decoded):
    if kind not in ("m", "i", "g", "f"):
        raise ValueError("bad stream kind")
    key = str(key or "0")
    part_index = int(part_index)
    part_count = int(part_count)
    if part_count <= 0 or part_count > 4096 or part_index < 0 or part_index >= part_count:
        raise ValueError("bad chunk indices")
    streams = session.setdefault("streams", {}).setdefault(kind, {})
    stream = streams.setdefault(key, {"total": part_count, "parts": {}})
    if int(stream.get("total", part_count)) != part_count:
        raise ValueError("chunk total changed")
    stream["parts"][part_index] = decoded
    if sum(len(x) for x in stream["parts"].values()) > MAX_STREAM_CHARS:
        raise ValueError("stream too large")


def _assemble(session, kind, key):
    stream = session.get("streams", {}).get(kind, {}).get(str(key))
    if not stream:
        return None
    total = int(stream.get("total", 0))
    parts = stream.get("parts", {})
    if total <= 0 or len(parts) != total:
        return None
    return "".join(parts[i] for i in range(total))


@sims4.commands.Command("fgeh.cas.collection.begin", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_begin(token="", expected_count="0", _connection=None):
    token = str(token or "").strip()
    if not token or len(token) > 96:
        return False
    try:
        expected = int(expected_count or 0)
    except Exception:
        expected = -1
    if expected < 0 or expected > 10000:
        return False
    _SESSIONS[token] = {"created": time.time(), "expected_count": expected, "streams": {}}
    _clean_sessions()
    _log("PY_RECEIVE BEGIN token={} expected={}".format(token, expected))
    return True


@sims4.commands.Command("fgeh.cas.collection.chunk", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_chunk(token="", kind="", key="0", part_index="0", part_count="1", encoded="", _connection=None):
    session = _session(token)
    if session is None:
        _log("PY_RECEIVE CHUNK rejected missing_session token={}".format(token))
        return False
    try:
        decoded = unquote(str(encoded or ""))
        _put_chunk(session, str(kind or ""), key, part_index, part_count, decoded)
        return True
    except Exception as exc:
        _log("PY_RECEIVE CHUNK failed token={} kind={} key={} error={!r}".format(token, kind, key, exc))
        return False


@sims4.commands.Command("fgeh.cas.collection.commit", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_commit(token="", _connection=None):
    token = str(token or "")
    session = _session(token)
    if session is None:
        _log("PY_RECEIVE COMMIT rejected missing_session token={}".format(token))
        return False
    try:
        manifest = _assemble(session, "m", "0")
        if not manifest:
            raise ValueError("manifest incomplete")
        # Parse manifest first to know exactly which item streams are required.
        from fgeh_cas_collection_codec import parse_manifest
        bases = parse_manifest(manifest)
        if int(session.get("expected_count", len(bases))) != len(bases):
            raise ValueError("expected item count mismatch")
        item_records = {}
        for base_id in bases:
            raw = _assemble(session, "i", base_id)
            if raw is None:
                raise ValueError("item stream incomplete base={}".format(base_id))
            item_records[base_id] = raw
        groups = _assemble(session, "g", "0") or ""
        data = build_collection(manifest, item_records, groups)
        data["exported_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        data["bridge"] = {
            "transport": "PLAY_GFX_PostServerCommand_chunked_v1",
            "token": token,
            "expected_count": len(bases),
        }
        if not _write_json_stable(data):
            raise ValueError("stable JSON write failed")
        _log("JSON_COMMIT SUCCESS token={} items={} groups={} variants={}".format(
            token, len(data.get("items", [])), len(data.get("groups", {})),
            sum(len(item.get("variants", [])) for item in data.get("items", []))))
        _SESSIONS.pop(token, None)
        return True
    except Exception as exc:
        _log("JSON_COMMIT FAIL token={} error={!r}\n{}".format(token, exc, traceback.format_exc()))
        # Keep session for diagnosis/retry; never overwrite existing JSON on validation failure.
        return False


@sims4.commands.Command("fgeh.cas.collection.abort", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_abort(token="", _connection=None):
    _SESSIONS.pop(str(token or ""), None)
    _log("PY_RECEIVE ABORT token={}".format(token))
    return True


@sims4.commands.Command("fgeh.cas.collection.status", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_status(_connection=None):
    output = sims4.commands.CheatOutput(_connection)
    data = _load_json_dict(_path(JSON_FILENAME))
    if data is None:
        output("FgEH CAS collection JSON: none")
        return False
    output("FgEH CAS collection JSON: items={} groups={} schema={}".format(
        data.get("item_count", 0), data.get("group_count", 0), data.get("schema", "")))
    return True


@sims4.commands.Command("fgeh.cas.collection.diag", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_diag(phase="", arg1="", arg2="", _connection=None):
    _log("GFX_DIAG phase={} arg1={} arg2={}".format(str(phase or ""), str(arg1 or ""), str(arg2 or "")))
    return True


_log("FgEH CAS collection PLAY receiver imported")


# --- H28 real V2 snapshot bridge ----------------------------------------------
# The live Pose Manager package sends the H26 compatibility mirror as one
# logical favorite stream (f) plus one group stream (g). Both are chunked and
# URL-decoded here. The V2 row still contains every captured variant/swatch.

@sims4.commands.Command("fgeh.cas.collection.v2begin", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_v2begin(token="", _connection=None):
    token = str(token or "").strip()
    if not token or len(token) > 96:
        return False
    _SESSIONS[token] = {"created": time.time(), "expected_count": -1, "streams": {}, "protocol": "v2_snapshot"}
    _clean_sessions()
    _log("PY_RECEIVE V2_BEGIN token={}".format(token))
    return True


@sims4.commands.Command("fgeh.cas.collection.v2chunk", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_v2chunk(token="", kind="", part_index="0", part_count="1", encoded="", _connection=None):
    session = _session(token)
    if session is None or session.get("protocol") != "v2_snapshot":
        _log("PY_RECEIVE V2_CHUNK rejected missing_session token={}".format(token))
        return False
    try:
        kind = str(kind or "")
        if kind not in ("f", "g"):
            raise ValueError("bad V2 stream kind")
        decoded = unquote(str(encoded or ""))
        _put_chunk(session, kind, "0", part_index, part_count, decoded)
        return True
    except Exception as exc:
        _log("PY_RECEIVE V2_CHUNK failed token={} kind={} error={!r}".format(token, kind, exc))
        return False


@sims4.commands.Command("fgeh.cas.collection.v2commit", command_type=sims4.commands.CommandType.Live)
def fgeh_cas_collection_v2commit(token="", _connection=None):
    token = str(token or "")
    session = _session(token)
    if session is None or session.get("protocol") != "v2_snapshot":
        _log("PY_RECEIVE V2_COMMIT rejected missing_session token={}".format(token))
        return False
    try:
        snapshot = _assemble(session, "f", "0")
        if not snapshot:
            raise ValueError("V2 favorite snapshot incomplete")
        groups = _assemble(session, "g", "0") or ""
        data = build_collection_v2(snapshot, groups)
        data["exported_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        data["bridge"] = {
            "transport": "PLAY_GFX_PostServerCommand_chunked_v2_snapshot",
            "token": token,
            "favorite_chars": len(snapshot),
            "group_chars": len(groups),
        }
        if not _write_json_stable(data):
            raise ValueError("stable JSON write failed")
        _log("JSON_COMMIT V2_SUCCESS token={} items={} groups={} variants={} fav_chars={} group_chars={}".format(
            token,
            len(data.get("items", [])),
            len(data.get("groups", {})),
            sum(len(item.get("variants", [])) for item in data.get("items", [])),
            len(snapshot), len(groups)))
        _SESSIONS.pop(token, None)
        return True
    except Exception as exc:
        _log("JSON_COMMIT V2_FAIL token={} error={!r}\n{}".format(token, exc, traceback.format_exc()))
        return False
