"""Small runtime registry for linked pose lifecycle state.

This module deliberately has no Sims 4 imports.  It owns only short-lived
session metadata; CAS and object application remain in their own modules.
"""


class _Session(object):
    __slots__ = (
        "sim_id",
        "generation",
        "controller",
        "controller_ended",
        "participants",
        "child_interaction_ids",
        "finished_child_interaction_ids",
    )

    def __init__(self, sim_id):
        self.sim_id = sim_id
        self.generation = 0
        self.controller = None
        self.controller_ended = False
        self.participants = []
        self.child_interaction_ids = set()
        self.finished_child_interaction_ids = set()


_sessions_by_sim = {}


def _get_session(sim_id, create=False):
    if sim_id is None:
        return None
    session = _sessions_by_sim.get(sim_id)
    if session is None and create:
        session = _Session(sim_id)
        _sessions_by_sim[sim_id] = session
    return session


def register_controller(controller, sim_ids):
    """Start or refresh a controller session for its Sim participants."""
    clean_ids = []
    for sim_id in sim_ids or ():
        if sim_id is not None and sim_id not in clean_ids:
            clean_ids.append(sim_id)

    for sim_id in clean_ids:
        session = _get_session(sim_id, create=True)
        if session.controller is not controller:
            session.generation += 1
            session.participants = []
            session.child_interaction_ids.clear()
            session.finished_child_interaction_ids.clear()
        session.controller = controller
        session.controller_ended = False
    return clean_ids


def mark_controller_ended(controller, sim_ids):
    """Mark only the matching controller as ended."""
    ended_ids = []
    for sim_id in sim_ids or ():
        session = _get_session(sim_id)
        if session is not None and session.controller is controller:
            session.controller_ended = True
            ended_ids.append(sim_id)
    return ended_ids


def mark_controller_ended_for_sim(sim_id):
    session = _get_session(sim_id)
    if session is None or session.controller is None:
        return False
    session.controller_ended = True
    return True


def is_controller_ended(sim_id):
    session = _get_session(sim_id)
    return bool(session is not None and session.controller_ended)


def get_active_controller(sim_ids):
    for sim_id in sim_ids or ():
        session = _get_session(sim_id)
        if session is not None and session.controller is not None and not session.controller_ended:
            return session.controller
    return None


def register_child(interaction, sim_ids):
    """Attach one child PoseInteraction to its active pack controller."""
    controller = get_active_controller(sim_ids)
    if controller is None:
        return False
    interaction_id = id(interaction)
    for session in list(_sessions_by_sim.values()):
        if session.controller is controller:
            session.child_interaction_ids.add(interaction_id)
            session.finished_child_interaction_ids.discard(interaction_id)
    return True


def finish_child(interaction, sim_ids):
    """Return (changed, chain_finished) and make the operation idempotent."""
    interaction_id = id(interaction)
    controllers = []
    for sim_id in sim_ids or ():
        session = _get_session(sim_id)
        if session is not None and session.controller is not None:
            if session.controller not in controllers:
                controllers.append(session.controller)

    changed = False
    remaining = False
    already_finished = False
    for session in list(_sessions_by_sim.values()):
        if session.controller not in controllers:
            continue
        if interaction_id in session.child_interaction_ids:
            session.child_interaction_ids.discard(interaction_id)
            session.finished_child_interaction_ids.add(interaction_id)
            changed = True
        elif interaction_id in session.finished_child_interaction_ids:
            already_finished = True
        if session.child_interaction_ids:
            remaining = True
    if not controllers:
        return False, False
    if not changed and already_finished:
        return False, False
    return changed, not remaining


def remember_participants(controller, participants):
    clean = []
    for participant in participants or ():
        if participant is None:
            continue
        if all(existing is not participant for existing in clean):
            clean.append(participant)

    for session in list(_sessions_by_sim.values()):
        if session.controller is controller:
            session.participants = list(clean)
    return clean


def get_participants(controller):
    for session in list(_sessions_by_sim.values()):
        if session.controller is controller and session.participants:
            return list(session.participants)
    return []


def clear_sim(sim_id):
    _sessions_by_sim.pop(sim_id, None)


def clear_all():
    _sessions_by_sim.clear()


def get_debug_snapshot():
    return {
        sim_id: {
            "generation": session.generation,
            "controller_ended": session.controller_ended,
            "participant_count": len(session.participants),
            "child_count": len(session.child_interaction_ids),
        }
        for sim_id, session in _sessions_by_sim.items()
    }
