from fgeh_shared_ui_localization import text as _t
"""Pose lifecycle uses EA AutonomyModifier with privately owned handles."""
import weakref

_entries = {}
_alarm = None
_zone = None
_log = lambda *args: None
_freeze = None

def _remove(sid):
    entry = _entries.get(sid)
    if entry is None:
        return
    sim = entry['ref']()
    if entry['handle'] is not None and sim is not None:
        try:
            sim.remove_statistic_modifier(entry['handle'])
        except Exception as error:
            _log('needs-remove-error', str(error))
            return
    _entries.pop(sid, None)

def release(sim):
    _remove(getattr(sim, 'sim_id', getattr(sim, 'id', None)))
    if not _entries:
        _stop_guard()

def release_all():
    for sid in list(_entries):
        _remove(sid)
    if not _entries:
        _stop_guard()

def _stop_guard():
    global _alarm
    if _alarm is not None:
        import alarms
        alarms.cancel_alarm(_alarm)
    _alarm = None

def _apply(entry):
    if entry['handle'] is not None or not _freeze.enabled(entry['manager']):
        return
    sim = entry['ref']()
    if sim is None:
        return
    import services
    from sims4.resources import Types
    from autonomy.autonomy_modifier import AutonomyModifier
    manager = services.get_instance_manager(Types.STATISTIC)
    modifiers = {stat: 0.0 for stat in (manager.get(guid) for guid in _freeze.MOTIVES) if stat is not None}
    if not modifiers:
        return
    # Same API as EA stats.disable_commodities; our handle never enters EA's
    # shared cheat-command registry. Zero is a valid handle, not a failure.
    handle = sim.add_statistic_modifier(AutonomyModifier(decay_modifiers=modifiers))
    if handle is None:
        raise ValueError(_t('shared_fc2a1c2cccba'))
    entry['handle'] = handle
    _log('needs-native-applied', str(getattr(sim, 'id', '')))

def acquire(manager, sim):
    global _zone
    if sim is None:
        return
    import services
    current = services.current_zone()
    if _zone is not current:
        release_all()
        _stop_guard()
        _zone = current
    sid = getattr(sim, 'sim_id', getattr(sim, 'id', None))
    if sid is None:
        return
    previous = _entries.get(sid)
    if previous is not None and previous['ref']() is not sim:
        _remove(sid)
        if sid in _entries:
            return
    if sid not in _entries:
        try:
            ref = weakref.ref(sim)
        except TypeError:
            ref = lambda: sim
        _entries[sid] = {'ref': ref, 'manager': manager, 'handle': None, 'zone': current}
    try:
        _apply(_entries[sid])
    except Exception as error:
        _log('needs-native-error', str(error))
    _guard()

def reconcile(manager, scan=False):
    import services
    # A one-time scan on setting change catches already posing participants.
    # No timer traverses the object manager.
    if scan:
        import services
        objects = services.object_manager()
        if objects is not None:
            for sim in objects.get_all():
                try:
                    if getattr(sim, 'is_sim', False) and manager.sim_has_pending_pose_interaction(sim):
                        acquire(manager, sim)
                except Exception as error:
                    _log('needs-native-error', str(error))
    for sid, entry in list(_entries.items()):
        sim = entry['ref']()
        try:
            if entry['zone'] is not services.current_zone() or sim is None or not entry['manager'].sim_has_pending_pose_interaction(sim):
                _remove(sid)
            elif _freeze.enabled(entry['manager']):
                _apply(entry)
            elif entry['handle'] is not None:
                sim.remove_statistic_modifier(entry['handle'])
                entry['handle'] = None
        except Exception as error:
            _log('needs-native-error', str(error))

def _guard():
    global _alarm
    if _alarm is not None or not _entries:
        return
    try:
        import services, alarms, clock
        owner = services.current_zone()
        if owner is None:
            return
        def check(handle):
            global _alarm
            if handle is not _alarm:
                return
            _alarm = None
            if services.current_zone() is not owner:
                release_all()
                _guard()
                return
            for manager in {entry['manager'] for entry in _entries.values()}:
                reconcile(manager)
            _guard()
        # Safety only for missed callbacks/unloaded actors; ordinary start/end
        # is synchronous. Work scales with registered actors, never furniture.
        _alarm = alarms.add_alarm_real_time(owner, clock.interval_in_real_seconds(30), check, use_sleep_time=False)
    except Exception as error:
        _log('needs-guard-error', str(error))

def install(log):
    global _log, _freeze
    _log = log
    import fgeh_pose_need_freeze as freeze
    if getattr(freeze.acquire, '_fgeh_native_u21', False):
        return
    freeze.release_all()
    if freeze._active:
        raise ValueError(_t('shared_a17f43f0a08b'))
    if freeze._alarm is not None:
        import alarms
        alarms.cancel_alarm(freeze._alarm)
        freeze._alarm = None
    original_toggle = freeze.toggle
    _freeze = freeze
    def toggle(manager):
        # Preserve the established settings key and save implementation.
        result = original_toggle(manager)
        reconcile(manager, scan=True)
        _guard()
        return result
    acquire._fgeh_native_u21 = True
    freeze.acquire = acquire
    freeze.release = release
    freeze.release_all = release_all
    freeze.toggle = toggle
    # Original watcher is no longer used; its old dictionary remains empty.
    freeze._watch = lambda manager: None
    _log('needs-native-installed')
    import sys
    manager = sys.modules.get('couplepose1')
    if manager is not None and hasattr(manager, 'sim_has_pending_pose_interaction'):
        try:
            reconcile(manager, scan=True)
        except Exception as error:
            _log('needs-native-error', str(error))
