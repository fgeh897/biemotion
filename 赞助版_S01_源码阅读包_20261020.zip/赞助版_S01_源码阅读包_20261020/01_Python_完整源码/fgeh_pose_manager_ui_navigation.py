# -*- coding: utf-8 -*-
"""
FGEH Pose Manager - UI Navigation Stack V3
==========================================

This module replaces the old "one last_ui_snapshot + many came_from_xxx flags"
for the custom EpicCard UI with a small browser-like path stack.

Design rules
------------
1. Sidebar navigation REPLACES the path (switching a top-level section).
2. Entering a creator/group/pack PUSHES a new node.
3. Back POPS exactly one node.
4. Closing the dialog NEVER pops. Reopening can restore the exact top node.
5. Sort/search/favorite/edit/scroll mutate the CURRENT node; they are not
   separate history entries.
6. Persistence piggybacks on state.custom_names, which the legacy manager
   already saves. No second user-data file and no fgeh_state.py migration are
   required.

The stored payload is intentionally JSON-only and versioned. Unknown/old data
is ignored safely.
"""

import json

NAV_STACK_VERSION = 3
NAV_STACK_STORAGE_KEY = "__fgeh_ui_navigation_stack_v3__"
NAV_STACK_RUNTIME_ATTR = "_fgeh_ui_navigation_stack_v3"
LEGACY_NAV_STACK_STORAGE_KEY = "__fgeh_ui_navigation_stack_v2__"
LEGACY_NAV_STACK_RUNTIME_ATTR = "_fgeh_ui_navigation_stack_v2"
MAX_STACK_DEPTH = 24

_ROOT_STATE_FIELDS = (
    "custom_pose_ui_active_nav",
    "custom_pose_ui_scroll_row",
    "custom_pose_ui_query",
    "custom_pose_ui_blank_pack_view",
    "custom_pose_ui_creator_view_mode",
    "custom_pose_ui_selected_creator",
    "custom_pose_ui_selected_macro_group",
    "custom_pose_ui_selected_fav_pack_group",
    "custom_pose_ui_selected_fav_pose_group",
    "custom_pose_ui_selected_fav_pose_author",
    "custom_pose_ui_favorite_only",
    "selected_linked_grouped_outer_name",
    "custom_pose_ui_outfit_manager_mode",
    "custom_pose_ui_outfit_manager_category",
    "custom_pose_ui_outfit_manager_index",
    "custom_pose_ui_outfit_manager_browse_category",
)

# These are transient modal/edit states. They must never be resurrected after
# closing the whole manager or when walking Back through the path.
_TRANSIENT_ROOT_FIELDS = (
    "custom_pose_ui_edit_outer_group",
    "custom_pose_ui_edit_fav_pack_group",
    "custom_pose_ui_edit_fav_pose_group",
)


def _debug(manager, message):
    try:
        manager.fgeh_pose_manager_debug_log("[NAV_V2] {}".format(message))
    except Exception:
        pass


def _state(manager):
    return getattr(manager, "state", None)


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def _json_scalar(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    try:
        return str(value)
    except Exception:
        return None


def _custom_names(manager):
    state = _state(manager)
    if state is None:
        return {}
    values = getattr(state, "custom_names", None)
    if not isinstance(values, dict):
        values = {}
        try:
            state.custom_names = values
        except Exception:
            pass
    return values


def _normalize_node(raw):
    if not isinstance(raw, dict):
        return None
    kind = str(raw.get("kind", "") or "")
    if kind not in ("root", "pack"):
        return None

    if kind == "root":
        node = {"kind": "root"}
        fields = raw.get("state", {})
        if not isinstance(fields, dict):
            fields = {}
        clean = {}
        for key in _ROOT_STATE_FIELDS:
            if key in fields:
                clean[key] = _json_scalar(fields.get(key))
        node["state"] = clean

        # V3 keeps ordinary browsing and live-search cursors independent.
        # This prevents a search page from overwriting the user's ALL Packs
        # browsing position, while retaining the legacy state fields for the
        # rest of the UI during staged migration.
        raw_view = raw.get("view", {})
        if not isinstance(raw_view, dict):
            raw_view = {}
        query = str(raw_view.get("query", clean.get("custom_pose_ui_query", "")) or "")
        legacy_page = max(0, _safe_int(clean.get("custom_pose_ui_scroll_row", 0), 0))
        node["view"] = {
            "plain_page": max(0, _safe_int(raw_view.get("plain_page", legacy_page if not query.strip() else 0), 0)),
            "search_page": max(0, _safe_int(raw_view.get("search_page", legacy_page if query.strip() else 0), 0)),
            "query": query,
            "generation": max(0, _safe_int(raw_view.get("generation", 0), 0)),
        }
        return node

    pack_id = str(raw.get("pack_id", "") or "").strip()
    if not pack_id:
        return None
    node = {
        "kind": "pack",
        "pack_id": pack_id,
        "page": max(0, _safe_int(raw.get("page", 0), 0)),
        "favorite_only": bool(raw.get("favorite_only", False)),
        "active_inner_group": _json_scalar(raw.get("active_inner_group")),
    }
    return node


def _normalize_stack(raw_stack):
    if not isinstance(raw_stack, list):
        return []
    result = []
    for raw in raw_stack[-MAX_STACK_DEPTH:]:
        node = _normalize_node(raw)
        if node is not None:
            result.append(node)
    return result


def _encode_stack(stack):
    payload = {
        "version": NAV_STACK_VERSION,
        "stack": _normalize_stack(stack),
    }
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _decode_stack(text):
    if not text:
        return []
    try:
        payload = json.loads(str(text))
    except Exception:
        return []
    if not isinstance(payload, dict):
        return []
    if _safe_int(payload.get("version", 0), 0) != NAV_STACK_VERSION:
        return []
    return _normalize_stack(payload.get("stack", []))


def _decode_legacy_v2_stack(text):
    """Best-effort import of the old V2 JSON into V3 nodes."""
    if not text:
        return []
    try:
        payload = json.loads(str(text))
    except Exception:
        return []
    if not isinstance(payload, dict) or _safe_int(payload.get("version", 0), 0) != 2:
        return []
    return _normalize_stack(payload.get("stack", []))


def load_stack(manager):
    state = _state(manager)
    if state is None:
        return []

    runtime = getattr(state, NAV_STACK_RUNTIME_ATTR, None)
    if isinstance(runtime, list):
        return runtime

    names = _custom_names(manager)
    stored = names.get(NAV_STACK_STORAGE_KEY, "")
    stack = _decode_stack(stored)
    if not stack:
        # One-way migration.  V2 is left untouched until the first V3 write,
        # so rollback remains possible while this phase is being tested.
        stack = _decode_legacy_v2_stack(names.get(LEGACY_NAV_STACK_STORAGE_KEY, ""))
    try:
        setattr(state, NAV_STACK_RUNTIME_ATTR, stack)
    except Exception:
        pass
    return stack


def _write_runtime(manager, stack, save=False):
    state = _state(manager)
    if state is None:
        return []
    stack = _normalize_stack(stack)[-MAX_STACK_DEPTH:]
    try:
        setattr(state, NAV_STACK_RUNTIME_ATTR, stack)
    except Exception:
        pass
    _custom_names(manager)[NAV_STACK_STORAGE_KEY] = _encode_stack(stack)
    if save:
        try:
            manager.save_favorites()
        except Exception:
            _debug(manager, "save_favorites failed while persisting navigation")
    return stack


def clear(manager, save=False):
    _debug(manager, "clear")
    return _write_runtime(manager, [], save=save)


def _root_scope(fields):
    """Identity of one root/subview, excluding volatile page/search state."""
    return tuple(fields.get(key) for key in (
        "custom_pose_ui_active_nav",
        "custom_pose_ui_blank_pack_view",
        "custom_pose_ui_creator_view_mode",
        "custom_pose_ui_selected_creator",
        "custom_pose_ui_selected_macro_group",
        "custom_pose_ui_selected_fav_pack_group",
        "custom_pose_ui_selected_fav_pose_group",
        "custom_pose_ui_selected_fav_pose_author",
        "selected_linked_grouped_outer_name",
    ))


def capture_root(manager, previous=None):
    state = _state(manager)
    fields = {}
    if state is not None:
        for key in _ROOT_STATE_FIELDS:
            try:
                fields[key] = _json_scalar(getattr(state, key, None))
            except Exception:
                fields[key] = None

    query = str(fields.get("custom_pose_ui_query", "") or "")
    page = max(0, _safe_int(fields.get("custom_pose_ui_scroll_row", 0), 0))
    plain_page = page if not query.strip() else 0
    search_page = page if query.strip() else 0
    generation = 0

    if isinstance(previous, dict) and previous.get("kind") == "root":
        prev_fields = previous.get("state", {}) if isinstance(previous.get("state"), dict) else {}
        prev_view = previous.get("view", {}) if isinstance(previous.get("view"), dict) else {}
        if _root_scope(prev_fields) == _root_scope(fields):
            plain_page = max(0, _safe_int(prev_view.get("plain_page", plain_page), plain_page))
            search_page = max(0, _safe_int(prev_view.get("search_page", search_page), search_page))
            generation = max(0, _safe_int(prev_view.get("generation", 0), 0))
            if query.strip():
                search_page = page
            else:
                plain_page = page

    return {
        "kind": "root",
        "state": fields,
        "view": {
            "plain_page": plain_page,
            "search_page": search_page,
            "query": query,
            "generation": generation,
        },
    }


def sync_root_view(manager, query=None, page=None, save=False):
    """Lightweight V3 UI -> Python state bridge.

    Ordinary browsing page and live-search page are stored separately.
    This function never reopens a dialog.  Disk persistence only occurs when
    save=True at navigation/close boundaries.
    """
    state = _state(manager)
    if state is None:
        return None
    stack = ensure_root(manager, save=False)
    previous = stack[-1] if stack and stack[-1].get("kind") == "root" else None
    prev_view = previous.get("view", {}) if isinstance(previous, dict) and isinstance(previous.get("view"), dict) else {}
    old_query = str(prev_view.get("query", getattr(state, "custom_pose_ui_query", "")) or "")
    new_query = old_query if query is None else str(query or "")

    plain_page = max(0, _safe_int(prev_view.get("plain_page", getattr(state, "custom_pose_ui_scroll_row", 0)), 0))
    search_page = max(0, _safe_int(prev_view.get("search_page", 0), 0))
    incoming_page = None if page is None else max(0, _safe_int(page, 0))

    if new_query.strip():
        if incoming_page is not None:
            search_page = incoming_page
        effective_page = search_page
    else:
        # Clearing search restores the independent ordinary browsing cursor.
        # A local search page supplied on the same debounce event must never
        # overwrite the remembered ALL Packs cursor.
        if not old_query.strip() and incoming_page is not None:
            plain_page = incoming_page
        effective_page = plain_page

    try:
        state.custom_pose_ui_query = new_query
        state.custom_pose_ui_scroll_row = effective_page
    except Exception:
        pass

    node = capture_root(manager, previous=previous)
    node["view"] = {
        "plain_page": plain_page,
        "search_page": search_page,
        "query": new_query,
        "generation": max(0, _safe_int(prev_view.get("generation", 0), 0)) + 1,
    }
    node["state"]["custom_pose_ui_query"] = new_query
    node["state"]["custom_pose_ui_scroll_row"] = effective_page

    if stack and stack[-1].get("kind") == "root":
        stack[-1] = node
    else:
        stack.append(node)
    _write_runtime(manager, stack, save=save)
    _debug(manager, "sync_view query={!r} plain={} search={} effective={}".format(
        new_query, plain_page, search_page, effective_page
    ))
    return node


def _pack_id(manager, pack):
    if pack is None:
        return ""
    if isinstance(pack, str):
        return str(pack)
    try:
        value = manager.get_pack_id(pack)
        if value:
            return str(value)
    except Exception:
        pass
    return str(getattr(pack, "__name__", "") or "")


def capture_pack(manager, pack, page=None):
    state = _state(manager)
    pack_id = _pack_id(manager, pack)
    if page is None:
        pages = getattr(state, "custom_pose_ui_pack_pages", {}) if state is not None else {}
        if not isinstance(pages, dict):
            pages = {}
        page = pages.get(pack_id, 0)
    return {
        "kind": "pack",
        "pack_id": pack_id,
        "page": max(0, _safe_int(page, 0)),
        "favorite_only": bool(getattr(state, "custom_pose_ui_favorite_only", False)) if state is not None else False,
        "active_inner_group": _json_scalar(getattr(state, "custom_pose_ui_active_inner_group", None)) if state is not None else None,
    }


def ensure_root(manager, save=False):
    stack = load_stack(manager)
    if not stack:
        stack = [capture_root(manager)]
        _write_runtime(manager, stack, save=save)
    return stack


def current(manager):
    stack = load_stack(manager)
    return stack[-1] if stack else None


def depth(manager):
    return len(load_stack(manager))


def sync_current_root(manager, save=False):
    stack = ensure_root(manager, save=False)
    previous = stack[-1] if stack and stack[-1].get("kind") == "root" else None
    node = capture_root(manager, previous=previous)
    if stack and stack[-1].get("kind") == "root":
        stack[-1] = node
    else:
        # Do not silently replace an active pack node. Root sync is called by
        # root callbacks only, so this path is mainly a defensive fallback.
        stack.append(node)
    _write_runtime(manager, stack, save=save)
    return node


def sync_current_pack(manager, pack, page=None, save=False):
    stack = load_stack(manager)
    node = capture_pack(manager, pack, page=page)
    if stack and stack[-1].get("kind") == "pack":
        stack[-1] = node
    else:
        if not stack:
            stack.append(capture_root(manager))
        stack.append(node)
    _write_runtime(manager, stack, save=save)
    return node


def switch_root(manager, save=False):
    """Sidebar navigation: the selected top-level section becomes a new path."""
    node = capture_root(manager)
    _debug(manager, "switch_root nav={} scroll={}".format(
        node.get("state", {}).get("custom_pose_ui_active_nav"),
        node.get("state", {}).get("custom_pose_ui_scroll_row"),
    ))
    _write_runtime(manager, [node], save=save)
    return node


def push_root(manager, save=False):
    """Push a creator/group subview after the caller has applied its state."""
    stack = ensure_root(manager, save=False)
    node = capture_root(manager)
    if stack and stack[-1] == node:
        return node
    stack.append(node)
    _write_runtime(manager, stack, save=save)
    _debug(manager, "push_root depth={} nav={}".format(
        len(stack), node.get("state", {}).get("custom_pose_ui_active_nav")
    ))
    return node


def enter_pack(manager, pack, page=None, save=False):
    """Push a pack detail while keeping the exact root/group parent below it."""
    stack = ensure_root(manager, save=False)
    # Root caller has already set its current scroll row; snapshot it first.
    if stack[-1].get("kind") == "root":
        stack[-1] = capture_root(manager, previous=stack[-1])
    elif stack[-1].get("kind") == "pack":
        # Defensive replacement when a caller jumps pack->pack directly.
        stack.pop()

    node = capture_pack(manager, pack, page=page)
    stack.append(node)
    _write_runtime(manager, stack, save=save)
    _debug(manager, "enter_pack depth={} pack={} page={}".format(
        len(stack), node.get("pack_id"), node.get("page")
    ))
    return node


def _clear_transients(state):
    if state is None:
        return
    for key in _TRANSIENT_ROOT_FIELDS:
        try:
            setattr(state, key, None)
        except Exception:
            pass
    try:
        state.custom_pose_ui_edit_inner_group = None
    except Exception:
        pass


def apply_root(manager, node):
    state = _state(manager)
    if state is None or not isinstance(node, dict):
        return False
    fields = node.get("state", {})
    if not isinstance(fields, dict):
        return False
    for key in _ROOT_STATE_FIELDS:
        if key not in fields:
            continue
        value = fields.get(key)
        if key in ("custom_pose_ui_active_nav", "custom_pose_ui_scroll_row", "custom_pose_ui_creator_view_mode"):
            value = _safe_int(value, 0)
        elif key in ("custom_pose_ui_favorite_only", "custom_pose_ui_blank_pack_view"):
            value = bool(value)
        try:
            setattr(state, key, value)
        except Exception:
            pass

    view = node.get("view", {}) if isinstance(node.get("view"), dict) else {}
    query = str(view.get("query", fields.get("custom_pose_ui_query", "")) or "")
    if query.strip():
        effective_page = max(0, _safe_int(view.get("search_page", fields.get("custom_pose_ui_scroll_row", 0)), 0))
    else:
        effective_page = max(0, _safe_int(view.get("plain_page", fields.get("custom_pose_ui_scroll_row", 0)), 0))
    try:
        state.custom_pose_ui_query = query
        state.custom_pose_ui_scroll_row = effective_page
    except Exception:
        pass
    _clear_transients(state)
    return True


def resolve_pack(manager, pack_id):
    pack_id = str(pack_id or "")
    if not pack_id:
        return None
    try:
        manager.build_cache_safe()
    except Exception:
        pass
    try:
        cache = getattr(manager.state, "all_packs_cache", {}) or {}
        pack = cache.get(pack_id)
        if pack is not None:
            return pack
    except Exception:
        pass
    try:
        return manager.deserialize_pack_reference(pack_id)
    except Exception:
        return None


def apply_pack(manager, node):
    state = _state(manager)
    if state is None or not isinstance(node, dict):
        return None
    pack_id = str(node.get("pack_id", "") or "")
    pack = resolve_pack(manager, pack_id)
    if pack is None:
        return None

    try:
        state.custom_pose_ui_favorite_only = bool(node.get("favorite_only", False))
    except Exception:
        pass
    try:
        state.custom_pose_ui_active_inner_group = node.get("active_inner_group")
    except Exception:
        pass
    try:
        pages = getattr(state, "custom_pose_ui_pack_pages", None)
        if not isinstance(pages, dict):
            pages = {}
            state.custom_pose_ui_pack_pages = pages
        pages[pack_id] = max(0, _safe_int(node.get("page", 0), 0))
    except Exception:
        pass
    _clear_transients(state)
    return pack


def apply_current(manager):
    """Apply the current path and return (kind, pack_or_none)."""
    stack = load_stack(manager)
    if not stack:
        return None, None

    # A pack node needs its parent root/group context restored first.
    parent_root = None
    for node in reversed(stack[:-1]):
        if node.get("kind") == "root":
            parent_root = node
            break
    if parent_root is not None:
        apply_root(manager, parent_root)

    top = stack[-1]
    if top.get("kind") == "root":
        apply_root(manager, top)
        return "root", None

    pack = apply_pack(manager, top)
    if pack is None:
        # Deleted/missing pack: drop the stale leaf and return to its parent.
        stack.pop()
        if not stack:
            stack = [capture_root(manager)]
        _write_runtime(manager, stack, save=False)
        return apply_current(manager)
    return "pack", pack


def back(manager, save=False):
    """Pop exactly one navigational level and apply the new top node."""
    stack = load_stack(manager)
    if len(stack) <= 1:
        if stack:
            apply_current(manager)
        return None
    popped = stack.pop()
    _write_runtime(manager, stack, save=save)
    kind, pack = apply_current(manager)
    _debug(manager, "back popped={} depth={} -> {}".format(
        popped.get("kind"), len(stack), kind
    ))
    return kind, pack


def can_back(manager):
    return len(load_stack(manager)) > 1


def persist(manager):
    """Persist the in-memory stack through the existing user-data save path."""
    stack = load_stack(manager)
    _write_runtime(manager, stack, save=True)
    return stack


def migrate_legacy_if_needed(manager):
    """
    Best-effort one-time migration.

    Old saves know only a single last_ui_snapshot. We cannot reconstruct every
    historical parent perfectly, but we can preserve the important invariant:
    reopening the manager returns to the last pack, with an all/current-root
    parent underneath so Back is always sane.
    """
    if load_stack(manager):
        return False

    state = _state(manager)
    if state is None:
        return False

    snapshot = getattr(state, "last_ui_snapshot", None)
    pack_ref = None
    if isinstance(snapshot, dict):
        pack_ref = snapshot.get("selected_pose_pack")
    if not pack_ref:
        pack_ref = getattr(state, "last_ui_selection", None)

    root_node = capture_root(manager)
    stack = [root_node]
    pack = resolve_pack(manager, pack_ref) if pack_ref else None
    if pack is not None:
        stack.append(capture_pack(manager, pack, page=0))
    _write_runtime(manager, stack, save=False)
    _debug(manager, "migrated legacy stack depth={}".format(len(stack)))
    return True
