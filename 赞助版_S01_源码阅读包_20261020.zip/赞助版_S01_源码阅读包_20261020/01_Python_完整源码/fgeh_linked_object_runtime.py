from objects.persistence_groups import PersistenceGroups
from objects.system import create_object

from fgeh_config import is_positioning_helper_definition_id


_spawned_objects_by_sim = {}


def _runtime_log(message, *args):
    try:
        from fgeh_cas_accessory_outfit_utils import debug_log
        debug_log("linked object runtime: " + str(message), *args)
    except Exception:
        pass


def _safe_int(value):
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _get_sim_key(sim):
    if sim is None:
        return None
    sim_info = getattr(sim, "sim_info", None)
    sim_id = getattr(sim_info, "sim_id", None)
    if sim_id is None:
        sim_id = getattr(sim, "sim_id", None)
    if sim_id is None:
        sim_id = getattr(sim, "id", None)
    if sim_id is None:
        return None
    return _safe_int(sim_id)


def _is_live_object(obj):
    if obj is None:
        return False
    try:
        if getattr(obj, "is_being_destroyed", False):
            return False
    except Exception:
        pass
    try:
        return getattr(obj, "id", None) is not None
    except Exception:
        return False


def _prune_spawned_object_registry():
    for sim_key, objects in tuple(_spawned_objects_by_sim.items()):
        live_objects = [obj for obj in objects if _is_live_object(obj)]
        if live_objects:
            _spawned_objects_by_sim[sim_key] = live_objects
        else:
            _spawned_objects_by_sim.pop(sim_key, None)


def _safe_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    try:
        return list(value)
    except Exception:
        return []


def _get_variant_definition_id(variant):
    for attr_name in ("object_definition_id", "definition_id"):
        definition_id = _safe_int(getattr(variant, attr_name, None))
        if definition_id:
            return definition_id
    return 0


def _get_variant_label(variant, fallback):
    for attr_name in ("label", "display_name", "name"):
        value = str(getattr(variant, attr_name, "") or "").strip()
        if value:
            return value
    return fallback


def _entry_pose_names(entry):
    raw_pose_names = getattr(entry, "pose_names", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "poses", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "pose_name", None)
    if raw_pose_names is None:
        return []
    if isinstance(raw_pose_names, str):
        raw_pose_names = [raw_pose_names]

    result = []
    for pose_name in _safe_list(raw_pose_names):
        pose_name = str(pose_name or "").strip()
        if pose_name:
            result.append(pose_name)
    return result


def _entry_matches_pose(entry_info, pose_name):
    entry = (entry_info or {}).get("entry")
    pose_names = _entry_pose_names(entry)
    if not pose_names:
        return True
    return str(pose_name or "") in pose_names


def iter_linked_object_variant_options(pack_cache, pack_id, pose_name):
    try:
        from fgeh_pose_requirement_registry import OBJECT_GROUP_TYPE, iter_requirement_sources_for_pack
    except Exception:
        return

    seen = set()
    for source in iter_requirement_sources_for_pack(pack_cache, pack_id, group_type=OBJECT_GROUP_TYPE):
        entry_info = source.get("entry_info") or {}
        if not _entry_matches_pose(entry_info, pose_name):
            continue

        source_origin = "local" if entry_info.get("snippet") is None else "external"
        source_label = "游戏内绑定" if source_origin == "local" else "外部联动包"
        source_type = str(entry_info.get("source_type") or "unknown")
        entry = entry_info.get("entry")
        entry_label = _get_variant_label(entry, "") if entry is not None else ""
        for variant in _safe_list(entry_info.get("variants")):
            definition_id = _get_variant_definition_id(variant)
            if is_positioning_helper_definition_id(definition_id):
                _runtime_log(
                    "candidate skipped internal positioning helper pose={} pack_id={} definition_id={} source_origin={}",
                    pose_name,
                    pack_id,
                    definition_id,
                    source_origin,
                )
                continue
            if not definition_id or definition_id in seen:
                continue
            seen.add(definition_id)
            yield {
                "definition_id": definition_id,
                "label": _get_variant_label(variant, "Object {}".format(len(seen))),
                "display_name": str(getattr(variant, "display_name", "") or ""),
                "entry_label": entry_label or _get_variant_label(variant, "Object {}".format(len(seen))),
                "note": str(getattr(variant, "note", "") or ""),
                "catalog_name": getattr(variant, "catalog_name", None),
                "source_origin": source_origin,
                "source_label": source_label,
                "source_type": source_type,
            }


def _iter_object_definition_ids(
    pack_cache,
    pack_id,
    pose_name,
    selected_definition_id=0,
    selected_definition_ids=None,
    options=None,
):
    selected_definition_id = _safe_int(selected_definition_id)
    if options is None:
        options = list(iter_linked_object_variant_options(pack_cache, pack_id, pose_name))
    if selected_definition_ids is not None:
        selected_ids = set()
        for value in selected_definition_ids or []:
            definition_id = _safe_int(value)
            if definition_id:
                selected_ids.add(definition_id)
        for option in options:
            definition_id = _safe_int(option.get("definition_id"))
            if definition_id in selected_ids:
                yield definition_id
        return

    if selected_definition_id:
        for option in options:
            definition_id = _safe_int(option.get("definition_id"))
            if definition_id == selected_definition_id:
                yield definition_id
                return

    for option in options:
        definition_id = _safe_int(option.get("definition_id"))
        if definition_id:
            yield definition_id


def _create_linked_object(definition_id, location):
    if not definition_id or location is None:
        return None
    if is_positioning_helper_definition_id(definition_id):
        _runtime_log(
            "create blocked internal positioning helper definition_id={}",
            definition_id,
        )
        return None

    def initialize_object(obj):
        try:
            obj.persistence_group = PersistenceGroups.NONE
        except Exception:
            pass

    try:
        obj = create_object(definition_id, init=initialize_object)
    except Exception as exc:
        _runtime_log("create failed definition_id={} error={}", definition_id, exc)
        return None
    if obj is None:
        _runtime_log("create returned None definition_id={}", definition_id)
        return None

    try:
        obj.location = location
    except Exception as exc:
        _runtime_log("location failed definition_id={} object={} error={}", definition_id, obj, exc)
        destroy_linked_object(obj)
        return None

    try:
        obj.opacity = 1.0
    except Exception:
        pass

    actual_definition_id = 0
    definition = getattr(obj, "definition", None)
    for attr_name in ("id", "guid64"):
        actual_definition_id = _safe_int(getattr(definition, attr_name, None))
        if actual_definition_id:
            break
    _runtime_log(
        "create success requested_definition_id={} actual_definition_id={} object_id={} object_type={} location={}",
        definition_id,
        actual_definition_id,
        getattr(obj, "id", None),
        type(obj).__name__,
        getattr(obj, "location", None),
    )

    try:
        obj._fgeh_linked_generated = True
    except Exception:
        pass

    return obj


def destroy_linked_object(obj, duration=0.2):
    if obj is None:
        return
    try:
        obj.destroy(
            source=obj,
            cause="FGEH linked pose object cleanup",
            fade_duration=float(duration),
        )
        return
    except Exception:
        pass
    try:
        obj.schedule_destroy_asap(
            source=obj,
            cause="FGEH linked pose object cleanup",
        )
    except Exception:
        pass


def spawn_matching_linked_objects(target_sim, pose_name=None, pose_pack=None, pack_cache=None, selected_definition_id=0, selected_definition_ids=None):
    if target_sim is None or pose_pack is None:
        return []

    pack_id = str(getattr(pose_pack, "__name__", "") or getattr(pose_pack, "pack_id", "") or "")
    if not pack_id:
        return []

    location = getattr(target_sim, "location", None)
    if location is None:
        return []

    sim_key = _get_sim_key(target_sim)
    _runtime_log(
        "spawn begin sim_id={} pose={} pack_id={} selected_ids={}",
        sim_key,
        pose_name,
        pack_id,
        selected_definition_ids,
    )
    options = list(iter_linked_object_variant_options(pack_cache or {}, pack_id, pose_name))
    _runtime_log(
        "spawn candidates pose={} pack_id={} options={}",
        pose_name,
        pack_id,
        [
            {
                "definition_id": option.get("definition_id"),
                "source_origin": option.get("source_origin"),
                "source_type": option.get("source_type"),
                "label": option.get("label"),
            }
            for option in options
        ],
    )
    spawned = []
    for definition_id in _iter_object_definition_ids(
        pack_cache or {},
        pack_id,
        pose_name,
        selected_definition_id=selected_definition_id,
        selected_definition_ids=selected_definition_ids,
        options=options,
    ):
        obj = _create_linked_object(definition_id, location)
        if obj is not None:
            spawned.append(obj)

    if spawned and sim_key is not None:
        for obj in spawned:
            try:
                obj._fgeh_linked_owner_sim_id = sim_key
            except Exception:
                pass
        registered = _spawned_objects_by_sim.setdefault(sim_key, [])
        registered_ids = {
            getattr(existing, "id", None)
            for existing in registered
            if _is_live_object(existing)
        }
        registered.extend(
            obj for obj in spawned
            if getattr(obj, "id", None) not in registered_ids
        )

    _runtime_log(
        "spawn end sim_id={} pose={} created_count={} object_ids={} registry_keys={}",
        sim_key,
        pose_name,
        len(spawned),
        [getattr(obj, "id", None) for obj in spawned],
        list(_spawned_objects_by_sim.keys()),
    )

    return spawned


def register_spawned_linked_objects(target_sim, objects):
    """Register externally spawned layout objects for existing cleanup flows."""
    sim_key = _get_sim_key(target_sim)
    if sim_key is None:
        return 0
    registered = _spawned_objects_by_sim.setdefault(sim_key, [])
    registered_ids = {
        getattr(existing, "id", None)
        for existing in registered
        if _is_live_object(existing)
    }
    added = 0
    for obj in objects or ():
        if not _is_live_object(obj):
            continue
        object_id = getattr(obj, "id", None)
        if object_id in registered_ids:
            continue
        try:
            obj._fgeh_linked_generated = True
            obj._fgeh_linked_owner_sim_id = sim_key
        except Exception:
            pass
        registered.append(obj)
        registered_ids.add(object_id)
        added += 1
    _runtime_log(
        "register external sim_id={} added_count={} object_ids={}",
        sim_key,
        added,
        [getattr(obj, "id", None) for obj in objects or ()],
    )
    return added


def destroy_linked_objects_for_sim(sim):
    _prune_spawned_object_registry()
    sim_key = _get_sim_key(sim)
    if sim_key is None:
        _runtime_log("destroy skipped: no sim key target={}", sim)
        return 0

    objects = _spawned_objects_by_sim.pop(sim_key, [])
    _runtime_log(
        "destroy sim_id={} count={} object_ids={} registry_keys_before={}",
        sim_key,
        len(objects),
        [getattr(obj, "id", None) for obj in objects],
        list(_spawned_objects_by_sim.keys()),
    )
    destroyed = 0
    for obj in list(objects):
        destroy_linked_object(obj)
        destroyed += 1
    return destroyed


def destroy_all_linked_objects(objects=None):
    _prune_spawned_object_registry()
    registry_keys = list(_spawned_objects_by_sim.keys())
    if objects is None:
        objects = get_all_spawned_linked_objects()
    objects_by_id = {
        getattr(obj, "id", None): obj
        for obj in objects or ()
        if _is_live_object(obj)
    }
    for registry_objects in _spawned_objects_by_sim.values():
        for obj in registry_objects:
            object_id = getattr(obj, "id", None)
            if object_id not in objects_by_id and _is_live_object(obj):
                objects_by_id[object_id] = obj
    destroyed = 0
    _spawned_objects_by_sim.clear()
    for obj in objects_by_id.values():
        destroy_linked_object(obj)
        destroyed += 1
    _runtime_log(
        "destroy current lot linked objects count={} registry_keys={}",
        destroyed,
        registry_keys,
    )
    return destroyed


def get_spawned_linked_objects_for_sim(sim):
    """Return live objects created by this mod for one Sim.

    The positioning layer uses this narrow read-only bridge instead of
    touching the runtime registry directly.
    """
    _prune_spawned_object_registry()
    sim_key = _get_sim_key(sim)
    if sim_key is None:
        return []
    return list(_spawned_objects_by_sim.get(sim_key, ()))


def get_all_spawned_linked_objects(include_lot_scan=True):
    """Return all live linked objects created during the current lot session.

    The optional lot scan is intentionally reserved for explicit cleanup UI.
    It recovers objects marked by this mod after a script reload without
    making normal pose or positioning paths scan the whole object manager.
    """
    _prune_spawned_object_registry()
    result = []
    seen_ids = set()
    for objects in _spawned_objects_by_sim.values():
        for obj in objects:
            object_id = getattr(obj, "id", None)
            if object_id in seen_ids:
                continue
            seen_ids.add(object_id)
            result.append(obj)
    if include_lot_scan:
        try:
            import services
            object_manager = services.object_manager()
            for obj in object_manager.get_all() if object_manager is not None else ():
                if not getattr(obj, "_fgeh_linked_generated", False):
                    continue
                if not _is_live_object(obj):
                    continue
                object_id = getattr(obj, "id", None)
                if object_id in seen_ids:
                    continue
                seen_ids.add(object_id)
                result.append(obj)
        except Exception:
            pass
    return result
