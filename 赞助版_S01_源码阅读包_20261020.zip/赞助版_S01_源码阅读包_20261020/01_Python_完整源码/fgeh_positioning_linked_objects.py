"""Small bridge between positioning sessions and generated linked objects.

The object runtime owns object creation and tracking.  The positioning system
only asks this module whether automatic linking is enabled and to attach live
tracked objects to a session when the user moves a Sim.
"""


SETTING_NAME = "auto_link_spawned_objects_during_positioning"


def is_auto_link_spawned_objects_enabled():
    try:
        from fgeh_state import state
        return bool(getattr(state, SETTING_NAME, False))
    except Exception:
        return False


def set_auto_link_spawned_objects_enabled(enabled, persist=True):
    enabled = bool(enabled)
    try:
        from fgeh_state import state
        setattr(state, SETTING_NAME, enabled)
    except Exception:
        return enabled

    if persist:
        try:
            from couplepose1 import save_favorites
            save_favorites()
        except Exception:
            pass
    return enabled


def _iter_session_sims(session):
    seen_ids = set()
    candidates = []
    try:
        candidates.extend(session.get_actors_list() or ())
    except Exception:
        pass
    for getter_name in ("get_target_sim", "get_source_sim"):
        try:
            candidates.append(getattr(session, getter_name)())
        except Exception:
            pass

    for sim in candidates:
        if sim is None:
            continue
        sim_id = getattr(sim, "sim_id", None)
        if sim_id is None:
            sim_id = getattr(sim, "id", None)
        if sim_id is None:
            sim_id = id(sim)
        if sim_id in seen_ids:
            continue
        seen_ids.add(sim_id)
        yield sim


def sync_spawned_objects_to_session(session):
    """Attach tracked generated objects to a positioning session.

    Existing nodes are left unchanged, so calling this from a movement
    callback is idempotent and does not reset offsets or selection state.
    """
    if session is None or not is_auto_link_spawned_objects_enabled():
        return 0

    try:
        from fgeh_linked_object_runtime import get_spawned_linked_objects_for_sim
    except Exception:
        return 0

    added = 0
    seen_ids = set()
    for sim in _iter_session_sims(session):
        for obj in get_spawned_linked_objects_for_sim(sim):
            object_id = getattr(obj, "id", None)
            if object_id in seen_ids:
                continue
            seen_ids.add(object_id)
            try:
                if session.get_node_for_owner(obj) is None:
                    if session.add_prop(obj) is not None:
                        added += 1
            except Exception:
                continue
    return added


def clear_current_lot_generated_objects():
    """Remove tracked generated objects and detach them from live sessions."""
    try:
        from fgeh_linked_object_runtime import (
            destroy_all_linked_objects,
            get_all_spawned_linked_objects,
        )
    except Exception:
        return 0

    objects = get_all_spawned_linked_objects()
    try:
        from andrew_positioning_session import get_all_andrew_positioning_sessions
        sessions = get_all_andrew_positioning_sessions()
    except Exception:
        sessions = ()

    for session in sessions:
        for obj in objects:
            try:
                if session.get_node_for_owner(obj) is not None:
                    session.remove_prop(obj)
            except Exception:
                continue

    return destroy_all_linked_objects(objects)
