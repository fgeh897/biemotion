"""Persistent links from individual poses to object layout preset IDs."""

import json
import os
import time

try:
    import fgeh_cas_accessory_settings as release_settings
except Exception:
    release_settings = None


POSE_LAYOUT_BINDINGS_FILENAME = "fgeh_pose_layout_bindings.json"
POSE_LAYOUT_BINDINGS_TMP_FILENAME = "fgeh_pose_layout_bindings_tmp"
SCHEMA_VERSION = 1
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))


def _linked_object_layouts_enabled():
    return bool(getattr(release_settings, "ENABLE_LINKED_OBJECT_LAYOUTS", False))


def get_mod_directory():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        return MODULE_DIR


def _binding_log(message, *args):
    try:
        from fgeh_positioning_log import positioning_log
        positioning_log("pose layout binding: " + str(message), *args)
    except Exception:
        pass


def _candidate_dirs():
    dirs = []
    for folder in (get_mod_directory(), MODULE_DIR):
        if folder and folder not in dirs:
            dirs.append(folder)
    return dirs


def _primary_dir():
    for folder in _candidate_dirs():
        try:
            if os.path.isdir(folder):
                return folder
        except Exception:
            pass
    return MODULE_DIR


def _path_in(folder, filename):
    return os.path.join(folder, filename)


def _now_stamp():
    try:
        return int(time.time())
    except Exception:
        return 0


def _safe_int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _clean_preset_ids(preset_ids):
    result = []
    for preset_id in preset_ids or ():
        preset_id = str(preset_id or "").strip()
        if preset_id and preset_id not in result:
            result.append(preset_id)
    return result


def _normalize_binding(binding):
    if not isinstance(binding, dict):
        return None
    pack_id = str(binding.get("pack_id") or "").strip()
    pose_name = str(binding.get("pose_name") or "").strip()
    if not pack_id or not pose_name:
        return None
    return {
        "pack_id": pack_id,
        "pose_name": pose_name,
        "preset_ids": _clean_preset_ids(binding.get("preset_ids")),
        "created_at": _safe_int(binding.get("created_at")),
        "updated_at": _safe_int(binding.get("updated_at")),
    }


def _load_json_dict(path):
    try:
        if not path or not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _load_data():
    bindings = []
    seen = set()
    version = SCHEMA_VERSION
    for folder in _candidate_dirs():
        data = _load_json_dict(_path_in(folder, POSE_LAYOUT_BINDINGS_FILENAME))
        if data is None:
            continue
        try:
            version = max(version, _safe_int(data.get("version")) or SCHEMA_VERSION)
        except Exception:
            pass
        for raw_binding in data.get("bindings", ()) or ():
            binding = _normalize_binding(raw_binding)
            if binding is None:
                continue
            key = (binding["pack_id"], binding["pose_name"])
            if key in seen:
                continue
            seen.add(key)
            bindings.append(binding)
    return {"version": version, "bindings": bindings}


def _save_data(data):
    try:
        target_dir = _primary_dir()
        target_path = _path_in(target_dir, POSE_LAYOUT_BINDINGS_FILENAME)
        temp_path = _path_in(target_dir, POSE_LAYOUT_BINDINGS_TMP_FILENAME)
        with open(temp_path, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False)
        if _load_json_dict(temp_path) is None:
            return False
        os.replace(temp_path, target_path)
        _binding_log("saved path={} bindings={}", target_path, len(data.get("bindings", ()) or ()))
        return True
    except Exception as exc:
        _binding_log("save failed error={}", exc)
        return False


def get_bound_preset_ids(pack_id, pose_name):
    if not _linked_object_layouts_enabled():
        return []
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    if not pack_id or not pose_name:
        return []
    for binding in _load_data().get("bindings", ()) or ():
        if binding.get("pack_id") == pack_id and binding.get("pose_name") == pose_name:
            return list(binding.get("preset_ids", ()) or ())
    return []


def is_preset_bound(pack_id, pose_name, preset_id):
    preset_id = str(preset_id or "").strip()
    return bool(preset_id and preset_id in get_bound_preset_ids(pack_id, pose_name))


def set_bound_preset_ids(pack_id, pose_name, preset_ids):
    if not _linked_object_layouts_enabled():
        return False
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    preset_ids = _clean_preset_ids(preset_ids)
    if not pack_id or not pose_name:
        return False

    data = _load_data()
    bindings = data.setdefault("bindings", [])
    now = _now_stamp()
    for index, binding in enumerate(list(bindings)):
        if not isinstance(binding, dict):
            continue
        if binding.get("pack_id") != pack_id or binding.get("pose_name") != pose_name:
            continue
        if not preset_ids:
            bindings.pop(index)
        else:
            binding["preset_ids"] = preset_ids
            binding["updated_at"] = now
        data["version"] = max(_safe_int(data.get("version")) or SCHEMA_VERSION, SCHEMA_VERSION)
        return _save_data(data)

    if not preset_ids:
        return True
    bindings.append({
        "pack_id": pack_id,
        "pose_name": pose_name,
        "preset_ids": preset_ids,
        "created_at": now,
        "updated_at": now,
    })
    data["version"] = max(_safe_int(data.get("version")) or SCHEMA_VERSION, SCHEMA_VERSION)
    return _save_data(data)


def toggle_preset_binding(pack_id, pose_name, preset_id):
    preset_id = str(preset_id or "").strip()
    if not preset_id:
        return False, []
    preset_ids = get_bound_preset_ids(pack_id, pose_name)
    if preset_id in preset_ids:
        preset_ids = [value for value in preset_ids if value != preset_id]
    else:
        preset_ids.append(preset_id)
    return set_bound_preset_ids(pack_id, pose_name, preset_ids), preset_ids


def add_preset_binding(pack_id, pose_name, preset_id):
    preset_id = str(preset_id or "").strip()
    if not preset_id:
        return False
    preset_ids = get_bound_preset_ids(pack_id, pose_name)
    if preset_id in preset_ids:
        return True
    preset_ids.append(preset_id)
    return set_bound_preset_ids(pack_id, pose_name, preset_ids)


def get_pose_refs_for_preset(preset_id):
    if not _linked_object_layouts_enabled():
        return []
    preset_id = str(preset_id or "").strip()
    if not preset_id:
        return []
    refs = []
    for binding in _load_data().get("bindings", ()) or ():
        if preset_id not in binding.get("preset_ids", ()):
            continue
        refs.append({
            "pack_id": binding.get("pack_id"),
            "pose_name": binding.get("pose_name"),
        })
    return refs


def copy_pose_layout_bindings_to_refs(pack_id, source_pose_name, refs):
    if not _linked_object_layouts_enabled():
        return 0
    pack_id = str(pack_id or "").strip()
    source_pose_name = str(source_pose_name or "").strip()
    if not pack_id or not source_pose_name:
        return 0
    source_ids = get_bound_preset_ids(pack_id, source_pose_name)
    changed = 0
    for ref in refs or ():
        if isinstance(ref, dict):
            ref_pack_id = str(ref.get("pack_id") or "").strip()
            pose_name = str(ref.get("pose_name") or "").strip()
        elif isinstance(ref, (tuple, list)) and len(ref) >= 2:
            ref_pack_id = str(ref[0] or "").strip()
            pose_name = str(ref[1] or "").strip()
        else:
            continue
        if ref_pack_id != pack_id or not pose_name or pose_name == source_pose_name:
            continue
        if get_bound_preset_ids(pack_id, pose_name) == source_ids:
            continue
        if set_bound_preset_ids(pack_id, pose_name, source_ids):
            changed += 1
    return changed


def delete_pose_layout_refs(refs):
    if not _linked_object_layouts_enabled():
        return 0
    keys = set()
    for ref in refs or ():
        if isinstance(ref, dict):
            key = (str(ref.get("pack_id") or "").strip(), str(ref.get("pose_name") or "").strip())
        elif isinstance(ref, (tuple, list)) and len(ref) >= 2:
            key = (str(ref[0] or "").strip(), str(ref[1] or "").strip())
        else:
            continue
        if key[0] and key[1]:
            keys.add(key)
    if not keys:
        return 0
    data = _load_data()
    old_bindings = data.get("bindings", []) or []
    new_bindings = [
        binding for binding in old_bindings
        if (str(binding.get("pack_id") or "").strip(), str(binding.get("pose_name") or "").strip()) not in keys
    ]
    removed = len(old_bindings) - len(new_bindings)
    if not removed:
        return 0
    data["bindings"] = new_bindings
    return removed if _save_data(data) else 0
