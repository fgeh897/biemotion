import os
import time
import traceback

import services
import sims4.resources

import injector2

from event_testing.results import TestResult
from interactions.base.immediate_interaction import ImmediateSuperInteraction
from sims.sim import Sim
from sims4.resources import Types
from sims4.tuning.instance_manager import InstanceManager


_AFFORDANCE_CACHE = {}
_PROCESSED_OBJECT_MANAGER_IDS = set()

from fgeh_config import (
    LINKED_OBJECT_BIND_INTERACTION_ID,
    is_positioning_helper_definition_id,
)
from fgeh_linked_object_bindings import get_mod_directory, save_object_binding_for_poses
try:
    import fgeh_cas_accessory_settings as release_settings
except Exception:
    release_settings = None


ENABLE_BINDING_DEBUG_LOG = bool(
    getattr(release_settings, "ENABLE_LINKED_OBJECT_BINDING_DEBUG_LOG", False)
)
LOG_FILE_NAME = "fgeh_linked_object_binding_debug.log"


def _binding_log(message, exc=None):
    return  # R26: release diagnostic/file output disabled.


_binding_log("module imported; interaction_id={}".format(LINKED_OBJECT_BIND_INTERACTION_ID))


def _safe_int(value):
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _get_definition_id(obj):
    definition = getattr(obj, "definition", None)
    for attr_name in ("id", "guid64"):
        definition_id = _safe_int(getattr(definition, attr_name, None))
        if definition_id:
            return definition_id
    return 0


def _text_from_value(value):
    try:
        if value is None:
            return ""
        text = str(value).strip()
        if text and text.lower() not in ("none", "null"):
            return text
    except Exception:
        pass
    return ""


def _get_object_display_name(obj):
    for method_name in ("get_display_name", "get_catalog_name"):
        method = getattr(obj, method_name, None)
        if callable(method):
            text = _text_from_value(method())
            if text:
                return text

    for attr_name in ("display_name", "catalog_name", "name"):
        text = _text_from_value(getattr(obj, attr_name, None))
        if text:
            return text

    definition = getattr(obj, "definition", None)
    for attr_name in ("display_name", "name", "__name__"):
        text = _text_from_value(getattr(definition, attr_name, None))
        if text:
            return text

    definition_id = _get_definition_id(obj)
    return "Object {}".format(definition_id) if definition_id else "Object"


def _is_valid_object_target(target):
    if target is None:
        _binding_log("target test failed: target is None")
        return False
    target_text = str(target)
    target_type = type(target).__name__
    if target_type == "TerrainPoint" or "object_terrain" in target_text:
        _binding_log("target test failed: terrain target {}; type={}".format(target, target_type))
        return False
    if getattr(target, "is_sim", False):
        _binding_log("target test failed: target is sim {}".format(target))
        return False
    if isinstance(target, Sim):
        _binding_log("target test failed: target is Sim instance {}".format(target))
        return False
    if getattr(target, "is_part", False):
        _binding_log("target test failed: target is object part {}".format(target))
        return False
    if getattr(target, "location", None) is None:
        _binding_log("target test failed: target has no location {}".format(target))
        return False
    definition_id = _get_definition_id(target)
    if not definition_id:
        _binding_log("target test failed: missing definition id {}".format(target))
        return False
    if is_positioning_helper_definition_id(definition_id):
        _binding_log(
            "target test failed: internal positioning helper definition_id={}".format(
                definition_id
            )
        )
        return False
    return True


def _is_pose_interaction(interaction):
    if interaction is None:
        return False
    try:
        if getattr(interaction, "has_been_canceled", False):
            return False
        if getattr(interaction, "has_been_killed", False):
            return False
    except Exception:
        pass
    if getattr(interaction, "pose_name", None):
        return True
    try:
        affordance = getattr(interaction, "affordance", None)
        module_name = getattr(affordance, "__module__", "")
        class_name = getattr(affordance, "__name__", "")
        return module_name == "poseplayer" and "Pose" in class_name
    except Exception:
        return False


def _iter_sim_interactions(sim):
    if sim is None:
        return
    getter = getattr(sim, "get_all_running_and_queued_interactions", None)
    if callable(getter):
        try:
            for interaction in getter():
                yield interaction
            return
        except Exception:
            pass
    for attr_name in ("queue", "si_state"):
        try:
            for interaction in getattr(sim, attr_name, ()):
                yield interaction
        except Exception:
            pass


def _get_pose_interaction_for_sim(sim):
    checked = 0
    for interaction in _iter_sim_interactions(sim):
        checked += 1
        if _is_pose_interaction(interaction):
            _binding_log("pose interaction found on sim {}; checked={}; pose_name={}".format(
                getattr(sim, "id", sim),
                checked,
                getattr(interaction, "pose_name", None),
            ))
            return interaction
    _binding_log("no pose interaction on sim {}; checked={}".format(getattr(sim, "id", sim), checked))
    return None


def _iter_instanced_sims():
    try:
        for obj in services.object_manager().get_all():
            if getattr(obj, "is_sim", False):
                yield obj
    except Exception:
        try:
            for sim_info in services.sim_info_manager().instanced_sims_gen():
                getter = getattr(sim_info, "get_sim_instance", None)
                sim = getter() if callable(getter) else sim_info
                if sim is not None and getattr(sim, "is_sim", False):
                    yield sim
        except Exception:
            return


def _find_pose_interaction(context=None):
    actor = getattr(context, "sim", None) if context is not None else None
    _binding_log("finding pose interaction; actor={}".format(getattr(actor, "id", actor)))
    if actor is not None:
        interaction = _get_pose_interaction_for_sim(actor)
        if interaction is not None:
            return actor, interaction
    for sim in _iter_instanced_sims():
        interaction = _get_pose_interaction_for_sim(sim)
        if interaction is not None:
            return sim, interaction
    return None, None


def _iter_pose_packs():
    try:
        manager = services.get_instance_manager(Types.SNIPPET)
        for _, pack in manager._tuned_classes.items():
            if hasattr(pack, "s4s_mod_type") and str(pack.s4s_mod_type).upper() == "POSE_PACK":
                yield pack
    except Exception:
        return


def _pose_names_for_pack(pack_id, anchor_pose_name=""):
    pack_id = str(pack_id or "").strip()
    anchor_pose_name = str(anchor_pose_name or "").strip()
    result = []
    seen = set()
    if pack_id:
        for pack in _iter_pose_packs():
            candidate = str(getattr(pack, "__name__", "") or getattr(pack, "pack_id", "") or "").strip()
            if candidate != pack_id:
                continue
            for pose_item in getattr(pack, "pose_list", []) or []:
                name = str(getattr(pose_item, "pose_name", "") or "").strip()
                if name and name not in seen:
                    seen.add(name)
                    result.append(name)
            break
    if anchor_pose_name and anchor_pose_name not in seen:
        result.append(anchor_pose_name)
    return result


def _mark_definition_selected_for_poses(pack_id, pose_names, definition_id):
    changed = 0
    for pose_name in pose_names or ():
        if _mark_definition_selected_for_pose(pack_id, pose_name, definition_id):
            changed += 1
    return changed


def _find_pack_id_for_pose(pose_name):
    pose_name = str(pose_name or "").strip()
    if not pose_name:
        _binding_log("find pack skipped: empty pose_name")
        return ""
    for pack in _iter_pose_packs():
        for pose_item in getattr(pack, "pose_list", []) or []:
            if str(getattr(pose_item, "pose_name", "") or "") == pose_name:
                pack_id = str(getattr(pack, "__name__", "") or getattr(pack, "pack_id", "") or "")
                _binding_log("pack found for pose {}; pack_id={}".format(pose_name, pack_id))
                return pack_id
    _binding_log("pack not found for pose {}".format(pose_name))
    return ""


def get_current_pose_binding_target(context=None, target_sim=None):
    if target_sim is not None:
        sim = target_sim
        interaction = _get_pose_interaction_for_sim(target_sim)
    else:
        sim, interaction = _find_pose_interaction(context)
    if interaction is None:
        return "", ""
    pose_name = str(getattr(interaction, "pose_name", "") or "").strip()
    if not pose_name:
        _binding_log("current pose target failed: no pose_name; sim={}; interaction={}".format(getattr(sim, "id", sim), interaction))
        return "", ""
    pack_id = _find_pack_id_for_pose(pose_name)
    _binding_log("current pose target resolved: sim={}; pack_id={}; pose_name={}".format(getattr(sim, "id", sim), pack_id, pose_name))
    return pack_id, pose_name


def _get_current_pose_binding_target(context=None):
    return get_current_pose_binding_target(context=context)


def _mark_definition_selected_for_pose(pack_id, pose_name, definition_id):
    try:
        from couplepose1 import (
            get_enabled_linked_object_definition_ids,
            set_enabled_linked_object_definition_ids,
        )
        current = get_enabled_linked_object_definition_ids(pack_id, pose_name, None)
        if current is None:
            current = []
        cleaned = []
        for value in current or []:
            value = _safe_int(value)
            if value and value not in cleaned:
                cleaned.append(value)
        definition_id = _safe_int(definition_id)
        if definition_id and definition_id not in cleaned:
            cleaned.append(definition_id)
        set_enabled_linked_object_definition_ids(pack_id, pose_name, cleaned)
        _binding_log("current pose object selection updated; pack_id={}; pose_name={}; selected_count={}".format(
            pack_id,
            pose_name,
            len(cleaned),
        ))
        return True
    except Exception as exc:
        _binding_log("current pose object selection update failed", exc)
        return False


def _get_affordance(interaction_id):
    cached = _AFFORDANCE_CACHE.get(interaction_id)
    if cached is not None:
        return cached
    try:
        key = sims4.resources.get_resource_key(interaction_id, Types.INTERACTION)
        affordance = services.affordance_manager().get(key)
        if affordance is not None:
            _AFFORDANCE_CACHE[interaction_id] = affordance
        _binding_log("affordance lookup: key={}; found={}".format(key, affordance is not None))
        return affordance
    except Exception as exc:
        _binding_log("affordance lookup failed for {}".format(interaction_id), exc)
        return None


@injector2.inject(InstanceManager, "load_data_into_class_instances")
def _inject_linked_object_binding_affordance(original, self, *args, **kwargs):
    result = original(self, *args, **kwargs)
    if not bool(getattr(release_settings, "ENABLE_IN_GAME_OBJECT_BINDING", False)):
        return result
    if self.TYPE != Types.OBJECT:
        return result

    manager_id = id(self)
    if manager_id in _PROCESSED_OBJECT_MANAGER_IDS:
        return result

    affordance = _get_affordance(LINKED_OBJECT_BIND_INTERACTION_ID)
    if affordance is None:
        _binding_log("object affordance injection skipped: binding affordance missing")
        return result

    injected_count = 0
    for object_tuning in self._tuned_classes.values():
        if not hasattr(object_tuning, "_super_affordances"):
            continue
        if getattr(object_tuning, "provides_terrain_interactions", False):
            continue
        if getattr(object_tuning, "is_sim", False):
            continue
        affordances = tuple(getattr(object_tuning, "_super_affordances", ()))
        if affordance not in affordances:
            object_tuning._super_affordances = affordances + (affordance,)
            injected_count += 1
    _binding_log("object affordance injection finished; injected_count={}".format(injected_count))
    _PROCESSED_OBJECT_MANAGER_IDS.add(manager_id)
    return result


class FgehBindLinkedObjectToCurrentPoseInteraction(ImmediateSuperInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        if not bool(getattr(release_settings, "ENABLE_IN_GAME_OBJECT_BINDING", False)):
            return TestResult(False, "In-game object binding is disabled for this release profile.")
        _binding_log("_test entered; target={}; definition_id={}".format(target, _get_definition_id(target)))
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            _binding_log("_test super failed: {}".format(result))
            return result
        if not _is_valid_object_target(target):
            return TestResult(False, "Target is not a bindable object.")
        pack_id, pose_name = _get_current_pose_binding_target(context)
        if not pack_id or not pose_name:
            _binding_log("_test failed: no current pose; pack_id={}; pose_name={}".format(pack_id, pose_name))
            return TestResult(False, "No current pose found for linked object binding.")
        _binding_log("_test passed; pack_id={}; pose_name={}".format(pack_id, pose_name))
        return TestResult.TRUE

    def _run_interaction_gen(self, timeline):
        pack_id, pose_name = _get_current_pose_binding_target(getattr(self, "context", None))
        definition_id = _get_definition_id(self.target)
        display_name = _get_object_display_name(self.target)
        _binding_log("_run entered; pack_id={}; pose_name={}; definition_id={}; display_name={}".format(
            pack_id,
            pose_name,
            definition_id,
            display_name,
        ))
        if pack_id and pose_name and definition_id:
            # H60: one in-game object choice belongs to the whole Pose Pack.
            # Keep the existing per-Pose JSON schema; batch fan-out in one save.
            pose_names = _pose_names_for_pack(pack_id, pose_name)
            saved_count = save_object_binding_for_poses(
                pack_id,
                pose_names,
                definition_id,
                display_name=display_name,
                source_type="unknown",
            )
            try:
                from couplepose1 import clear_hidden_linked_object_definition_id
                for target_pose_name in pose_names:
                    clear_hidden_linked_object_definition_id(pack_id, target_pose_name, definition_id)
            except Exception:
                _binding_log("clear hidden object state after pack rebinding failed")
            _binding_log("pack binding saved; pack_id={}; anchor_pose={}; poses={}; saved_count={}; definition_id={}".format(
                pack_id, pose_name, len(pose_names), saved_count, definition_id
            ))
            try:
                from fgeh_pose_requirement_registry import clear_requirement_cache
                clear_requirement_cache()
                _binding_log("requirement cache cleared after pack binding")
            except Exception as exc:
                _binding_log("clear requirement cache failed", exc)
                pass
            _mark_definition_selected_for_poses(pack_id, pose_names, definition_id)
        else:
            _binding_log("binding skipped; missing pack/pose/definition")
        return True
        if False:
            yield None
