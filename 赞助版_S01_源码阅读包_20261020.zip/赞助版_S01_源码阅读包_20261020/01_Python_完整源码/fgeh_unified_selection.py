from fgeh_shared_ui_localization import text as _t
# -*- coding: utf-8 -*-
"""M01: explicit candidate snapshot and bounded translation experiment."""
import math
UNIFIED_API_VERSION=21
MAX_SELECTION=64


def position(owner):
    p = owner.position
    values = tuple(float(getattr(p, axis)) for axis in ('x', 'y', 'z'))
    if not all(math.isfinite(v) for v in values):
        raise ValueError(_t('shared_ab79b0201f1c'))
    return values


def value(owner, name, default=None):
    result = getattr(owner, name, default)
    return result() if callable(result) else result


def eligible(owner, session, sessions_for_sim, allow_new_actors=False):
    if owner is None or int(getattr(owner, 'id', 0)) <= 0:
        raise ValueError(_t('shared_91723e5f69f8'))
    if value(owner, 'parent') is not None or value(owner, 'parent_object') is not None:
        raise ValueError(_t('shared_ad6f24d06ac9'))
    if value(owner, 'is_part', False) or value(owner, 'part_owner') is not None:
        raise ValueError(_t('shared_424ab6f8c4d0'))
    if not getattr(owner, 'is_sim', False):
        if not getattr(getattr(owner, 'definition', None), 'id', 0):
            raise ValueError(_t('shared_11ae0bda15e2'))
        inventory = getattr(owner, 'is_in_inventory', None)
        if inventory is None or bool(inventory() if callable(inventory) else inventory):
            raise ValueError(_t('shared_ae7a99e7d13b'))
    else:
        if any(not s.is_canceled and s.get_identifier() != session.get_identifier()
               for s in sessions_for_sim(owner)):
            raise ValueError(_t('shared_0375f78d78b8'))
        if session.get_node_for_owner(owner) is None and not allow_new_actors:
            raise ValueError(_t('shared_037cb0573f53'))
    position(owner)
    return owner


class Selection:
    def __init__(self, session, zone, active_id, candidates):
        self.session = session
        self.zone = zone
        self.active_id = active_id
        self.candidates = {str(o.id): o for o in candidates}
        self.selected = []

    def check_context(self, zone, active_id):
        if zone != self.zone or active_id != self.active_id or self.session.is_canceled:
            raise ValueError(_t('shared_ff9a91f4ecd6'))

    def select(self, ids, resolve, sessions_for_sim):
        ids = list(dict.fromkeys(ids))
        if not ids or len(ids) > MAX_SELECTION:
            raise ValueError(_t('shared_4c376bd06fd2'))
        owners = []
        for ident in ids:
            owner = self.candidates.get(ident)
            if owner is None or resolve(int(ident)) is not owner:
                raise ValueError(_t('shared_a1bb2366e56a'))
            owners.append(eligible(owner, self.session, sessions_for_sim))
        # Selection itself never adds props or restores/moves objects.
        self.selected = owners
        return owners

    def move(self, delta, resolve, sessions_for_sim, vector):
        if len(delta) != 3 or not all(math.isfinite(v) and abs(v) <= 0.25 for v in delta):
            raise ValueError(_t('shared_cf44482497b7'))
        if not self.selected:
            raise ValueError(_t('shared_dea8c3c75c8e'))
        # Validate every object before changing any session membership or position.
        for owner in self.selected:
            if resolve(owner.id) is not owner:
                raise ValueError(_t('shared_8716d10ea0f4'))
            eligible(owner, self.session, sessions_for_sim)
        before = [position(o) for o in self.selected]
        keys = []
        old_keys = [n.key for n in self.session.get_positioning_selected_nodes()]
        try:
            for owner in self.selected:
                node = self.session.get_node_for_owner(owner)
                if node is None:
                    self.session.add_prop(owner, label='M01 {}'.format(owner.id))
                    node = self.session.get_node_for_owner(owner)
                keys.append(node.key)
            self.session.select_node_keys(keys)
            self.session.apply_delta_to_selected_nodes(delta_position=vector(*delta))
        finally:
            self.session.select_node_keys(old_keys)
        after = [position(o) for o in self.selected]
        return [(str(o.id), old, new,
                 all(abs(new[i] - old[i] - delta[i]) < 0.0001 for i in range(3)))
                for o, old, new in zip(self.selected, before, after)]
