# coding: utf-8
"""Pure-Python codec for FgEH CAS Collection V3 -> JSON schema v1.

No Sims imports. Python 3.7 compatible so it can also be unit-tested outside TS4.
"""

SCHEMA = "fgeh.cas.collection.v1"
SCHEMA_VERSION = 1
MANIFEST_MAGIC = "FGCAS_FAVORITES_V3"
GROUP_MAGIC = "FGCAS_GROUPS_V2"
ITEM_FIELD_COUNT = 8


def _text(value):
    return str(value or "").strip()


def _safe_int(value, default=0):
    try:
        return int(str(value).strip())
    except Exception:
        return default


def parse_manifest(raw):
    raw = _text(raw)
    parts = raw.split("^") if raw else []
    if len(parts) < 2 or parts[0] != MANIFEST_MAGIC:
        raise ValueError("bad V3 manifest header")
    count = _safe_int(parts[1], -1)
    if count < 0:
        raise ValueError("bad V3 manifest count")
    bases = [_text(x) for x in parts[2:] if _text(x)]
    if len(bases) != count:
        raise ValueError("V3 manifest count mismatch: {} != {}".format(len(bases), count))
    if len(set(bases)) != len(bases):
        raise ValueError("V3 manifest contains duplicate base ids")
    return bases


def _parse_bool(value):
    value = _text(value).lower()
    if value in ("true", "1", "yes"):
        return True
    if value in ("false", "0", "no"):
        return False
    return None


def parse_variant_ids(raw):
    # Current CAS GFX stores: |id||id||id| . Filtering empty tokens preserves order.
    result = []
    seen = set()
    for token in _text(raw).split("|"):
        token = _text(token)
        if not token or token in seen:
            continue
        seen.add(token)
        result.append(token)
    return result


def parse_swatches(raw):
    """Return swatch metadata keyed by variant/CASPart id.

    Current shape example:
      198489:;COLORS=4275940685,4272137123;ICON=0;MODDED=false|...
    Unknown future key/value pairs are preserved under extra.
    """
    result = {}
    order = []
    for piece in _text(raw).split("|"):
        piece = _text(piece)
        if not piece or ":" not in piece:
            continue
        variant_id, tail = piece.split(":", 1)
        variant_id = _text(variant_id)
        if not variant_id:
            continue
        fields = {}
        for part in tail.split(";"):
            part = _text(part)
            if not part or "=" not in part:
                continue
            key, value = part.split("=", 1)
            fields[_text(key).upper()] = _text(value)
        colors = []
        for value in fields.get("COLORS", "").split(","):
            value = _text(value)
            if not value:
                continue
            parsed = _safe_int(value, None)
            if parsed is not None:
                colors.append(parsed)
        icon_raw = fields.get("ICON", "")
        extra = {}
        for key, value in fields.items():
            if key not in ("COLORS", "ICON", "MODDED"):
                extra[key] = value
        result[variant_id] = {
            "cas_part_id": variant_id,
            "colors": colors,
            "icon_key_raw": icon_raw,
            "modded": _parse_bool(fields.get("MODDED", "")),
            "extra": extra,
        }
        order.append(variant_id)
    return result, order


def parse_item_record(raw, expected_base=None):
    raw = _text(raw)
    fields = raw.split("~")
    if len(fields) != ITEM_FIELD_COUNT:
        raise ValueError("favorite item field count {} != {}".format(len(fields), ITEM_FIELD_COUNT))
    base_id = _text(fields[0])
    selected_variant_id = _text(fields[1])
    if not base_id:
        raise ValueError("favorite item missing base id")
    if expected_base is not None and base_id != _text(expected_base):
        raise ValueError("favorite item base mismatch {} != {}".format(base_id, expected_base))

    variant_ids = parse_variant_ids(fields[5])
    swatch_map, swatch_order = parse_swatches(fields[6])
    # Preserve variant order from the CAS variant pipe, append any metadata-only swatches.
    all_variant_ids = list(variant_ids)
    for variant_id in swatch_order:
        if variant_id not in all_variant_ids:
            all_variant_ids.append(variant_id)

    variants = []
    any_modded = False
    all_known_game = bool(all_variant_ids)
    for index, variant_id in enumerate(all_variant_ids):
        swatch = swatch_map.get(variant_id, {})
        modded = swatch.get("modded")
        if modded is True:
            any_modded = True
        if modded is not False:
            all_known_game = False
        variants.append({
            "cas_part_id": variant_id,
            "style_index": index,
            "is_selected": variant_id == selected_variant_id,
            "colors": list(swatch.get("colors", [])),
            "icon_key_raw": _text(swatch.get("icon_key_raw")),
            "modded": modded,
            "extra": dict(swatch.get("extra", {})),
        })

    source_type = "cc" if any_modded else ("game" if all_known_game else "unknown")
    declared_variant_count = _safe_int(fields[3], 0)
    declared_swatch_count = _safe_int(fields[4], 0)
    return {
        "base_id": base_id,
        "selected_variant_id": selected_variant_id,
        "body_type": _safe_int(fields[2], 0),
        "variant_count": declared_variant_count,
        "swatch_count": declared_swatch_count,
        "variant_ids": all_variant_ids,
        "variants": variants,
        "captured_request": _text(fields[7]),
        "source_type": source_type,
        "source_origin": "cas_favorites",
        "groups": [],
        "raw": {
            "variant_ids": fields[5],
            "swatches": fields[6],
        },
        "validation": {
            "variant_count_matches": declared_variant_count == len(all_variant_ids),
            "swatch_count_matches": declared_swatch_count == len(swatch_order),
        },
    }


def parse_groups(raw):
    raw = _text(raw)
    if not raw:
        return [], {}
    parts = raw.split("^")
    if not parts or parts[0] != GROUP_MAGIC:
        raise ValueError("bad group header")
    names = []
    membership = {}
    for piece in parts[1:]:
        if piece.startswith("G~"):
            name = _text(piece[2:])
            if name and name not in names:
                names.append(name)
        elif piece.startswith("M~"):
            fields = piece.split("~", 2)
            if len(fields) != 3:
                continue
            base_id = _text(fields[1])
            member_names = []
            for name in fields[2].split("|"):
                name = _text(name)
                if name and name not in member_names:
                    member_names.append(name)
                    if name not in names:
                        names.append(name)
            if base_id:
                membership[base_id] = member_names
    return names, membership


def build_collection(manifest_raw, item_records, group_raw=""):
    bases = parse_manifest(manifest_raw)
    if not isinstance(item_records, dict):
        raise ValueError("item_records must be dict")
    group_names, membership = parse_groups(group_raw)
    items = []
    for base_id in bases:
        if base_id not in item_records:
            raise ValueError("missing item record for base {}".format(base_id))
        item = parse_item_record(item_records[base_id], base_id)
        item["groups"] = list(membership.get(base_id, []))
        items.append(item)

    groups = {}
    for name in group_names:
        groups[name] = []
    for base_id in bases:
        for name in membership.get(base_id, []):
            groups.setdefault(name, []).append(base_id)

    return {
        "schema": SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "source": "CAS_AccountSettings_PLAY_bridge",
        "item_count": len(items),
        "group_count": len(groups),
        "items": items,
        "groups": groups,
        "order": list(bases),
        "compatibility": {
            "pose_manager_variant_option_id": "cas_part_id",
            "base_identity": "base_id",
            "body_type": "body_type",
            "different_styles_are_variants": True,
            "ids_serialized_as_strings": True,
        },
    }

# --- H28 V2 snapshot transport -------------------------------------------------
V2_MAGIC = "FGCAS_FAVORITES_V2"


def parse_v2_snapshot(raw):
    """Parse the H26-compatible monolithic V2 mirror.

    Shape:
      FGCAS_FAVORITES_V2^COUNT^item0^item1...
    Each item is the same 8-field row used by parse_item_record().
    """
    raw = _text(raw)
    parts = raw.split("^") if raw else []
    if len(parts) < 2 or parts[0] != V2_MAGIC:
        raise ValueError("bad V2 snapshot header")
    count = _safe_int(parts[1], -1)
    if count < 0:
        raise ValueError("bad V2 snapshot count")
    rows = parts[2:]
    if len(rows) != count:
        raise ValueError("V2 snapshot count mismatch: {} != {}".format(len(rows), count))
    bases = []
    item_records = {}
    for row in rows:
        item = parse_item_record(row)
        base_id = _text(item.get("base_id"))
        if not base_id:
            raise ValueError("V2 snapshot item missing base id")
        if base_id in item_records:
            raise ValueError("V2 snapshot duplicate base id {}".format(base_id))
        bases.append(base_id)
        item_records[base_id] = row
    return bases, item_records


def build_collection_v2(snapshot_raw, group_raw=""):
    bases, item_records = parse_v2_snapshot(snapshot_raw)
    group_names, membership = parse_groups(group_raw)
    items = []
    for base_id in bases:
        item = parse_item_record(item_records[base_id], base_id)
        item["groups"] = list(membership.get(base_id, []))
        items.append(item)

    groups = {}
    for name in group_names:
        groups[name] = []
    for base_id in bases:
        for name in membership.get(base_id, []):
            groups.setdefault(name, []).append(base_id)

    return {
        "schema": SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "source": "CAS_AccountSettings_PLAY_bridge",
        "source_snapshot_schema": V2_MAGIC,
        "item_count": len(items),
        "group_count": len(groups),
        "items": items,
        "groups": groups,
        "order": list(bases),
        "compatibility": {
            "pose_manager_variant_option_id": "cas_part_id",
            "base_identity": "base_id",
            "body_type": "body_type",
            "different_styles_are_variants": True,
            "ids_serialized_as_strings": True,
        },
    }
