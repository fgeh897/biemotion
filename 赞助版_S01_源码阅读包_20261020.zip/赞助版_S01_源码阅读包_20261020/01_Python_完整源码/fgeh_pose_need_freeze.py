"""Pose-scoped natural need decay modifiers. No value writes or global cheats."""
import weakref
KEY='__fgeh_pose_need_freeze_n1__'
MOTIVES=(16652,16654,16655,16656,16657,16658)
_active={}
_alarm=None
_zone=None

def enabled(manager):
    return str((getattr(manager.state,'custom_names',{}) or {}).get(KEY,'0'))=='1'

def _remove(entry):
    remaining=[]
    for stat in entry['stats']:
        try:stat.remove_decay_rate_modifier(0.0)
        except Exception:remaining.append(stat)
    entry['stats']=remaining

def _apply(entry):
    if entry['stats']:return
    import services
    from sims4.resources import Types
    sim=entry['ref']()
    if sim is None:return
    info=getattr(sim,'sim_info',sim)
    tracker=getattr(info,'commodity_tracker',None)
    if tracker is None:return
    manager=services.get_instance_manager(Types.STATISTIC)
    for guid in MOTIVES:
        stat_type=manager.get(guid)
        if stat_type is None:continue
        stat=tracker.get_statistic(stat_type,add=False)
        if stat is None:continue
        try:
            stat.add_decay_rate_modifier(0.0)
            entry['stats'].append(stat)
        except Exception:
            _remove(entry)
            return

def toggle(manager):
    value=not enabled(manager)
    names=getattr(manager.state,'custom_names',{})
    if not isinstance(names,dict):names={}
    names[KEY]='1' if value else '0'
    manager.state.custom_names=names
    manager.save_favorites()
    for entry in list(_active.values()):
        if value:_apply(entry)
        else:_remove(entry)
    return value

def release(sim):
    sid=getattr(sim,'sim_id',getattr(sim,'id',None))
    entry=_active.get(sid)
    if entry is None:return
    _remove(entry)
    if not entry['stats']:_active.pop(sid,None)

def release_all():
    for sid,entry in list(_active.items()):
        _remove(entry)
        if not entry['stats']:_active.pop(sid,None)

def _watch(manager):
    global _alarm
    if _alarm is not None or not _active:return
    try:
        import alarms,clock,services
        owner=services.current_zone()
        def check(handle):
            global _alarm
            _alarm=None
            try:
                if services.current_zone() is not owner:
                    release_all()
                    return
                for sid,entry in list(_active.items()):
                    sim=entry['ref']()
                    if sim is None:
                        _remove(entry)
                        if not entry['stats']:_active.pop(sid,None)
                    elif not manager.sim_has_pending_pose_interaction(sim):release(sim)
                    elif enabled(manager):_apply(entry)
                    else:_remove(entry)
            finally:_watch(manager)
        _alarm=alarms.add_alarm_real_time(owner,clock.interval_in_real_seconds(2),check,use_sleep_time=False)
    except Exception:_alarm=None

def acquire(manager,sim):
    global _zone,_alarm
    if sim is None:return
    import services
    current=services.current_zone()
    if _zone is not current:
        release_all()
        if _alarm is not None:
            try:
                import alarms
                alarms.cancel_alarm(_alarm)
            except Exception:pass
        _alarm=None
        _zone=current
    sid=getattr(sim,'sim_id',getattr(sim,'id',None))
    if sid is None:return
    if sid not in _active:
        try:ref=weakref.ref(sim)
        except TypeError:ref=lambda:sim
        _active[sid]={'ref':ref,'stats':[]}
    if enabled(manager):_apply(_active[sid])
    _watch(manager)
