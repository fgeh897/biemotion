import json
import os
import time


OBJECT_BINDINGS_FILENAME = "fgeh_linked_object_bindings.json"
OBJECT_BINDINGS_TMP_FILENAME = "fgeh_linked_object_bindings_tmp"
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))


def get_mod_directory():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        return MODULE_DIR


def _candidate_dirs():
    dirs = []
    for folder in (get_mod_directory(), MODULE_DIR):
        if folder and folder not in dirs:
            dirs.append(folder)
    return dirs


def _primary_dir():
    for folder in _candidate_dirs():
        try:
            if os.path.isdir(folder):
                return folder
        except Exception:
            pass
    return MODULE_DIR


def _path_in(folder, filename):
    return os.path.join(folder, filename)


def _primary_path(filename):
    return _path_in(_primary_dir(), filename)


def _load_json_dict(path):
    try:
        if not path or not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _preferred_json_data(folder, filename, tmp_filename):
    candidates = []
    for name in (filename, tmp_filename):
        path = _path_in(folder, name)
        data = _load_json_dict(path)
        if data is None:
            continue
        try:
            modified = os.path.getmtime(path)
        except Exception:
            modified = 0
        candidates.append((modified, data))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _write_json_safely(target_path, tmp_path, data):
    with open(tmp_path, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False)
    if _load_json_dict(tmp_path) is None:
        return False
    try:
        os.replace(tmp_path, target_path)
        return True
    except Exception:
        pass
    try:
        with open(target_path, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False)
        if _load_json_dict(target_path) is None:
            return True
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return True
    except Exception:
        return True


def _safe_int(value):
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _now_text():
    try:
        return time.strftime("%Y-%m-%dT%H:%M:%S")
    except Exception:
        return ""


def _load_data():
    merged = []
    merged_assets = []
    seen = set()
    seen_assets = set()
    schema_version = 1
    for folder in _candidate_dirs():
        try:
            data = _preferred_json_data(folder, OBJECT_BINDINGS_FILENAME, OBJECT_BINDINGS_TMP_FILENAME)
            if data is None:
                continue
            try:
                schema_version = max(schema_version, int(data.get("schema_version", 1) or 1))
            except Exception:
                pass
            assets = data.get("object_assets", [])
            if isinstance(assets, list):
                for asset in assets:
                    if not isinstance(asset, dict):
                        continue
                    key = (
                        str(asset.get("pack_id") or ""),
                        _safe_int(asset.get("definition_id")),
                    )
                    if not key[0] or not key[1] or key in seen_assets:
                        continue
                    seen_assets.add(key)
                    merged_assets.append(asset)
            bindings = data.get("object_bindings", [])
            if not isinstance(bindings, list):
                continue
            for binding in bindings:
                if not isinstance(binding, dict):
                    continue
                key = (
                    str(binding.get("pack_id") or ""),
                    str(binding.get("pose_name") or ""),
                    _safe_int(binding.get("definition_id")),
                )
                if not key[0] or not key[1] or not key[2] or key in seen:
                    continue
                seen.add(key)
                merged.append(binding)
        except Exception:
            continue
    return {
        "schema_version": max(schema_version, 2 if merged_assets else schema_version),
        "object_assets": merged_assets,
        "object_bindings": merged,
    }


def _save_data(data):
    try:
        target_dir = _primary_dir()
        target_path = _path_in(target_dir, OBJECT_BINDINGS_FILENAME)
        tmp_path = _path_in(target_dir, OBJECT_BINDINGS_TMP_FILENAME)
        return _write_json_safely(target_path, tmp_path, data)
    except Exception:
        return False


def _clean_object_definition_from_data(data, pack_id, definition_id):
    if not isinstance(data, dict):
        return data, False

    old_assets = data.get("object_assets", []) or []
    old_bindings = data.get("object_bindings", []) or []

    new_assets = []
    for asset in old_assets:
        if not isinstance(asset, dict):
            continue
        if (
            str(asset.get("pack_id") or "").strip() == pack_id
            and _safe_int(asset.get("definition_id")) == definition_id
        ):
            continue
        new_assets.append(asset)

    new_bindings = []
    for binding in old_bindings:
        if not isinstance(binding, dict):
            continue
        if (
            str(binding.get("pack_id") or "").strip() == pack_id
            and _safe_int(binding.get("definition_id")) == definition_id
        ):
            continue
        new_bindings.append(binding)

    changed = len(new_assets) != len(old_assets) or len(new_bindings) != len(old_bindings)
    if changed:
        data["object_assets"] = new_assets
        data["object_bindings"] = new_bindings
        data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    return data, changed


def _save_data_to_folder(folder, data):
    try:
        target_path = _path_in(folder, OBJECT_BINDINGS_FILENAME)
        tmp_path = _path_in(folder, OBJECT_BINDINGS_TMP_FILENAME)
        return _write_json_safely(target_path, tmp_path, data)
    except Exception:
        return False


def iter_saved_object_bindings():
    data = _load_data()
    for binding in data.get("object_bindings", []) or []:
        if isinstance(binding, dict):
            yield binding


def iter_saved_object_assets():
    data = _load_data()
    seen = set()

    for asset in data.get("object_assets", []) or []:
        if not isinstance(asset, dict):
            continue
        pack_id = str(asset.get("pack_id") or "").strip()
        definition_id = _safe_int(asset.get("definition_id"))
        key = (pack_id, definition_id)
        if not pack_id or not definition_id or key in seen:
            continue
        seen.add(key)
        yield asset

    for binding in data.get("object_bindings", []) or []:
        if not isinstance(binding, dict):
            continue
        pack_id = str(binding.get("pack_id") or "").strip()
        definition_id = _safe_int(binding.get("definition_id"))
        key = (pack_id, definition_id)
        if not pack_id or not definition_id or key in seen:
            continue
        seen.add(key)
        yield {
            "asset_kind": "object",
            "source_type": binding.get("source_type") or "unknown",
            "user_group": binding.get("user_group") or "in_game_binding",
            "pack_id": pack_id,
            "definition_id": definition_id,
            "display_name": binding.get("display_name") or "Object {}".format(definition_id),
            "created_in_game": True,
            "created_at": binding.get("created_at") or "",
            "updated_at": binding.get("updated_at") or "",
        }


def has_saved_object_binding(pack_id, pose_name, definition_id):
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    definition_id = _safe_int(definition_id)
    if not pack_id or not pose_name or not definition_id:
        return False
    for binding in iter_saved_object_bindings():
        if (
            str(binding.get("pack_id") or "").strip() == pack_id
            and str(binding.get("pose_name") or "").strip() == pose_name
            and _safe_int(binding.get("definition_id")) == definition_id
        ):
            return True
    return False


def is_saved_object_asset(pack_id, definition_id):
    pack_id = str(pack_id or "").strip()
    definition_id = _safe_int(definition_id)
    if not pack_id or not definition_id:
        return False
    for asset in iter_saved_object_assets():
        if (
            str(asset.get("pack_id") or "").strip() == pack_id
            and _safe_int(asset.get("definition_id")) == definition_id
        ):
            return True
    return False


def get_saved_object_ids_for_pose(pack_id, pose_name):
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    asset_ids = set()
    binding_ids = set()
    if not pack_id:
        return asset_ids, binding_ids

    data = _load_data()
    for asset in data.get("object_assets", []) or []:
        if not isinstance(asset, dict):
            continue
        definition_id = _safe_int(asset.get("definition_id"))
        if str(asset.get("pack_id") or "").strip() == pack_id and definition_id:
            asset_ids.add(definition_id)

    for binding in data.get("object_bindings", []) or []:
        if not isinstance(binding, dict):
            continue
        definition_id = _safe_int(binding.get("definition_id"))
        if str(binding.get("pack_id") or "").strip() != pack_id or not definition_id:
            continue
        asset_ids.add(definition_id)
        if pose_name and str(binding.get("pose_name") or "").strip() == pose_name:
            binding_ids.add(definition_id)

    return asset_ids, binding_ids


def save_object_binding_for_poses(pack_id, pose_names, definition_id, display_name=None, source_type="unknown"):
    """Save one in-game object binding for many Poses with ONE JSON write.

    H60 keeps the proven per-Pose storage schema.  "Pack scope" is an operation
    semantic only; no third pack-level binding store is introduced.
    """
    pack_id = str(pack_id or "").strip()
    definition_id = _safe_int(definition_id)
    display_name = str(display_name or "").strip()
    source_type = str(source_type or "unknown").strip().lower() or "unknown"
    if source_type not in ("game", "cc", "unknown"):
        source_type = "unknown"
    names = []
    seen = set()
    for value in pose_names or ():
        value = str(value or "").strip()
        if value and value not in seen:
            seen.add(value)
            names.append(value)
    if not pack_id or not definition_id or not names:
        return 0

    data = _load_data()
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    assets = data.setdefault("object_assets", [])
    bindings = data.setdefault("object_bindings", [])
    now = _now_text()

    asset = None
    for row in assets:
        if not isinstance(row, dict):
            continue
        if str(row.get("pack_id") or "") == pack_id and _safe_int(row.get("definition_id")) == definition_id:
            asset = row
            break
    if asset is None:
        asset = {
            "asset_kind": "object",
            "source_type": source_type,
            "user_group": "in_game_binding",
            "pack_id": pack_id,
            "definition_id": definition_id,
            "display_name": display_name or "Object {}".format(definition_id),
            "created_in_game": True,
            "created_at": now,
            "updated_at": now,
        }
        assets.append(asset)
    else:
        asset["display_name"] = display_name or asset.get("display_name") or "Object {}".format(definition_id)
        asset["source_type"] = source_type
        asset["updated_at"] = now

    existing = set()
    for row in bindings:
        if not isinstance(row, dict):
            continue
        if str(row.get("pack_id") or "") == pack_id and _safe_int(row.get("definition_id")) == definition_id:
            pose_name = str(row.get("pose_name") or "").strip()
            if pose_name in seen:
                existing.add(pose_name)
                row["display_name"] = display_name or row.get("display_name") or "Object {}".format(definition_id)
                row["source_type"] = source_type
                row["updated_at"] = now

    added = 0
    for pose_name in names:
        if pose_name in existing:
            continue
        bindings.append({
            "asset_kind": "object",
            "source_type": source_type,
            "user_group": "in_game_binding",
            "pack_id": pack_id,
            "pose_name": pose_name,
            "definition_id": definition_id,
            "display_name": display_name or "Object {}".format(definition_id),
            "created_in_game": True,
            "created_at": now,
            "updated_at": now,
        })
        added += 1

    return len(names) if _save_data(data) else 0


def remove_object_bindings_for_poses(pack_id, pose_names, definition_ids):
    """Remove local object-binding rows for a Pose scope with ONE JSON write.

    External XML/snippet/package requirements are not stored here and are never
    modified.  Orphan local object_assets are cleaned only when no local row in
    the Pack still references that definition.
    """
    pack_id = str(pack_id or "").strip()
    names = set(str(value or "").strip() for value in (pose_names or ()) if str(value or "").strip())
    ids = set(_safe_int(value) for value in (definition_ids or ()) if _safe_int(value))
    if not pack_id or not names or not ids:
        return 0

    data = _load_data()
    old = data.get("object_bindings", []) or []
    kept = []
    removed = 0
    for row in old:
        if not isinstance(row, dict):
            kept.append(row)
            continue
        same = (
            str(row.get("pack_id") or "").strip() == pack_id
            and str(row.get("pose_name") or "").strip() in names
            and _safe_int(row.get("definition_id")) in ids
        )
        if same:
            removed += 1
        else:
            kept.append(row)
    if not removed:
        return 0

    data["object_bindings"] = kept
    still_used = set(
        _safe_int(row.get("definition_id"))
        for row in kept
        if isinstance(row, dict)
        and str(row.get("pack_id") or "").strip() == pack_id
        and _safe_int(row.get("definition_id"))
    )
    cleaned_assets = []
    for asset in data.get("object_assets", []) or []:
        if not isinstance(asset, dict):
            cleaned_assets.append(asset)
            continue
        asset_id = _safe_int(asset.get("definition_id"))
        if (
            str(asset.get("pack_id") or "").strip() == pack_id
            and asset_id in ids
            and asset_id not in still_used
        ):
            continue
        cleaned_assets.append(asset)
    data["object_assets"] = cleaned_assets
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    return removed if _save_data(data) else 0


def save_object_binding(pack_id, pose_name, definition_id, display_name=None, source_type="unknown"):
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    definition_id = _safe_int(definition_id)
    display_name = str(display_name or "").strip()
    source_type = str(source_type or "unknown").strip().lower() or "unknown"
    if source_type not in ("game", "cc", "unknown"):
        source_type = "unknown"
    if not pack_id or not pose_name or not definition_id:
        return False

    data = _load_data()
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    assets = data.setdefault("object_assets", [])
    bindings = data.setdefault("object_bindings", [])
    now = _now_text()

    asset_updated = False
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        if (
            str(asset.get("pack_id") or "") == pack_id
            and _safe_int(asset.get("definition_id")) == definition_id
        ):
            asset["display_name"] = display_name or asset.get("display_name") or "Object {}".format(definition_id)
            asset["source_type"] = source_type
            asset["updated_at"] = now
            asset_updated = True
            break
    if not asset_updated:
        assets.append({
            "asset_kind": "object",
            "source_type": source_type,
            "user_group": "in_game_binding",
            "pack_id": pack_id,
            "definition_id": definition_id,
            "display_name": display_name or "Object {}".format(definition_id),
            "created_in_game": True,
            "created_at": now,
            "updated_at": now,
        })

    for binding in bindings:
        if not isinstance(binding, dict):
            continue
        if (
            str(binding.get("pack_id") or "") == pack_id
            and str(binding.get("pose_name") or "") == pose_name
            and _safe_int(binding.get("definition_id")) == definition_id
        ):
            binding["display_name"] = display_name or binding.get("display_name") or "Object {}".format(definition_id)
            binding["source_type"] = source_type
            binding["updated_at"] = now
            return _save_data(data)

    bindings.append({
        "asset_kind": "object",
        "source_type": source_type,
        "user_group": "in_game_binding",
        "pack_id": pack_id,
        "pose_name": pose_name,
        "definition_id": definition_id,
        "display_name": display_name or "Object {}".format(definition_id),
        "created_in_game": True,
        "created_at": now,
        "updated_at": now,
    })
    return _save_data(data)


def delete_saved_object_definition(pack_id, definition_id):
    pack_id = str(pack_id or "").strip()
    definition_id = _safe_int(definition_id)
    if not pack_id or not definition_id:
        return False

    changed_any = False
    saved_any = False
    for folder in _candidate_dirs():
        try:
            path = _path_in(folder, OBJECT_BINDINGS_FILENAME)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8") as stream:
                data = json.load(stream)
            data, changed = _clean_object_definition_from_data(data, pack_id, definition_id)
            if not changed:
                continue
            changed_any = True
            if _save_data_to_folder(folder, data):
                saved_any = True
        except Exception:
            continue
    return bool(changed_any and saved_any)


def _clean_pose_refs_from_data(data, refs):
    if not isinstance(data, dict):
        return data, False
    ref_keys = set(
        (str(pack_id or "").strip(), str(pose_name or "").strip())
        for pack_id, pose_name in (refs or [])
        if str(pack_id or "").strip() and str(pose_name or "").strip()
    )
    if not ref_keys:
        return data, False

    old_bindings = data.get("object_bindings", []) or []
    old_assets = data.get("object_assets", []) or []

    new_bindings = []
    for binding in old_bindings:
        if not isinstance(binding, dict):
            continue
        key = (
            str(binding.get("pack_id") or "").strip(),
            str(binding.get("pose_name") or "").strip(),
        )
        if key in ref_keys:
            continue
        new_bindings.append(binding)

    referenced_assets = set(
        (
            str(binding.get("pack_id") or "").strip(),
            _safe_int(binding.get("definition_id")),
        )
        for binding in new_bindings
        if isinstance(binding, dict)
    )
    new_assets = []
    for asset in old_assets:
        if not isinstance(asset, dict):
            continue
        asset_key = (
            str(asset.get("pack_id") or "").strip(),
            _safe_int(asset.get("definition_id")),
        )
        pack_has_deleted_ref = any(pack_id == asset_key[0] for pack_id, _pose_name in ref_keys)
        if pack_has_deleted_ref and asset_key not in referenced_assets:
            continue
        new_assets.append(asset)

    changed = len(new_bindings) != len(old_bindings) or len(new_assets) != len(old_assets)
    if changed:
        data["object_bindings"] = new_bindings
        data["object_assets"] = new_assets
        data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    return data, changed


def delete_saved_object_pose_refs(refs):
    refs = list(refs or [])
    if not refs:
        return 0
    changed_count = 0
    saved_any = False
    for folder in _candidate_dirs():
        try:
            path = _path_in(folder, OBJECT_BINDINGS_FILENAME)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8") as stream:
                data = json.load(stream)
            old_count = len(data.get("object_bindings", []) or []) + len(data.get("object_assets", []) or [])
            data, changed = _clean_pose_refs_from_data(data, refs)
            if not changed:
                continue
            new_count = len(data.get("object_bindings", []) or []) + len(data.get("object_assets", []) or [])
            changed_count += max(0, old_count - new_count)
            if _save_data_to_folder(folder, data):
                saved_any = True
        except Exception:
            continue
    return changed_count if saved_any else 0
