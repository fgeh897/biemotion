from fgeh_pose_manager_localization import display_text as _fgeh_hash_ui_text
# -*- coding: utf-8 -*-
"""FgEH Outfit Manager Phase 1 read-only canary.

Goals
-----
1. Enumerate only real existing EA outfits without calling get_outfit on
   nonexistent slots.
2. Reuse EA's native UiOutfitPicker thumbnail protocol as a visual canary.
3. Read one saved outfit's CASPart/BodyType rows from save_outfits().

No permanent outfit edit/save logic lives here.
"""

import os
import time
import traceback

import sims4.commands

BUILD_TAG = "OUTFIT_MANAGER_PHASE1_R16"
LOG_NAME = "fgeh_outfit_manager_phase1.log"


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def _log_path():
    candidates = []
    try:
        import paths
        root = getattr(paths, "USER_DATA_ROOT", None)
        if root:
            candidates.append(str(root))
    except Exception:
        pass
    try:
        import sims4.paths as sims4_paths
        root = getattr(sims4_paths, "USER_DATA_ROOT", None)
        if root:
            candidates.append(str(root))
    except Exception:
        pass
    candidates.extend((
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
        os.path.join(os.path.expanduser("~/OneDrive/Documents"), "Electronic Arts", "The Sims 4"),
    ))
    for root in candidates:
        try:
            if root and os.path.isdir(root):
                return os.path.join(root, LOG_NAME)
        except Exception:
            pass
    return None


def _log(event, detail="", exc=False):
    return  # R26: release diagnostic/file output disabled.


def _raw_text(value):
    from sims4.localization import LocalizationHelperTuning
    return _fgeh_hash_ui_text(str(value or ""))


def _active_sim_info():
    try:
        import services
        sim = services.get_active_sim()
        return getattr(sim, "sim_info", None) if sim is not None else None
    except Exception:
        return None


def _category_name(category):
    try:
        from sims.outfits.outfit_enums import OutfitCategory
        value = OutfitCategory(int(category))
        return str(getattr(value, "name", value))
    except Exception:
        return str(category)


def _real_outfit_keys(sim_info, regular_only=False):
    """Read only existing keys. Never probes empty indices with get_outfit()."""
    if sim_info is None:
        return ()
    allowed = None
    if regular_only:
        try:
            from sims.outfits.outfit_enums import REGULAR_OUTFIT_CATEGORIES
            allowed = set(int(value) for value in REGULAR_OUTFIT_CATEGORIES)
        except Exception:
            allowed = None
    result = []
    for category, index in tuple(sim_info.get_all_outfit_entries() or ()):
        cat = _safe_int(category, -1)
        idx = _safe_int(index, -1)
        if cat < 0 or idx < 0:
            continue
        if allowed is not None and cat not in allowed:
            continue
        result.append((cat, idx))
    return tuple(result)


def _find_saved_outfit_proto(sim_info, category, category_index):
    """Locate saved outfit proto by category-local index without generation."""
    message = sim_info.save_outfits()
    matches = []
    for outfit in tuple(getattr(message, "outfits", ()) or ()):
        if _safe_int(getattr(outfit, "category", -1), -1) == int(category):
            matches.append(outfit)
    index = int(category_index)
    if 0 <= index < len(matches):
        return message, matches[index]
    return message, None


def _parallel_values(root, *names):
    value = root
    for name in names:
        value = getattr(value, name, None)
        if value is None:
            return ()
    try:
        return tuple(value or ())
    except Exception:
        return ()


def _part_rows(sim_info, category, category_index):
    _, outfit = _find_saved_outfit_proto(sim_info, category, category_index)
    if outfit is None:
        return None
    ids = _parallel_values(outfit, "parts", "ids")
    body_types = _parallel_values(outfit, "body_types_list", "body_types")
    shifts = _parallel_values(outfit, "part_shifts", "color_shift")
    object_ids = _parallel_values(outfit, "object_ids", "object_id")
    layer_ids = _parallel_values(outfit, "layer_ids", "layer_id")
    try:
        from cas.cas import get_caspart_bodytype
    except Exception:
        get_caspart_bodytype = None
    rows = []
    for i, raw_id in enumerate(ids):
        cas_part_id = _safe_int(raw_id, 0)
        if not cas_part_id:
            continue
        body_type = _safe_int(body_types[i], 0) if i < len(body_types) else 0
        if not body_type and get_caspart_bodytype is not None:
            try:
                body_type = _safe_int(get_caspart_bodytype(cas_part_id), 0)
            except Exception:
                body_type = 0
        rows.append({
            "part_index": i,
            "cas_part_id": cas_part_id,
            "body_type": body_type,
            "body_type_name": _body_type_name(body_type),
            "color_shift": _safe_int(shifts[i], 0) if i < len(shifts) else 0,
            "object_id": _safe_int(object_ids[i], 0) if i < len(object_ids) else 0,
            "layer_id": _safe_int(layer_ids[i], 0) if i < len(layer_ids) else 0,
        })
    return tuple(rows)


def _body_type_name(value):
    try:
        from sims.outfits.outfit_enums import BodyType
        item = BodyType(int(value))
        return str(getattr(item, "name", item))
    except Exception:
        return str(value)


def _summary(sim_info):
    keys = _real_outfit_keys(sim_info, regular_only=False)
    by_category = {}
    for category, index in keys:
        by_category.setdefault(category, []).append(index)
    return tuple(
        (category, _category_name(category), tuple(indices))
        for category, indices in sorted(by_category.items(), key=lambda item: item[0])
    )


@sims4.commands.Command("fgeh.outfit.scan", command_type=sims4.commands.CommandType.Live)
def fgeh_outfit_scan(_connection=None):
    output = sims4.commands.CheatOutput(_connection)
    sim_info = _active_sim_info()
    if sim_info is None:
        output("No active Sim")
        return False
    try:
        summary = _summary(sim_info)
        total = sum(len(indices) for _, _, indices in summary)
        current = tuple(sim_info.get_current_outfit())
        output("FgEH Outfit Phase1: sim={} current={} total={}".format(
            getattr(sim_info, "sim_id", 0), current, total
        ))
        for category, name, indices in summary:
            output("{} ({}) count={} indices={}".format(name, category, len(indices), indices))
        _log("SCAN", "sim_id={} current={} total={} summary={}".format(
            getattr(sim_info, "sim_id", 0), current, total, summary
        ))
        return True
    except Exception:
        _log("SCAN_ERROR", exc=True)
        output("Outfit scan failed; see {}".format(LOG_NAME))
        return False


def show_native_picker_read_only(sim_info=None, output=None):
    """Open EA's native read-only outfit picker from code or command."""
    if sim_info is None:
        sim_info = _active_sim_info()
    if sim_info is None:
        if output is not None:
            output("No active Sim")
        return False
    try:
        from ui.ui_dialog_picker import OutfitPickerRow, UiOutfitPicker
        keys = _real_outfit_keys(sim_info, regular_only=True)
        if not keys:
            if output is not None:
                output("No regular saved outfits")
            return False
        dialog = UiOutfitPicker.TunableFactory().default(
            sim_info,
            title=lambda *_, **__: _raw_text("FgEH Outfit Manager · Phase 1"),
            text=lambda *_, **__: _raw_text("只读缩略图验证：点击不会修改服装。"),
        )
        categories = sorted(set(category for category, _ in keys))
        dialog.outfit_category_filters = tuple(categories)
        for category, index in keys:
            dialog.add_row(OutfitPickerRow(
                outfit_sim_id=_safe_int(getattr(sim_info, "sim_id", 0), 0),
                outfit_category=category,
                outfit_index=index,
                tag=(category, index),
                name=_raw_text("{} {}".format(_category_name(category), index + 1)),
                row_description=_raw_text("只读 · ({}, {})".format(category, index)),
            ))

        def _on_selected(response_dialog):
            try:
                if not response_dialog.accepted:
                    _log("NATIVE_CANCEL")
                    return
                tags = tuple(response_dialog.get_result_tags() or ())
                selected = tuple(tags[0]) if tags else None
                _log("NATIVE_SELECTED_READONLY", "selected={}".format(selected))
            except Exception:
                _log("NATIVE_CALLBACK_ERROR", exc=True)

        dialog.add_listener(_on_selected)
        dialog.show_dialog()
        _log("NATIVE_OPEN", "sim_id={} rows={} categories={}".format(
            getattr(sim_info, "sim_id", 0), len(keys), categories
        ))
        if output is not None:
            output("Outfit thumbnail canary opened: {} real outfits".format(len(keys)))
        return True
    except Exception:
        _log("NATIVE_OPEN_ERROR", exc=True)
        if output is not None:
            output("Outfit thumbnail canary failed; see {}".format(LOG_NAME))
        return False


@sims4.commands.Command("fgeh.outfit.native", command_type=sims4.commands.CommandType.Live)
def fgeh_outfit_native(_connection=None):
    output = sims4.commands.CheatOutput(_connection)
    return show_native_picker_read_only(output=output)


@sims4.commands.Command("fgeh.outfit.parts", command_type=sims4.commands.CommandType.Live)
def fgeh_outfit_parts(category=0, index=0, _connection=None):
    """Read one real saved outfit's part rows. Usage: fgeh.outfit.parts 0 1"""
    output = sims4.commands.CheatOutput(_connection)
    sim_info = _active_sim_info()
    if sim_info is None:
        output("No active Sim")
        return False
    category = _safe_int(category, -1)
    index = _safe_int(index, -1)
    try:
        real_keys = set(_real_outfit_keys(sim_info, regular_only=False))
        if (category, index) not in real_keys:
            output("Outfit ({}, {}) does not exist; no get_outfit() call was made.".format(category, index))
            _log("PARTS_MISSING", "key=({}, {})".format(category, index))
            return False
        rows = _part_rows(sim_info, category, index)
        if rows is None:
            output("Saved outfit proto not found")
            return False
        output("{} {} · {} CAS parts".format(_category_name(category), index + 1, len(rows)))
        for row in rows:
            output("#{part_index} {body_type_name}({body_type}) CASP={cas_part_id} shift={color_shift} obj={object_id} layer={layer_id}".format(**row))
        _log("PARTS", "key=({}, {}) rows={}".format(category, index, rows))
        return True
    except Exception:
        _log("PARTS_ERROR", "key=({}, {})".format(category, index), exc=True)
        output("Outfit parts read failed; see {}".format(LOG_NAME))
        return False


_log("MODULE_IMPORTED")
