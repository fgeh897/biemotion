def scope(manager, context, pack_id, source):
    group = getattr(manager.state, 'custom_pose_ui_active_inner_group', None)
    if not group:
        return None
    pack = (context or {}).get('pack')
    if pack is None or str(manager.get_pack_id(pack)) != str(pack_id):
        raise ValueError('Linked group context does not match pack')
    groups = (getattr(manager.state, 'grouped_packs', {}) or {}).get(str(pack_id), {}) or {}
    if group not in groups:
        raise ValueError('Linked group no longer exists')
    members = set(str(v) for v in groups[group] or ())
    if str(source) not in members:
        raise ValueError('Source pose is outside active group')
    return members
