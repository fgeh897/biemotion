import traceback
import os
import time

import sims4.log
import services

import fgeh_cas_accessory_settings as settings

try:
    from cas.cas import get_caspart_bodytype
except Exception:
    get_caspart_bodytype = None

try:
    from sims.outfits.outfit_enums import BodyType, OutfitCategory
except Exception:
    BodyType = None
    OutfitCategory = None


logger = sims4.log.Logger("FGEH_CAS_Accessory", default_owner="fgeh")

_original_outfit_by_sim_id = {}


def _get_debug_log_paths():
    paths = []
    seen = set()
    filename = "fgeh_cas_accessory_debug.log"

    def add_path(path):
        if not path:
            return
        try:
            normalized = os.path.normcase(os.path.abspath(path))
        except Exception:
            normalized = path
        if normalized not in seen:
            seen.add(normalized)
            paths.append(path)

    try:
        mod_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if mod_dir:
            add_path(os.path.join(mod_dir, filename))
    except Exception:
        pass
    for sims_dir in (
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
    ):
        try:
            if sims_dir and os.path.isdir(sims_dir):
                add_path(os.path.join(sims_dir, filename))
                mods_dir = os.path.join(sims_dir, "Mods")
                if os.path.isdir(mods_dir):
                    add_path(os.path.join(mods_dir, filename))
        except Exception:
            pass
    try:
        add_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), filename))
    except Exception:
        pass
    return paths


def _debug_logging_enabled():
    return bool(getattr(settings, "ENABLE_DEBUG_LOG", False))


def _debug_log_max_bytes():
    try:
        return int(getattr(settings, "DEBUG_LOG_MAX_BYTES", 0) or 0)
    except Exception:
        return 0


def _trim_debug_log_if_needed(path):
    return  # R26: release diagnostic/file output disabled.


def _write_debug_log(line):
    return  # R26: release diagnostic/file output disabled.


def _log(message, *args):
    return  # R26: release diagnostic/file output disabled.


def _log_exception(label):
    _log("{}\n{}", label, traceback.format_exc())


def debug_log(message, *args):
    _log(message, *args)


def _safe_list(value):
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        return []


def _enum_name(enum_class, value, fallback_prefix):
    try:
        if enum_class is not None:
            for name, member in getattr(enum_class, "__dict__", {}).items():
                try:
                    if int(member) == int(value):
                        return str(name)
                except Exception:
                    pass
    except Exception:
        pass
    try:
        return "{} {}".format(fallback_prefix, int(value))
    except Exception:
        return "{} {}".format(fallback_prefix, value)


def get_outfit_category_name(category):
    return _enum_name(OutfitCategory, category, "Outfit")


def get_body_type_name(body_type):
    return _enum_name(BodyType, body_type, "BodyType")


def get_body_group_for_body_type(body_type):
    try:
        body_type = int(body_type or 0)
    except Exception:
        body_type = 0

    if body_type in (2,):
        return "hair"
    if body_type in (29, 30, 31, 32, 33, 37):
        return "makeup"
    if body_type in (1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 36, 42):
        return "accessory"
    if body_type in (5, 6, 7, 8):
        return "clothing"
    if body_type in (38, 39, 40, 41, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58):
        return "skin_detail"
    return "other"


def get_body_group_name(body_group):
    body_group = str(body_group or "").strip()
    labels = {
        "all": "整套服装",
        "hair": "头发",
        "makeup": "妆容",
        "accessory": "配饰",
        "clothing": "衣服/鞋子",
        "skin_detail": "皮肤细节",
        "other": "身体/其它 CAS",
    }
    return labels.get(body_group, body_group or "身体/其它 CAS")


def get_sim_info_from_target(target):
    if target is None:
        _log("get_sim_info_from_target: target is None")
        return None
    try:
        sim_info = getattr(target, "sim_info", None)
        if sim_info is not None:
            return sim_info
    except Exception:
        _log_exception("get_sim_info_from_target failed")
    _log("get_sim_info_from_target: no sim_info on target {}", target)
    return None


def dump_current_outfit_parts(sim_info):
    if sim_info is None:
        _log("dump_current_outfit_parts: sim_info is None")
        return False


def iter_all_outfit_cas_parts(sim_info):
    """Yield outfit rows with CAS parts without modifying the Sim's outfits."""
    if sim_info is None:
        _log("iter_all_outfit_cas_parts: sim_info is None")
        return

    try:
        current_outfit = sim_info.get_current_outfit()
    except Exception:
        current_outfit = None

    try:
        outfits_msg = sim_info.save_outfits()
        outfits = _safe_list(getattr(outfits_msg, "outfits", None))
    except Exception:
        _log_exception("iter_all_outfit_cas_parts save_outfits failed")
        return

    category_counts = {}
    for proto_index, outfit_data in enumerate(outfits):
        try:
            category = int(getattr(outfit_data, "category", -1))
        except Exception:
            category = -1
        category_counts[category] = category_counts.get(category, 0) + 1
        category_index = category_counts[category] - 1

        parts = _safe_list(getattr(getattr(outfit_data, "parts", None), "ids", None))
        body_types = _safe_list(getattr(getattr(outfit_data, "body_types_list", None), "body_types", None))
        color_shifts = _safe_list(getattr(getattr(outfit_data, "part_shifts", None), "color_shift", None))
        object_ids = _safe_list(getattr(getattr(outfit_data, "object_ids", None), "object_id", None))
        part_rows = []
        for index, part_id in enumerate(parts):
            try:
                part_id = int(part_id or 0)
            except Exception:
                part_id = 0
            if not part_id:
                continue

            body_type = 0
            if index < len(body_types):
                try:
                    body_type = int(body_types[index] or 0)
                except Exception:
                    body_type = 0
            if not body_type and get_caspart_bodytype is not None:
                try:
                    body_type = int(get_caspart_bodytype(part_id) or 0)
                except Exception:
                    body_type = 0

            part_rows.append({
                "index": index,
                "cas_part_id": part_id,
                "body_type": body_type,
                "body_type_name": get_body_type_name(body_type),
                "body_group": get_body_group_for_body_type(body_type),
                "body_group_name": get_body_group_name(get_body_group_for_body_type(body_type)),
                "color_shift": color_shifts[index] if index < len(color_shifts) else 0,
                "object_id": object_ids[index] if index < len(object_ids) else 0,
            })

        category_name = get_outfit_category_name(category)
        outfit_label = "{} {}".format(category_name, category_index + 1)
        yield {
            "proto_index": proto_index,
            "category": category,
            "category_name": category_name,
            "category_index": category_index,
            "outfit_id": getattr(outfit_data, "outfit_id", 0),
            "outfit_label": outfit_label,
            "is_current": current_outfit is not None and tuple(current_outfit) == (category, category_index),
            "parts": part_rows,
        }

    try:
        current_outfit = sim_info.get_current_outfit()
        _log("Dump outfit parts for sim_id={} current_outfit={}", getattr(sim_info, "sim_id", None), current_outfit)
        outfits_msg = sim_info.save_outfits()
        outfits = _safe_list(getattr(outfits_msg, "outfits", None))
        _log("save_outfits returned {} outfit proto rows", len(outfits))

        for proto_index, outfit_data in enumerate(outfits):
            parts = getattr(getattr(outfit_data, "parts", None), "ids", None)
            body_types = getattr(getattr(outfit_data, "body_types_list", None), "body_types", None)
            color_shifts = getattr(getattr(outfit_data, "part_shifts", None), "color_shift", None)
            object_ids = getattr(getattr(outfit_data, "object_ids", None), "object_id", None)
            _log(
                "Outfit proto_index={} category={} outfit_id={} parts={} body_types={} color_shifts={} object_ids={}",
                proto_index,
                getattr(outfit_data, "category", None),
                getattr(outfit_data, "outfit_id", None),
                _safe_list(parts),
                _safe_list(body_types),
                _safe_list(color_shifts),
                _safe_list(object_ids),
            )
        return True
    except Exception:
        _log_exception("dump_current_outfit_parts failed")
        return False


def find_outfit_data(outfits_msg, outfit_key):
    try:
        category, outfit_index = outfit_key
        category_int = int(category)
        matching = []
        for proto_index, outfit_data in enumerate(_safe_list(getattr(outfits_msg, "outfits", None))):
            if int(getattr(outfit_data, "category", -1)) == category_int:
                matching.append((proto_index, outfit_data))

        _log(
            "find_outfit_data key={} category_matches={} outfit_ids={}",
            outfit_key,
            len(matching),
            [getattr(item[1], "outfit_id", None) for item in matching],
        )

        if 0 <= int(outfit_index) < len(matching):
            return matching[int(outfit_index)][1]
    except Exception:
        _log_exception("find_outfit_data failed")
    return None


def _get_parallel_field(outfit_data, path):
    value = outfit_data
    for name in path:
        value = getattr(value, name, None)
        if value is None:
            return None
    return value


def replace_cas_part_in_outfit_data(outfit_data, new_part_id):
    if outfit_data is None:
        _log("replace_cas_part_in_outfit_data: outfit_data is None")
        return False
    if not new_part_id:
        _log("replace_cas_part_in_outfit_data: TEST_CAS_PART_ID is 0; set a real CASP instance id first")
        return False
    if get_caspart_bodytype is None:
        _log("replace_cas_part_in_outfit_data: cas.cas.get_caspart_bodytype is unavailable")
        return False

    try:
        new_body_type = get_caspart_bodytype(int(new_part_id))
        if new_body_type is None:
            _log("CAS part {} returned body type None", new_part_id)
            return False

        parts = _get_parallel_field(outfit_data, ("parts", "ids"))
        body_types = _get_parallel_field(outfit_data, ("body_types_list", "body_types"))
        color_shifts = _get_parallel_field(outfit_data, ("part_shifts", "color_shift"))
        object_ids = _get_parallel_field(outfit_data, ("object_ids", "object_id"))
        layer_ids = _get_parallel_field(outfit_data, ("layer_ids", "layer_id"))
        if parts is None or body_types is None:
            _log("OutfitData has missing parts/body_types fields: parts={} body_types={}", parts, body_types)
            return False

        if len(body_types) != len(parts) or any(v is not None and len(v) not in (0,len(parts)) for v in (color_shifts,object_ids,layer_ids)):
            _log("Outfit parallel arrays do not align; replacement cancelled")
            return False
        before_parts = _safe_list(parts)
        before_body_types = _safe_list(body_types)
        _log("Before replace: parts={} body_types={} new_part={} new_body_type={}", before_parts, before_body_types, new_part_id, new_body_type)

        replace_index = None
        for index, body_type in enumerate(before_body_types):
            if int(body_type) == int(new_body_type):
                replace_index = index
                break

        if replace_index is not None and replace_index < len(parts):
            parts[replace_index] = int(new_part_id)
            _log("Replaced CAS part at index={} body_type={}", replace_index, new_body_type)
        else:
            old_count = len(parts)
            parts.append(int(new_part_id))
            body_types.append(int(new_body_type))
            if color_shifts is not None:
                if not len(color_shifts):color_shifts.extend([0]*old_count)
                color_shifts.append(int(settings.DEFAULT_COLOR_SHIFT))
            if object_ids is not None:
                if not len(object_ids):object_ids.extend([0]*old_count)
                object_ids.append(0)
            if layer_ids is not None:
                if not len(layer_ids):layer_ids.extend([0]*old_count)
                layer_ids.append(0)
            _log("Appended CAS part body_type={}", new_body_type)

        if int(new_body_type)==2 and hasattr(outfit_data,'match_hair_style'):
            outfit_data.match_hair_style=False

        _log(
            "After replace: parts={} body_types={} color_shifts={} object_ids={}",
            _safe_list(parts),
            _safe_list(body_types),
            _safe_list(color_shifts),
            _safe_list(object_ids),
        )
        return True
    except Exception:
        _log_exception("replace_cas_part_in_outfit_data failed")
        return False


def _get_special_outfit_key():
    if OutfitCategory is None:
        return None
    return (OutfitCategory.SPECIAL, settings.USE_SPECIAL_OUTFIT_INDEX)


def _normalize_outfit_key(outfit_key):
    try:
        category, outfit_index = outfit_key
        return (int(category), int(outfit_index))
    except Exception:
        return outfit_key


def _is_linked_temp_outfit(outfit_key):
    temp_outfit = _get_special_outfit_key()
    if temp_outfit is None or outfit_key is None:
        return False
    return _normalize_outfit_key(outfit_key) == _normalize_outfit_key(temp_outfit)


def _get_everyday_fallback_outfit():
    if OutfitCategory is None:
        return None
    try:
        return (OutfitCategory.EVERYDAY, 0)
    except Exception:
        return None


def _get_safe_original_outfit(sim_info):
    try:
        current_outfit = sim_info.get_current_outfit()
    except Exception:
        _log_exception("_get_safe_original_outfit get_current_outfit failed")
        current_outfit = None

    if not _is_linked_temp_outfit(current_outfit):
        return current_outfit

    existing_backup = _original_outfit_by_sim_id.get(getattr(sim_info, "sim_id", None))
    if existing_backup is not None and not _is_linked_temp_outfit(existing_backup):
        _log("Current outfit is linked temp; reusing existing safe backup {}", existing_backup)
        return existing_backup

    fallback = _get_everyday_fallback_outfit()
    _log("Current outfit is linked temp and no safe backup exists; using fallback original {}", fallback)
    return fallback if fallback is not None else current_outfit


# R58: an explicit manual edit owns the current wear until a real outfit switch.
# Store only the outfit key; no models, textures or serialized outfit copies.
_manual_current_outfit_by_sim_id = {}

# R59: slot journal for changes made by linked CAS, independent of old outfit keys.
_linked_current_baselines = {}

def _linked_restore_log(event, sim_info, count=0):
    try:
        import couplepose1
        couplepose1.fgeh_pose_manager_perf_log('CAS_CHAIN {} sim={} slots={}'.format(event, sim_info.sim_id, count))
    except Exception:
        pass

def capture_linked_current_baseline(sim_info):
    import fgeh_outfit_editor_r30 as editor
    key = _normalize_outfit_key(sim_info.get_current_outfit())
    data = find_outfit_data(sim_info.save_outfits(), key)
    if data is None:
        raise ValueError('Cannot capture current wear before linked CAS')
    bodies = set(map(int, editor.fields(data)[1]))
    records = {body:tuple(editor.slot_records(data, body)) for body in bodies}
    return (key, records, bool(getattr(data, 'match_hair_style', False)))

def complete_linked_current_baseline(sim_info, snapshot):
    import fgeh_outfit_editor_r30 as editor
    before_key, before, before_hair = snapshot
    key = _normalize_outfit_key(sim_info.get_current_outfit())
    data = find_outfit_data(sim_info.save_outfits(), key)
    if data is None:
        raise ValueError('Cannot read current wear after linked CAS')
    bodies = set(before) | set(map(int, editor.fields(data)[1]))
    journal = _linked_current_baselines.get(sim_info.sim_id)
    if journal is None or journal['key'] != before_key:
        journal = dict(key=key, slots={}, return_key=before_key)
    else:
        journal['key'] = key
    for body in bodies:
        old = before.get(body, ())
        after = tuple(editor.slot_records(data, body))
        if old == after:
            continue
        previous = journal['slots'].get(body)
        baseline = previous[0] if previous is not None and previous[1] == old else old
        journal['slots'][body] = (baseline, after)
    after_hair = bool(getattr(data, 'match_hair_style', False))
    if before_hair != after_hair:
        previous = journal.get('hair')
        journal['hair'] = (previous[0] if previous and previous[1] == before_hair else before_hair, after_hair)
    if journal['slots'] or 'hair' in journal:
        _linked_current_baselines[sim_info.sim_id] = journal
        _linked_restore_log('CAPTURED', sim_info, len(journal['slots']))
        return True
    return False

def has_linked_current_baseline(sim_info):
    return getattr(sim_info, 'sim_id', None) in _linked_current_baselines


def discard_linked_current_baseline(sim_info):
    _linked_current_baselines.pop(sim_info.sim_id, None)

def restore_linked_current_baseline(sim_info):
    import fgeh_outfit_editor_r30 as editor
    journal = _linked_current_baselines.get(sim_info.sim_id)
    if journal is None:
        return False
    key = _normalize_outfit_key(sim_info.get_current_outfit())
    if key != journal['key']:
        discard_linked_current_baseline(sim_info)
        _linked_restore_log('SKIP_OUTFIT_CHANGED', sim_info)
        return True  # Handled: do not fall back to an unrelated old outfit.
    message = sim_info.save_outfits()
    data = find_outfit_data(message, key)
    if data is None:
        raise ValueError('Linked restore current outfit missing')
    restore = {body:before for body,(before,after) in journal['slots'].items()
               if tuple(editor.slot_records(data, body)) == after}
    hair = journal.get('hair')
    restore_hair = hair is not None and bool(getattr(data, 'match_hair_style', False)) == hair[1]
    if not restore and not restore_hair:
        discard_linked_current_baseline(sim_info)
        _linked_restore_log('SKIP_PLAYER_CHANGED_SLOTS', sim_info)
        return True
    # A saved whole-outfit binding must not be modified by automatic cleanup.
    # Compose into our temporary outfit, then restore only linked-owned slots.
    if not _is_linked_temp_outfit(key):
        temp = _get_special_outfit_key()
        sim_info.generate_merged_outfit(sim_info, temp, key, key)
        key = _normalize_outfit_key(temp)
        message = sim_info.save_outfits()
        data = find_outfit_data(message, key)
        if data is None:
            raise ValueError('Linked restore temporary outfit missing')
    for body,records in restore.items():
        editor.restore_slot(data, body, records)
    if restore_hair and hasattr(data, 'match_hair_style'):
        data.match_hair_style = hair[0]
    editor.fields(data)
    sim_info.load_outfits(message)
    # EA 1.128 refuses an unchanged outfit key unless its category is dirty.
    # The slot data changed above, so mark it before requesting the rebuild.
    sim_info.set_outfit_dirty(key[0])
    if sim_info.set_current_outfit(key) is False:
        raise ValueError('Game rejected linked CAS restoration')
    _refresh_current_outfit(sim_info, key, 'R59_LINKED_SLOT_RESTORE')
    actual = find_outfit_data(sim_info.save_outfits(), key)
    if actual is None or any(tuple(editor.slot_records(actual, body)) != records for body,records in restore.items()):
        raise ValueError('Game did not retain restored linked CAS slots')
    discard_linked_current_baseline(sim_info)
    _linked_restore_log('RESTORED', sim_info, len(restore))
    return True


def mark_manual_current_outfit(sim_info):
    sid = getattr(sim_info, 'sim_id', None)
    if sid is not None:
        key = _normalize_outfit_key(sim_info.get_current_outfit())
        journal = _linked_current_baselines.get(sid)
        if journal is not None and journal['key'] != key:
            if _is_linked_temp_outfit(key):
                journal['key'] = key
            else:
                discard_linked_current_baseline(sim_info)
        _manual_current_outfit_by_sim_id[sid] = key
        if not _is_linked_temp_outfit(key):
            _original_outfit_by_sim_id[sid] = key

def has_manual_current_outfit(sim_info):
    sid = getattr(sim_info, 'sim_id', None)
    remembered = _manual_current_outfit_by_sim_id.get(sid)
    if remembered is None:
        return False
    if remembered != _normalize_outfit_key(sim_info.get_current_outfit()):
        _manual_current_outfit_by_sim_id.pop(sid, None)
        return False
    return True


def _get_source_outfit_for_apply(sim_id, current_outfit, original_outfit):
    # Current temporary wear remains the source even after Save consumed its
    # original backup. The backup is for explicit restoration, not composition.
    return current_outfit if current_outfit is not None else original_outfit


def _refresh_current_outfit(sim_info, outfit_key, label):
    before = None
    try:
        before = sim_info.get_current_outfit()
    except Exception:
        pass
    _log("{} refresh begin outfit_key={} current_before={}", label, outfit_key, before)
    try:
        tracker = getattr(sim_info, 'appearance_tracker', None)
        if tracker is not None and getattr(tracker, 'appearance_override_sim_info', None) is not None:
            tracker.evaluate_appearance_modifiers()
    except Exception:
        _log_exception("{} appearance override refresh failed".format(label))
    try:
        sim_info.set_outfit_dirty(outfit_key[0])
        if sim_info.set_current_outfit(outfit_key) is False:
            raise ValueError('Game rejected current outfit switch')
    except Exception:
        _log_exception("{} current outfit rebuild failed".format(label))
    # Recompute external appearance first, then compose only our current hair.
    import fgeh_outfit_editor_r30 as editor
    import sys
    editor.sync_display_hair(sim_info,outfit_key,sys.modules[__name__])
    try:
        editor.diagnostic(sim_info,'TRACE_BEFORE_RESEND_OUTFITS')
        sim_info.resend_outfits()
        editor.diagnostic(sim_info,'TRACE_AFTER_RESEND_OUTFITS')
    except Exception:
        _log_exception("{} resend_outfits failed".format(label))
    try:
        editor.diagnostic(sim_info,'TRACE_BEFORE_RESEND_CURRENT')
        sim_info.resend_current_outfit()
        editor.diagnostic(sim_info,'TRACE_AFTER_RESEND_CURRENT')
    except Exception:
        _log_exception("{} resend_current_outfit failed".format(label))
    after = None
    try:
        after = sim_info.get_current_outfit()
    except Exception:
        pass
    _log("{} refresh end outfit_key={} current_after={}", label, outfit_key, after)
    if label in ('R33_VARIANT', 'R31_REMOVE_PREVIEW', 'R31_CANCEL_LIBRARY_SLOT',
                 'R31_CANCEL_LIBRARY_COMPLETE', 'R55_COMMIT_KEEP_CURRENT'):
        mark_manual_current_outfit(sim_info)
    elif label in ('restore', 'apply_saved_outfit'):
        if label == 'restore':
            discard_linked_current_baseline(sim_info)
        _manual_current_outfit_by_sim_id.pop(getattr(sim_info, 'sim_id', None), None)


def apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id=None):
    if sim_info is None:
        _log("apply_fixed_cas_accessory_to_sim: sim_info is None")
        return False

    if cas_part_id is None:
        _log("No snippet CASP id supplied; using settings.TEST_CAS_PART_ID={}", settings.TEST_CAS_PART_ID)
        cas_part_id = settings.TEST_CAS_PART_ID
    else:
        _log("Using CASP id supplied by snippet/argument: {}", cas_part_id)
    if not cas_part_id:
        _log("apply_fixed_cas_accessory_to_sim: TEST_CAS_PART_ID is still 0")
        return False

    temp_outfit = _get_special_outfit_key()
    if temp_outfit is None:
        _log("apply_fixed_cas_accessory_to_sim: OutfitCategory.SPECIAL unavailable")
        return False

    try:
        sim_id = getattr(sim_info, "sim_id", None)
        current_outfit = sim_info.get_current_outfit()
        manual_owned = has_manual_current_outfit(sim_info)
        original_outfit = _get_safe_original_outfit(sim_info)
        existing_backup = _original_outfit_by_sim_id.get(sim_id)
        if existing_backup is None:
            _original_outfit_by_sim_id[sim_id] = original_outfit
        elif _is_linked_temp_outfit(existing_backup) and not _is_linked_temp_outfit(original_outfit):
            _original_outfit_by_sim_id[sim_id] = original_outfit
            _log("Replaced contaminated original outfit backup sim_id={} old={} new={}", sim_id, existing_backup, original_outfit)
        source_outfit = _get_source_outfit_for_apply(sim_id, current_outfit, original_outfit)
        _log(
            "Applying fixed CAS accessory sim_id={} current={} current_is_temp={} original={} existing_backup={} source={} temp={} cas_part={} backup_keys={}",
            sim_id,
            current_outfit,
            _is_linked_temp_outfit(current_outfit),
            original_outfit,
            existing_backup,
            source_outfit,
            temp_outfit,
            cas_part_id,
            list(_original_outfit_by_sim_id.keys()),
        )

        sim_info.generate_merged_outfit(sim_info, temp_outfit, source_outfit, source_outfit)
        outfits_msg = sim_info.save_outfits()
        temp_outfit_data = find_outfit_data(outfits_msg, temp_outfit)
        if temp_outfit_data is None:
            _log("Could not find temp SPECIAL outfit data after generate_merged_outfit")
            return False

        if not replace_cas_part_in_outfit_data(temp_outfit_data, cas_part_id):
            return False

        sim_info.load_outfits(outfits_msg)
        _refresh_current_outfit(sim_info, temp_outfit, "apply")
        if manual_owned:
            _manual_current_outfit_by_sim_id[sim_id] = _normalize_outfit_key(temp_outfit)

        _log("Applied fixed CAS accessory successfully sim_id={} temp={}", sim_id, temp_outfit)
        return True
    except Exception:
        _log_exception("apply_fixed_cas_accessory_to_sim failed")
        return False


def apply_saved_outfit_to_sim(sim_info, category, category_index, label=None):
    if sim_info is None:
        _log("apply_saved_outfit_to_sim: sim_info is None")
        return False
    try:
        category = int(category or 0)
        category_index = int(category_index or 0)
    except Exception:
        _log("apply_saved_outfit_to_sim: invalid category={} index={}", category, category_index)
        return False

    try:
        sim_id = getattr(sim_info, "sim_id", None)
        current_outfit = sim_info.get_current_outfit()
        original_outfit = _get_safe_original_outfit(sim_info)
        if _original_outfit_by_sim_id.get(sim_id) is None:
            _original_outfit_by_sim_id[sim_id] = original_outfit
        outfit_key = (category, category_index)
        _log(
            "Applying saved outfit sim_id={} label={} current={} original={} outfit_key={}",
            sim_id,
            label,
            current_outfit,
            original_outfit,
            outfit_key,
        )
        result = sim_info.set_current_outfit(outfit_key)
        _refresh_current_outfit(sim_info, outfit_key, "apply_saved_outfit")
        _log("Applied saved outfit sim_id={} outfit_key={} result={}", sim_id, outfit_key, result)
        return True
    except Exception:
        _log_exception("apply_saved_outfit_to_sim failed")
        return False


def restore_original_outfit(sim_info):
    if sim_info is None:
        _log("restore_original_outfit: sim_info is None")
        return False

    try:
        sim_id = getattr(sim_info, "sim_id", None)
        current_before = sim_info.get_current_outfit()
        original_outfit = _original_outfit_by_sim_id.get(sim_id)
        _log(
            "restore_original_outfit begin sim_id={} current={} current_is_temp={} backup={} backup_keys={}",
            sim_id,
            current_before,
            _is_linked_temp_outfit(current_before),
            original_outfit,
            list(_original_outfit_by_sim_id.keys()),
        )
        if original_outfit is None:
            current_outfit = current_before
            if not _is_linked_temp_outfit(current_outfit):
                _log("No original outfit backup for sim_id={} current={} is not linked temp", sim_id, current_outfit)
                return False
            original_outfit = _get_everyday_fallback_outfit()
            if original_outfit is None:
                _log("No original outfit backup and no fallback outfit for sim_id={}", sim_id)
                return False
            _log("No original outfit backup for sim_id={}; current is linked temp {}, fallback restore to {}", sim_id, current_outfit, original_outfit)

        _log("Restoring original outfit sim_id={} outfit={}", sim_id, original_outfit)
        restored = sim_info.set_current_outfit(original_outfit)
        _log("restore set_current_outfit result sim_id={} result={} now={}", sim_id, restored, sim_info.get_current_outfit())
        if not restored:
            return False
        _refresh_current_outfit(sim_info, original_outfit, "restore")
        try:
            if sim_id in _original_outfit_by_sim_id:
                del _original_outfit_by_sim_id[sim_id]
        except Exception:
            pass
        _log("restore_original_outfit end sim_id={} current={} backup_removed={}", sim_id, sim_info.get_current_outfit(), sim_id not in _original_outfit_by_sim_id)
        return True
    except Exception:
        _log_exception("restore_original_outfit failed")
        return False


def _iter_instanced_sim_infos():
    try:
        sim_info_manager = services.sim_info_manager()
    except Exception:
        sim_info_manager = None
    if sim_info_manager is None:
        return
    try:
        for candidate in sim_info_manager.instanced_sims_gen():
            sim_info = getattr(candidate, "sim_info", None) or candidate
            if sim_info is not None:
                yield sim_info
    except Exception:
        _log_exception("_iter_instanced_sim_infos failed")


def _find_instanced_sim_info(sim_id):
    try:
        sim_info_manager = services.sim_info_manager()
    except Exception:
        sim_info_manager = None
    if sim_info_manager is not None:
        try:
            sim_info = sim_info_manager.get(sim_id)
            if sim_info is not None:
                return sim_info
        except Exception:
            pass
    try:
        for sim_info in _iter_instanced_sim_infos():
            if getattr(sim_info, "sim_id", None) == sim_id:
                return sim_info
    except Exception:
        pass
    return None


def restore_all_original_outfits():
    restored_count = 0
    try:
        backup_ids = list(_original_outfit_by_sim_id.keys())
    except Exception:
        backup_ids = []

    restored_sim_ids = set()
    for sim_id in backup_ids:
        sim_info = _find_instanced_sim_info(sim_id)
        if sim_info is None:
            _log("restore_all_original_outfits: sim_info not found for sim_id={}", sim_id)
            continue
        if restore_original_outfit(sim_info):
            restored_count += 1
            restored_sim_ids.add(sim_id)

    try:
        for sim_info in _iter_instanced_sim_infos():
            sim_id = getattr(sim_info, "sim_id", None)
            if sim_id in restored_sim_ids:
                continue
            try:
                current_outfit = sim_info.get_current_outfit()
            except Exception:
                continue
            if not _is_linked_temp_outfit(current_outfit):
                continue
            _log("restore_all_original_outfits: found linked temp outfit without active backup sim_id={} current={}", sim_id, current_outfit)
            if restore_original_outfit(sim_info):
                restored_count += 1
                restored_sim_ids.add(sim_id)
    except Exception:
        _log_exception("restore_all_original_outfits linked temp scan failed")

    _log("restore_all_original_outfits backup_count={} restored_count={}", len(backup_ids), restored_count)
    return restored_count


def claim_manual_cas_part(sim_info, body_type):
    """A library choice owns its slot, including a repeat of a linked item."""
    sid = getattr(sim_info, 'sim_id', None)
    journal = _linked_current_baselines.get(sid)
    if journal is not None:
        journal['slots'].pop(int(body_type), None)
        if get_body_type_name(body_type) == 'HAIR':
            journal['hair'] = None
        if not journal['slots'] and journal.get('hair') is None:
            discard_linked_current_baseline(sim_info)
    mark_manual_current_outfit(sim_info)
    # A subsequent genuinely linked pose must apply its requirements again.
    import sys
    manager = sys.modules.get('couplepose1')
    active = getattr(manager, '_ACTIVE_LINKED_CAS_KEYS_BY_SIM', None)
    if isinstance(active, dict):
        active.pop(sid, None)


def claim_manual_outfit_changes(sim_info, before_message, selected_body_type):
    """Claim manual preview changes from the actual editor/library route."""
    import fgeh_outfit_editor_r30 as editor
    key = _normalize_outfit_key(sim_info.get_current_outfit())
    after = find_outfit_data(sim_info.save_outfits(), key)
    before = find_outfit_data(before_message, key)
    if before is None:
        # Trial editing may have created the SPECIAL outfit from the old key.
        previous = _original_outfit_by_sim_id.get(sim_info.sim_id)
        if previous is not None:
            before = find_outfit_data(before_message, previous)
    if before is None or after is None:
        raise ValueError('Cannot transfer manual outfit slot ownership')
    bodies = set(map(int, editor.fields(before)[1])) | set(map(int, editor.fields(after)[1]))
    claimed = {int(selected_body_type)}
    claimed.update(body for body in bodies
                   if tuple(editor.slot_records(before, body)) != tuple(editor.slot_records(after, body)))
    for body in claimed:
        claim_manual_cas_part(sim_info, body)
