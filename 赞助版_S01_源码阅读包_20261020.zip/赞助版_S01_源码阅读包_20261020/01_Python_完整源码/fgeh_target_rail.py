from fgeh_shared_ui_localization import text as _t
"""T01: detail-only target context and non-closing target acknowledgement."""
import uuid
import json
import time
import traceback
from pathlib import Path
from urllib.parse import quote
import services
import sims4.commands

MARKER = '__FGEH_TARGET_RAIL_T01__'
MESSAGE = 'FgEHTargetRailStateT01'
_context = None
_last_diagnostic = ''
_diagnostic_count = 0
_working_ids = None
_working_zone = None


def _constant(value):
    return lambda *args, **kwargs: value


def diagnostic(event, error=None):
    # Release: memory only; never create diagnostic files.
    global _last_diagnostic, _diagnostic_count
    _last_diagnostic = '{}: {}'.format(event, error or '')














def prepare_safe(*args):
    try:
        result = prepare(*args)
        diagnostic('prepared' if result is not args[4] else 'not_enabled')
        return result
    except Exception as error:
        global _context
        _context = None
        diagnostic('prepare_failed', error)
        return args[4]


def _name(sim):
    return ' '.join(str(getattr(sim, k, '') or '') for k in ('first_name', 'last_name')).strip() or _t('shared_bcae15208cc0')


def prepare(panel, manager, owner, callback, payload, enabled, icon_base=0):
    global _context, _working_ids, _working_zone
    _context = None
    if not enabled:
        return payload
    interaction = panel._v86_resolve_interaction_from_callback(callback)
    if interaction is None:
        return payload
    candidates = {}
    for sim in services.sim_info_manager().instanced_sims_gen():
        ident = int(getattr(sim, 'id', 0) or getattr(sim, 'sim_id', 0) or 0)
        if ident and getattr(sim, 'first_name', None):
            candidates[str(ident)] = sim
    if not candidates:
        return payload
    target = panel._v8944_dialog_portrait_sim_info(owner, callback)
    selected = str(getattr(target, 'sim_id', 0) or getattr(target, 'id', 0) or 0)
    zone = services.current_zone_id()
    if _working_zone != zone:
        _working_zone = zone
        _working_ids = None
    working = set(candidates) if _working_ids is None else set(candidates).intersection(_working_ids)
    if selected in candidates:
        working.add(selected)
    token = uuid.uuid4().hex
    ordered = sorted(candidates, key=lambda k: (_name(candidates[k]).casefold(), int(k)))
    # Keep IDs as strings end to end: AS3 Number cannot represent all uint64 IDs.
    from distributor.shared_messages import IconInfoData, create_icon_info_msg
    portraits = [create_icon_info_msg(IconInfoData(obj_instance=candidates[ident].sim_info)) for ident in ordered]
    rows = ['{}\t{}\t{}\t{}'.format(ident, quote(_name(candidates[ident]), safe=''), icon_base+index, int(ident in working)) for index,ident in enumerate(ordered)]
    wire = MARKER + '\n' + token + '\n' + selected + '\n' + '\n'.join(rows)
    _context = {'token': token, 'interaction': interaction, 'candidates': candidates,
                'zone': services.current_zone_id(), 'dialog': None, 'requests': {},
                'play_context': panel._ACTIVE_PLAY_CONTEXT, 'panel': panel, 'owner': owner,
                'portrait_infos': portraits, 'working_ids': working, 'selected': selected}
    return tuple(payload) + __import__("fgeh_shared_ui_localization").entries() + (wire,)


def bind(dialog):
    if _context is not None:
        _context['dialog'] = dialog
        diagnostic('bound_dialog')


def icons():
    return tuple(_context['portrait_infos']) if _context is not None else ()


def _live_context(token):
    ctx = _context
    if ctx is None or ctx['token'] != token or ctx['zone'] != services.current_zone_id():
        raise ValueError(_t('shared_6dee341053be'))
    if ctx['panel']._ACTIVE_PLAY_CONTEXT is not ctx['play_context']:
        raise ValueError(_t('shared_b507e1d5984f'))
    dialog = ctx['dialog']
    if dialog is None or services.ui_dialog_service().get_dialog(dialog.dialog_id) is not dialog:
        raise ValueError(_t('shared_b5794f4ae54f'))
    return ctx


def _ack(ctx, request, ok, selected, message, kind='choose'):
    from sims4.localization import LocalizationHelperTuning
    from event_testing.resolver import SingleSimResolver
    from ui.ui_dialog_labeled_icons import UiDialogIcons
    owner = ctx['owner']
    blank = LocalizationHelperTuning.get_raw_text('')
    texts = (ctx['token'], request, 'ok' if ok else 'error', selected, message, kind, ','.join(sorted(ctx['working_ids'])))
    dialog = UiDialogIcons.TunableFactory().default(
        owner, resolver=SingleSimResolver(owner.sim_info), title=_constant(blank), text=_constant(blank),
        additional_texts=tuple(_constant(t) for t in __import__("fgeh_shared_ui_localization").pack(texts, False)),
        show_dialog_message_override=MESSAGE)
    dialog.set_responses(())
    dialog.show_dialog()


def _deliver(ctx, request, result):
    try:
        _ack(ctx, request, *result)
    except Exception as error:
        # A failed delivery cannot turn an already-committed target into an error ack.
        # The UI keeps its input barrier until confirmation or closing the window.
        diagnostic('ack_delivery_failed', error)


@sims4.commands.Command('fgeh.targets.choose', command_type=sims4.commands.CommandType.Live)
def choose(token: str, request: str, sim_id: str, _connection=None):
    ctx = None
    try:
        diagnostic('choose_received')
        ctx = _live_context(token)
        if len(request) > 32 or not request.isdigit() or len(sim_id) > 20 or not sim_id.isdigit():
            raise ValueError(_t('shared_c3553fd29706'))
        if request in ctx['requests']:
            result = ctx['requests'][request]
            _deliver(ctx, request, result)
            return result[0]
        sim = ctx['candidates'].get(sim_id)
        if sim is None or services.object_manager().get(int(sim_id)) is not sim:
            raise ValueError(_t('shared_3a8a00e3b3b2'))
        if sim_id not in ctx['working_ids']:
            raise ValueError(_t('shared_cd4ebbcc4a43'))
        ctx['interaction'].fgeh_custom_target_id = int(sim_id)
        ctx['selected'] = sim_id
        diagnostic('target_changed')
        result = (True, sim_id, _name(sim))
        # Bounded duplicate suppression. No queue transfer, active-Sim switch or JSON write.
        ctx['requests'][request] = result
        while len(ctx['requests']) > 64:
            del ctx['requests'][next(iter(ctx['requests']))]
        _deliver(ctx, request, result)
        return True
    except Exception as error:
        diagnostic('choose_rejected', error)
        if ctx is not None:
            try:
                _ack(ctx, request, False, '', str(error))
            except Exception:
                pass
        return False


@sims4.commands.Command('fgeh.targets.clear', command_type=sims4.commands.CommandType.Live)
def clear(token: str, _connection=None):
    global _context
    if _context is not None and _context['token'] == token:
        _context = None
        diagnostic('closed_context')
    return True


@sims4.commands.Command('fgeh.targets.status', command_type=sims4.commands.CommandType.Live)
def status(_connection=None):
    import fgeh_pose_manager_ui_panel as panel
    message = '{} | detail_error={} | active={}'.format(_last_diagnostic, getattr(panel, 'LAST_ERROR', ''), _context is not None)
    sims4.commands.CheatOutput(_connection)(message)
    diagnostic('status', message)
    return True


@sims4.commands.Command('fgeh.targets.image', command_type=sims4.commands.CommandType.Live)
def image_event(token: str, event: str, detail: str = '', _connection=None):
    from urllib.parse import unquote
    if _context is not None and token == _context['token'] and event in ('requested','loaded','failed','error','waiting','observed','rejected','listener'):
        diagnostic('portrait_'+event, unquote(detail)[:600] if detail else None)
    return True


def filter_people(token, request, wire):
    global _working_ids
    ctx = _live_context(token)
    if not request.isdigit() or len(request) > 32:
        raise ValueError(_t('shared_f3902d9af90a'))
    key = 'filter:' + request
    if key not in ctx['requests']:
        ids = set(wire.split(','))
        if not ids or len(ids) > 64 or not ids.issubset(ctx['candidates']):
            raise ValueError(_t('shared_4bda3710af10'))
        ids.add(ctx['selected'])
        if len(ids) > 64:
            raise ValueError(_t('shared_f105be6842fa'))
        _working_ids = set(ids)
        ctx['working_ids'] = set(ids)
        ctx['requests'][key] = (True, ctx['selected'], _t('shared_64e19f239422').format(len(ids)))
        while len(ctx['requests']) > 64:
            del ctx['requests'][next(iter(ctx['requests']))]
    _ack(ctx, request, *ctx['requests'][key], kind='filter')
    diagnostic('filter_applied')
    return True


@sims4.commands.Command('fgeh.targets.packet', command_type=sims4.commands.CommandType.Live)
def packet(wire: str, _connection=None):
    from urllib.parse import unquote
    try:
        if len(wire) > 4096:
            raise ValueError(_t('shared_9b17f355655d'))
        token, request, operation, value = unquote(wire, encoding='utf-8', errors='strict').split('|')
        if operation == 'choose':
            return choose(token, request, value, _connection)
        if operation == 'clear':
            return clear(token, _connection)
        if operation == 'image':
            event, detail = value.split('~', 1)
            return image_event(token, event, detail, _connection)
        if operation == 'filter':
            return filter_people(token, request, value)
        raise ValueError(_t('shared_93ea289794f2'))
    except Exception as error:
        diagnostic('packet_rejected', error)
        return False
