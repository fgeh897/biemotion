from fgeh_pose_manager_localization import display_text as _fgeh_hash_ui_text
"""Outfit-editor-only change journal. No writes until explicit Save response."""
import base64
import datetime
import json
import importlib
import sys
import copy
from pathlib import Path

DEFAULT_COLOR_SHIFT = 4611686018427387904
SESSIONS = {}
SAVE_RESPONSE = 700030
REFRESH_RESPONSE = 700031
REMOVE_RESPONSE = 700032
CLEAR_RESPONSE = 700033
LIBRARY_SESSIONS = {}
BALD_PARTS = {2:(160844,12290),4:(42928,12292),128:(310516,12416)}

def outfit_contract(data):
    # Native CAS may normalize timestamp/field presence and serialization order.
    return (int(data.category),int(data.outfit_id),
        tuple(tuple(v) if v is not None and len(v) else () for v in fields(data)),
        bool(getattr(data,'match_hair_style',False)),
        int(getattr(data,'outfit_flags',0)),int(getattr(data,'outfit_flags_high',0)),
        str(getattr(data,'title','')),tuple(getattr(data,'outfitflags_array',())),
        getattr(data,'metadata',None))

def same_contract(data,baseline):
    return outfit_contract(data)==baseline

def remember(session,data):
    session['preview_bytes']=data.SerializeToString()
    session['preview_contract']=outfit_contract(data)

def preview_matches(session,data):
    if 'preview_contract' in session:return same_contract(data,session['preview_contract'])
    return data.SerializeToString()==session['preview_bytes']

def other_outfit_contracts(snapshot,key):
    # Protobuf wrappers may return different Python objects for the same row.
    # Identify the target by category and occurrence, never by object identity.
    category,index=map(int,key);seen=0;result=[]
    for row in snapshot.outfits:
        if int(row.category)==category:
            is_target=seen==index;seen+=1
            if is_target:continue
        result.append(outfit_contract(row))
    # Native serialization can reorder categories; retain order within each category.
    return sorted(result,key=lambda contract:contract[0])

TRACE_SIMS={}
def install_hair_trace(sim_info):
    TRACE_SIMS[int(sim_info.sim_id)]=sim_info
    try:
        from buffs.appearance_modifier.appearance_tracker import AppearanceTracker
        from distributor.ops import SetSimOutfits
        if not getattr(AppearanceTracker.evaluate_appearance_modifiers,'_fgeh_hair_trace',False):
            previous=AppearanceTracker.evaluate_appearance_modifiers
            def evaluate(tracker,*args,**kwargs):
                actor=getattr(tracker,'_sim_info',None)
                watched=actor is not None and int(getattr(actor,'sim_id',0)) in TRACE_SIMS
                if watched:diagnostic(actor,'TRACE_EVALUATE_BEFORE')
                result=previous(tracker,*args,**kwargs)
                if watched:
                    # WW v185k reevaluates inside resend_outfits. Compose after
                    # that evaluation, before its wrapper sends the new object.
                    import fgeh_cas_accessory_outfit_utils as outfits
                    sync_display_hair(actor,actor.get_current_outfit(),outfits)
                    diagnostic(actor,'POST_EVALUATE_HAIR_COMPOSED')
                return result
            evaluate._fgeh_hair_trace=True
            AppearanceTracker.evaluate_appearance_modifiers=evaluate
        if not getattr(SetSimOutfits.write,'_fgeh_hair_trace',False):
            previous_write=SetSimOutfits.write
            def write(op,*args,**kwargs):
                actors=[actor for actor in TRACE_SIMS.values() if int(getattr(op.outfits,'sim_id',getattr(op.outfits,'id',0)) or 0)==int(actor.sim_id) or op.outfits is actor or op.outfits is getattr(getattr(actor,'appearance_tracker',None),'appearance_override_sim_info',None)]
                for actor in actors:diagnostic(actor,'TRACE_SEND_WRITE_BEFORE',op.outfits)
                try:return previous_write(op,*args,**kwargs)
                finally:
                    for actor in actors:diagnostic(actor,'TRACE_SEND_WRITE_AFTER',op.outfits)
            write._fgeh_hair_trace=True
            SetSimOutfits.write=write
    except Exception as exc:diagnostic(sim_info,'TRACE_INSTALL_FAILURE:'+str(exc))

def native_hair(sim_info,key,part_id,outfits,match_style=False):
    install_hair_trace(sim_info)
    # Compatibility name for callers; bypass native appearance merging entirely.
    # Directly edit only this outfit and give its changed appearance a fresh ID.
    import uuid
    snapshot=sim_info.save_outfits();data=outfits.find_outfit_data(snapshot,key)
    if data is None:raise ValueError('Hair target outfit is missing')
    if int(outfits.get_caspart_bodytype(int(part_id)))!=2:
        raise ValueError('Requested hair CASP is not HAIR')
    original=copy.deepcopy(data);others=other_outfit_contracts(snapshot,key)
    replace_part(data,int(part_id),outfits)
    if hasattr(data,'match_hair_style'):data.match_hair_style=bool(match_style)
    used={int(v.outfit_id) for v in snapshot.outfits}
    identity=uuid.uuid4().int&((1<<64)-1)
    while not identity or identity in used:identity=uuid.uuid4().int&((1<<64)-1)
    data.outfit_id=identity
    validate_transition(original,data)
    sim_info.load_outfits(snapshot)
    actual=sim_info.save_outfits();target=outfits.find_outfit_data(actual,key)
    if other_outfit_contracts(actual,key)!=others:
        raise ValueError('Direct hair edit changed a different outfit')
    if target is None or slot_records(target,2)!=slot_records(data,2):
        raise ValueError('Direct hair write did not retain the selected swatch')
    if int(target.outfit_id)!=identity or bool(getattr(target,'match_hair_style',False))!=bool(match_style):
        raise ValueError('Direct hair identity/matching was normalized')
    diagnostic(sim_info,'DIRECT_HAIR_WRITTEN:'+str(part_id))

def hair_independent(data):
    if hasattr(data,'match_hair_style'):
        data.match_hair_style=False

def sync_display_hair(sim_info,key,outfits):
    tracker=getattr(sim_info,'appearance_tracker',None)
    override=getattr(tracker,'appearance_override_sim_info',None)
    if override is None:return
    base=outfits.find_outfit_data(sim_info.save_outfits(),key)
    # Respect external matching when this outfit is not independent.
    if base is None or bool(getattr(base,'match_hair_style',True)):return
    snapshot=override.save_outfits();backup=copy.deepcopy(snapshot);target=outfits.find_outfit_data(snapshot,key)
    if target is None:raise ValueError('Display override lacks the edited outfit')
    before=copy.deepcopy(target);others=other_outfit_contracts(snapshot,key)
    restore_slot(target,2,slot_records(base,2))
    target.match_hair_style=False
    target.outfit_id=base.outfit_id
    try:
        override.load_outfits(snapshot)
        actual=override.save_outfits();display=outfits.find_outfit_data(actual,key)
        if display is None or slot_records(display,2)!=slot_records(base,2):
            raise ValueError('Display override did not retain edited hair')
        kinds=set(fields(before)[1])|set(fields(display)[1])
        if any(slot_records(before,b)!=slot_records(display,b) for b in kinds if b!=2):
            raise ValueError('Display hair synchronization changed another body slot')
        if other_outfit_contracts(actual,key)!=others:
            raise ValueError('Display hair synchronization changed another outfit')
    except Exception:
        override.load_outfits(backup)
        raise
    diagnostic(sim_info,'DISPLAY_HAIR_SYNCED')

def verify_applied(sim_info,key,expected,bodies,outfits):
    if tuple(map(int,sim_info.get_current_outfit()))!=tuple(map(int,key)):
        raise ValueError('Game rejected preview outfit switch')
    actual=outfits.find_outfit_data(sim_info.save_outfits(),key)
    if actual is None:raise ValueError('Applied outfit disappeared')
    validate_transition(expected,actual)
    for body in bodies:
        if slot_records(actual,body)!=slot_records(expected,body):
            raise ValueError('Applied slot differs after refresh: '+str(body))
    if 2 in bodies and bool(getattr(actual,'match_hair_style',False))!=bool(getattr(expected,'match_hair_style',False)):
        raise ValueError('Hair matching changed after refresh')
    return actual

def bald_part(sim_info,outfits):
    age=int(getattr(sim_info,'age',0));gender=int(getattr(sim_info,'gender',0))
    if int(getattr(sim_info,'species',0))!=1:return None
    candidate=BALD_PARTS.get(age)
    if age in (8,16,32,64):
        candidate=(27056,8312) if gender==8192 else (27047,4216) if gender==4096 else None
    if not candidate:return None
    part,mask=candidate
    if not mask&age or not mask&gender or int(outfits.get_caspart_bodytype(part))!=2:return None
    return part


_DIAGNOSTIC_FLAG_CACHE = (0.0, False)
def _verbose_diagnostics_enabled():
    global _DIAGNOSTIC_FLAG_CACHE
    import time
    now = time.monotonic()
    if now - _DIAGNOSTIC_FLAG_CACHE[0] < 10.0:
        return _DIAGNOSTIC_FLAG_CACHE[1]
    try:
        import fgeh_cas_accessory_outfit_utils as outfits
        enabled = any((Path(path).parent / 'fgeh_verbose_outfit_diagnostics.flag').exists() for path in outfits._get_debug_log_paths())
    except Exception:
        enabled = False
    _DIAGNOSTIC_FLAG_CACHE = (now, enabled)
    return enabled

def _timed_operation(function):
    import functools
    @functools.wraps(function)
    def measured(*args, **kwargs):
        import time
        started = time.perf_counter()
        success = False
        try:
            result = function(*args, **kwargs)
            success = not (isinstance(result, tuple) and result and result[0] is False)
            return result
        finally:
            try:
                import couplepose1
                couplepose1.fgeh_pose_manager_perf_log('PERF OUTFIT_{} ms={:.3f} success={}'.format(function.__name__.upper(), (time.perf_counter()-started)*1000.0, int(success)))
            except Exception:
                pass
    return measured

def diagnostic(sim_info,label,sending=None):
    # Full protobuf/stack snapshots were repeatedly generated by appearance hooks.
    # Keep failure evidence; opt in to verbose successful-operation snapshots.
    return  # R26: release diagnostic/file output disabled.
REMOVABLE = frozenset(('HAT','HAIR','FACIAL_HAIR','FULL_BODY','UPPER_BODY','LOWER_BODY',
    'SHOES','CUMMERBUND','EARRINGS','GLASSES','NECKLACE','GLOVES','SOCKS','TIGHTS',
    'LIPS_TICK','EYE_SHADOW','EYE_LINER','BLUSH','FACEPAINT','EYELASHES','FINGERNAIL','TOENAIL',
    'SKIN_OVERLAY','BODYFRECKLES','FOREARM_SCAR','SCARFACE','MOLEFACE','MOLECHESTUPPER','MOLEBACKUPPER'))

def removable(body_type, outfits):
    name = outfits.get_body_type_name(body_type).upper()
    return name in REMOVABLE or name.startswith(('WRIST_','LIP_RING_','NOSE_RING_',
        'BROW_RING_','INDEX_FINGER_','RING_FINGER_','MIDDLE_FINGER_','TATTOO_',
        'BODYHAIR_','SKINDETAIL_','BODYSCAR_'))

def fields(data):
    parts = data.parts.ids
    body_types = data.body_types_list.body_types
    shifts = getattr(getattr(data, 'part_shifts', None), 'color_shift', None)
    objects = getattr(getattr(data, 'object_ids', None), 'object_id', None)
    layers = getattr(getattr(data, 'layer_ids', None), 'layer_id', None)
    n = len(parts)
    if len(body_types) != n or any(v is not None and len(v) not in (0,n) for v in (shifts,objects,layers)):
        raise ValueError('Outfit parallel arrays do not align')
    return parts,body_types,shifts,objects,layers

def slot_records(data, body_type):
    parts,types,shifts,objects,layers = fields(data)
    return [(int(parts[i]),int(types[i]),int(shifts[i]) if shifts is not None and len(shifts) else None,
        int(objects[i]) if objects is not None and len(objects) else None,
        int(layers[i]) if layers is not None and len(layers) else None)
        for i in range(len(parts)) if int(types[i]) == int(body_type)]

def remove_slot(data, body_type):
    arrays = fields(data)
    indices = [i for i,v in enumerate(arrays[1]) if int(v) == int(body_type)]
    populated = [v for v in arrays if v is not None and len(v)]
    for i in reversed(indices):
        for v in populated:
            del v[i]
    return len(indices)

def restore_slot(data, body_type, records):
    remove_slot(data, body_type)
    parts,types,shifts,objects,layers = fields(data)
    for record in records:
        part,kind,shift,obj = record[:4]
        layer = record[4] if len(record)>4 else None
        for optional,value in ((shifts,shift),(objects,obj),(layers,layer)):
            if optional is not None and (len(optional) or value is not None):
                if not len(optional):
                    optional.extend([0]*len(parts))
                optional.append(0 if value is None else value)
        parts.append(part)
        types.append(kind)
    fields(data)

def replace_part(data, part_id, outfits=None):
    if outfits is None:
        import fgeh_cas_accessory_outfit_utils as outfits
    body = int(outfits.get_caspart_bodytype(int(part_id)))
    if body <= 0:
        return False
    records = slot_records(data,body)
    # Preserve existing per-part metadata and other tattoo/detail layers.
    old = records[0] if records else (0,body,DEFAULT_COLOR_SHIFT,0,0)
    new = (int(part_id),body,old[2],old[3],old[4])
    restore_slot(data,body,[new]+records[1:])
    if body==2:hair_independent(data)
    return True

def apply_changes(data, changes, outfits):
    for body,part in changes.items():
        if part is None:
            if body==8 or body in (6,7) and not changes.get(5):
                raise ValueError('Cannot leave body geometry empty')
            remove_slot(data,body)
        elif isinstance(part,(tuple,list)):
            restore_slot(data,body,part)
        elif not replace_part(data,part,outfits):
            raise ValueError('Invalid CAS part')
    fields(data)
    if 2 in changes:hair_independent(data)

def _editor_preview(sim_info, session, outfits):
    current_key = tuple(map(int, sim_info.get_current_outfit()))
    data = outfits.find_outfit_data(sim_info.save_outfits(), current_key)
    if data is None:
        raise ValueError('Current outfit is missing')
    # Ordinary operations always use the current live outfit, not a stale journal.
    return data

def variant_plan(sim_info,data,part_id,outfits):
    body=int(outfits.get_caspart_bodytype(int(part_id)))
    changes={body:int(part_id)}
    if body==5:
        changes={6:None,7:None,5:int(part_id)}
    elif body in (6,7) and slot_records(data,5):
        other=7 if body==6 else 6
        records=slot_records(data,other) or foundation_records(sim_info,other,outfits)
        if not records:raise ValueError('Cannot complete body after replacing full-body clothing')
        changes={5:None,other:tuple(records),body:int(part_id)}
    return changes

def validate_transition(before,after):
    fields(after)
    for body in (3,4,8):
        if slot_records(before,body) and not slot_records(after,body):
            raise ValueError('Missing essential body geometry')
    if slot_records(before,5) or slot_records(before,6) or slot_records(before,7):
        if not slot_records(after,5) and not (slot_records(after,6) and slot_records(after,7)):
            raise ValueError('Incomplete body halves')

@_timed_operation
def stage_variant(sim_info,part_id,outfits):
    backup=sim_info.save_outfits()
    source=tuple(map(int,sim_info.get_current_outfit()))
    hair=int(outfits.get_caspart_bodytype(int(part_id)))==2
    if hair:diagnostic(sim_info,'HAIR_BEFORE:'+str(part_id))
    try:
        result=_stage_variant(sim_info,part_id,outfits)
        if hair:diagnostic(sim_info,'HAIR_AFTER:'+str(part_id))
        return result
    except Exception as exc:
        diagnostic(sim_info,'VARIANT_FAILURE:'+str(exc))
        sim_info.load_outfits(backup)
        sim_info.set_current_outfit(source)
        outfits._refresh_current_outfit(sim_info,source,'R33_ROLLBACK')
        sync_censor(sim_info)
        raise

def _stage_variant(sim_info,part_id,outfits):
    source=tuple(map(int,sim_info.get_current_outfit()))
    current=outfits.find_outfit_data(sim_info.save_outfits(),source)
    if current is None:return None
    changes=variant_plan(sim_info,current,part_id,outfits)
    temp=tuple(map(int,outfits._get_special_outfit_key()))
    if source!=temp:
        sim_info.generate_merged_outfit(sim_info,temp,source,source)
    snapshot=sim_info.save_outfits();data=outfits.find_outfit_data(snapshot,temp)
    if data is None:return None
    if 5 in changes and changes[5] is not None:
        remove_slot(data,6);remove_slot(data,7);replace_part(data,part_id,outfits)
    else:apply_changes(data,changes,outfits)
    validate_transition(current,data)
    import uuid
    data.outfit_id=uuid.uuid4().int & ((1<<64)-1)
    sim_info.load_outfits(snapshot)
    if int(outfits.get_caspart_bodytype(int(part_id)))==2:
        native_hair(sim_info,temp,part_id,outfits)
        data=outfits.find_outfit_data(sim_info.save_outfits(),temp)
    actual=outfits.find_outfit_data(sim_info.save_outfits(),temp)
    if actual is not None:validate_transition(current,actual)
    body=int(outfits.get_caspart_bodytype(int(part_id)))
    if actual is None or int(part_id) not in [r[0] for r in slot_records(actual,body)]:
        raise ValueError('Game did not retain the requested variant')
    if body==2 and bool(getattr(actual,'match_hair_style',False)):
        raise ValueError('Game retained default hair matching; original outfit restored')
    if source!=temp:outfits._original_outfit_by_sim_id[int(sim_info.sim_id)]=source
    outfits._refresh_current_outfit(sim_info,temp,'R33_VARIANT')
    diagnostic(sim_info,'TRACE_BEFORE_VERIFY')
    verify_applied(sim_info,temp,data,changes,outfits)
    diagnostic(sim_info,'TRACE_AFTER_VERIFY')
    sync_censor(sim_info)
    diagnostic(sim_info,'TRACE_AFTER_CENSOR')
    return changes

def remove_preview(sim_info, bodies, part_id=None):
    import fgeh_cas_accessory_outfit_utils as outfits
    session=SESSIONS.get(int(sim_info.sim_id))
    if session is not None:_editor_preview(sim_info,session,outfits)
    backup=sim_info.save_outfits()
    key=tuple(map(int,sim_info.get_current_outfit()))
    sid=int(sim_info.sim_id)
    previous=outfits._original_outfit_by_sim_id.get(sid)
    try:
        return _remove_preview(sim_info,bodies,part_id)
    except Exception:
        sim_info.load_outfits(backup)
        sim_info.set_current_outfit(key)
        if previous is None:outfits._original_outfit_by_sim_id.pop(sid,None)
        else:outfits._original_outfit_by_sim_id[sid]=previous
        outfits._refresh_current_outfit(sim_info,key,'R33_REMOVE_ROLLBACK')
        sync_censor(sim_info)
        raise

def _remove_preview(sim_info, bodies, part_id=None):
    import fgeh_cas_accessory_outfit_utils as outfits
    session = SESSIONS.get(int(sim_info.sim_id))
    if session is None:
        return False, '请先进入服装编辑'
    data = _editor_preview(sim_info, session, outfits)
    bodies = set(int(v) for v in bodies if removable(v, outfits) and slot_records(data, v))
    if not bodies:
        return False, '没有可移除的部件；基础身体部件不会被删除'
    # Clothing and feet contain geometry. Deletion is not CAS undressing.
    changes = {body:None for body in bodies}
    if part_id is not None:
        for body in bodies:
            records=slot_records(data,body)
            if not any(r[0]==int(part_id) for r in records):
                return False, '选中物品已经变化，请重新选择'
            if body not in (5,6,7,8):
                remaining=tuple(r for r in records if r[0]!=int(part_id))
                changes[body]=remaining or None
    for body in sorted(bodies):
        name = outfits.get_body_type_name(body).upper()
        if body==2:
            part=bald_part(sim_info,outfits)
            if part is None:return False, '未找到适配的无头发部件，已保留头发'
            changes[2]=part
        targets = (6,7) if name == 'FULL_BODY' else (body,)
        if name in ('FULL_BODY','UPPER_BODY','LOWER_BODY','SHOES'):
            for target in targets:
                if name == 'FULL_BODY' and slot_records(data,target):
                    continue
                records = foundation_records(sim_info,target,outfits)
                if not records:
                    return False, '无法取得兼容的基础身体，已保留当前服装'
                changes[target] = records
    data = _editor_preview(sim_info,session,outfits)
    temp = outfits._get_special_outfit_key()
    live_key=tuple(map(int,sim_info.get_current_outfit()))
    if live_key!=tuple(map(int,temp)):
        sim_info.generate_merged_outfit(sim_info,temp,live_key,live_key)
        outfits._original_outfit_by_sim_id[int(sim_info.sim_id)]=live_key
    snapshot = sim_info.save_outfits()
    data = outfits.find_outfit_data(snapshot, temp)
    if data is None:
        return False, '没有取得临时预览'
    apply_changes(data,changes,outfits)
    validate_transition(_editor_preview(sim_info,session,outfits),data)
    sim_info.load_outfits(snapshot)
    actual=outfits.find_outfit_data(sim_info.save_outfits(),temp)
    if actual is None:raise ValueError('Preview outfit missing after removal')
    validate_transition(data,actual)
    for body in changes:
        if slot_records(data,body)!=slot_records(actual,body):
            raise ValueError('Game did not retain the removal; original outfit restored')
    if 2 in changes and bool(getattr(actual,'match_hair_style',False)):
        raise ValueError('Game retained default hair matching; original hair restored')
    sim_info.set_current_outfit(temp)
    outfits._refresh_current_outfit(sim_info, temp, 'R31_REMOVE_PREVIEW')
    verify_applied(sim_info,temp,data,changes,outfits)
    session['changes'].update(changes)
    session['preview_key'] = tuple(map(int, temp))
    remember(session,outfits.find_outfit_data(sim_info.save_outfits(),temp))
    sync_censor(sim_info)
    return True, '已临时移除；基础身体保留。点击保存才覆盖原套装'

FOUNDATIONS = {}
CENSORS = {}

def foundation_records(sim_info,body,outfits):
    body=int(body)
    if int(getattr(sim_info,'species',0)) != 1 or int(getattr(sim_info,'age',0)) not in (8,16,32,64):
        return None
    ww_active=any(n=='wickedwhims' or n.startswith('wickedwhims.') for n in sys.modules)
    if ww_active:
        try:
            wrapper=importlib.import_module('turbolib2.wrappers.sim.sim').TurboSim(sim_info)
            kind={6:'top',7:'bottom',8:'feet'}[body]
            module=importlib.import_module('wickedwhims.nudity.body.parts.'+kind)
            value=getattr(module,'get_sim_body_'+kind+'_cas_part')(wrapper)
            part=int(getattr(value,'cas_part_id',value))
            if part<=0 or int(outfits.get_caspart_bodytype(part))!=body:
                return None
            records=[(part,body,0,0,0)]
        except Exception:
            # Never silently replace a WW-selected custom body with EA IDs.
            return None
    else:
        bathing=outfits.find_outfit_data(sim_info.save_outfits(),(5,0))
        if bathing is None:
            from sims.outfits.outfit_enums import OutfitCategory,OutfitFilterFlag
            sim_info.generate_outfit(OutfitCategory.BATHING,filter_flag=OutfitFilterFlag.NONE)
            bathing=outfits.find_outfit_data(sim_info.save_outfits(),(5,0))
        if bathing is None:
            return None
        records=slot_records(bathing,body)
        if not records or any(int(outfits.get_caspart_bodytype(r[0]))!=body for r in records):
            return None
    FOUNDATIONS.setdefault(int(sim_info.sim_id),{})[body]=tuple(records)
    register_censor_callback(sim_info)
    return tuple(records)

def register_censor_callback(sim_info):
    try:
        sim_info.register_for_outfit_changed_callback(_on_outfit_changed)
    except Exception:
        pass

def _on_outfit_changed(sim_info,*args):
    sync_censor(sim_info)

def sync_censor(sim_info):
    # Request only our own mask; never switch off another interaction's mask.
    sid=int(sim_info.sim_id)
    previous=CENSORS.pop(sid,None)
    if previous:
        try:previous[0].remove_censor(previous[1])
        except Exception:pass
    try:
        import fgeh_cas_accessory_outfit_utils as outfits
        from objects.components.censor_grid_component import CensorState
        actor=sim_info.get_sim_instance();component=getattr(actor,'censorgrid_component',None)
        if component is None:return
        data=outfits.find_outfit_data(sim_info.save_outfits(),sim_info.get_current_outfit())
        if data is None:return
        known=FOUNDATIONS.get(sid,{})
        naked=[b for b in (6,7) if b in known and tuple(slot_records(data,b))==known[b]]
        if naked:
            state=CensorState.TORSO_PELVIS if len(naked)==2 else CensorState.TORSO if naked[0]==6 else CensorState.PELVIS
            CENSORS[sid]=(component,component.add_censor(state))
    except Exception:
        pass

def consume_remove(sim_info, dialog_id, manager=None, panel=None):
    import fgeh_cas_accessory_outfit_utils as outfits
    session = SESSIONS.get(int(sim_info.sim_id)) or {}
    pending = session.pop('pending_remove', None)
    if not pending or pending[0] != str(dialog_id):
        return False, '请先在右侧选择要移除的部件'
    body = int(outfits.get_caspart_bodytype(pending[1]))
    if panel is not None:
        selected = panel._outfit_ui_selected_part_group(manager)
        if not selected:
            return False, '请先进入对应分类，再脱下物品'
        if panel._outfit_ui_part_group(outfits.get_body_type_name(body)) != selected:
            return False, '选中物品不属于当前分类，请重新选择'
    return remove_preview(sim_info, (body,), pending[1])

def clear_category(sim_info, manager, panel):
    import fgeh_cas_accessory_outfit_utils as outfits
    session = SESSIONS.get(int(sim_info.sim_id))
    if not session:
        return False, '请先进入服装编辑'
    data = _editor_preview(sim_info, session, outfits)
    selected = panel._outfit_ui_selected_part_group(manager)
    bodies = set(int(v) for v in fields(data)[1])
    if not selected:
        return False, '全部页不提供脱下；请先进入对应分类'
    # Other contains individual cosmetic details; category-wide stripping is not implicit.
    if selected in ('其他','妆容','头部'):
        return False, '此分类请选中具体物品后单独移除'
    bodies = {v for v in bodies if panel._outfit_ui_part_group(outfits.get_body_type_name(v)) == selected}
    return remove_preview(sim_info, bodies)

def library_try(sim_info, part_id, original_apply, manager, target):
    import fgeh_cas_accessory_outfit_utils as outfits
    sid=int(sim_info.sim_id);key=tuple(map(int,sim_info.get_current_outfit()))
    snapshot=sim_info.save_outfits()
    session=copy.deepcopy(LIBRARY_SESSIONS.get(sid));original=outfits._original_outfit_by_sim_id.get(sid)
    try:
        result = _library_try(sim_info,part_id,original_apply,manager,target)
        if result:
            outfits.claim_manual_outfit_changes(
                sim_info, snapshot, int(outfits.get_caspart_bodytype(int(part_id))))
        return result
    except Exception as exc:
        diagnostic(sim_info,'LIBRARY_FAILURE:'+str(exc))
        if tuple(map(int,sim_info.get_current_outfit()))!=key or tuple(v.SerializeToString() for v in sim_info.save_outfits().outfits)!=tuple(v.SerializeToString() for v in snapshot.outfits):
            sim_info.load_outfits(snapshot);sim_info.set_current_outfit(key)
            outfits._refresh_current_outfit(sim_info,key,'R49_LIBRARY_ROLLBACK')
        if session is None:LIBRARY_SESSIONS.pop(sid,None)
        else:LIBRARY_SESSIONS[sid]=session
        if original is None:outfits._original_outfit_by_sim_id.pop(sid,None)
        else:outfits._original_outfit_by_sim_id[sid]=original
        notify(target,'试穿或取消未被游戏应用，已恢复本次操作前的状态')
        return False

def _library_try(sim_info, part_id, original_apply, manager, target):
    import fgeh_cas_accessory_outfit_utils as outfits
    sid = int(sim_info.sim_id)
    body = int(outfits.get_caspart_bodytype(int(part_id)))
    session = LIBRARY_SESSIONS.get(sid)
    current_key = tuple(map(int, sim_info.get_current_outfit()))
    current = outfits.find_outfit_data(sim_info.save_outfits(), current_key)
    if current is None:
        return False
    if session and (current_key != session['preview_key'] or not preview_matches(session,current)):
        # A linked pose or another action owns the latest state. Rebase the trial
        # journal; never cancel a stale entry against a different outfit.
        diagnostic(sim_info,'LIBRARY_REBASE_EXTERNAL_CHANGE')
        session=None
    if session is None:
        session={'slots':{},'preview_key':None,'preview_bytes':None,'source_key':current_key}
    previous = session['slots'].get(body)
    if previous and previous['selected'] == int(part_id):
        if not previous['records'] and not removable(body, outfits):
            return False
        snapshot = sim_info.save_outfits()
        data = outfits.find_outfit_data(snapshot, current_key)
        for kind,records in previous.get('restore', {body:previous['records']}).items():
            restore_slot(data,kind,records)
        if body==2 and 'match_hair_style' in previous and hasattr(data,'match_hair_style'):
            data.match_hair_style=previous['match_hair_style']
        validate_transition(current,data)
        sim_info.load_outfits(snapshot)
        if body==2 and slot_records(data,2):
            native_hair(sim_info,current_key,slot_records(data,2)[0][0],outfits,getattr(data,'match_hair_style',False))
            data=outfits.find_outfit_data(sim_info.save_outfits(),current_key)
        outfits._refresh_current_outfit(sim_info, current_key, 'R31_CANCEL_LIBRARY_SLOT')
        verify_applied(sim_info,current_key,data,previous.get('restore',{body:previous['records']}),outfits)
        session['slots'].pop(body)
        if not session['slots']:
            source_key = session['source_key']
            if outfits.find_outfit_data(sim_info.save_outfits(), source_key) is not None:
                sim_info.set_current_outfit(source_key)
                outfits._refresh_current_outfit(sim_info, source_key, 'R31_CANCEL_LIBRARY_COMPLETE')
                backup = outfits._original_outfit_by_sim_id.get(sid)
                if backup is not None and tuple(map(int, backup)) == source_key:
                    outfits._original_outfit_by_sim_id.pop(sid, None)
            LIBRARY_SESSIONS.pop(sid, None)
        else:
            remember(session,outfits.find_outfit_data(sim_info.save_outfits(),current_key))
        return True
    records = previous['records'] if previous else slot_records(current, body)
    plan=variant_plan(sim_info,current,part_id,outfits)
    if body in (5,6,7):
        for kind,entry in list(session['slots'].items()):
            if kind!=body and set(entry.get('restore',{})).intersection(plan):
                session['slots'].pop(kind)
                session['source_key']=current_key
    restore=previous.get('restore') if previous else {kind:slot_records(current,kind) for kind in plan}
    if stage_variant(sim_info,part_id,outfits) is None:return False
    preview_key = tuple(map(int, sim_info.get_current_outfit()))
    if preview_key != tuple(map(int, outfits._get_special_outfit_key())):
        return False
    data = outfits.find_outfit_data(sim_info.save_outfits(), preview_key)
    if data is None:
        return False
    session['slots'][body] = {'selected':int(part_id),'records':records,'restore':restore}
    if body==2:
        session['slots'][body]['match_hair_style']=previous.get('match_hair_style',False) if previous else bool(getattr(current,'match_hair_style',False))
    session['preview_key'] = preview_key
    remember(session,data)
    LIBRARY_SESSIONS[sid] = session
    return True

def _identity(sim_info, key):
    return int(sim_info.sim_id), (int(key[0]), int(key[1]))

def prepare(sim_info, key):
    sid, normalized = _identity(sim_info, key)
    session = SESSIONS.get(sid)
    return bool(session and session['key'] == normalized)

def begin(sim_info, key):
    import fgeh_cas_accessory_outfit_utils as outfits
    sid, normalized = _identity(sim_info, key)
    existing = SESSIONS.get(sid)
    if existing and existing['key'] == normalized:
        return
    if normalized == tuple(map(int, outfits._get_special_outfit_key())):
        raise ValueError('Cannot edit the shared temporary outfit as a saved outfit')
    data = outfits.find_outfit_data(sim_info.save_outfits(), normalized)
    if data is None:
        raise ValueError('Selected saved outfit no longer exists')
    SESSIONS[sid] = {'key': normalized, 'baseline': data.SerializeToString(),'baseline_contract':outfit_contract(data),
                     'changes': {}, 'preview_key': None, 'preview_bytes': None}

def catalog_key(sim_info, key):
    if prepare(sim_info, key):
        return tuple(map(int, sim_info.get_current_outfit()))
    return tuple(map(int, key))

def preview_url(sim_info, category, index):
    category, index = catalog_key(sim_info, (category, index))
    return 'img://thumbs/sims/w_{}_l_{}_{}'.format(int(sim_info.sim_id), category, index)

def discard(sim_info):
    SESSIONS.pop(int(sim_info.sim_id), None)

def _write_backup(sim_info, session):
    return  # R26: release diagnostic/file output disabled.

@_timed_operation
def commit(sim_info, key, outfits=None, backup=None):
    diagnostic(sim_info,'SAVE_BEFORE')
    try:
        result=_commit(sim_info,key,outfits,backup)
        diagnostic(sim_info,('SAVE_OK:' if result[0] else 'SAVE_FAILURE:')+result[1])
        return result
    except Exception as exc:
        diagnostic(sim_info,'SAVE_EXCEPTION:'+str(exc))
        raise

def _commit(sim_info, key, outfits=None, backup=None):
    """Patch only journaled slots in a fresh snapshot, preserving other outfits."""
    if outfits is None:
        import fgeh_cas_accessory_outfit_utils as outfits
    sid, normalized = _identity(sim_info, key)
    session = SESSIONS.get(sid)
    if not session or session['key'] != normalized:
        return False, '保存目标已改变，未执行覆盖'
    current = sim_info.save_outfits()
    rollback = sim_info.save_outfits()
    destination = outfits.find_outfit_data(current, normalized)
    live_key=tuple(map(int,sim_info.get_current_outfit()))
    preview = outfits.find_outfit_data(current,live_key)
    if destination is None or preview is None:
        return False, '服装已不存在，未执行覆盖'
    # Explicit Save copies current worn slots into the selected saved outfit.
    # Preserve destination identity/metadata and every other saved outfit.
    fields(preview);fields(destination)
    bodies=set(map(int,fields(destination)[1]))|set(map(int,fields(preview)[1]))
    changes={body:tuple(slot_records(preview,body)) for body in bodies}
    session['baseline']=destination.SerializeToString()
    session['changes']=changes
    session['preview_key']=live_key
    for body,records in changes.items():restore_slot(destination,body,records)
    if hasattr(destination,'match_hair_style'):
        destination.match_hair_style=getattr(preview,'match_hair_style',False)
    validate_transition(preview,destination)
    expected = destination.SerializeToString()
    (backup or _write_backup)(sim_info, session)
    sim_info.load_outfits(current)
    actual = outfits.find_outfit_data(sim_info.save_outfits(), normalized)
    if 2 in session['changes']:
        selected=slot_records(destination,2)
        if selected:
            try:
                native_hair(sim_info,normalized,selected[0][0],outfits)
                actual=outfits.find_outfit_data(sim_info.save_outfits(),normalized)
                expected=actual.SerializeToString()
                destination=actual
            except Exception as exc:
                diagnostic(sim_info,'SAVE_NATIVE_FAILURE:'+str(exc))
                sim_info.load_outfits(rollback)
                return False, '原生头发保存失败，已恢复原套装；请检查 R49 日志'
    if actual is None or actual.SerializeToString() != expected:
        sim_info.load_outfits(rollback)
        outfits._refresh_current_outfit(sim_info,session['preview_key'],'R49_SAVE_ROLLBACK')
        return False, '保存验证未通过，原套装已恢复；请保留备份和日志'
    # Saving writes the destination, without equipping it or discarding current wear.
    sim_info.set_current_outfit(live_key)
    outfits._refresh_current_outfit(sim_info, live_key, 'R55_COMMIT_KEEP_CURRENT')
    try:
        current_expected = destination if live_key == normalized else preview
        verify_applied(sim_info,live_key,current_expected,set(map(int,fields(current_expected)[1])),outfits)
    except Exception:
        sim_info.load_outfits(rollback)
        sim_info.set_current_outfit(session['preview_key'])
        outfits._refresh_current_outfit(sim_info,session['preview_key'],'R49_SAVE_SWITCH_ROLLBACK')
        return False, '游戏未应用保存结果，已恢复原套装和临时预览'
    sync_censor(sim_info)
    original = outfits._original_outfit_by_sim_id.get(sid)
    if original is not None and tuple(map(int, original)) == normalized:
        outfits._original_outfit_by_sim_id.pop(sid, None)
    SESSIONS.pop(sid, None)
    return True, '已保存并覆盖所选套装，当前造型保持不变；请保存游戏以保留修改'

def notify(owner, message):
    try:
        from ui.ui_dialog_notification import UiDialogNotification
        from sims4.localization import LocalizationHelperTuning
        def text(**kwargs):
            return _fgeh_hash_ui_text(message)
        UiDialogNotification.TunableFactory().default(owner, title=text, text=text).show_dialog()
    except Exception:
        pass

def install(panel):
    """Wrap only the editor bridge; Accessory Library retains original behavior."""
    if getattr(panel, '_r30_installed', False):
        return
    original_apply = panel._caslib_apply_variant
    original_restore = panel._v8966_restore_original_outfit
    def apply(manager, target, cas_part_id):
        sim_info = getattr(target, 'sim_info', target)
        sid = int(getattr(sim_info, 'sim_id', 0) or 0)
        session = SESSIONS.get(sid)
        editor = session is not None and panel._v7_active_nav(manager) == panel.NAV_OUTFIT_MANAGER
        if not editor:
            if panel._v7_active_nav(manager) == panel.NAV_ACCESSORY_LIBRARY:
                return library_try(sim_info, int(cas_part_id), original_apply, manager, target)
            return original_apply(manager, target, cas_part_id)
        import fgeh_cas_accessory_outfit_utils as outfits
        current_key = tuple(map(int, sim_info.get_current_outfit()))
        # Trial editing intentionally follows the current live state.
        body_type = int(outfits.get_caspart_bodytype(int(cas_part_id)))
        if body_type <= 0:
            return False
        existing = outfits.find_outfit_data(sim_info.save_outfits(),current_key)
        plan = variant_plan(sim_info,existing,cas_part_id,outfits)
        manual_before = sim_info.save_outfits()
        success = stage_variant(sim_info,int(cas_part_id),outfits) is not None
        if success:
            outfits.claim_manual_outfit_changes(sim_info, manual_before, body_type)
            preview_key = tuple(map(int, sim_info.get_current_outfit()))
            if preview_key != tuple(map(int, outfits._get_special_outfit_key())):
                return False
            data = outfits.find_outfit_data(sim_info.save_outfits(), preview_key)
            if data is None:
                return False
            session['changes'].update(plan)
            session['preview_key'] = preview_key
            remember(session,data)
            diagnostic(sim_info,'EDITOR_PREVIEW_ACCEPTED:'+str(cas_part_id))
        return success
    def restore(sim_info):
        LIBRARY_SESSIONS.pop(int(getattr(getattr(sim_info, 'sim_info', sim_info), 'sim_id', 0) or 0), None)
        discard(getattr(sim_info, 'sim_info', sim_info))
        return original_restore(sim_info)
    panel._caslib_apply_variant = apply
    panel._v8966_restore_original_outfit = restore
    library_restore = panel._caslib_restore
    def restore_library(manager, target):
        LIBRARY_SESSIONS.pop(int(getattr(getattr(target, 'sim_info', target), 'sim_id', 0) or 0), None)
        return library_restore(manager, target)
    panel._caslib_restore = restore_library
    import sims4.commands
    @sims4.commands.Command('fgeh.outfit_queue_remove', command_type=sims4.commands.CommandType.Live)
    def queue_remove(part_id='0', dialog_id='0', _connection=None):
        try:
            import couplepose1 as manager
            if panel._v7_active_nav(manager) != panel.NAV_OUTFIT_MANAGER:
                return False
            target = panel._caslib_target_from_state(manager)
            info = getattr(target, 'sim_info', target)
            session = SESSIONS.get(int(info.sim_id))
            if session and int(part_id) > 0:
                session['pending_remove'] = (str(dialog_id), int(part_id))
                return True
        except Exception:
            return False
        return False
    panel._r30_installed = True
