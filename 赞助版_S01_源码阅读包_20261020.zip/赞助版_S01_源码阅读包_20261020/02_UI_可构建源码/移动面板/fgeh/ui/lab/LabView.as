package fgeh.ui.lab {
import flash.display.Sprite;
import flash.display.Stage;
import flash.events.Event;
import flash.events.MouseEvent;
import flash.events.KeyboardEvent;
import flash.events.TimerEvent;
import flash.utils.Timer;
import flash.utils.getTimer;
import flash.text.TextField;
import flash.text.TextFormat;
import flash.text.TextFieldType;
public class LabView extends Sprite {
 public var action:String="";
 public var argument:String="";
 public var token:String="";
 public var uiScale:Number=1;
 private var scaleTrack:Sprite=new Sprite();
 private var scaleLabel:TextField;
 private var scaleStage:Stage;
 private var status:TextField;
 private var settings:TextField;
 private var axisLabel:TextField;
 private var people:Sprite=new Sprite();
 private var rows:Array=[];
 private var groundAlignment:Boolean=false;
 private var alignFacing:Boolean=true;
 private var axis:String="y";
 private var gate:HoldGate=new HoldGate();
 private var clock:Timer=new Timer(40);
 private var holdStage:Stage;
 private var holdOp:String="";
 private var holdArg:String="";
 private var context:String="";
 private var holdSerial:int=0;
 private var shownActive:Boolean=false;
 private var rosterKey:String="";
 private var drawer:Boolean=false;
 private var listOpen:Boolean=false;
 private var advanced:Boolean=false;
 private var alignMode:String="individual";
 private var page:int=0;
 private var addMode:Boolean=false;
 private var peopleEnabled:Boolean=true;
 private var objectsEnabled:Boolean=false;
 private var pivotMode:String="group";
 private var pivotValues:Array=[0,0,0];
 private var xyzFields:Array=[];
 private var stepInput:TextField;
 private var angleInput:TextField;
 private var radiusInput:TextField;
 private var radiusValue:String="12";
 public function LabView() {
  clock.addEventListener(TimerEvent.TIMER,onTick);
  addEventListener(Event.REMOVED_FROM_STAGE,onRemoved);
  graphics.lineStyle(1,0xC9E1E4);graphics.beginFill(0xF8FCFD);graphics.drawRoundRect(0,0,350,584,36,36);graphics.endFill();
  var drag:Sprite=new Sprite();drag.graphics.beginFill(0,0);drag.graphics.drawRect(0,0,224,44);drag.graphics.endFill();addChild(drag);
  drag.addEventListener(MouseEvent.MOUSE_DOWN,function(e:MouseEvent):void {dispatchEvent(new Event("fgehMoveDrag",true));});
  label(LabText.t("shared_4b2620970dac"),14,14,18,0x294F58,180);
  button(LabText.t("shared_849c2edcb98f"),230,12,48,28,"box");button(LabText.t("shared_6c14bd7f6f9e"),286,12,50,28,"close");
  button(LabText.t("shared_eb8534acb79c"),14,52,102,54,"axis","y");button(LabText.t("shared_41a684869a7f"),124,52,102,54,"axis","x");button(LabText.t("shared_6ca43337badb"),234,52,102,54,"axis","z");
  button(LabText.t("shared_e7338d5c8e4e"),108,124,54,54,"forward");button(LabText.t("shared_df3ee667608c"),50,182,54,54,"left");button(LabText.t("shared_70b208202ce5"),108,182,54,54,"people");button(LabText.t("shared_851cdd609190"),166,182,54,54,"right");button(LabText.t("shared_d8c84172acf3"),108,240,54,54,"back");
  label(LabText.t("shared_eea51aa44b92"),275,125,12,0x557D86,60);button(LabText.t("shared_abdb0612c76b"),264,150,70,64,"up");button(LabText.t("shared_9d4ed2a55bb0"),264,222,70,64,"down");
  label(LabText.t("shared_a69e51e50320"),14,318,13,0x294F58,60);
  button("",14,346,58,48,"rotate","-");axisLabel=label(LabText.t("shared_c9ceff7ac7c2"),88,358,16,0x246E7B,176);button("",278,346,58,48,"rotate","+");
  label(LabText.t("shared_e0cad4f1db01"),14,398,11,0x557D86,104);label(LabText.t("shared_5ee61ed55766"),178,398,11,0x557D86,150);
  stepInput=numericInput("0.05",14,"applyStep");angleInput=numericInput("5",178,"applyAngle");
  button(LabText.t("shared_f526c89937e1"),124,416,46,24,"applyStep");button(LabText.t("shared_f526c89937e1"),288,416,48,24,"applyAngle");
  button(LabText.t("shared_849c2edcb98f"),14,446,100,30,"box");button(LabText.t("shared_23b1c531853a"),122,446,100,30,"marks");button(LabText.t("shared_a6d3de0e8678"),230,446,106,30,"clear");
  button(LabText.t("shared_a010cd7000e2"),14,486,156,30,"undo");button(LabText.t("shared_ac56b2bd2ac1"),178,486,158,30,"resetinitial");
  settings=label(LabText.t("shared_e4d02e4a63a5"),14,523,12,0x557D86,320);
  settings.visible=false;label(LabText.t("shared_f7c065e2592f"),14,523,12,0x557D86,80);
  scaleTrack.x=100;scaleTrack.y=530;scaleTrack.buttonMode=true;addChild(scaleTrack);
  scaleLabel=label("100%",290,523,12,0x557D86,55);setUIScale(1);
  scaleTrack.addEventListener(MouseEvent.MOUSE_DOWN,startScale);
  status=label(LabText.t("shared_6ce75f7e20d5"),14,546,12,0x294F58,320);
  people.x=360;people.y=0;people.visible=false;addChild(people);
 }
 public function setUIScale(value:Number):void {
  if(!isFinite(value)){return;}uiScale=Math.max(0.6,Math.min(1.4,value));
  scaleTrack.graphics.clear();scaleTrack.graphics.beginFill(0,0);scaleTrack.graphics.drawRect(0,-10,180,24);scaleTrack.graphics.endFill();
  scaleTrack.graphics.lineStyle(3,0xC9E1E4);scaleTrack.graphics.moveTo(0,0);scaleTrack.graphics.lineTo(180,0);
  scaleTrack.graphics.lineStyle();scaleTrack.graphics.beginFill(0x18AFC4);scaleTrack.graphics.drawCircle((uiScale-0.6)/0.8*180,0,7);scaleTrack.graphics.endFill();
  scaleLabel.text=Math.round(uiScale*100)+"%";
 }
 private function startScale(e:MouseEvent):void {
  stopHold();stopScale();scaleStage=stage;if(scaleStage==null){return;}
  scaleStage.addEventListener(MouseEvent.MOUSE_MOVE,moveScale);scaleStage.addEventListener(MouseEvent.MOUSE_UP,finishScale);scaleStage.addEventListener(Event.DEACTIVATE,finishScale);moveScale(e);
 }
 private function moveScale(e:MouseEvent):void {setUIScale(Math.round((0.6+Math.max(0,Math.min(180,mouseX-100))/180*0.8)*20)/20);dispatchEvent(new Event("fgehUIScale",true));}
 private function finishScale(e:Event):void {stopScale();dispatchEvent(new Event("fgehUIScaleSave",true));}
 private function stopScale():void {if(scaleStage!=null){scaleStage.removeEventListener(MouseEvent.MOUSE_MOVE,moveScale);scaleStage.removeEventListener(MouseEvent.MOUSE_UP,finishScale);scaleStage.removeEventListener(Event.DEACTIVATE,finishScale);scaleStage=null;}}
 private function label(value:String,xv:Number,yv:Number,size:Number,color:uint,w:Number):TextField {
  var t:TextField=new TextField();t.embedFonts=true;t.defaultTextFormat=new TextFormat("$TextFont",size,color);t.width=w;t.height=30;t.x=xv;t.y=yv;t.text=value;t.selectable=false;t.mouseEnabled=false;addChild(t);return t;
 }
 private function numericInput(value:String,xv:Number,op:String):TextField {
  var t:TextField=new TextField();t.type=TextFieldType.INPUT;t.embedFonts=true;t.defaultTextFormat=new TextFormat("$TextFont",13,0x294F58);
  t.border=true;t.borderColor=0xC9E1E4;t.background=true;t.backgroundColor=0xFFFFFF;t.x=xv;t.y=416;t.width=104;t.height=24;t.text=value;t.maxChars=12;t.restrict="0-9.";addChild(t);
  t.addEventListener(MouseEvent.MOUSE_WHEEL,function(e:MouseEvent):void {
   e.stopImmediatePropagation();e.preventDefault();stopHold();
   if(gate.waiting!="" || token=="" || e.delta==0){return;}
   var old:Number=Number(t.text),next:Number=BoxMath.wheelValue(old,e.delta,op=="applyStep");
   if(next==old){return;}t.text=String(next);send(op,"");
  });
  t.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void {if(e.keyCode==13){e.stopImmediatePropagation();send(op,"");}});
  t.addEventListener(MouseEvent.MOUSE_DOWN,function(e:MouseEvent):void {stopHold();});
  return t;
 }
 private function button(value:String,xv:Number,yv:Number,w:Number,h:Number,op:String,arg:String="",host:Sprite=null):void {
  var b:Sprite=new Sprite();b.x=xv;b.y=yv;b.graphics.lineStyle(1,0xC9E1E4);b.graphics.beginFill(0xEEF9FA);b.graphics.drawRoundRect(0,0,w,h,22,22);b.graphics.endFill();
  var t:TextField=new TextField();t.embedFonts=true;t.defaultTextFormat=new TextFormat("$TextFont",14,0x294F58);t.width=w-8;t.height=h-4;t.x=4;t.y=(h-22)/2;t.text=value;t.selectable=false;b.addChild(t);b.mouseChildren=false;b.buttonMode=true;
  if(op=="rotate"){drawRotation(b,arg=="-"?-1:1,w,h);b.name=arg=="-"?"rotateNegative":"rotatePositive";}
  if(isMotion(op)){
   b.addEventListener(MouseEvent.MOUSE_DOWN,function(e:MouseEvent):void {beginHold(op,arg,e.shiftKey);});
   b.addEventListener(MouseEvent.ROLL_OUT,function(e:MouseEvent):void {stopHold();});
  }else{
   b.addEventListener(MouseEvent.CLICK,function(e:MouseEvent):void {send(op,arg);});
  }
  b.addEventListener(MouseEvent.ROLL_OVER,function(e:MouseEvent):void {b.alpha=0.75;});b.addEventListener(MouseEvent.ROLL_OUT,function(e:MouseEvent):void {b.alpha=1;});
  (host==null?this:host).addChild(b);
 }
 private function drawRotation(host:Sprite,sign:int,w:Number,h:Number):void {
  var shape:Array=BoxMath.rotationShape(sign),arc:Array=shape[0],head:Array=shape[1];
  host.graphics.lineStyle(2.5,0x18AFC4);host.graphics.moveTo(w/2+arc[0][0],h/2+arc[0][1]);
  for(var i:int=1;i<arc.length;i++){host.graphics.lineTo(w/2+arc[i][0],h/2+arc[i][1]);}
  host.graphics.lineStyle();host.graphics.beginFill(0x18AFC4);host.graphics.moveTo(w/2+head[0][0],h/2+head[0][1]);
  host.graphics.lineTo(w/2+head[1][0],h/2+head[1][1]);host.graphics.lineTo(w/2+head[2][0],h/2+head[2][1]);host.graphics.lineTo(w/2+head[0][0],h/2+head[0][1]);host.graphics.endFill();
 }
 private function isMotion(op:String):Boolean {
  return op=="forward" || op=="back" || op=="left" || op=="right" || op=="up" || op=="down" || op=="rotate" || op.substr(0,1)=="r" && op.length==3 && (op.substr(2)=="+" || op.substr(2)=="-");
 }
 private function wire(value:Object):String {
  return String(value).replace(/[\u210b\u210e\u210f\u212a\u212b\u212c\u212d\u212e\u2166\u2167\u2168\u2169\ufeff]/g,"").replace(/^\s+|\s+$/g,"");
 }
 private function beginHold(op:String,arg:String,fine:Boolean=false):void {
  stopHold();
  if(!shownActive || stage==null || !gate.start(getTimer(),token,context)){return;}
  holdOp=op=="rotate"?"r"+axis+arg:op;
  holdSerial++;holdArg=(fine?"f_h":"h")+String(getTimer())+"_"+String(holdSerial);
  holdStage=stage;
  holdStage.addEventListener(MouseEvent.MOUSE_UP,onRelease,true);
  holdStage.addEventListener(MouseEvent.MOUSE_MOVE,onPointer,true);
  holdStage.addEventListener(Event.MOUSE_LEAVE,onRelease);
  holdStage.addEventListener(Event.DEACTIVATE,onRelease);
  clock.start();send(holdOp,holdArg);
 }
 private function onRelease(event:Event):void {stopHold();}
 private function onPointer(event:MouseEvent):void {if(!event.buttonDown){stopHold();}}
 private function onRemoved(event:Event):void {suspend();}
 public function cancelHold():void {stopHold();}
 private function stopHold():void {
  if(holdArg!=""){try{flash.utils.getDefinitionByName("olympus.io::CommunicationManager").PostServerCommand("fgeh.unified.event","press-end",holdArg);}catch(error:Error){}}
  gate.stop();holdOp="";holdArg="";
  if(holdStage!=null){
   holdStage.removeEventListener(MouseEvent.MOUSE_UP,onRelease,true);
   holdStage.removeEventListener(MouseEvent.MOUSE_MOVE,onPointer,true);
   holdStage.removeEventListener(Event.MOUSE_LEAVE,onRelease);
   holdStage.removeEventListener(Event.DEACTIVATE,onRelease);holdStage=null;
  }
  if(gate.waiting==""){clock.stop();}
 }
 private function onTick(event:TimerEvent):void {
  var due:Boolean=gate.check(getTimer());
  if(!gate.active){
   stopHold();
   if(gate.timedOut){clock.stop();status.text=LabText.t("shared_765f4392e2f0");}
   return;
  }
  if(due){send(holdOp,holdArg);}
 }
 public function submitted(request:String):void {gate.submitted(request,getTimer());clock.start();}
 public function choose(ids:String):void {send("boxselect",ids);}
 public function pickedAlignment(id:String):void {send("align",id+","+(alignFacing?"1":"0"));}
 public function pickedPivot(xyz:String):void {send(groundAlignment?"groundalign":"centerxyz",xyz);groundAlignment=false;}
 public function hint(message:String):void {status.text=message;}
 public function canChoose():Boolean {return token!="" && gate.waiting=="";}
 private function send(op:String,arg:String):void {
  if(isMotion(op) || op=="land" || op=="groundpick" || op=="alignarm" || op=="alignpick"){
   var selectedCount:int=0;for each(var selectedRow:String in rows){if(selectedRow.split("\t")[1]=="1"){selectedCount++;}}
   if(selectedCount==0){stopHold();status.text=LabText.t("shared_db3e79aebddb");return;}
  }
  if(!isMotion(op)){stopHold();}
  if(op=="people"){drawer=!drawer;people.visible=drawer;drawPeople();return;}
  if(op=="showList"){listOpen=!listOpen;if(listOpen){advanced=false;}page=0;drawPeople();return;}
  if(op=="advanced"){advanced=!advanced;if(advanced){listOpen=false;}drawPeople();return;}
  if(op=="ground" || op=="groundpick"){groundAlignment=op=="groundpick";op="ground";}
  if(op=="alignFacing"){alignFacing=!alignFacing;drawPeople();return;}
  if(op=="members"){addMode=false;page=0;drawPeople();return;}
  if(op=="prev"){page=Math.max(0,page-1);drawPeople();return;}
  if(op=="next"){page++;drawPeople();return;}
  if(op=="axis"){axis=arg;axisLabel.text=(axis=="x"?LabText.t("shared_f17b90b1c5e4"):axis=="y"?LabText.t("shared_3775ce98b443"):LabText.t("shared_225c39310d5a"))+" · "+axis.toUpperCase()+LabText.t("shared_cbd575e8652d");return;}
  if(gate.waiting!="" && op!="close" && op!="refresh" && op!="choosepose"){return;}
  if(op=="catalog"){addMode=true;page=0;}
  if(token=="" && op!="close" && op!="refresh" && op!="choosepose"){status.text=LabText.t("shared_02b48616c3ea");return;}
  if(op=="rotate"){op="r"+axis+arg;arg="";}
  if(op=="applyStep" || op=="applyAngle"){
   var isStep:Boolean=op=="applyStep";arg=wire(isStep?stepInput.text:angleInput.text);var value:Number=Number(arg);
   if(arg=="" || !isFinite(value) || value<(isStep?0.001:0.1) || value>(isStep?10:180)){status.text=isStep?LabText.t("shared_49af813d5de9"):LabText.t("shared_4b6c3e95cc27");return;}
   op=isStep?"step":"angle";
  }
  if(op=="alignarm"){arg=alignFacing?"1":"0";}
  if(op=="applyRadius"){arg=wire(radiusInput.text);var radius:Number=Number(arg);if(arg=="" || !isFinite(radius) || radius<1 || radius>256){status.text=LabText.t("shared_b04f54cca050");return;}op="radius";}
  if(op=="applyxyz"){op="centerxyz";arg=xyzFields[0].text+","+xyzFields[1].text+","+xyzFields[2].text;}
  action=op;argument=arg;status.text=LabText.t("shared_f7aef3167be3");dispatchEvent(new Event("fgehMoveAction",true));
 }
 private function drawPeople():void {
  while(people.numChildren>0){people.removeChildAt(0);}xyzFields=[];
  people.graphics.clear();people.graphics.lineStyle(1,0xC9E1E4);people.graphics.beginFill(0xF8FCFD);people.graphics.drawRoundRect(0,0,280,advanced?572:listOpen?494:302,24,24);people.graphics.endFill();
  button((peopleEnabled?"[√]":"[ ]")+LabText.t("shared_2cace32e7049"),10,12,126,32,"peoplefilter",peopleEnabled?"0":"1",people);button((objectsEnabled?"[√]":"[ ]")+LabText.t("shared_5198f6094d10"),144,12,124,32,"objectfilter",objectsEnabled?"0":"1",people);
  var radiusTitle:TextField=new TextField();radiusTitle.embedFonts=true;radiusTitle.defaultTextFormat=new TextFormat("$TextFont",12,0x557D86);radiusTitle.x=10;radiusTitle.y=57;radiusTitle.width=96;radiusTitle.height=24;radiusTitle.text=LabText.t("shared_4ab2e9babfc9");radiusTitle.mouseEnabled=false;people.addChild(radiusTitle);
  radiusInput=new TextField();radiusInput.type=TextFieldType.INPUT;radiusInput.embedFonts=true;radiusInput.defaultTextFormat=new TextFormat("$TextFont",13,0x294F58);radiusInput.border=true;radiusInput.borderColor=0xC9E1E4;radiusInput.background=true;radiusInput.backgroundColor=0xFFFFFF;radiusInput.x=108;radiusInput.y=54;radiusInput.width=84;radiusInput.height=26;radiusInput.text=radiusValue;radiusInput.restrict="0-9.";radiusInput.maxChars=12;people.addChild(radiusInput);
  radiusInput.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void {if(e.keyCode==13){e.stopImmediatePropagation();send("applyRadius","");}});radiusInput.addEventListener(MouseEvent.MOUSE_DOWN,function(e:MouseEvent):void {stopHold();});
  button(LabText.t("shared_4562024ddec7"),202,54,66,26,"applyRadius","",people);
  button(LabText.t("shared_f70c48a7984e"),10,94,126,30,"showList","",people);button(LabText.t("shared_e92d79560be4"),144,94,124,30,"refresh","",people);
  button((alignMode=="individual"?"[√] ":"")+LabText.t("shared_ff06e559b48d"),10,134,126,32,"alignmode","individual",people);button((alignMode=="group"?"[√] ":"")+LabText.t("shared_de4ea19c5799"),144,134,124,32,"alignmode","group",people);
  button((alignFacing?"[√]":"[ ]")+LabText.t("shared_450dec9bdc46"),10,176,258,30,"alignFacing","",people);
  button(LabText.t("shared_e9c3b57753a2"),10,216,258,32,"alignarm","",people);
  button((listOpen?LabText.t("shared_5d5815647c76"):LabText.t("shared_b0e24833f752"))+LabText.t("shared_f70c48a7984e"),10,262,126,28,"showList","",people);button((advanced?LabText.t("shared_5d5815647c76"):LabText.t("shared_b0e24833f752"))+LabText.t("shared_dd07e641ca66"),144,262,124,28,"advanced","",people);
  if(listOpen){
   button(LabText.t("shared_a6d3de0e8678"),10,304,156,30,"clear","",people);button(LabText.t("shared_3e44b2a93338"),174,304,94,30,"all","",people);
   var filtered:Array=[];for each(var row:String in rows){var p:Array=row.split("\t");if(true){filtered.push(p);}}
   page=Math.min(page,Math.max(0,Math.ceil(filtered.length/3)-1));
   for(var i:int=page*3;i<Math.min(filtered.length,page*3+3);i++){var item:Array=filtered[i];button((item[1]=="1"?LabText.t("shared_254cfaef6212"):"[ ] ")+item[2],10,344+(i-page*3)*34,208,30,"toggle",item[0],people);button("◎",226,344+(i-page*3)*34,42,30,"centerobject",item[0],people);}
   button(LabText.t("shared_b41561d80765"),10,454,126,28,"prev","",people);button(LabText.t("shared_67a246a344ae"),144,454,124,28,"next","",people);
  }
  if(advanced){
   button(LabText.t("shared_c5524cb54033"),10,304,60,30,"floor","current",people);button(LabText.t("shared_414e94653ca2"),76,304,60,30,"floor","up",people);button(LabText.t("shared_da4d23083795"),142,304,60,30,"floor","down",people);button(LabText.t("shared_778fc8f99453"),208,304,60,30,"floor","all",people);
   button(LabText.t("shared_1bc784fdc391"),10,344,126,30,"centergroup","",people);button(LabText.t("shared_8bf66a5156ec"),144,344,124,30,"centerself","",people);
  var axes:TextField=new TextField();axes.embedFonts=true;axes.defaultTextFormat=new TextFormat("$TextFont",11,0x557D86);axes.x=10;axes.y=376;axes.width=258;axes.height=20;axes.text=(pivotMode=="group"?LabText.t("shared_b6aaed58e2ae"):pivotMode=="self"?LabText.t("shared_8bf66a5156ec"):pivotMode=="object"?LabText.t("shared_9e1a1a9c0e02"):LabText.t("shared_20122ee06667"))+LabText.t("shared_0fcacd094ff5");axes.mouseEnabled=false;people.addChild(axes);
  xyzFields=[];
  for(var j:int=0;j<3;j++){
   var input:TextField=new TextField();input.type=TextFieldType.INPUT;input.embedFonts=true;input.defaultTextFormat=new TextFormat("$TextFont",13,0x294F58);input.border=true;input.borderColor=0xC9E1E4;input.background=true;input.backgroundColor=0xFFFFFF;input.x=10+j*88;input.y=396;input.width=80;input.height=28;input.text=Number(pivotValues[j]).toFixed(3);people.addChild(input);xyzFields.push(input);
  }
  button(LabText.t("shared_655a6b76e5db"),10,428,126,30,"applyxyz","",people);button(LabText.t("shared_72a3797cebab"),144,428,124,30,"ground","",people);
   button(LabText.t("shared_80d9a674a4aa"),10,464,258,28,"alignpick","",people);button(LabText.t("shared_6365c9894e4c"),10,500,258,26,"points","",people);
   button(LabText.t("shared_70f84bb02e5d"),10,536,126,26,"rebase","",people);button(LabText.t("shared_5e9e8bc2be31"),144,536,124,26,"legacy","",people);
  }
 }
 public function applyState(data:Object):Boolean {
  if(!shownActive){return false;}
  if(data==null || data.additional_texts==null || data.additional_texts.length<6){stopHold();status.text=LabText.t("shared_0237e4ec8174");return false;}
  var arr:Object=data.additional_texts;
  var incomingToken:String=wire(arr[1]);var request:String=wire(arr[3]);
  // An unrelated/late reply cannot clear a newer in-flight request or replace its state.
  if(request!="" && (incomingToken!="" && incomingToken!=token || request!=gate.waiting)){return false;}
  status.text=String(arr[0]);token=incomingToken;settings.text=String(arr[2]);context=wire(arr[5]);
  for(var fi:int=6;fi<arr.length;fi++){var flags:Array=String(arr[fi]).split('|');if(flags.length==3 && flags[0]=='$flags'){peopleEnabled=flags[1]=='1';objectsEnabled=flags[2]=='1';break;}}
  gate.state(token,context);gate.ack(request,wire(arr[4])=="ok");
  if(!gate.active){stopHold();}
  rows=[];for(var i:int=6;i<arr.length;i++){var raw:String=wire(arr[i]);if(raw=="__FGEH_SHARED_UI_L10N_L01__"){break;}if(raw.substr(0,1)=="$"){continue;}if(raw.substr(0,1)=="~"){var numeric:Array=raw.substr(1).split("|");if(numeric.length==2){if(stage==null || stage.focus!=stepInput){stepInput.text=numeric[0];}if(stage==null || stage.focus!=angleInput){angleInput.text=numeric[1];}}}else if(raw.substr(0,1)=="&"){alignMode=raw.substr(1);}else if(raw.substr(0,1)=="%"){radiusValue=raw.substr(1);}else if(raw.substr(0,1)=="!"){var pv:Array=raw.substr(1).split("|");if(pv.length==4){pivotMode=pv[0];pivotValues=[Number(pv[1]),Number(pv[2]),Number(pv[3])];}}else if(raw.substr(0,1)!="@" && raw.substr(0,1)!="^"){rows.push(String(arr[i]));}}
  var key:String=rows.join("\n")+settings.text+pivotMode+alignMode;if(drawer && key!=rosterKey){drawPeople();}rosterKey=key;
  if(radiusInput!=null && (stage==null || stage.focus!=radiusInput)){radiusInput.text=radiusValue;}
  if(drawer){for(var j:int=0;j<xyzFields.length;j++){if(stage==null || stage.focus!=xyzFields[j]){xyzFields[j].text=Number(pivotValues[j]).toFixed(3);}}}
  return true;
 }
 public function shown(count:int):void {suspend();shownActive=true;status.text=LabText.t("shared_783169193818");}
 public function suspend():void {stopScale();stopHold();clock.stop();gate.reset();token="";context="";shownActive=false;}
 public function dispose():void {suspend();clock.removeEventListener(TimerEvent.TIMER,onTick);removeEventListener(Event.REMOVED_FROM_STAGE,onRemoved);rows=[];}
}
}
