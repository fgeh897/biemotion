package fgeh.ui.lab {
 import flash.display.DisplayObject;
 import flash.display.DisplayObjectContainer;
 import flash.text.TextField;
 public class LabText {
  private static var values:Object={};
  public static function t(key:String):String {return values.hasOwnProperty(key)?String(values[key]):"\ue000"+key+"\ue001";}
  public static function resolve(text:String,depth:int=0):String {
   if(depth>8){return text;}var pos:int=0;
   while(true){var start:int=text.indexOf("\ue000",pos);if(start<0){break;}var end:int=text.indexOf("\ue001",start);if(end<0){break;}
    var parts:Array=text.substring(start+1,end).split("\ue002");var key:String=String(parts[0]);if(!values.hasOwnProperty(key)){pos=end+1;continue;}
    var result:String=String(values[key]);for(var i:int=1;i<parts.length;i++){var arg:String;try{arg=decodeURIComponent(String(parts[i]));}catch(error:Error){arg=String(parts[i]);}result=result.split("[["+(i-1)+"]]").join(resolve(arg,depth+1));}
    text=text.substring(0,start)+result+text.substr(end+1);pos=start+result.length;
   }return text;
  }
  public static function load(data:Object):void {
   if(data==null || data.additional_texts==null){return;}var a:Object=data.additional_texts;var marker:int=-1;
   for(var i:int=0;i<a.length;i++){if(String(a[i])=="__FGEH_SHARED_UI_L10N_L01__"){marker=i;break;}}
   if(marker<0){for(var plain:int=0;plain<a.length;plain++){a[plain]=resolve(String(a[plain]));}return;}if(marker+1>=a.length){return;}var keys:Array=String(a[marker+1]).split(",");if(marker+2+keys.length>a.length){return;}
   for(i=0;i<keys.length;i++){values[String(keys[i])]=String(a[marker+2+i]);}
   for(i=0;i<marker;i++){a[i]=resolve(String(a[i]));}
  }
  public static function tree(root:DisplayObject):void {
   if(root is TextField){var f:TextField=root as TextField;var changed:String=resolve(f.text);if(changed!=f.text){f.text=changed;}return;}
   if(root is DisplayObjectContainer){var c:DisplayObjectContainer=root as DisplayObjectContainer;for(var i:int=0;i<c.numChildren;i++){tree(c.getChildAt(i));}}
  }
 }
}
