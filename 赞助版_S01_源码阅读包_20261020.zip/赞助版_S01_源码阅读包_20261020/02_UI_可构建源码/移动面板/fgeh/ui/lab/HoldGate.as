package fgeh.ui.lab {
// Pure clock/request state. No timers, dispatch, or native/game dependencies.
public class HoldGate {
 public var active:Boolean=false;
 public var waiting:String="";
 public var timedOut:Boolean=false;
 public var nextAt:Number=0;
 public var sentAt:Number=0;
 public var startedAt:Number=0;
 private var boundToken:String="";
 private var boundContext:String="";
 public function start(now:Number,token:String,context:String):Boolean {
  if(waiting!="" || token==""){return false;}
  active=true;timedOut=false;startedAt=now;nextAt=now+300;
  boundToken=token;boundContext=context;return true;
 }
 public function submitted(request:String,now:Number):void {
  waiting=request;sentAt=now;nextAt=Math.max(nextAt,now+100);
 }
 public function ack(request:String,ok:Boolean):Boolean {
  if(request=="" || request!=waiting){return false;}
  waiting="";if(!ok){active=false;}return true;
 }
 public function check(now:Number):Boolean {
  if(waiting!="" && now-sentAt>=2000){active=false;timedOut=true;return false;}
  if(active && now-startedAt>=10000){active=false;return false;}
  return active && waiting=="" && now>=nextAt;
 }
 public function state(token:String,context:String):void {
  if(active && (token!=boundToken || context!=boundContext)){active=false;}
 }
 public function stop():void {active=false;}
 public function reset():void {active=false;waiting="";timedOut=false;nextAt=0;}
}
}
