package fgeh.ui.lab {
 import flash.display.Sprite;
 import flash.display.Stage;
 import flash.events.Event;
 import flash.events.MouseEvent;
 import flash.events.KeyboardEvent;
 import flash.geom.Point;
 import flash.geom.Vector3D;
 import olympus.utils.DisplayObjectUtils;
 public class SelectionLayer extends Sprite {
  public var chosen:String="";
  public var picked:String="";
  private var aligning:Boolean=false;
  private var picking:Boolean=false;
  private var groundDots:Array=[];
  private var cameraDots:Array=[];
  public var cameraFailure:String="";
  private var planeCenter:Array=[0,0,0];
  private var pivotDot:Sprite;
  private var surface:Sprite=new Sprite();
  private var probes:Sprite=new Sprite();
  private var marquee:Sprite=new Sprite();
  private var entries:Array=[];
  private var boundStage:Stage;
  private var armed:Boolean=false;
  private var dragging:Boolean=false;
  private var dragPoints:Array=[];
  private var showMarks:Boolean=true;
  private var pointMode:int=0;
  private var x0:Number=0;
  private var y0:Number=0;
  public function SelectionLayer() {
   addChild(surface);addChild(probes);addChild(marquee);surface.visible=false;
   probes.mouseEnabled=false;probes.mouseChildren=false;marquee.mouseEnabled=false;marquee.mouseChildren=false;
   surface.addEventListener(MouseEvent.MOUSE_DOWN,onDown);
  }
  public function shown():void {
   suspend();boundStage=stage;
   if(boundStage!=null){boundStage.addEventListener(MouseEvent.MOUSE_UP,onUp,true);boundStage.addEventListener(MouseEvent.MOUSE_MOVE,onPointer,true);boundStage.addEventListener(Event.MOUSE_LEAVE,onCancel);boundStage.addEventListener(Event.DEACTIVATE,onCancel);boundStage.addEventListener(KeyboardEvent.KEY_DOWN,onKey,true);}
   addEventListener(Event.ENTER_FRAME,onFrame);
  }
  private function onFrame(event:Event):void {
   if(stage==null){return;}var a:Point=globalToLocal(new Point(0,0));var b:Point=globalToLocal(new Point(stage.stageWidth,stage.stageHeight));
   surface.graphics.clear();surface.graphics.beginFill(0,0.002);surface.graphics.drawRect(a.x,a.y,b.x-a.x,b.y-a.y);surface.graphics.endFill();
   if(picking && groundDots.length==4){
    marquee.graphics.clear();marquee.graphics.lineStyle(1,0xE0B45E);marquee.graphics.beginFill(0xE0B45E,.08);
    for(var i:int=0;i<4;i++){var p:Point=globalToLocal(groundDots[i].localToGlobal(new Point()));if(i==0){marquee.graphics.moveTo(p.x,p.y);}else{marquee.graphics.lineTo(p.x,p.y);}}
    var first:Point=globalToLocal(groundDots[0].localToGlobal(new Point()));marquee.graphics.lineTo(first.x,first.y);marquee.graphics.endFill();
   }
  }
  public function cameraDirection():String {
   cameraFailure="";if(stage==null || cameraDots.length!=4){cameraFailure="missing-stage-or-probes";return "";}
   var corners:Array=[],cx:Number=0,cy:Number=0;
   for each(var dot:Sprite in cameraDots){
    if(!dot.visible){cameraFailure="native-probe-hidden";return "";}var p:Point=dot.localToGlobal(new Point());
    if(!isFinite(p.x)||!isFinite(p.y)){cameraFailure="nonfinite-screen-point";return "";}corners.push([p.x,p.y]);cx+=p.x/4;cy+=p.y/4;
   }
   var c:Array=BoxMath.planeUV(corners,cx,cy),up:Array=BoxMath.planeUV(corners,cx,cy-.01),right:Array=BoxMath.planeUV(corners,cx+.01,cy);
   if(c.length!=2||up.length!=2||right.length!=2){cameraFailure="degenerate-plane";return "";}
   var fx:Number=up[0]-c[0],fz:Number=up[1]-c[1],rx:Number=right[0]-c[0],rz:Number=right[1]-c[1];
   var fl:Number=Math.sqrt(fx*fx+fz*fz),rl:Number=Math.sqrt(rx*rx+rz*rz);
   if(!isFinite(fl)||!isFinite(rl)||fl<.00000001||rl<.00000001){cameraFailure="degenerate-direction";return "";}
   return String(fx/fl)+"~"+String(fz/fl)+"~"+String(rx/rl)+"~"+String(rz/rl);
  }
  public function alignTarget():void {cancel();aligning=true;surface.visible=true;paint();}
  public function ground():Boolean {cancel();if(groundDots.length!=4){return false;}picking=true;surface.visible=true;return true;}
  public function toggle():void {var next:Boolean=!armed;cancel();armed=next;surface.visible=armed;paint();}
  public function points():String {pointMode=(pointMode+1)%3;paint();return pointMode==0?LabText.t("shared_ba522e99446f"):pointMode==1?LabText.t("shared_d780c469cbc7"):LabText.t("shared_5c23be05d43c");}
  public function marks():void {showMarks=!showMarks;paint();}
  public function cancel():void {dragPoints=[];aligning=false;dragging=false;armed=false;picking=false;surface.visible=false;marquee.graphics.clear();paint();}
  private function onCancel(event:Event):void {cancel();}
  private function onKey(event:KeyboardEvent):void {if(event.keyCode==27){cancel();}}
  private function onDown(event:MouseEvent):void {
   if(aligning){
    event.stopImmediatePropagation();var best:Object=null;var distance:Number=324;
    for each(var candidate:Object in entries){var cp:Point=candidate.dot.localToGlobal(new Point());var d:Number=(cp.x-event.stageX)*(cp.x-event.stageX)+(cp.y-event.stageY)*(cp.y-event.stageY);if(!candidate.selected && candidate.dot.visible && d<=distance){best=candidate;distance=d;}}
    if(best==null){dispatchEvent(new Event("fgehAlignError",true));return;}
    picked=best.id;cancel();dispatchEvent(new Event("fgehAlignPick",true));return;
   }
   if(picking){
    event.stopImmediatePropagation();var corners:Array=[];
    for each(var dot:Sprite in groundDots){var p:Point=dot.localToGlobal(new Point());if(!dot.visible){corners=[];break;}corners.push([p.x,p.y]);}
    var uv:Array=BoxMath.planeUV(corners,event.stageX,event.stageY);cancel();
    if(uv.length==2){picked=String(planeCenter[0]-8+16*uv[0])+","+planeCenter[1]+","+String(planeCenter[2]-8+16*uv[1]);dispatchEvent(new Event("fgehPivotPick",true));}
    else{dispatchEvent(new Event("fgehPivotError",true));}return;
   }
   if(!armed){return;}dragging=true;x0=event.stageX;y0=event.stageY;dragPoints=[];
   for each(var item:Object in entries){var dp:Point=item.dot.localToGlobal(new Point());if(item.dot.visible && isFinite(dp.x) && isFinite(dp.y) && BoxMath.inside(dp.x,dp.y,-6,-6,stage.stageWidth+6,stage.stageHeight+6)){dragPoints.push({id:item.id,x:dp.x,y:dp.y});}}
   event.stopImmediatePropagation();
  }
  private function onPointer(event:MouseEvent):void {
   if(!dragging){return;}if(!event.buttonDown){cancel();return;}
   var a:Point=globalToLocal(new Point(x0,y0));var b:Point=globalToLocal(new Point(event.stageX,event.stageY));
   marquee.graphics.clear();marquee.graphics.lineStyle(1,0x49A7F5);marquee.graphics.beginFill(0x49A7F5,.12);marquee.graphics.drawRect(Math.min(a.x,b.x),Math.min(a.y,b.y),Math.abs(b.x-a.x),Math.abs(b.y-a.y));marquee.graphics.endFill();
  }
  private function onUp(event:MouseEvent):void {
   if(!dragging){return;}event.stopImmediatePropagation();var ids:Array=[];
   if(BoxMath.dragged(x0,y0,event.stageX,event.stageY)){
    for each(var point:Object in dragPoints){if(BoxMath.circleHit(point.x,point.y,6,x0,y0,event.stageX,event.stageY)){ids.push(point.id);}}
   }
   dragging=false;dragPoints=[];marquee.graphics.clear();armed=true;surface.visible=true;paint();chosen=ids.join(",");dispatchEvent(new Event("fgehBoxChoose",true));
  }
  public function applyState(data:Object):void {
   var resumeBox:Boolean=armed && !dragging;var resumeAlign:Boolean=aligning;
   cancel();destroyEntries();var arr:Object=data.additional_texts;
   for(var i:int=6;i<arr.length;i++){
    var raw:String=String(arr[i]).replace(/[\u210b\u210e\u210f\ufeff]/g,"").replace(/^\s+|\s+$/g,"");
    if(raw.substr(0,1)=="!"){
     var pv:Array=raw.substr(1).split("|");if(pv.length==4){var nextCenter:Array=[Number(pv[1]),Number(pv[2]),Number(pv[3])];if(pivotDot==null || nextCenter[0]!=planeCenter[0] || nextCenter[1]!=planeCenter[1] || nextCenter[2]!=planeCenter[2]){destroyGround();planeCenter=nextCenter;buildPivot();}}continue;
    }
    if(raw.substr(0,1)!="@" || entries.length>=320){continue;}
    var row:Array=raw.substr(1).split("|");if(row.length!=6 || !/^[1-9][0-9]*$/.test(row[0])){continue;}
    var x:Number=Number(row[2]),y:Number=Number(row[3]),z:Number=Number(row[4]);if(!isFinite(x)||!isFinite(y)||!isFinite(z)){continue;}
    var dot:Sprite=new Sprite();dot.mouseEnabled=false;dot.graphics.beginFill(0,0);dot.graphics.drawRect(-1,-1,2,2);dot.graphics.endFill();probes.addChild(dot);entries.push({id:String(row[0]),sim:row[1]=="1",selected:row[5]=="1",dot:dot});
    try{DisplayObjectUtils.BindDisplayObject(dot,new Vector3D(x,y,z));}catch(error:Error){dot.visible=false;}
   }
   armed=resumeBox;aligning=resumeAlign;surface.visible=armed || aligning;paint();
  }
  private function buildPivot():void {
   if(!isFinite(planeCenter[0])||!isFinite(planeCenter[1])||!isFinite(planeCenter[2])){return;}
   pivotDot=new Sprite();pivotDot.mouseEnabled=false;probes.addChild(pivotDot);pivotDot.graphics.lineStyle(2,0xE0B45E);pivotDot.graphics.moveTo(-12,0);pivotDot.graphics.lineTo(12,0);pivotDot.graphics.moveTo(0,-12);pivotDot.graphics.lineTo(0,12);
   try{DisplayObjectUtils.BindDisplayObject(pivotDot,new Vector3D(planeCenter[0],planeCenter[1],planeCenter[2]));
   var offsets:Array=[[-8,-8],[8,-8],[8,8],[-8,8]];
   for(var i:int=0;i<4;i++){
    var dot:Sprite=new Sprite();dot.mouseEnabled=false;dot.graphics.beginFill(0,0);dot.graphics.drawRect(-1,-1,2,2);dot.graphics.endFill();probes.addChild(dot);groundDots.push(dot);DisplayObjectUtils.BindDisplayObject(dot,new Vector3D(planeCenter[0]+offsets[i][0],planeCenter[1],planeCenter[2]+offsets[i][1]));
   }
   var cameraOffsets:Array=[[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]];
   for(var ci:int=0;ci<4;ci++){
    var cameraDot:Sprite=new Sprite();cameraDot.mouseEnabled=false;cameraDot.graphics.beginFill(0,0);cameraDot.graphics.drawRect(-1,-1,2,2);cameraDot.graphics.endFill();probes.addChild(cameraDot);cameraDots.push(cameraDot);DisplayObjectUtils.BindDisplayObject(cameraDot,new Vector3D(planeCenter[0]+cameraOffsets[ci][0],planeCenter[1],planeCenter[2]+cameraOffsets[ci][1]));
   }
   }catch(error:Error){if(pivotDot!=null){pivotDot.visible=false;}for each(var failed:Sprite in groundDots.concat(cameraDots)){failed.visible=false;}}
  }
  private function paint():void {
   if(pivotDot!=null){
    pivotDot.graphics.clear();pivotDot.graphics.beginFill(0,0);pivotDot.graphics.drawRect(-1,-1,2,2);pivotDot.graphics.endFill();
    if(showMarks){pivotDot.graphics.lineStyle(2,0xE0B45E);pivotDot.graphics.moveTo(-12,0);pivotDot.graphics.lineTo(12,0);pivotDot.graphics.moveTo(0,-12);pivotDot.graphics.lineTo(0,12);}
   }
   for each(var entry:Object in entries){
    var dot:Sprite=entry.dot;dot.graphics.clear();dot.graphics.beginFill(0,0);dot.graphics.drawRect(-1,-1,2,2);dot.graphics.endFill();
    if(showMarks || armed || aligning){
     if(pointMode==0 || armed || aligning){dot.graphics.lineStyle(1,0xFFFFFF);dot.graphics.beginFill(entry.sim?0xE270A7:0x429BD7);dot.graphics.drawCircle(0,0,6);dot.graphics.endFill();}
     if(entry.selected){dot.graphics.lineStyle(2,0xF4A62A);dot.graphics.drawRect(-10,-10,20,20);}
    }
   }
  }
  public function get candidateSummary():String {var people:int=0;for each(var entry:Object in entries){if(entry.sim){people++;}}return LabText.t("shared_b755b68373c8")+people+LabText.t("shared_f76f781fb217")+(entries.length-people);}
  public function get count():int {return entries.length;}
  private function destroyGround():void {
   var all:Array=groundDots.concat(cameraDots);if(pivotDot!=null){all.push(pivotDot);pivotDot=null;}
   for each(var extra:Sprite in all){try{DisplayObjectUtils.UnbindDisplayObject(extra);}catch(error:Error){}if(probes.contains(extra)){probes.removeChild(extra);}}groundDots=[];cameraDots=[];
  }
  private function destroyEntries():void {
   for each(var entry:Object in entries){try{DisplayObjectUtils.UnbindDisplayObject(entry.dot);}catch(error:Error){}if(probes.contains(entry.dot)){probes.removeChild(entry.dot);}}entries=[];
  }
  private function destroyProbes():void {destroyGround();destroyEntries();}
  public function suspend():void {
   cancel();removeEventListener(Event.ENTER_FRAME,onFrame);destroyProbes();
   if(boundStage!=null){boundStage.removeEventListener(MouseEvent.MOUSE_UP,onUp,true);boundStage.removeEventListener(MouseEvent.MOUSE_MOVE,onPointer,true);boundStage.removeEventListener(Event.MOUSE_LEAVE,onCancel);boundStage.removeEventListener(Event.DEACTIVATE,onCancel);boundStage.removeEventListener(KeyboardEvent.KEY_DOWN,onKey,true);boundStage=null;}
  }
  public function dispose():void {suspend();surface.removeEventListener(MouseEvent.MOUSE_DOWN,onDown);}
 }
}
