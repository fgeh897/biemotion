package fgeh.ui.lab {
 public class BoxMath {
  public static function circleHit(x:Number,y:Number,r:Number,x0:Number,y0:Number,x1:Number,y1:Number):Boolean {
   if(!isFinite(x)||!isFinite(y)||!isFinite(r)||!isFinite(x0)||!isFinite(y0)||!isFinite(x1)||!isFinite(y1)||r<0){return false;}
   var dx:Number=x-Math.max(Math.min(x0,x1),Math.min(Math.max(x0,x1),x));
   var dy:Number=y-Math.max(Math.min(y0,y1),Math.min(Math.max(y0,y1),y));
   return dx*dx+dy*dy<=r*r;
  }
  public static function wheelValue(value:Number,direction:int,isStep:Boolean):Number {
   var values:Array=isStep?[0.001,0.01,0.05,0.1,0.5,1,2]:[5,30,45,90];
   if(!isFinite(value)){value=isStep?0.05:5;}
   if(direction>0){for(var i:int=0;i<values.length;i++){if(values[i]>value+0.0000001){return values[i];}}return values[values.length-1];}
   if(direction<0){for(var j:int=values.length-1;j>=0;j--){if(values[j]<value-0.0000001){return values[j];}}return values[0];}
   return value;
  }
  public static function panelBounds(w:Number,h:Number):Array {
   if(!isFinite(w)||!isFinite(h)||w<=0||h<=0){return [];}
   return [8,Math.min(64,Math.max(8,h-44)),Math.max(8,w-358),Math.max(Math.min(64,Math.max(8,h-44)),h-592)];
  }
  public static function panelPosition(x:Number,y:Number,w:Number,h:Number):Array {
   var b:Array=panelBounds(w,h);if(b.length!=4){return [];}
   return [Math.max(b[0],Math.min(b[2],isFinite(x)?x:b[0])),Math.max(b[1],Math.min(b[3],isFinite(y)?y:b[1]))];
  }

  public static function scaledPanelBounds(w:Number,h:Number,s:Number):Array {
   if(!isFinite(w)||!isFinite(h)||w<=0||h<=0||!isFinite(s)||s<0.6||s>1.4){return [];}
   var top:Number=Math.min(96,Math.max(8,h-44*s));
   return [8,top,Math.max(8,w-350*s-8),Math.max(top,h-584*s-8)];
  }
  public static function scaledPanelPosition(x:Number,y:Number,w:Number,h:Number,s:Number):Array {
   var b:Array=scaledPanelBounds(w,h,s);if(b.length!=4){return [];}
   return [Math.max(b[0],Math.min(b[2],isFinite(x)?x:b[2])),Math.max(b[1],Math.min(b[3],isFinite(y)?y:b[1]))];
  }
  public static function rotationShape(sign:int):Array {
   sign=sign<0?-1:1;var arc:Array=[];
   for(var i:int=0;i<=36;i++){var angle:Number=-Math.PI/2+sign*Math.PI*1.5*i/36;arc.push([15*Math.cos(angle),15*Math.sin(angle)]);}
   var tip:Array=arc[36];var tx:Number=-Math.sin(angle)*sign,ty:Number=Math.cos(angle)*sign;
   return [arc,[tip,[tip[0]-7*tx-4*ty,tip[1]-7*ty+4*tx],[tip[0]-7*tx+4*ty,tip[1]-7*ty-4*tx]]];
  }

  public static function planeUV(points:Array,x:Number,y:Number):Array {
   if(points.length!=4 || !isFinite(x) || !isFinite(y)){return [];}
   var positive:Boolean=false,negative:Boolean=false;
   var matrix:Array=[];
   for(var i:int=0;i<4;i++){
    var p:Array=points[i],q:Array=points[(i+1)%4];
    var cross:Number=(q[0]-p[0])*(y-p[1])-(q[1]-p[1])*(x-p[0]);
    if(cross>0.001){positive=true;}if(cross<-.001){negative=true;}
    if(!isFinite(p[0]) || !isFinite(p[1]) || positive && negative){return [];}
    var u:Number=i==1 || i==2?1:0,v:Number=i>=2?1:0;
    matrix.push([p[0],p[1],1,0,0,0,-u*p[0],-u*p[1],u]);
    matrix.push([0,0,0,p[0],p[1],1,-v*p[0],-v*p[1],v]);
   }
   for(var col:int=0;col<8;col++){
    var best:int=col;
    for(var row:int=col+1;row<8;row++){if(Math.abs(matrix[row][col])>Math.abs(matrix[best][col])){best=row;}}
    if(Math.abs(matrix[best][col])<0.00000001){return [];}
    var swap:Array=matrix[col];matrix[col]=matrix[best];matrix[best]=swap;
    var divisor:Number=matrix[col][col];
    for(var j:int=col;j<9;j++){matrix[col][j]/=divisor;}
    for(row=0;row<8;row++){
     if(row==col){continue;}var factor:Number=matrix[row][col];
     for(j=col;j<9;j++){matrix[row][j]-=factor*matrix[col][j];}
    }
   }
   var denominator:Number=matrix[6][8]*x+matrix[7][8]*y+1;
   if(Math.abs(denominator)<0.0000001){return [];}
   var result:Array=[(matrix[0][8]*x+matrix[1][8]*y+matrix[2][8])/denominator,(matrix[3][8]*x+matrix[4][8]*y+matrix[5][8])/denominator];
   return isFinite(result[0]) && isFinite(result[1]) && result[0]>=-.0001 && result[0]<=1.0001 && result[1]>=-.0001 && result[1]<=1.0001?result:[];
  }
  public static function stagePlane(a:Number,b:Number,c:Number,d:Number,tx:Number,ty:Number):Array {
   var determinant:Number=a*d-b*c;
   if(!isFinite(determinant) || !isFinite(tx) || !isFinite(ty) || Math.abs(determinant)<0.000001){return [];}
   return [d/determinant,-b/determinant,-c/determinant,a/determinant,
           (c*ty-d*tx)/determinant,(b*tx-a*ty)/determinant];
  }
  public static function inside(x:Number,y:Number,x0:Number,y0:Number,x1:Number,y1:Number):Boolean {
   return isFinite(x) && isFinite(y) && x>=Math.min(x0,x1) && x<=Math.max(x0,x1) && y>=Math.min(y0,y1) && y<=Math.max(y0,y1);
  }
  public static function dragged(x0:Number,y0:Number,x1:Number,y1:Number):Boolean {
   return (x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)>=25;
  }
 }
}
