package fgeh.ui.lab {
 import flash.display.MovieClip;
 import flash.display.Sprite;
 import flash.display.Stage;
 import flash.events.Event;
 import flash.events.KeyboardEvent;
 import flash.events.MouseEvent;
 import flash.text.TextField;
 import flash.text.TextFieldType;
 import flash.geom.Matrix;
 import flash.geom.Rectangle;
 import flash.utils.getTimer;
 import olympus.input.InputAction;
 import olympus.input.InputTrigger;
 import olympus.io.InputActionManager;
 import olympus.constants.GameStates;
 import olympus.core.widget.WidgetBase;
 import olympus.io.CommunicationManager;
 public class LabWidget extends WidgetBase {
  private var plane:Sprite=new Sprite();
  private var view:LabView;
  private var selection:SelectionLayer;
  private var requestCount:int=0;
  private var keyStage:Stage;
  private var panelX:Number=20;
  private var panelY:Number=90;
  private var windowRestored:Boolean=false;
  private var displayed:Boolean=false;
  private var armed:Boolean=false;
  private var toggleDown:Boolean=false;
  private var boxDown:Boolean=false;
  private var dragStage:Stage;
  private var shortcut:InputAction;
  private var nativeRegistered:Boolean=false;
  private var lastSwitch:int=-10000;
  private var lastNative:int=-10000;
  public function LabWidget() {
   super();mcPositionHelper=new MovieClip();mcPositionHelper.name="mcPositionHelper";
   mcPositionHelper.graphics.beginFill(0,0);mcPositionHelper.graphics.drawRect(0,0,350,500);mcPositionHelper.graphics.endFill();mcPositionHelper.mouseEnabled=false;mcPositionHelper.mouseChildren=false;mcPositionHelper.visible=false;addChild(mcPositionHelper);
   addChild(plane);buildView();addEventListener(Event.ADDED_TO_STAGE,onStageReady);
  }
  private function buildView():void {
   if(view!=null){return;}
   selection=new SelectionLayer();plane.addChild(selection);selection.addEventListener("fgehBoxChoose",onChoose);selection.addEventListener("fgehPivotPick",onPivot);selection.addEventListener("fgehPivotError",onPivotError);selection.addEventListener("fgehAlignPick",onAlignPick);selection.addEventListener("fgehAlignError",onAlignError);
   view=new LabView();view.x=20;view.y=90;plane.addChild(view);view.addEventListener("fgehMoveAction",onAction);view.addEventListener("fgehMoveDrag",onDrag);view.addEventListener("fgehUIScale",onScale);view.addEventListener("fgehUIScaleSave",saveWindow);
  }
  override public function Initialize():void {super.Initialize();buildView();CommunicationManager.AddMessageListener("FgEHUnifiedState",onState,this);CommunicationManager.AddMessageListener("FgEHUnifiedDisarm",onDisarm,this);CommunicationManager.AddMessageListener("FgEHUnifiedConceal",onConceal,this);notify("init");}
  override public function Show(data:Object=null):void {
   super.Show(data);buildView();displayed=false;armed=true;view.visible=false;alignPlane();keepPanelVisible();view.shown(1);selection.suspend();
   removeEventListener(Event.ENTER_FRAME,onFrame);
   attachShortcut();registerNative();
   if(keyStage==null){addEventListener(Event.ENTER_FRAME,onStageReady);}
   notify("show");CommunicationManager.PostServerCommand("fgeh.unified.refresh");
  }
  override public function Hide(data:Object=null):void {
   armed=false;detachShortcut();unregisterNative();toggleDown=false;boxDown=false;endDrag();displayed=false;removeEventListener(Event.ENTER_FRAME,onFrame);if(view!=null){view.suspend();selection.suspend();}super.Hide(data);notify("hide");
  }
  private function alignPlane():void {
   var m:Matrix=transform.concatenatedMatrix;var a:Array=BoxMath.stagePlane(m.a,m.b,m.c,m.d,m.tx,m.ty);
   if(a.length==6){plane.transform.matrix=new Matrix(a[0],a[1],a[2],a[3],a[4],a[5]);}
  }
  private function keepPanelVisible():void {
   if(view==null || stage==null){return;}if(dragStage!=null){panelX=view.x;panelY=view.y;}var p:Array=BoxMath.scaledPanelPosition(panelX,panelY,stage.stageWidth,stage.stageHeight,view.uiScale);
   if(p.length==2){panelX=p[0];panelY=p[1];view.x=panelX;view.y=panelY;}
  }
  private function onFrame(event:Event):void {alignPlane();keepPanelVisible();}
  private function onDrag(event:Event):void {
   view.cancelHold();selection.cancel();endDrag();dragStage=stage;
   if(dragStage!=null){keepPanelVisible();var b:Array=BoxMath.scaledPanelBounds(stage.stageWidth,stage.stageHeight,view.uiScale);if(b.length!=4){dragStage=null;return;}view.startDrag(false,new Rectangle(b[0],b[1],b[2]-b[0],b[3]-b[1]));dragStage.addEventListener(MouseEvent.MOUSE_UP,endDrag);dragStage.addEventListener(Event.DEACTIVATE,endDrag);}
  }
  private function endDrag(event:Event=null):void {
   if(view!=null){view.stopDrag();keepPanelVisible();}if(dragStage!=null){dragStage.removeEventListener(MouseEvent.MOUSE_UP,endDrag);dragStage.removeEventListener(Event.DEACTIVATE,endDrag);dragStage=null;if(displayed){saveWindow();}}
  }
  private function onScale(event:Event):void {view.cancelHold();selection.cancel();view.scaleX=view.uiScale;view.scaleY=view.uiScale;keepPanelVisible();}
  private function saveWindow(event:Event=null):void {if(view!=null && windowRestored){CommunicationManager.PostServerCommand("fgeh.unified.window",view.uiScale+","+view.x+","+view.y);}}
  private function restoreWindow(data:Object):void {
   if(windowRestored || stage==null){return;}
   var arr:Object=data.additional_texts;
   for(var i:int=6;i<arr.length;i++){var raw:String=String(arr[i]);if(raw.charAt(0)=="^"){
    var p:Array=raw.substr(1).split("|");if(p.length!=3){continue;}
    view.setUIScale(Number(p[0]));view.scaleX=view.uiScale;view.scaleY=view.uiScale;
    view.x=p[1]==""?stage.stageWidth-350*view.uiScale-24:Number(p[1]);view.y=p[2]==""?96:Number(p[2]);
    panelX=view.x;panelY=view.y;windowRestored=true;keepPanelVisible();return;
   }}
  }
  private function onStageReady(event:Event):void {if(armed){attachShortcut();}}
  private function attachShortcut():void {
   if(keyStage==stage && keyStage!=null){return;}
   if(stage==null){return;}detachShortcut();keyStage=stage;
   keyStage.addEventListener(KeyboardEvent.KEY_DOWN,onKey,true,1000);
   keyStage.addEventListener(KeyboardEvent.KEY_DOWN,onKey,false,1000);
   keyStage.addEventListener(KeyboardEvent.KEY_UP,onKeyUp,true,1000);
   keyStage.addEventListener(KeyboardEvent.KEY_UP,onKeyUp,false,1000);
   keyStage.addEventListener(Event.DEACTIVATE,onDeactivate);
   removeEventListener(Event.ENTER_FRAME,onStageReady);notify("stage-attached");
  }
  private function detachShortcut():void {
   removeEventListener(Event.ENTER_FRAME,onStageReady);
   if(keyStage==null){return;}
   keyStage.removeEventListener(KeyboardEvent.KEY_DOWN,onKey,true);keyStage.removeEventListener(KeyboardEvent.KEY_DOWN,onKey,false);
   keyStage.removeEventListener(KeyboardEvent.KEY_UP,onKeyUp,true);keyStage.removeEventListener(KeyboardEvent.KEY_UP,onKeyUp,false);
   keyStage.removeEventListener(Event.DEACTIVATE,onDeactivate);keyStage=null;
  }
  private function canShortcut():Boolean {
   return armed && !(keyStage!=null && keyStage.focus is TextField && TextField(keyStage.focus).type==TextFieldType.INPUT);
  }
  private function registerNative():void {
   if(nativeRegistered){return;}
   try{
    if(shortcut==null){shortcut=InputAction.WhenTriggered(InputTrigger.FromKeyBinding(118,0)).SetPriority(1000).SetKillPropagation(true).RestrictToGameStates(GameStates.PLAY).SetValidCheck(canShortcut).CallFunction(onNativeToggle);}
    nativeRegistered=InputActionManager.RegisterAction(shortcut);notify(nativeRegistered?"native-registered":"native-rejected");
   }catch(error:Error){notify("native-error");}
  }
  private function unregisterNative():void {
   if(nativeRegistered){try{InputActionManager.UnregisterAction(shortcut);}catch(error:Error){}}
   nativeRegistered=false;
  }
  private function switchPanel(path:String):void {
   var now:int=getTimer();if(now-lastSwitch<120){return;}lastSwitch=now;
   view.cancelHold();selection.cancel();notify(path);CommunicationManager.PostServerCommand("fgeh.unified.toggle");
  }
  private function onNativeToggle():Boolean {
   var now:int=getTimer(),gap:int=now-lastNative;lastNative=now;
   if(canShortcut() && !toggleDown && gap>=750){switchPanel("key-native-F7");}
   return false;
  }
  private function onKey(event:KeyboardEvent):void {
   if(!canShortcut()){return;}
   if(!event.ctrlKey && !event.shiftKey && !event.altKey && event.keyCode==118){
    if(!toggleDown){toggleDown=true;switchPanel("key-stage-F7");}
    event.stopImmediatePropagation();event.preventDefault();
   }else if(displayed && event.keyCode==27){CommunicationManager.PostServerCommand("fgeh.unified.aligncancel");selection.cancel();
   }else if(displayed && event.ctrlKey && event.shiftKey && event.keyCode==66 && view.canChoose()){
    if(!boxDown){boxDown=true;view.cancelHold();selection.toggle();}event.stopImmediatePropagation();event.preventDefault();
   }
  }
  private function onKeyUp(event:KeyboardEvent):void {if(event.keyCode==118){toggleDown=false;lastNative=-10000;}if(event.keyCode==66){boxDown=false;}}
  private function onDeactivate(event:Event):void {toggleDown=false;boxDown=false;lastNative=-10000;if(view!=null){view.cancelHold();}}
  private function onConceal(data:Object):void {endDrag();displayed=false;removeEventListener(Event.ENTER_FRAME,onFrame);if(view!=null){view.visible=false;view.suspend();selection.suspend();}}
  private function onDisarm(data:Object):void {armed=false;toggleDown=false;boxDown=false;detachShortcut();unregisterNative();onConceal(null);}
  private function onChoose(event:Event):void {view.choose(selection.chosen);}
  private function onPivot(event:Event):void {view.pickedPivot(selection.picked);}
  private function onAlignPick(event:Event):void {view.pickedAlignment(selection.picked);}
  private function onAlignError(event:Event):void {view.hint(LabText.t("shared_1343ab9c4575"));}
  private function onPivotError(event:Event):void {view.hint(LabText.t("shared_ed40de2a64dc"));}
  private function onState(data:Object):void {
   LabText.load(data);LabText.tree(this);
   notify("state-received");
   if(view==null || !view.applyState(data)){notify("state-rejected");return;}
   if(view.token==""){notify("state-unbound");}
   restoreWindow(data);
   if(!displayed){displayed=true;view.visible=true;alignPlane();addEventListener(Event.ENTER_FRAME,onFrame);selection.shown();}
   selection.applyState(data);
   try{CommunicationManager.PostServerCommand("fgeh.unified.event","state-applied","displayed="+displayed+" view_visible="+view.visible+" widget_visible="+visible+" stage="+(stage!=null)+" bounds="+(stage==null?"none":view.getBounds(stage).toString()));}catch(error:Error){notify("state-ack-error");}
  }
  private function onAction(event:Event):void {
   if(view.action!="alignarm"){CommunicationManager.PostServerCommand("fgeh.unified.aligncancel");}
   if(view.action=="box"){if(view.canChoose()){view.cancelHold();selection.toggle();view.hint(LabText.t("shared_140a0f33d760")+selection.candidateSummary+LabText.t("shared_12a3cdc542ba"));}return;}
   if(view.action=="marks"){selection.marks();view.hint(LabText.t("shared_37ad973b1f92"));return;}
   if(view.action=="points"){view.hint(LabText.t("shared_bae1b444dac1")+selection.points());return;}
   if(view.action=="alignpick"){if(view.canChoose()){view.cancelHold();selection.alignTarget();view.hint(LabText.t("shared_ef85d422f2ce"));}return;}
   if(view.action=="ground"){view.hint(selection.ground()?LabText.t("shared_fb403b710fc0"):LabText.t("shared_eb6caef1ab74"));return;}
   selection.cancel();
   if(view.action=="close"){CommunicationManager.PostServerCommand("fgeh.unified.close");onConceal(null);return;}
   if(view.action=="refresh"){CommunicationManager.PostServerCommand("fgeh.unified.refresh");return;}
   if(view.action=="legacy"){CommunicationManager.PostServerCommand("fgeh.unified.legacy");return;}
   var outgoing:String=view.argument;
   if(view.action=="forward" || view.action=="back" || view.action=="left" || view.action=="right"){
    var direction:String=selection.cameraDirection();
    if(direction==""){view.cancelHold();view.hint(LabText.t("shared_6c47c113faf1"));try{CommunicationManager.PostServerCommand("fgeh.unified.event","camera-projection-unavailable",selection.cameraFailure);}catch(cameraError:Error){}return;}
    outgoing+="~"+direction+"~"+String(getTimer());
   }
   requestCount++;var request:String="q"+String(new Date().time)+"_"+requestCount;view.submitted(request);
   CommunicationManager.PostServerCommand("fgeh.unified.packet",encodeURIComponent(view.token+"|"+request+"|"+view.action+"|"+outgoing));
  }
  override public function Unload():void {
   endDrag();
   removeEventListener(Event.ENTER_FRAME,onFrame);
   detachShortcut();unregisterNative();removeEventListener(Event.ADDED_TO_STAGE,onStageReady);
   armed=false;toggleDown=false;boxDown=false;CommunicationManager.RemoveMessageListener("FgEHUnifiedState",onState,this);CommunicationManager.RemoveMessageListener("FgEHUnifiedDisarm",onDisarm,this);CommunicationManager.RemoveMessageListener("FgEHUnifiedConceal",onConceal,this);notify("unload");
   if(view!=null){view.removeEventListener("fgehMoveAction",onAction);view.removeEventListener("fgehMoveDrag",onDrag);view.removeEventListener("fgehUIScale",onScale);view.removeEventListener("fgehUIScaleSave",saveWindow);view.dispose();selection.removeEventListener("fgehBoxChoose",onChoose);selection.removeEventListener("fgehPivotPick",onPivot);selection.removeEventListener("fgehPivotError",onPivotError);selection.removeEventListener("fgehAlignPick",onAlignPick);selection.removeEventListener("fgehAlignError",onAlignError);selection.dispose();plane.removeChild(view);plane.removeChild(selection);view=null;selection=null;}super.Unload();
  }
  private function notify(phase:String):void {try{CommunicationManager.PostServerCommand("fgeh.unified.event",phase);}catch(error:Error){}}
 }
}
