package {
    import flash.display.Sprite;
    import flash.external.ExternalInterface;
    import flash.utils.getDefinitionByName;
    [SWF(width="350",height="500",frameRate="30",backgroundColor="#E9EDF3")]
    public class FgEHUiLabRoot extends Sprite {
        public var widget:Object;
        public function FgEHUiLabRoot() {
            super();receipt("root","P04 root constructor");
            try {
                var widgetClass:Class=getDefinitionByName("fgeh.ui.lab.LabWidget") as Class;
                widget=new widgetClass();addChild(widget as Sprite);
                receipt("constructed","P04 widget constructed");
            } catch(error:Error) {
                receipt("error",error.toString());
                throw error;
            }
        }
        private function receipt(phase:String,detail:String):void {
            if(ExternalInterface.available) {
                ExternalInterface.call("CallGameService","PostServerCommand",{
                    command:"fgeh.unified.event",commandArgs:[phase,detail]
                },false);
            }
        }
    }
}
