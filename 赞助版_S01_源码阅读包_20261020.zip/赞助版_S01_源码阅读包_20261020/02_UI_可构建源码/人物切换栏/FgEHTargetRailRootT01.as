package {
 import flash.display.Sprite;
 public class FgEHTargetRailRootT01 extends Sprite { public function FgEHTargetRailRootT01(){super();} }
}
