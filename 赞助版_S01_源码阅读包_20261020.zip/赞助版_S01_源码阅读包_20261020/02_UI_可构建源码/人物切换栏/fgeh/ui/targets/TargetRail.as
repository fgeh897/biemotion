package fgeh.ui.targets {
 import flash.display.DisplayObject;
 import flash.display.DisplayObjectContainer;
 import flash.display.Sprite;
 import flash.display.Stage;
 import flash.events.Event;
 import flash.events.MouseEvent;
 import flash.events.TimerEvent;
 import flash.geom.Rectangle;
 import flash.text.TextField;
 import flash.text.TextFormat;
 import flash.utils.Dictionary;
 import flash.utils.Timer;
 import flash.utils.getDefinitionByName;
 import flash.utils.setTimeout;
 import flash.utils.clearTimeout;

 public class TargetRail extends Sprite {
  private static var rails:Dictionary=new Dictionary(true);
  private static const PREFIX:String='__FGEH_TARGET_RAIL_T01__';
  private static const MESSAGE:String='FgEHTargetRailStateT01';
  private var comm:Object;
  private var content:DisplayObjectContainer;
  private var rows:Array=[];
  private var token:String='';
  private var selected:String='';
  private var page:int=0;
  private var counter:int=0;
  private var request:String='';
  private var status:TextField;
  private var rowLayer:Sprite=new Sprite();
  private var blocker:Sprite;
  private var timeout:Timer=new Timer(3000,1);
  private var disposed:Boolean=false;
  private var format:TextFormat;
  private var iconInfos:Object;
  private var images:Array=[];
  private var cards:Array=[];
  private var listenerHost:DisplayObjectContainer;
  private var listenerReady:Boolean=false;
  private var pendingKind:String='choose';
  private var desired:String='';
  private var retryCount:int=0;
  private var editor:Sprite;
  private var editorPage:int=0;
  private var draft:Object;
  private var editingMembers:Boolean=true;
  private var inputStage:Stage;
  private var editorActions:Dictionary=new Dictionary(true);
  private var editorPress:Boolean=false;
  private static const INPUT_EVENTS:Array=['mouseDown','mouseUp','mouseMove','click','doubleClick','mouseWheel','rightMouseDown','rightMouseUp','rightClick','middleMouseDown','middleMouseUp','middleClick'];

  public static function Show(host:DisplayObjectContainer, area:DisplayObjectContainer, data:Object):void {
   try {
    var marker:String='';
    if(data!=null && data.additional_texts!=null){
     var texts:Object=data.additional_texts;
     for(var i:int=Math.max(0,texts.length-3);i<texts.length;i++){
      var item:String=String(texts[i]);if(item.indexOf(PREFIX+'\n')==0){marker=item;break;}
     }
    }
    // Real rail content resolves its own displayed strings. Do not rewrite
    // the main dialog's entire payload just to populate this small rail.
    // No-rail views retain full resolution for shared labels on Settings.
    TargetText.load(data,marker=='');
    var rail:TargetRail=rails[host] as TargetRail;
    if(marker=='' || area==null){Hide(host);return;}
    if(rail==null || rail.disposed){rail=new TargetRail(area,host);rails[host]=rail;area.addChild(rail);}
    rail.apply(marker,data.icon_infos);
   } catch(error:Error) { /* Original detail UI stays usable if experimental rail fails. */ }
  }
  public static function Hide(host:DisplayObjectContainer):void {
   var rail:TargetRail=rails[host] as TargetRail;
   if(rail!=null){rail.dispose();if(rail.parent!=null){rail.parent.removeChild(rail);}delete rails[host];}
  }
  public function TargetRail(area:DisplayObjectContainer,widget:DisplayObjectContainer){
   super();content=area;name='fgehTargetPortraitRailT01';
   comm=getDefinitionByName('olympus.io.CommunicationManager');
   format=new TextFormat('$TextFont',12,0x347584);
   graphics.lineStyle(1,0xC6E8EB);graphics.beginFill(0xF5FCFD);graphics.drawRoundRect(0,0,214,132,14,14);graphics.endFill();
   status=label(TargetText.t("shared_2ae69dfa6a12"),8,5,160,22);button(TargetText.t("shared_a7f814c0a40d"),174,3,34,22,onEdit,this);addChild(rowLayer);rowLayer.y=28;
   addEventListener(MouseEvent.MOUSE_WHEEL,onWheel,false,10000);
   addEventListener(Event.REMOVED_FROM_STAGE,onRemoved);
   timeout.addEventListener(TimerEvent.TIMER_COMPLETE,onTimeout);
   listenerHost=widget;listenerReady=Boolean(comm.AddMessageListener(MESSAGE,onState,listenerHost));
   addEventListener(MouseEvent.CLICK,onShift,true,10000);
   // Main content uses its own local coordinate plane, not screen pixels.
   x=-470;y=166;
  }
  private function label(value:String,px:Number,py:Number,w:Number,h:Number,host:Sprite=null):TextField {
   var text:TextField=new TextField();text.embedFonts=true;text.defaultTextFormat=format;text.text=TargetText.resolve(value);text.x=px;text.y=py;text.width=w;text.height=h;text.selectable=false;text.mouseEnabled=false;
   (host==null?this:host).addChild(text);return text;
  }
  private function apply(marker:String,icons:Object):void {
   var values:Array=marker.split('\n');if(values.length<4){return;}
   if(token==String(values[1])){return;}
   finishPending();token=String(values[1]);selected=String(values[2]);rows=[];iconInfos=icons;
   for(var i:int=3;i<values.length;i++){
    var fields:Array=String(values[i]).split('\t');
    if(fields.length==4){rows.push({id:String(fields[0]),name:decodeURIComponent(String(fields[1])),iconIndex:int(fields[2]),enabled:String(fields[3])=='1'});}
   }
   page=0;var enabledIndex:int=0;for(i=0;i<rows.length;i++){if(rows[i].enabled){if(rows[i].id==selected){page=int(enabledIndex/3);break;}enabledIndex++;}}
   imageEvent('listener','registered='+listenerReady+' widget='+listenerHost.name);
   draw();
  }
  private function button(text:String,px:Number,py:Number,w:Number,h:Number,click:Function,host:Sprite):Sprite {
   var s:Sprite=new Sprite();s.x=px;s.y=py;s.graphics.lineStyle(1,0xB8E0E5);s.graphics.beginFill(0xFFFFFF);s.graphics.drawRoundRect(0,0,w,h,8,8);s.graphics.endFill();
   s.buttonMode=true;s.mouseChildren=false;label(text,3,2,w-6,h-2,s);s.addEventListener(MouseEvent.CLICK,click);if(host==editor){editorActions[s]=click;}host.addChild(s);return s;
  }
  private function draw():void {
   clearImages();
   while(rowLayer.numChildren>0){rowLayer.removeChildAt(0);}
   var active:Array=[];for each(var entry:Object in rows){if(entry.enabled){active.push(entry);}}
   page=Math.max(0,Math.min(page,Math.ceil(active.length/3)-1));
   refreshStatus();
   for(var i:int=page*3;i<Math.min(active.length,page*3+3);i++){makePerson(active[i],i-page*3);}
   if(active.length>3){
    button('‹',8,77,28,22,onPrev,rowLayer);button('›',178,77,28,22,onNext,rowLayer);
    label((page+1)+' / '+Math.ceil(active.length/3)+' · '+active.length+TargetText.t("shared_de86a2985501"),46,79,124,20,rowLayer);
   }
  }
  private function refreshStatus():void {
   var current:String=TargetText.t("shared_53e2db70167f");for each(var person:Object in rows){if(person.id==selected){current=person.name;break;}}
   status.text=request==''?TargetText.t("shared_103746334780")+current:TargetText.t("shared_2fe41fc497b1");
  }
  private function paintPerson(surface:Sprite, highlighted:Boolean, editing:Boolean):void {
   surface.graphics.clear();surface.graphics.lineStyle(highlighted?2:1,highlighted?0x20BCD3:0xC6E8EB);surface.graphics.beginFill(0xFFFFFF);surface.graphics.drawRoundRect(0,0,editing?148:62,72,10,10);surface.graphics.endFill();
  }
  private function refreshChoice():void {
   refreshStatus();
   for each(var record:Object in cards){
    if(record.surface.parent==null){continue;}
    var highlighted:Boolean=record.editing && editingMembers?Boolean(draft[record.id]):record.id==selected;
    if(record.highlighted!==highlighted){paintPerson(record.surface,highlighted,record.editing);record.highlighted=highlighted;}
    if(record.stateLabel!=null){var nextLabel:String=TargetText.resolve(record.id==selected?TargetText.t("shared_1d0382d77432"):editingMembers?(highlighted?TargetText.t("shared_f7ac2f92d428"):TargetText.t("shared_5b12db24ef25")):TargetText.t("shared_a29959b13c41"));if(record.stateLabel.text!=nextLabel){record.stateLabel.text=nextLabel;}}
   }
  }
  private function makePerson(person:Object,index:int,host:Sprite=null):void {
   host=host==null?rowLayer:host;var editing:Boolean=host!=rowLayer;
   var highlighted:Boolean=editing && editingMembers?Boolean(draft[person.id]):person.id==selected;
   var s:Sprite=new Sprite();s.x=editing?10+(index%4)*160:8+index*68;s.y=editing?42+int(index/4)*88:0;paintPerson(s,highlighted,editing);
   var placeholder:TextField=label(TargetText.t("shared_4912771a4216"),16,12,32,30,s);label(person.name,editing?62:3,editing?7:51,editing?82:56,editing?36:20,s);
   var stateLabel:TextField=null;if(editing){stateLabel=label(person.id==selected?TargetText.t("shared_1d0382d77432"):editingMembers?(highlighted?TargetText.t("shared_f7ac2f92d428"):TargetText.t("shared_5b12db24ef25")):TargetText.t("shared_a29959b13c41"),62,45,82,20,s);}
   s.buttonMode=true;s.mouseChildren=false;
   var activate:Function=function(event:MouseEvent):void {event.stopImmediatePropagation();if(editing && editingMembers){togglePerson(person.id);}else{selectPerson(person.id);}};
   s.addEventListener(MouseEvent.CLICK,activate);if(editing){editorActions[s]=activate;}
   host.addChild(s);cards.push({surface:s,section:host,id:person.id,editing:editing,stateLabel:stateLabel,highlighted:highlighted});
   try {
    if(iconInfos==null || person.iconIndex<0 || person.iconIndex>=iconInfos.length){throw new Error('native portrait IconInfo missing');}
    var imageClass:Class=getDefinitionByName('olympus.controls::ImageResource') as Class;
    var image:Object=new imageClass();var display:Sprite=image as Sprite;
    display.graphics.beginFill(0xFFFFFF,1);display.graphics.drawRect(0,0,48,48);display.graphics.endFill();display.x=7;display.y=2;s.addChild(display);
    var utils:Object=getDefinitionByName('olympus.utils::ImageUtils');
    var infoClass:Class=getDefinitionByName('olympus.objects::IconInfo') as Class;
    var info:Object=iconInfos[person.iconIndex];
    if(!(info is infoClass)){info=new infoClass(info);}
    var record:Object={image:image,display:display,section:host,poll:0,ready:null,completed:null,failed:null};
    var completed:Function=function(event:Event):void {
     if(disposed || display.stage==null){return;}
     var loaded:DisplayObject=image.GetLoadedImage() as DisplayObject;
     if(loaded!=null && loaded.width>0 && loaded.height>0){placeholder.visible=false;imageEvent('loaded','slot='+person.iconIndex+' size='+loaded.width+'x'+loaded.height);}
    };
    var failed:Function=function(event:Event):void {if(!disposed && display.stage!=null){imageEvent('failed','native thumbnail request failed');}};
    display.addEventListener('assetLoadComplete',completed,false,-100);
    display.addEventListener('assetLoadFail',failed,false,-100);
    record.completed=completed;record.failed=failed;images.push(record);
    var ready:Function=function(event:Event):void {
     display.removeEventListener(Event.ADDED_TO_STAGE,ready);
     if(disposed || display.stage==null){return;}
     try {
      image.imageRegion=new Rectangle(0,0,48,48);image.smoothing=true;
      var url:String=String(utils.CreateIconInfoImageUrl(info,'_m',false));
      var manager:String=info.icon_object==null?'none':String(info.icon_object.manager_id);
      var ident:String=info.icon_object==null?'none':String(info.icon_object.object_id);
      var accepted:Boolean=Boolean(utils.LoadFromIconInfo(image,info,'_m'));
      imageEvent(accepted?'requested':'rejected','slot='+person.iconIndex+' manager='+manager+' id='+ident+' url='+url+' stage='+Boolean(display.stage)+' region='+image.imageRegion+' resource='+image.resourceId);
      record.poll=setTimeout(function():void {
       record.poll=0;if(disposed || display.stage==null){return;}
       var result:DisplayObject=image.GetLoadedImage() as DisplayObject;
       if(result!=null && result.width>0 && result.height>0){placeholder.visible=false;}
       imageEvent('observed','slot='+person.iconIndex+' children='+display.numChildren+' loaded='+(result!=null)+' size='+(result==null?'none':result.width+'x'+result.height)+' region='+image.imageRegion+' resource='+image.resourceId);
      },1200);
     } catch(loadError:Error){imageEvent('error',loadError.toString());}
    };
    record.ready=ready;
    if(display.stage!=null){ready(null);}else{display.addEventListener(Event.ADDED_TO_STAGE,ready,false,-100);imageEvent('waiting','slot='+person.iconIndex+' waiting for stage');}
   } catch(error:Error) {imageEvent('error',error.toString());}
  }
  private function sendPacket(kind:String,value:String='',id:String='0'):void {comm.PostServerCommand('fgeh.targets.packet',encodeURIComponent(token+'|'+id+'|'+kind+'|'+value));}
  private function imageEvent(kind:String,detail:String):void {if(!disposed && token!=''){sendPacket('image',kind+'~'+encodeURIComponent(detail));}}
  private function clearImages(section:Sprite=null):void {
   var keep:Array=[];
   for each(var record:Object in images){
    if(section!=null && record.section!=section){keep.push(record);continue;}
    if(record.poll){clearTimeout(record.poll);record.poll=0;}
    record.display.removeEventListener(Event.ADDED_TO_STAGE,record.ready);
    record.display.removeEventListener('assetLoadComplete',record.completed);record.display.removeEventListener('assetLoadFail',record.failed);
    try {record.image.LoadImage(null,true);}catch(error:Error){}
   }
   images=keep;
   var keptCards:Array=[];for each(var cardRecord:Object in cards){if(section!=null && cardRecord.section!=section){keptCards.push(cardRecord);}}cards=keptCards;
  }
  private function selectPerson(id:String):void {
   if(disposed || request!='' || id==selected){return;}
   if(!listenerReady){status.text=TargetText.t("shared_82a8c7503444");return;}
   pendingKind='choose';desired=id;request=String(++counter);retryCount=0;status.text=TargetText.t("shared_9498610e6c48");
   blocker=new Sprite();var bounds:Rectangle=content.getBounds(content);
   // Leave the header close button usable even if confirmation never arrives.
   var top:Number=Math.max(bounds.y,-240);
   blocker.graphics.beginFill(0,0);blocker.graphics.drawRect(bounds.x,top,bounds.width,Math.max(0,bounds.bottom-top));blocker.graphics.endFill();content.addChild(blocker);content.setChildIndex(this,content.numChildren-1);if(editor!=null){content.setChildIndex(editor,content.numChildren-1);}
   timeout.reset();timeout.start();sendPacket('choose',id,request);
  }
  private function onState(data:Object):void {
   if(disposed){return;}
   TargetText.load(data);
   if(data==null || data.additional_texts==null){imageEvent('listener','ack_callback missing additional_texts');return;}
   var a:Object=data.additional_texts;
   imageEvent('listener','ack_callback token_match='+(String(a[0])==token)+' request_match='+(String(a[1])==request)+' fields='+a.length);
   if(a.length<5 || String(a[0])!=token || String(a[1])!=request || request==''){return;}
   var ok:Boolean=String(a[2])=='ok';if(ok){selected=String(a[3]);}
   var membershipChanged:Boolean=false;if(ok && a.length>=7){var accepted:Array=String(a[6]).split(',');for each(var row:Object in rows){var nextEnabled:Boolean=accepted.indexOf(row.id)>=0;if(row.enabled!=nextEnabled){membershipChanged=true;}row.enabled=nextEnabled;}}
   var message:String=String(a[4]);var filtered:Boolean=pendingKind=='filter';finishPending();
   if(filtered && ok){closeEditor();}else if(!membershipChanged){refreshChoice();}else{draw();if(editor!=null){drawEditor();}}if(!ok){status.text=message;}
  }
  private function finishPending():void {timeout.stop();request='';if(blocker!=null && blocker.parent!=null){blocker.parent.removeChild(blocker);}blocker=null;}
  private function onTimeout(event:TimerEvent):void {
   if(retryCount++==0){timeout.reset();timeout.start();sendPacket(pendingKind,desired,request);status.text=TargetText.t("shared_f022406269ea");return;}
   status.text=TargetText.t("shared_3a804ecd2400");
  }
  private function onPrev(event:MouseEvent):void {event.stopImmediatePropagation();page--;draw();}
  private function onNext(event:MouseEvent):void {event.stopImmediatePropagation();page++;draw();}
  private function onWheel(event:MouseEvent):void {event.stopImmediatePropagation();page+=event.delta<0?1:-1;draw();}
  private function onShift(event:MouseEvent):void {if(event.shiftKey){event.stopImmediatePropagation();openEditor(false);}}
  private function onEdit(event:MouseEvent):void {event.stopImmediatePropagation();openEditor(true);}
  private function openEditor(editing:Boolean=true):void {
   editingMembers=editing;draft={};for each(var row:Object in rows){draft[row.id]=row.enabled;}editorPage=0;
   if(editor!=null){drawEditor();return;}
   editor=new Sprite();editor.x=-220;editor.y=-220;
   editor.addEventListener(MouseEvent.CLICK,stopEditorEvent);editor.addEventListener(MouseEvent.MOUSE_DOWN,stopEditorEvent);editor.addEventListener(MouseEvent.MOUSE_UP,stopEditorEvent);
   editor.addEventListener(MouseEvent.MOUSE_WHEEL,function(event:MouseEvent):void {event.stopImmediatePropagation();editorPage+=event.delta<0?1:-1;drawEditor();});
   content.addChild(editor);bindEditorInput();drawEditor();
  }
  // Original widget uses Stage capture hit-tests (priority up to 10030).
  // Stop there before it runs, then call our action directly: redispatch would
  // traverse the same Stage listeners and recreate the underlying pose click.
  private function bindEditorInput():void {
   inputStage=content.stage;if(inputStage==null){return;}
   for each(var type:String in INPUT_EVENTS){inputStage.addEventListener(type,onEditorInput,true,30000);}
  }
  private function unbindEditorInput():void {
   if(inputStage!=null){for each(var type:String in INPUT_EVENTS){inputStage.removeEventListener(type,onEditorInput,true);}}
   inputStage=null;editorPress=false;editorActions=new Dictionary(true);
  }
  private function onEditorInput(event:MouseEvent):void {
   if(editor==null || disposed){return;}
   var inside:Boolean=editor.hitTestPoint(event.stageX,event.stageY,false);
   var held:Boolean=editorPress;
   if(event.type==MouseEvent.MOUSE_DOWN && inside){editorPress=true;}
   if(event.type==MouseEvent.MOUSE_UP){editorPress=false;}
   if(!inside && !held){return;}
   event.preventDefault();event.stopImmediatePropagation();
   if(event.type==MouseEvent.MOUSE_WHEEL && inside){editorPage+=event.delta<0?1:-1;drawEditor();return;}
   if(event.type!=MouseEvent.CLICK || !inside){return;}
   var target:DisplayObject=event.target as DisplayObject;
   while(target!=null && target!=editor){
    var action:Function=editorActions[target] as Function;
    if(action!=null){action(event);return;}
    target=target.parent;
   }
  }
  private function stopEditorEvent(event:MouseEvent):void {event.stopImmediatePropagation();}
  private function drawEditor():void {
   editorActions=new Dictionary(true);clearImages(editor);while(editor.numChildren>0){editor.removeChildAt(0);}editor.graphics.clear();editor.graphics.lineStyle(2,0x71B5C1);editor.graphics.beginFill(0xF4FCFD);editor.graphics.drawRoundRect(0,0,660,366,18,18);editor.graphics.endFill();
   label(editingMembers?TargetText.t("shared_2d00d8f28fdc"):TargetText.t("shared_2606e5518b09"),12,9,500,25,editor);
   var visibleRows:Array=[];for each(var listed:Object in rows){if(editingMembers || listed.enabled){visibleRows.push(listed);}}
   editorPage=Math.max(0,Math.min(editorPage,Math.ceil(visibleRows.length/12)-1));
   for(var i:int=editorPage*12;i<Math.min(visibleRows.length,editorPage*12+12);i++){makePerson(visibleRows[i],i-editorPage*12,editor);}
   button(TargetText.t("shared_b41561d80765"),12,322,82,30,function(e:MouseEvent):void{e.stopImmediatePropagation();editorPage--;drawEditor();},editor);
   button(TargetText.t("shared_67a246a344ae"),102,322,82,30,function(e:MouseEvent):void{e.stopImmediatePropagation();editorPage++;drawEditor();},editor);
   label((editorPage+1)+' / '+Math.ceil(visibleRows.length/12),550,10,90,24,editor);
   if(editingMembers){
    button(TargetText.t("shared_5a34ed791d57"),192,322,100,30,function(e:MouseEvent):void {e.stopImmediatePropagation();if(request!=''){return;}draft={};draft[selected]=true;refreshChoice();},editor);
    button(TargetText.t("shared_3e44b2a93338"),304,322,100,30,function(e:MouseEvent):void {e.stopImmediatePropagation();if(request!=''){return;}if(rows.length>64){status.text=TargetText.t("shared_8ad508e3dea0");return;}for each(var person:Object in rows){draft[person.id]=true;}refreshChoice();},editor);
    button(TargetText.t("shared_6751b0a1148f"),420,322,106,30,onApply,editor);
   }else{button(TargetText.t("shared_15f1faf0d5af"),420,322,106,30,onEdit,editor);}
   button(TargetText.t("shared_6c14bd7f6f9e"),538,322,106,30,onCancel,editor);
  }
  private function togglePerson(id:String):void {if(request!='' || id==selected){return;}draft[id]=!draft[id];refreshChoice();}
  private function onApply(event:MouseEvent):void {
   event.stopImmediatePropagation();if(request!=''){return;}if(!listenerReady){status.text=TargetText.t("shared_82a8c7503444");return;}
   var chosen:Array=[];for each(var row:Object in rows){if(draft[row.id]){chosen.push(row.id);}}
   if(chosen.length==0 || chosen.length>64){status.text=TargetText.t("shared_34cd6c6df33d");return;}
   pendingKind='filter';desired=chosen.join(',');request=String(++counter);retryCount=0;timeout.reset();timeout.start();sendPacket('filter',desired,request);status.text=TargetText.t("shared_8ecb76e88e53");
  }
  private function onCancel(event:MouseEvent):void {event.stopImmediatePropagation();closeEditor();}
  private function closeEditor():void {unbindEditorInput();if(editor!=null){clearImages(editor);if(editor.parent!=null){editor.parent.removeChild(editor);}}editor=null;draft=null;draw();}
  private function onRemoved(event:Event):void {dispose();}
  private function dispose():void {
   if(disposed){return;}disposed=true;unbindEditorInput();finishPending();clearImages();iconInfos=null;timeout.removeEventListener(TimerEvent.TIMER_COMPLETE,onTimeout);
   removeEventListener(MouseEvent.MOUSE_WHEEL,onWheel);removeEventListener(Event.REMOVED_FROM_STAGE,onRemoved);
   comm.RemoveMessageListener(MESSAGE,onState,listenerHost);if(token!=''){sendPacket('clear');}rows=[];
   if(editor!=null && editor.parent!=null){editor.parent.removeChild(editor);}editor=null;draft=null;listenerHost=null;
   for(var owner:Object in rails){if(rails[owner]===this){delete rails[owner];break;}}
   content=null;comm=null;
  }
 }
}
